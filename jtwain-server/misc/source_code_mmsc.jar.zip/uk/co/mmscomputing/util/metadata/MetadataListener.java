package uk.co.mmscomputing.util.metadata;

public interface MetadataListener{
  public void update(Object type, Metadata metadata);
}