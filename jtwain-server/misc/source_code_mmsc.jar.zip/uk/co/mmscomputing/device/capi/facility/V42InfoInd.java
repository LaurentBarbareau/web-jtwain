package uk.co.mmscomputing.device.capi.facility;

import uk.co.mmscomputing.device.capi.*;

public class V42InfoInd extends FacilityInd{
  public V42InfoInd(Rider r){
    super(r);
  }
}

