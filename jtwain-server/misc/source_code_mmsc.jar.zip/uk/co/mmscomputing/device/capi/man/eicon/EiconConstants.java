package uk.co.mmscomputing.device.capi.man.eicon;

public interface EiconConstants{
  static public final int CAPI_EICON_OPTIONS = 9;
}

