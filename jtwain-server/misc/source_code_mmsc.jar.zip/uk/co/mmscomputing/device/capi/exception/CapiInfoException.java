package uk.co.mmscomputing.device.capi.exception;

// NO NEED ANYMORE ?

public class CapiInfoException extends CapiIOException{

  public CapiInfoException(int errno){
    super(errno);
  }

}