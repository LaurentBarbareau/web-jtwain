package uk.co.mmscomputing.device.capi.exception;

public class CapiInformation extends CapiException{

  public CapiInformation(String info){
    super(info);
  }

}