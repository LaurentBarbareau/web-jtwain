package uk.co.mmscomputing.device.scanner;

import java.io.*;

public class ScannerIOException extends IOException{

  public ScannerIOException(String msg){
    super(msg);
  }

}