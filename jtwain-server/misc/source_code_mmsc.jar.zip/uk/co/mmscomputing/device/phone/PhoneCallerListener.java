package uk.co.mmscomputing.device.phone;

public interface PhoneCallerListener{
  public void update(PhoneCallerMetadata.Type type, PhoneCallerMetadata metadata);
}