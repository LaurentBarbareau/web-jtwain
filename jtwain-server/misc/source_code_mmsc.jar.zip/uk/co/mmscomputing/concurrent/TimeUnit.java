package uk.co.mmscomputing.concurrent;

public class TimeUnit{
  public static final TimeUnit MILLISECONDS=new TimeUnit();
}