////////////////////////////////////////////////////////////////////////////////
//	File:
//		$Archive: /main/deliverables/scantwain/sttypes.h $
//
//	Description:
/**
//		This file contains the definition of several contants and types used
//		throughout ScanTWAIN.
**/
//	History:
//		$Log: /main/deliverables/scantwain/sttypes.h $
//		
//		12    4/16/09 9:58a V737585
//		Redesigned the file format dialog and some of the underlying structures
//		to work better with the new file format scheme. Also fixed a couple of
//		warnings compiling on Debian x64 systems.
//		
//		11    4/08/09 2:18p V737585
//		PR12757: Added a dialog to allow the user to let ScanTWAIN choose the
//		file type automatically or allow the user to select the file type based
//		on the pixel type. This allows dual-stream scanning, auto color detect
//		and toggle patch to be used while still making it easy for the user and
//		giving them the same flexibility as before if they want it.
//		
//		10    5/28/08 3:31p V737585
//		Added support for the TWAIN GUI. ScanTWAIN will now try to use the
//		driver's UI before using it's own. Additionally, support for
//		transferring Group IV and JPEG compressed images has been added.
//		Additionally, the ScanSettings dialog (aka the default driver UI) has
//		been updated to add support for setting the compression.
//		
//		9     3/26/08 1:04p V737585
//		PR 11740, 11749, 11750: THIS IS A MAJOR REVISION!! We now maintain an
//		image buffer of 10 images, we will not continue to transfer images from
//		the driver while that buffer is full. Additionally, a save thread has
//		been added to save the images in a separate thread. Several new custom
//		events have been added to assist in coordinating this. Finally, the
//		display resolution of the images has been reduced to between 75-150 dpi
//		to make the display faster. NOTE: ScanTWAIN now uses considerably more
//		memory and we may have to consider moving to memory mapped files if
//		this becomes a problem on low memory systems.
//		
//		8     12/11/07 2:59p V737585
//		PR 11506: The error handling and coordination between
//		CSTTwain::XferMemory and ScanTWAIN's scan thread was overly
//		complicated, leading to errors/crashes if something went wrong while
//		scanning. This code was simplified to eliminate the problem.
//		
//		7     11/27/07 11:02a V737585
//		Added code to make ScanTWAIN, TWAIN 2.0 compliant
//		
//		6     4/10/07 4:23p V737585
//		Updated to use twain2.h instead of the older twain.h
//		
//		5     1/24/06 10:16a V737585
//		Added JPEG compression support for TIFFs and the Image Transfer event
//		constant.
//		
//		2     11/11/05 3:39p V737585
//		Added version.h to project - Initially set to version 0.1.0.0
//		
//		1     11/02/05 3:54p V737585
//		Initial Revision
//
// Copyright (c) 2005-2008 Eastman Kodak Company
//
// This file is part of ScanTWAIN
//
// ScanTWAIN is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// ScanTWAIN is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY;  without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along
// with ScanTWAIN; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
//	$NoKeywords: $
////////////////////////////////////////////////////////////////////////////////
#ifndef SCANTWAINTYPES_H
#define SCANTWAINTYPES_H

////////////////////////////////////////////////////////////////////////////////
//									INCLUDE FILES
////////////////////////////////////////////////////////////////////////////////
#include <qevent.h>
#include "twain.h"
#include "version.h"

////////////////////////////////////////////////////////////////////////////////
//						DEFINES, TYPEDEFS, CONSTS & ENUMS
////////////////////////////////////////////////////////////////////////////////
#define UISTATE_STARTUP			0
#define UISTATE_SCANNING		1
#define UISTATE_SCANNERSELECTED	2
#define UISTATE_DRIVERUIOPEN	3
#define UISTATE_DRIVERUICLOSED	4

// Indexes for TIFF Codecs
#define IDX_NONE		0
#define IDX_LZW			1
#define IDX_JPEG		2

#define IDX_CCITT3		1
#define IDX_CCITT4		2

#define IDX_TIFFFILE	0
#define IDX_PNGFILE		1
#define IDX_JPEGFILE	2

#define	STSCANISDONE	QEvent::User+1
#define STIMAGEXFER		QEvent::User+2
#define	STSTARTXFER		QEvent::User+3
#define STIMAGESAVED	QEvent::User+4
#define STIMAGEXFERFAIL	QEvent::User+5
#define STIMAGESAVEFAIL	QEvent::User+6
#define STSAVEISDONE	QEvent::User+7
#define STDISABLEDS		QEvent::User+8

#define UNUSED_ARG(x)	{x=x;}

#define FREE(addr)		if ((addr) != NULL ) { free((addr)); (addr)=NULL; }

struct STFileFormatSettings {
	bool			blAutoFromDriver;
	uint			uiColorFileFormat;
	uint            uiColorTIFFCodec;
	uint			uiGrayFileFormat;
	uint            uiGrayTIFFCodec;
	uint			uiBitonalFileFormat;
	uint            uiBitonalTIFFCodec;
	int				iGrayJPEGQuality;
	int             iColorJPEGQuality;

	STFileFormatSettings() {
		blAutoFromDriver	= true;
		uiColorFileFormat   = IDX_JPEGFILE;
		uiColorTIFFCodec    = IDX_LZW;
		uiGrayFileFormat    = IDX_JPEGFILE;
		uiGrayTIFFCodec     = IDX_LZW;
		uiBitonalFileFormat = IDX_TIFFFILE;
		uiBitonalTIFFCodec  = IDX_CCITT4;
		iGrayJPEGQuality	= 60;
		iColorJPEGQuality   = 60;
	}
};


// Call back function definition
////////////////////////////////////////////////////////////////////////
// Description:
//		This function is passed to the TWAIN DSM to handle callbacks. It
//		responds to the TWAIN MSG by sending events to ScanTWAIN's main
//		window, via postEvent. This function is defined in main.cpp.
//
//	Parameters:
//		a_pOrigin	- The origin of the callback (data source)
//		a_pDest		- The destination of the callback (application)
//		a_DG		- The TWAIN data group
//		a_DAT		- The TWAIN capability
//		a_MSG		- The TWAIN message
//		a_pData		- The
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
TW_UINT16 TWAINCallback(
						pTW_IDENTITY a_pOrigin,
						pTW_IDENTITY a_pDest,
						TW_UINT32	a_DG,
						TW_UINT16	a_DAT,
						TW_UINT16	a_MSG,
						TW_MEMREF	a_pData
					   );



#endif
