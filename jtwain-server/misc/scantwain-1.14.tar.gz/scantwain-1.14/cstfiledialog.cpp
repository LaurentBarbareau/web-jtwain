////////////////////////////////////////////////////////////////////////////////
//	File:
//		$Archive: /main/deliverables/scantwain/cstfiledialog.cpp $
//
//	Description:
//		This file contains the implementation of ScanTWAIN's "Save As" dialog.
//
//	History:
//		$Log: /main/deliverables/scantwain/cstfiledialog.cpp $
//		
//		1     11/02/05 3:41p V737585
//		Initial Revision
//
// Copyright (c) 2005 Eastman Kodak Company
//
// This file is part of ScanTWAIN
//
// ScanTWAIN is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// ScanTWAIN is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY;  without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along
// with ScanTWAIN; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
//	$NoKeywords: $
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
//									INCLUDE FILES
////////////////////////////////////////////////////////////////////////////////
#include <qlabel.h>
#include <qstring.h>
#include "cstfiledialog.h"



////////////////////////////////////////////////////////////////////////
// Description:
//		Constructor: Initializes the classes member variables
//
//	Parameters:
//		parent	- This widget's parent widget
//		name	- The widget's name (for debugging)
//		modal	- Whether or not the dialog is shown modally
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
CSTFileDialog::CSTFileDialog( QWidget* parent, const char* name, bool modal) :
	QFileDialog(parent, name, modal)
{
	qlExample = new QLabel(tr("Example: "), this);

	// Add the sample name widget under the File Types list
	addWidgets(qlExample, 0, 0);

}



////////////////////////////////////////////////////////////////////////
// Description:
//		Destructor: Destroy's the dialog
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
CSTFileDialog::~CSTFileDialog()
{
	// no need to delete child widgets, Qt does it all for us
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Sets the extension to use in the example file name
//
//	Parameters:
//		a_qsExt	- The extension to use
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTFileDialog::SetCurrentExtension(const QString &a_qsExt)
{
	qsExtension = a_qsExt;

	qlExample->setText(QString(tr("Example: ")) + "myfilename-001" + a_qsExt);
	setSelection("myfilename");
	
	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Updates the example label in the dialog
//
//	Parameters:
//		a_qsFile	- The filename to change the label to
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTFileDialog::UpdateExample(const QString &a_qsFile)
{
	QString	qsExampleFile;

	// create the example file name
	qsExampleFile = a_qsFile + QString(tr("-001")) + qsExtension;
	
	// modify the label contents to show the update
	qlExample->setText(QString(tr("Example: ")) + qsExampleFile);

	return;
}
