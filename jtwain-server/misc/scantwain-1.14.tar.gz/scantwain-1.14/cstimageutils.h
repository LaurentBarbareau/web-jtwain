////////////////////////////////////////////////////////////////////////////////
//	File:
//		$Archive: /main/deliverables/scantwain/cstimageutils.h $
//
//	Description:
/**
//		This file contains functions for manipulating images that are mostly
//		copied from other places and don't fit well anywhere else, so they were
//		put here.
 **/
//	History:
//		$Log: /main/deliverables/scantwain/cstimageutils.h $
//		
//		1     5/28/08 3:31p V737585
//		Added support for the TWAIN GUI. ScanTWAIN will now try to use the
//		driver's UI before using it's own. Additionally, support for
//		transferring Group IV and JPEG compressed images has been added.
//		Additionally, the ScanSettings dialog (aka the default driver UI) has
//		been updated to add support for setting the compression.
//
// Copyright (c) 2008-2008 Eastman Kodak Company
//
// This file is part of ScanTWAIN
//
// ScanTWAIN is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// ScanTWAIN is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY;  without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along
// with ScanTWAIN; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
//	$NoKeywords: $
////////////////////////////////////////////////////////////////////////////////
#ifndef CSTIMAGEUTILS_H
#define CSTIMAGEUTILS_H



////////////////////////////////////////////////////////////////////////////////
//						DEFINES, TYPEDEFS, CONSTS & ENUMS
////////////////////////////////////////////////////////////////////////////////
#define COMPRESS_NEGATE_BITS	0x08
#define COMPRESS_G4_2D			0x30


// Compress using CCITT Group IV
int memg4_compress
(
	int nWidth,
	int nHeight,
	unsigned char *pImageData,
	unsigned char **ppCompressedBuffer,
	int *pnCompressedBufferSize,
	int nFlags
);


// Decompress a CCITT Group IV Image
int memg4_decompress
(
	int nWidth,
	int nHeight,
	int nWidthBytes,
	unsigned char *pImageData,
	unsigned char *pCompressedBuffer,
	int nCompressedBufferSize,
	int nFlags
);

#endif
