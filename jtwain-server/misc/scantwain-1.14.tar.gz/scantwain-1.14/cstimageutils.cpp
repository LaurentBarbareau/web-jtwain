////////////////////////////////////////////////////////////////////////////////
//	File:
//		$Archive: /main/deliverables/scantwain/cstimageutils.cpp $
//
//	Description:
//		This file contains functions for manipulating images that are mostly
//		copied from other places and don't fit well anywhere else, so they were
//		put here.
//
//	History:
//		$Log: /main/deliverables/scantwain/cstimageutils.cpp $
//		
//		1     5/28/08 3:31p V737585
//		Added support for the TWAIN GUI. ScanTWAIN will now try to use the
//		driver's UI before using it's own. Additionally, support for
//		transferring Group IV and JPEG compressed images has been added.
//		Additionally, the ScanSettings dialog (aka the default driver UI) has
//		been updated to add support for setting the compression.
//
// Copyright (c) 2008-2008 Eastman Kodak Company
//
// This file is part of ScanTWAIN
//
// ScanTWAIN is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// ScanTWAIN is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY;  without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along
// with ScanTWAIN; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
//	$NoKeywords: $
////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////
//									INCLUDE FILES
////////////////////////////////////////////////////////////////////////////////
#include <string.h>
#include <sys/types.h>
#include "cstimageutils.h"



////////////////////////////////////////////////////////////////////////////////
//						DEFINES, TYPEDEFS, CONSTS & ENUMS
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
//					CCITT Group IV Compress/Decompress						  //
//	From here on down is the code for compressing and decompressing Group IV  //
//	images. It has been copied from another file that existed in a galaxy far //
//	far away, so that now one seems to know where it all came from. So pardon //
//	the seemingly one or two out of place comments and in general try and 	  //
//	avoid editing the following code. 
////////////////////////////////////////////////////////////////////////////////
/****************************************************************************
    CCITT.C
****************************************************************************/

/***********************************************************************
**
** The origin of this code isn't completely known nor documented.
**
** However, it has been "scrubbed" by the Official Institute of
** Software Archaeology - which means that it has been decoded,
** deciphered, and documented (hopefully) such that a mere mortal
** can come along and maintain it.
**
** Some recommended reading before delving into this code.
**
**	EIA Standard
**	ANSI/EIA-538-1988
**	March 2, 1988
**	Facsimile Coding Schemes and Coding Control Functions
**	for Group 4 Facsimile Equipment
**
** Available for a mere $11.00 in either paper or electronic copy.
** The electronic copy may be purchased at:
**
**	http://www.itu.int/home/index.html
**
**	Search for "T.4" and "T.6".
**
** Other items of interest:
**
**	"Compression algorithms reduce digitized images to manageable size"
**	William C. Warner
**	EDN June 21, 1990
**	pp. 203-212.
**
** And for the faint of heart:
**
**	"Construction of Minimum-Redundancy Codes With an Optimum
**	Synchronizing Property"
**	Beulah Rudner
**	IEEE Transactions on Information Theory, Vol. IT-17, No. 4, July 1971.
**	pp. 478-487.
**
** And for little bit of technical history, try:
**
**	"Optimum Run Length Codes"
**	H. Meyr, Hans G. Rosdolsky, and Thomas S. Huang
**	IEEE Transactions on Communications, COM-22, No. 6, June 1974
**	pp. 826-835.
**
** (Note: The above seems to be only available on microfilm at RIT.)
**
** And you might find the following U.S. Patents entertaining.
**
** 4,888,645 - helpful for figuring out what's going on G4 wise
**
** There's another one on table lookups that I don't have handy.
**
** There are at least 21 tables included below. 17 of those tables
** have been deciphered and code has been written to generate the
** tables. However, 6 of those tables have special entries that
** link tables and those special entries ARE NOT code generated.
** They are tagged with the word SPECIAL for ease of finding. DO
** NOT REMOVE THOSE LINES unless you know what you are doing.
***********************************************************************/


// These are some defines that are standard on Windows, the OS this code
// was designed for that it needs (so that we could preserve the original
// code as is. If you ever want to compile ScanTWAIN on Windows, you'll need
// to get rid of these.
#define STATIC	static
#define WINAPI
#undef  min
#define	min(a,b)		(((a)<=(b))?(a):(b))
#define	max(a,b)		(((a)>=(b))?(a):(b))
typedef long			LONG;
typedef	long			*PLONG;
typedef int				*PINT;
typedef	unsigned int	UINT;
typedef unsigned int	*PUINT;
typedef unsigned char	BYTE;
typedef unsigned char	*PBYTE;
typedef unsigned char	UCHAR;
typedef bool			BOOL;
typedef unsigned long	DWORD;
#ifdef TRUE
	#undef TRUE
#endif
#define	TRUE			(1)
#ifdef FALSE
	#undef FALSE
#endif
#define	FALSE			(0)
#if defined(__x86_x64__) || defined(__LP64__)
	typedef int64_t		INT_PTR;
#else
	typedef int32_t		INT_PTR;
#endif



/////////////////////////////////////////////////////////////////////////////
// ENGDISP.CPP
/////////////////////////////////////////////////////////////////////////////
/****************************************************************************
****************************************************************************/
#define CheckError2(nReturn) if ((nStatus = nReturn)){ goto Exit;}
int WINAPI LineToRunLengths(PBYTE,PINT,int,int,int);

/* Compression/decompression flags. */
#define COMPRESS_BEGINNING_EOLS     0x01
#define COMPRESS_ENDING_EOLS        0x02
#define COMPRESS_BYTE_ALIGN_LINES   0x04
#define COMPRESS_COMPRESSED_IS_LTR  0x10
#define COMPRESS_EXPANDED_IS_LTR    0x20
// The following flags are for private use only.
#define COMPRESS_DONT_DELETE_EOLS   0x800

#define COMPRESS_ALIGN_AND_END_EOL  0x06

#define MEMGRP_DISPLAY_CANTALLOC		-1
#define MEMGRP_DISPLAY_COMPRESS_BAD_DATA	-2


// CODE_WORD_BITS = the number of bits in uCodeWord that are nsed.
// CODE_WORD_SHIFT = ALWAYS 8 less than CODE_WORD_BITS. It is nsed for shifting the data and comparing.
#define CODE_WORD_BITS 32
#define CODE_WORD_SHIFT 24
#define CODE_WORD_BIT_MASK 0x80000000


/*
** The normal run length tables have entries [0..63].
**
** This is the WHITE table (or white half) of Table 2 in the EIA-538
** specification, page 11.
**
** The index is the run length as a decimal number and the value
** is a 16-bit binary value, left justified, that contains the bit
** pattern for the associated TERMINATING CODE.
*/

#if 0
STATIC int nWRunLengthToTermCode[64] = {
/*  0 */	0x3500,		/* terminating code: 0011-0101-xxxx-xxxx */
/*  1 */	0x1c00,		/* terminating code: 0001-11xx-xxxx-xxxx */
/*  2 */	0x7000,		/* terminating code: 0111-xxxx-xxxx-xxxx */
/*  3 */	0x8000,		/* terminating code: 1000-xxxx-xxxx-xxxx */
/*  4 */	0xb000,		/* terminating code: 1011-xxxx-xxxx-xxxx */
/*  5 */	0xc000,		/* terminating code: 1100-xxxx-xxxx-xxxx */
/*  6 */	0xe000,		/* terminating code: 1110-xxxx-xxxx-xxxx */
/*  7 */	0xf000,		/* terminating code: 1111-xxxx-xxxx-xxxx */
/*  8 */	0x9800,		/* terminating code: 1001-1xxx-xxxx-xxxx */
/*  9 */	0xa000,		/* terminating code: 1010-0xxx-xxxx-xxxx */
/* 10 */	0x3800,		/* terminating code: 0011-1xxx-xxxx-xxxx */
/* 11 */	0x4000,		/* terminating code: 0100-0xxx-xxxx-xxxx */
/* 12 */	0x2000,		/* terminating code: 0010-00xx-xxxx-xxxx */
/* 13 */	0x0c00,		/* terminating code: 0000-11xx-xxxx-xxxx */
/* 14 */	0xd000,		/* terminating code: 1101-00xx-xxxx-xxxx */
/* 15 */	0xd400,		/* terminating code: 1101-01xx-xxxx-xxxx */
/* 16 */	0xa800,		/* terminating code: 1010-10xx-xxxx-xxxx */
/* 17 */	0xac00,		/* terminating code: 1010-11xx-xxxx-xxxx */
/* 18 */	0x4e00,		/* terminating code: 0100-111x-xxxx-xxxx */
/* 19 */	0x1800,		/* terminating code: 0001-100x-xxxx-xxxx */
/* 20 */	0x1000,		/* terminating code: 0001-000x-xxxx-xxxx */
/* 21 */	0x2e00,		/* terminating code: 0010-111x-xxxx-xxxx */
/* 22 */	0x0600,		/* terminating code: 0000-011x-xxxx-xxxx */
/* 23 */	0x0800,		/* terminating code: 0000-100x-xxxx-xxxx */
/* 24 */	0x5000,		/* terminating code: 0101-000x-xxxx-xxxx */
/* 25 */	0x5600,		/* terminating code: 0101-011x-xxxx-xxxx */
/* 26 */	0x2600,		/* terminating code: 0010-011x-xxxx-xxxx */
/* 27 */	0x4800,		/* terminating code: 0100-100x-xxxx-xxxx */
/* 28 */	0x3000,		/* terminating code: 0011-000x-xxxx-xxxx */
/* 29 */	0x0200,		/* terminating code: 0000-0010-xxxx-xxxx */
/* 30 */	0x0300,		/* terminating code: 0000-0011-xxxx-xxxx */
/* 31 */	0x1a00,		/* terminating code: 0001-1010-xxxx-xxxx */
/* 32 */	0x1b00,		/* terminating code: 0001-1011-xxxx-xxxx */
/* 33 */	0x1200,		/* terminating code: 0001-0010-xxxx-xxxx */
/* 34 */	0x1300,		/* terminating code: 0001-0011-xxxx-xxxx */
/* 35 */	0x1400,		/* terminating code: 0001-0100-xxxx-xxxx */
/* 36 */	0x1500,		/* terminating code: 0001-0101-xxxx-xxxx */
/* 37 */	0x1600,		/* terminating code: 0001-0110-xxxx-xxxx */
/* 38 */	0x1700,		/* terminating code: 0001-0111-xxxx-xxxx */
/* 39 */	0x2800,		/* terminating code: 0010-1000-xxxx-xxxx */
/* 40 */	0x2900,		/* terminating code: 0010-1001-xxxx-xxxx */
/* 41 */	0x2a00,		/* terminating code: 0010-1010-xxxx-xxxx */
/* 42 */	0x2b00,		/* terminating code: 0010-1011-xxxx-xxxx */
/* 43 */	0x2c00,		/* terminating code: 0010-1100-xxxx-xxxx */
/* 44 */	0x2d00,		/* terminating code: 0010-1101-xxxx-xxxx */
/* 45 */	0x0400,		/* terminating code: 0000-0100-xxxx-xxxx */
/* 46 */	0x0500,		/* terminating code: 0000-0101-xxxx-xxxx */
/* 47 */	0x0a00,		/* terminating code: 0000-1010-xxxx-xxxx */
/* 48 */	0x0b00,		/* terminating code: 0000-1011-xxxx-xxxx */
/* 49 */	0x5200,		/* terminating code: 0101-0010-xxxx-xxxx */
/* 50 */	0x5300,		/* terminating code: 0101-0011-xxxx-xxxx */
/* 51 */	0x5400,		/* terminating code: 0101-0100-xxxx-xxxx */
/* 52 */	0x5500,		/* terminating code: 0101-0101-xxxx-xxxx */
/* 53 */	0x2400,		/* terminating code: 0010-0100-xxxx-xxxx */
/* 54 */	0x2500,		/* terminating code: 0010-0101-xxxx-xxxx */
/* 55 */	0x5800,		/* terminating code: 0101-1000-xxxx-xxxx */
/* 56 */	0x5900,		/* terminating code: 0101-1001-xxxx-xxxx */
/* 57 */	0x5a00,		/* terminating code: 0101-1010-xxxx-xxxx */
/* 58 */	0x5b00,		/* terminating code: 0101-1011-xxxx-xxxx */
/* 59 */	0x4a00,		/* terminating code: 0100-1010-xxxx-xxxx */
/* 60 */	0x4b00,		/* terminating code: 0100-1011-xxxx-xxxx */
/* 61 */	0x3200,		/* terminating code: 0011-0010-xxxx-xxxx */
/* 62 */	0x3300,		/* terminating code: 0011-0011-xxxx-xxxx */
/* 63 */	0x3400,		/* terminating code: 0011-0100-xxxx-xxxx */
};
#endif

/*
** There are 27 run length entries for black and white, that
** deal with run lengths above 64.
**
** Then there are 13 make up codes that are above 1792.
**
** 41 = 27 + 13. Hmmm...coincidence?
**
** The value in the array is the bit pattern (right justified) of the
** MAKE-UP CODE code that cooresponds to the associated run length.
**
** The top part [0..27] are for WHITE run length encodings.
*/

STATIC int nWRunLengthToMakeUpCodeR[41] = {

/*  0 */	0x0000,

/*  1 */	0x001b,	/* run:   64, make-up code: xxxx-xxxx-xxx1-1011 */
/*  2 */	0x0012,	/* run:  128, make-up code: xxxx-xxxx-xxx1-0010 */
/*  3 */	0x0017,	/* run:  192, make-up code: xxxx-xxxx-xx01-0111 */
/*  4 */	0x0037,	/* run:  256, make-up code: xxxx-xxxx-x011-0111 */
/*  5 */	0x0036,	/* run:  320, make-up code: xxxx-xxxx-0011-0110 */
/*  6 */	0x0037,	/* run:  384, make-up code: xxxx-xxxx-0011-0111 */
/*  7 */	0x0064,	/* run:  448, make-up code: xxxx-xxxx-0110-0100 */
/*  8 */	0x0065,	/* run:  512, make-up code: xxxx-xxxx-0110-0101 */
/*  9 */	0x0068,	/* run:  576, make-up code: xxxx-xxxx-0110-1000 */
/* 10 */	0x0067,	/* run:  640, make-up code: xxxx-xxxx-0110-0111 */
/* 11 */	0x00cc,	/* run:  704, make-up code: xxxx-xxx0-1100-1100 */
/* 12 */	0x00cd,	/* run:  768, make-up code: xxxx-xxx0-1100-1101 */
/* 13 */	0x00d2,	/* run:  832, make-up code: xxxx-xxx0-1101-0010 */
/* 14 */	0x00d3,	/* run:  896, make-up code: xxxx-xxx0-1101-0011 */
/* 15 */	0x00d4,	/* run:  960, make-up code: xxxx-xxx0-1101-0100 */
/* 16 */	0x00d5,	/* run: 1024, make-up code: xxxx-xxx0-1101-0101 */
/* 17 */	0x00d6,	/* run: 1088, make-up code: xxxx-xxx0-1101-0110 */
/* 18 */	0x00d7,	/* run: 1152, make-up code: xxxx-xxx0-1101-0111 */
/* 19 */	0x00d8,	/* run: 1216, make-up code: xxxx-xxx0-1101-1000 */
/* 20 */	0x00d9,	/* run: 1280, make-up code: xxxx-xxx0-1101-1001 */
/* 21 */	0x00da,	/* run: 1344, make-up code: xxxx-xxx0-1101-1010 */
/* 22 */	0x00db,	/* run: 1408, make-up code: xxxx-xxx0-1101-1011 */
/* 23 */	0x0098,	/* run: 1472, make-up code: xxxx-xxx0-1001-1000 */
/* 24 */	0x0099,	/* run: 1536, make-up code: xxxx-xxx0-1001-1001 */
/* 25 */	0x009a,	/* run: 1600, make-up code: xxxx-xxx0-1001-1010 */
/* 26 */	0x0018,	/* run: 1664, make-up code: xxxx-xxxx-xx01-1000 */
/* 27 */	0x009b,	/* run: 1728, make-up code: xxxx-xxx0-1001-1011 */
/* 28 */	0x0008,	/* run: 1792, make-up code: xxxx-x000-0000-1000 */

/* 29 */	0x000c,	/* run: 1856, make-up code: xxxx-x000-0000-1100 */
/* 30 */	0x000d,	/* run: 1920, make-up code: xxxx-x000-0000-1101 */
/* 31 */	0x0012,	/* run: 1984, make-up code: xxxx-0000-0001-0010 */
/* 32 */	0x0013,	/* run: 2048, make-up code: xxxx-0000-0001-0011 */
/* 33 */	0x0014,	/* run: 2112, make-up code: xxxx-0000-0001-0100 */
/* 34 */	0x0015,	/* run: 2176, make-up code: xxxx-0000-0001-0101 */
/* 35 */	0x0016,	/* run: 2240, make-up code: xxxx-0000-0001-0110 */
/* 36 */	0x0017,	/* run: 2304, make-up code: xxxx-0000-0001-0111 */
/* 37 */	0x001c,	/* run: 2368, make-up code: xxxx-0000-0001-1100 */
/* 38 */	0x001d,	/* run: 2432, make-up code: xxxx-0000-0001-1101 */
/* 39 */	0x001e,	/* run: 2496, make-up code: xxxx-0000-0001-1110 */
/* 40 */	0x001f,	/* run: 2560, make-up code: xxxx-0000-0001-1111 */
};

/*
** This table cooresponds to the one above, but holds the length
** (in BITS) of the make-up code.
**
** Again, this is the WHITE table.
**
** The value in the array is the length (in BITS) of the make-up code.
**
** The top part [0..27] are for WHITE run length encodings.
**
** The index is the run length (/ 64).
*/

STATIC int nWRunLengthToMakeUpCodeLength[41] = {

/*  0 */	0,

/*  1 */	5,	/* run:   64, make-up code: xxxx-xxxx-xxx1-1011 */
/*  2 */	5,	/* run:  128, make-up code: xxxx-xxxx-xxx1-0010 */
/*  3 */	6,	/* run:  192, make-up code: xxxx-xxxx-xx01-0111 */
/*  4 */	7,	/* run:  256, make-up code: xxxx-xxxx-x011-0111 */
/*  5 */	8,	/* run:  320, make-up code: xxxx-xxxx-0011-0110 */
/*  6 */	8,	/* run:  384, make-up code: xxxx-xxxx-0011-0111 */
/*  7 */	8,	/* run:  448, make-up code: xxxx-xxxx-0110-0100 */
/*  8 */	8,	/* run:  512, make-up code: xxxx-xxxx-0110-0101 */
/*  9 */	8,	/* run:  576, make-up code: xxxx-xxxx-0110-1000 */
/* 10 */	8,	/* run:  640, make-up code: xxxx-xxxx-0110-0111 */
/* 11 */	9,	/* run:  704, make-up code: xxxx-xxx0-1100-1100 */
/* 12 */	9,	/* run:  768, make-up code: xxxx-xxx0-1100-1101 */
/* 13 */	9,	/* run:  832, make-up code: xxxx-xxx0-1101-0010 */
/* 14 */	9,	/* run:  896, make-up code: xxxx-xxx0-1101-0011 */
/* 15 */	9,	/* run:  960, make-up code: xxxx-xxx0-1101-0100 */
/* 16 */	9,	/* run: 1024, make-up code: xxxx-xxx0-1101-0101 */
/* 17 */	9,	/* run: 1088, make-up code: xxxx-xxx0-1101-0110 */
/* 18 */	9,	/* run: 1152, make-up code: xxxx-xxx0-1101-0111 */
/* 19 */	9,	/* run: 1216, make-up code: xxxx-xxx0-1101-1000 */
/* 20 */	9,	/* run: 1280, make-up code: xxxx-xxx0-1101-1001 */
/* 21 */	9,	/* run: 1344, make-up code: xxxx-xxx0-1101-1010 */
/* 22 */	9,	/* run: 1408, make-up code: xxxx-xxx0-1101-1011 */
/* 23 */	9,	/* run: 1472, make-up code: xxxx-xxx0-1001-1000 */
/* 24 */	9,	/* run: 1536, make-up code: xxxx-xxx0-1001-1001 */
/* 25 */	9,	/* run: 1600, make-up code: xxxx-xxx0-1001-1010 */
/* 26 */	6,	/* run: 1664, make-up code: xxxx-xxxx-xx01-1000 */
/* 27 */	9,	/* run: 1728, make-up code: xxxx-xxx0-1001-1011 */

/* 28 */	11,	/* run: 1792, make-up code: xxxx-x000-0000-1000 */
/* 29 */	11,	/* run: 1856, make-up code: xxxx-x000-0000-1100 */
/* 30 */	11,	/* run: 1920, make-up code: xxxx-x000-0000-1101 */
/* 31 */	12,	/* run: 1984, make-up code: xxxx-0000-0001-0010 */
/* 32 */	12,	/* run: 2048, make-up code: xxxx-0000-0001-0011 */
/* 33 */	12,	/* run: 2112, make-up code: xxxx-0000-0001-0100 */
/* 34 */	12,	/* run: 2176, make-up code: xxxx-0000-0001-0101 */
/* 35 */	12,	/* run: 2240, make-up code: xxxx-0000-0001-0110 */
/* 36 */	12,	/* run: 2304, make-up code: xxxx-0000-0001-0111 */
/* 37 */	12,	/* run: 2368, make-up code: xxxx-0000-0001-1100 */
/* 38 */	12,	/* run: 2432, make-up code: xxxx-0000-0001-1101 */
/* 39 */	12,	/* run: 2496, make-up code: xxxx-0000-0001-1110 */
/* 40 */	12,	/* run: 2560, make-up code: xxxx-0000-0001-1111 */
};

/*
** This is the BLACK table, from the Table 3 of the EIA-538 specification,
** page 11.
**
** The index is the run length (/ 64).
**
** The value is a 16-bit word containing the bit-pattern (right justified)
** of the cooresponding MAKE-UP CODE.
*/

STATIC int nBRunLengthToMakeUpCodeR[41] = {

/*  0 */	0x0000,

/*  1 */	0x000f,	/* run:   64, make-up code: xxxx-xx00-0000-1111 */
/*  2 */	0x00c8,	/* run:  128, make-up code: xxxx-0000-1100-1000 */
/*  3 */	0x00c9,	/* run:  192, make-up code: xxxx-0000-1100-1001 */
/*  4 */	0x005b,	/* run:  256, make-up code: xxxx-0000-0101-1011 */
/*  5 */	0x0033,	/* run:  320, make-up code: xxxx-0000-0011-0011 */
/*  6 */	0x0034,	/* run:  384, make-up code: xxxx-0000-0011-0100 */
/*  7 */	0x0035,	/* run:  448, make-up code: xxxx-0000-0011-0101 */
/*  8 */	0x006c,	/* run:  512, make-up code: xxx0-0000-0110-1100 */
/*  9 */	0x006d,	/* run:  576, make-up code: xxx0-0000-0110-1101 */
/* 10 */	0x004a,	/* run:  640, make-up code: xxx0-0000-0100-1010 */
/* 11 */	0x004b,	/* run:  704, make-up code: xxx0-0000-0100-1011 */
/* 12 */	0x004c,	/* run:  768, make-up code: xxx0-0000-0100-1100 */
/* 13 */	0x004d,	/* run:  832, make-up code: xxx0-0000-0100-1101 */
/* 14 */	0x0072,	/* run:  896, make-up code: xxx0-0000-0111-0010 */
/* 15 */	0x0073,	/* run:  960, make-up code: xxx0-0000-0111-0011 */
/* 16 */	0x0074,	/* run: 1024, make-up code: xxx0-0000-0111-0100 */
/* 17 */	0x0075,	/* run: 1088, make-up code: xxx0-0000-0111-0101 */
/* 18 */	0x0076,	/* run: 1152, make-up code: xxx0-0000-0111-0110 */
/* 19 */	0x0077,	/* run: 1216, make-up code: xxx0-0000-0111-0111 */
/* 20 */	0x0052,	/* run: 1280, make-up code: xxx0-0000-0101-0010 */
/* 21 */	0x0053,	/* run: 1344, make-up code: xxx0-0000-0101-0011 */
/* 22 */	0x0054,	/* run: 1408, make-up code: xxx0-0000-0101-0100 */
/* 23 */	0x0055,	/* run: 1472, make-up code: xxx0-0000-0101-0101 */
/* 24 */	0x005a,	/* run: 1536, make-up code: xxx0-0000-0101-1010 */
/* 25 */	0x005b,	/* run: 1600, make-up code: xxx0-0000-0101-1011 */
/* 26 */	0x0064,	/* run: 1664, make-up code: xxx0-0000-0110-0100 */
/* 27 */	0x0065,	/* run: 1728, make-up code: xxx0-0000-0110-0101 */

/* 28 */	0x0008,	/* run: 1792, make-up code: xxxx-x000-0000-1000 */
/* 29 */	0x000c,	/* run: 1856, make-up code: xxxx-x000-0000-1100 */
/* 30 */	0x000d,	/* run: 1920, make-up code: xxxx-x000-0000-1101 */
/* 31 */	0x0012,	/* run: 1984, make-up code: xxxx-0000-0001-0010 */
/* 32 */	0x0013,	/* run: 2048, make-up code: xxxx-0000-0001-0011 */
/* 33 */	0x0014,	/* run: 2112, make-up code: xxxx-0000-0001-0100 */
/* 34 */	0x0015,	/* run: 2176, make-up code: xxxx-0000-0001-0101 */
/* 35 */	0x0016,	/* run: 2240, make-up code: xxxx-0000-0001-0110 */
/* 36 */	0x0017,	/* run: 2304, make-up code: xxxx-0000-0001-0111 */
/* 37 */	0x001c,	/* run: 2368, make-up code: xxxx-0000-0001-1100 */
/* 38 */	0x001d,	/* run: 2432, make-up code: xxxx-0000-0001-1101 */
/* 39 */	0x001e,	/* run: 2496, make-up code: xxxx-0000-0001-1110 */
/* 40 */	0x001f,	/* run: 2560, make-up code: xxxx-0000-0001-1111 */
};

/*
** This is the BLACK table.
**
** The index is the run length (/ 64).
**
** The value is the length (in BITS) of the MAKE-UP CODE bit pattern.
*/

STATIC int nBRunLengthToMakeUpCodeLength[41] = {

/*  0 */	0,

/*  1 */	10,	/* run:   64, make-up code: xxxx-xx00-0000-1111 */
/*  2 */	12,	/* run:  128, make-up code: xxxx-0000-1100-1000 */
/*  3 */	12,	/* run:  192, make-up code: xxxx-0000-1100-1001 */
/*  4 */	12,	/* run:  256, make-up code: xxxx-0000-0101-1011 */
/*  5 */	12,	/* run:  320, make-up code: xxxx-0000-0011-0011 */
/*  6 */	12,	/* run:  384, make-up code: xxxx-0000-0011-0100 */
/*  7 */	12,	/* run:  448, make-up code: xxxx-0000-0011-0101 */
/*  8 */	13,	/* run:  512, make-up code: xxx0-0000-0110-1100 */
/*  9 */	13,	/* run:  576, make-up code: xxx0-0000-0110-1101 */
/* 10 */	13,	/* run:  640, make-up code: xxx0-0000-0100-1010 */
/* 11 */	13,	/* run:  704, make-up code: xxx0-0000-0100-1011 */
/* 12 */	13,	/* run:  768, make-up code: xxx0-0000-0100-1100 */
/* 13 */	13,	/* run:  832, make-up code: xxx0-0000-0100-1101 */
/* 14 */	13,	/* run:  896, make-up code: xxx0-0000-0111-0010 */
/* 15 */	13,	/* run:  960, make-up code: xxx0-0000-0111-0011 */
/* 16 */	13,	/* run: 1024, make-up code: xxx0-0000-0111-0100 */
/* 17 */	13,	/* run: 1088, make-up code: xxx0-0000-0111-0101 */
/* 18 */	13,	/* run: 1152, make-up code: xxx0-0000-0111-0110 */
/* 19 */	13,	/* run: 1216, make-up code: xxx0-0000-0111-0111 */
/* 20 */	13,	/* run: 1280, make-up code: xxx0-0000-0101-0010 */
/* 21 */	13,	/* run: 1344, make-up code: xxx0-0000-0101-0011 */
/* 22 */	13,	/* run: 1408, make-up code: xxx0-0000-0101-0100 */
/* 23 */	13,	/* run: 1472, make-up code: xxx0-0000-0101-0101 */
/* 24 */	13,	/* run: 1536, make-up code: xxx0-0000-0101-1010 */
/* 25 */	13,	/* run: 1600, make-up code: xxx0-0000-0101-1011 */
/* 26 */	13,	/* run: 1664, make-up code: xxx0-0000-0110-0100 */
/* 27 */	13,	/* run: 1728, make-up code: xxx0-0000-0110-0101 */

/* 28 */	11,	/* run: 1792, make-up code: xxxx-x000-0000-1000 */
/* 29 */	11,	/* run: 1856, make-up code: xxxx-x000-0000-1100 */
/* 30 */	11,	/* run: 1920, make-up code: xxxx-x000-0000-1101 */
/* 31 */	12,	/* run: 1984, make-up code: xxxx-0000-0001-0010 */
/* 32 */	12,	/* run: 2048, make-up code: xxxx-0000-0001-0011 */
/* 33 */	12,	/* run: 2112, make-up code: xxxx-0000-0001-0100 */
/* 34 */	12,	/* run: 2176, make-up code: xxxx-0000-0001-0101 */
/* 35 */	12,	/* run: 2240, make-up code: xxxx-0000-0001-0110 */
/* 36 */	12,	/* run: 2304, make-up code: xxxx-0000-0001-0111 */
/* 37 */	12,	/* run: 2368, make-up code: xxxx-0000-0001-1100 */
/* 38 */	12,	/* run: 2432, make-up code: xxxx-0000-0001-1101 */
/* 39 */	12,	/* run: 2496, make-up code: xxxx-0000-0001-1110 */
/* 40 */	12,	/* run: 2560, make-up code: xxxx-0000-0001-1111 */
};

/*
** The table decoding continues.
**
** nWRunLengthToTermCodeR[]
**  |   |       |       |
**  |   |       |       Right justified
**  |   |       |
**  |   |       TERMINATING CODE is the array value
**  |   |
**  |   Run Length is the array index
**  |
**  WHITE runs
*/

STATIC int nWRunLengthToTermCodeR[64] = {
/*  0 */	0x0035,		/* terminating code: xxxx-xxxx-0011-0101 */
/*  1 */	0x0007,		/* terminating code: xxxx-xxxx-xx00-0111 */
/*  2 */	0x0007,		/* terminating code: xxxx-xxxx-xxxx-0111 */
/*  3 */	0x0008,		/* terminating code: xxxx-xxxx-xxxx-1000 */
/*  4 */	0x000b,		/* terminating code: xxxx-xxxx-xxxx-1011 */
/*  5 */	0x000c,		/* terminating code: xxxx-xxxx-xxxx-1100 */
/*  6 */	0x000e,		/* terminating code: xxxx-xxxx-xxxx-1110 */
/*  7 */	0x000f,		/* terminating code: xxxx-xxxx-xxxx-1111 */
/*  8 */	0x0013,		/* terminating code: xxxx-xxxx-xxx1-0011 */
/*  9 */	0x0014,		/* terminating code: xxxx-xxxx-xxx1-0100 */
/* 10 */	0x0007,		/* terminating code: xxxx-xxxx-xxx0-0111 */
/* 11 */	0x0008,		/* terminating code: xxxx-xxxx-xxx0-1000 */
/* 12 */	0x0008,		/* terminating code: xxxx-xxxx-xx00-1000 */
/* 13 */	0x0003,		/* terminating code: xxxx-xxxx-xx00-0011 */
/* 14 */	0x0034,		/* terminating code: xxxx-xxxx-xx11-0100 */
/* 15 */	0x0035,		/* terminating code: xxxx-xxxx-xx11-0101 */
/* 16 */	0x002a,		/* terminating code: xxxx-xxxx-xx10-1010 */
/* 17 */	0x002b,		/* terminating code: xxxx-xxxx-xx10-1011 */
/* 18 */	0x0027,		/* terminating code: xxxx-xxxx-x010-0111 */
/* 19 */	0x000c,		/* terminating code: xxxx-xxxx-x000-1100 */
/* 20 */	0x0008,		/* terminating code: xxxx-xxxx-x000-1000 */
/* 21 */	0x0017,		/* terminating code: xxxx-xxxx-x001-0111 */
/* 22 */	0x0003,		/* terminating code: xxxx-xxxx-x000-0011 */
/* 23 */	0x0004,		/* terminating code: xxxx-xxxx-x000-0100 */
/* 24 */	0x0028,		/* terminating code: xxxx-xxxx-x010-1000 */
/* 25 */	0x002b,		/* terminating code: xxxx-xxxx-x010-1011 */
/* 26 */	0x0013,		/* terminating code: xxxx-xxxx-x001-0011 */
/* 27 */	0x0024,		/* terminating code: xxxx-xxxx-x010-0100 */
/* 28 */	0x0018,		/* terminating code: xxxx-xxxx-x001-1000 */
/* 29 */	0x0002,		/* terminating code: xxxx-xxxx-0000-0010 */
/* 30 */	0x0003,		/* terminating code: xxxx-xxxx-0000-0011 */
/* 31 */	0x001a,		/* terminating code: xxxx-xxxx-0001-1010 */
/* 32 */	0x001b,		/* terminating code: xxxx-xxxx-0001-1011 */
/* 33 */	0x0012,		/* terminating code: xxxx-xxxx-0001-0010 */
/* 34 */	0x0013,		/* terminating code: xxxx-xxxx-0001-0011 */
/* 35 */	0x0014,		/* terminating code: xxxx-xxxx-0001-0100 */
/* 36 */	0x0015,		/* terminating code: xxxx-xxxx-0001-0101 */
/* 37 */	0x0016,		/* terminating code: xxxx-xxxx-0001-0110 */
/* 38 */	0x0017,		/* terminating code: xxxx-xxxx-0001-0111 */
/* 39 */	0x0028,		/* terminating code: xxxx-xxxx-0010-1000 */
/* 40 */	0x0029,		/* terminating code: xxxx-xxxx-0010-1001 */
/* 41 */	0x002a,		/* terminating code: xxxx-xxxx-0010-1010 */
/* 42 */	0x002b,		/* terminating code: xxxx-xxxx-0010-1011 */
/* 43 */	0x002c,		/* terminating code: xxxx-xxxx-0010-1100 */
/* 44 */	0x002d,		/* terminating code: xxxx-xxxx-0010-1101 */
/* 45 */	0x0004,		/* terminating code: xxxx-xxxx-0000-0100 */
/* 46 */	0x0005,		/* terminating code: xxxx-xxxx-0000-0101 */
/* 47 */	0x000a,		/* terminating code: xxxx-xxxx-0000-1010 */
/* 48 */	0x000b,		/* terminating code: xxxx-xxxx-0000-1011 */
/* 49 */	0x0052,		/* terminating code: xxxx-xxxx-0101-0010 */
/* 50 */	0x0053,		/* terminating code: xxxx-xxxx-0101-0011 */
/* 51 */	0x0054,		/* terminating code: xxxx-xxxx-0101-0100 */
/* 52 */	0x0055,		/* terminating code: xxxx-xxxx-0101-0101 */
/* 53 */	0x0024,		/* terminating code: xxxx-xxxx-0010-0100 */
/* 54 */	0x0025,		/* terminating code: xxxx-xxxx-0010-0101 */
/* 55 */	0x0058,		/* terminating code: xxxx-xxxx-0101-1000 */
/* 56 */	0x0059,		/* terminating code: xxxx-xxxx-0101-1001 */
/* 57 */	0x005a,		/* terminating code: xxxx-xxxx-0101-1010 */
/* 58 */	0x005b,		/* terminating code: xxxx-xxxx-0101-1011 */
/* 59 */	0x004a,		/* terminating code: xxxx-xxxx-0100-1010 */
/* 60 */	0x004b,		/* terminating code: xxxx-xxxx-0100-1011 */
/* 61 */	0x0032,		/* terminating code: xxxx-xxxx-0011-0010 */
/* 62 */	0x0033,		/* terminating code: xxxx-xxxx-0011-0011 */
/* 63 */	0x0034,		/* terminating code: xxxx-xxxx-0011-0100 */
};

/*
** The table decoding continues.
**
** nWRunLengthToTermCodeLength[]
**  |   |       |
**  |   |       |
**  |   |       |
**  |   |       TERMINATING CODE LENGTH (in bits) is the array value
**  |   |
**  |   Run Length is the array index
**  |
**  WHITE runs
*/

STATIC int nWRunLengthToTermCodeLength[64] = {
/*  0 */	8,	/* terminating code: 0011-0101-xxxx-xxxx */
/*  1 */	6,	/* terminating code: 0001-11xx-xxxx-xxxx */
/*  2 */	4,	/* terminating code: 0111-xxxx-xxxx-xxxx */
/*  3 */	4,	/* terminating code: 1000-xxxx-xxxx-xxxx */
/*  4 */	4,	/* terminating code: 1011-xxxx-xxxx-xxxx */
/*  5 */	4,	/* terminating code: 1100-xxxx-xxxx-xxxx */
/*  6 */	4,	/* terminating code: 1110-xxxx-xxxx-xxxx */
/*  7 */	4,	/* terminating code: 1111-xxxx-xxxx-xxxx */
/*  8 */	5,	/* terminating code: 1001-1xxx-xxxx-xxxx */
/*  9 */	5,	/* terminating code: 1010-0xxx-xxxx-xxxx */
/* 10 */	5,	/* terminating code: 0011-1xxx-xxxx-xxxx */
/* 11 */	5,	/* terminating code: 0100-0xxx-xxxx-xxxx */
/* 12 */	6,	/* terminating code: 0010-00xx-xxxx-xxxx */
/* 13 */	6,	/* terminating code: 0000-11xx-xxxx-xxxx */
/* 14 */	6,	/* terminating code: 1101-00xx-xxxx-xxxx */
/* 15 */	6,	/* terminating code: 1101-01xx-xxxx-xxxx */
/* 16 */	6,	/* terminating code: 1010-10xx-xxxx-xxxx */
/* 17 */	6,	/* terminating code: 1010-11xx-xxxx-xxxx */
/* 18 */	7,	/* terminating code: 0100-111x-xxxx-xxxx */
/* 19 */	7,	/* terminating code: 0001-100x-xxxx-xxxx */
/* 20 */	7,	/* terminating code: 0001-000x-xxxx-xxxx */
/* 21 */	7,	/* terminating code: 0010-111x-xxxx-xxxx */
/* 22 */	7,	/* terminating code: 0000-011x-xxxx-xxxx */
/* 23 */	7,	/* terminating code: 0000-100x-xxxx-xxxx */
/* 24 */	7,	/* terminating code: 0101-000x-xxxx-xxxx */
/* 25 */	7,	/* terminating code: 0101-011x-xxxx-xxxx */
/* 26 */	7,	/* terminating code: 0010-011x-xxxx-xxxx */
/* 27 */	7,	/* terminating code: 0100-100x-xxxx-xxxx */
/* 28 */	7,	/* terminating code: 0011-000x-xxxx-xxxx */
/* 29 */	8,	/* terminating code: 0000-0010-xxxx-xxxx */
/* 30 */	8,	/* terminating code: 0000-0011-xxxx-xxxx */
/* 31 */	8,	/* terminating code: 0001-1010-xxxx-xxxx */
/* 32 */	8,	/* terminating code: 0001-1011-xxxx-xxxx */
/* 33 */	8,	/* terminating code: 0001-0010-xxxx-xxxx */
/* 34 */	8,	/* terminating code: 0001-0011-xxxx-xxxx */
/* 35 */	8,	/* terminating code: 0001-0100-xxxx-xxxx */
/* 36 */	8,	/* terminating code: 0001-0101-xxxx-xxxx */
/* 37 */	8,	/* terminating code: 0001-0110-xxxx-xxxx */
/* 38 */	8,	/* terminating code: 0001-0111-xxxx-xxxx */
/* 39 */	8,	/* terminating code: 0010-1000-xxxx-xxxx */
/* 40 */	8,	/* terminating code: 0010-1001-xxxx-xxxx */
/* 41 */	8,	/* terminating code: 0010-1010-xxxx-xxxx */
/* 42 */	8,	/* terminating code: 0010-1011-xxxx-xxxx */
/* 43 */	8,	/* terminating code: 0010-1100-xxxx-xxxx */
/* 44 */	8,	/* terminating code: 0010-1101-xxxx-xxxx */
/* 45 */	8,	/* terminating code: 0000-0100-xxxx-xxxx */
/* 46 */	8,	/* terminating code: 0000-0101-xxxx-xxxx */
/* 47 */	8,	/* terminating code: 0000-1010-xxxx-xxxx */
/* 48 */	8,	/* terminating code: 0000-1011-xxxx-xxxx */
/* 49 */	8,	/* terminating code: 0101-0010-xxxx-xxxx */
/* 50 */	8,	/* terminating code: 0101-0011-xxxx-xxxx */
/* 51 */	8,	/* terminating code: 0101-0100-xxxx-xxxx */
/* 52 */	8,	/* terminating code: 0101-0101-xxxx-xxxx */
/* 53 */	8,	/* terminating code: 0010-0100-xxxx-xxxx */
/* 54 */	8,	/* terminating code: 0010-0101-xxxx-xxxx */
/* 55 */	8,	/* terminating code: 0101-1000-xxxx-xxxx */
/* 56 */	8,	/* terminating code: 0101-1001-xxxx-xxxx */
/* 57 */	8,	/* terminating code: 0101-1010-xxxx-xxxx */
/* 58 */	8,	/* terminating code: 0101-1011-xxxx-xxxx */
/* 59 */	8,	/* terminating code: 0100-1010-xxxx-xxxx */
/* 60 */	8,	/* terminating code: 0100-1011-xxxx-xxxx */
/* 61 */	8,	/* terminating code: 0011-0010-xxxx-xxxx */
/* 62 */	8,	/* terminating code: 0011-0011-xxxx-xxxx */
/* 63 */	8,	/* terminating code: 0011-0100-xxxx-xxxx */
};

/*
** The table decoding continues.
**
** nBRunLengthToTermCodeR[]
**  |   |       |       |
**  |   |       |       Right justified
**  |   |       |
**  |   |       TERMINATING CODE
**  |   |
**  |   Run Length is the array index
**  |
**  BLACK runs
*/

STATIC int nBRunLengthToTermCodeR[64] = {
/*  0 */	0x0037,	/* terminating code: xxxx-xx00-0011-0111 */
/*  1 */	0x0002,	/* terminating code: xxxx-xxxx-xxxx-x010 */
/*  2 */	0x0003,	/* terminating code: xxxx-xxxx-xxxx-xx11 */
/*  3 */	0x0002,	/* terminating code: xxxx-xxxx-xxxx-xx10 */
/*  4 */	0x0003,	/* terminating code: xxxx-xxxx-xxxx-x011 */
/*  5 */	0x0003,	/* terminating code: xxxx-xxxx-xxxx-0011 */
/*  6 */	0x0002,	/* terminating code: xxxx-xxxx-xxxx-0010 */
/*  7 */	0x0003,	/* terminating code: xxxx-xxxx-xxx0-0011 */
/*  8 */	0x0005,	/* terminating code: xxxx-xxxx-xx00-0101 */
/*  9 */	0x0004,	/* terminating code: xxxx-xxxx-xx00-0100 */
/* 10 */	0x0004,	/* terminating code: xxxx-xxxx-x000-0100 */
/* 11 */	0x0005,	/* terminating code: xxxx-xxxx-x000-0101 */
/* 12 */	0x0007,	/* terminating code: xxxx-xxxx-x000-0111 */
/* 13 */	0x0004,	/* terminating code: xxxx-xxxx-0000-0100 */
/* 14 */	0x0007,	/* terminating code: xxxx-xxxx-0000-0111 */
/* 15 */	0x0018,	/* terminating code: xxxx-xxx0-0001-1000 */
/* 16 */	0x0017,	/* terminating code: xxxx-xx00-0001-0111 */
/* 17 */	0x0018,	/* terminating code: xxxx-xx00-0001-1000 */
/* 18 */	0x0008,	/* terminating code: xxxx-xx00-0000-1000 */
/* 19 */	0x0067,	/* terminating code: xxxx-x000-0110-0111 */
/* 20 */	0x0068,	/* terminating code: xxxx-x000-0110-1000 */
/* 21 */	0x006c,	/* terminating code: xxxx-x000-0110-1100 */
/* 22 */	0x0037,	/* terminating code: xxxx-x000-0011-0111 */
/* 23 */	0x0028,	/* terminating code: xxxx-x000-0010-1000 */
/* 24 */	0x0017,	/* terminating code: xxxx-x000-0001-0111 */
/* 25 */	0x0018,	/* terminating code: xxxx-x000-0001-1000 */
/* 26 */	0x00ca,	/* terminating code: xxxx-0000-1100-1010 */
/* 27 */	0x00cb,	/* terminating code: xxxx-0000-1100-1011 */
/* 28 */	0x00cc,	/* terminating code: xxxx-0000-1100-1100 */
/* 29 */	0x00cd,	/* terminating code: xxxx-0000-1100-1101 */
/* 30 */	0x0068,	/* terminating code: xxxx-0000-0110-1000 */
/* 31 */	0x0069,	/* terminating code: xxxx-0000-0110-1001 */
/* 32 */	0x006a,	/* terminating code: xxxx-0000-0110-1010 */
/* 33 */	0x006b,	/* terminating code: xxxx-0000-0110-1011 */
/* 34 */	0x00d2,	/* terminating code: xxxx-0000-1101-0010 */
/* 35 */	0x00d3,	/* terminating code: xxxx-0000-1101-0011 */
/* 36 */	0x00d4,	/* terminating code: xxxx-0000-1101-0100 */
/* 37 */	0x00d5,	/* terminating code: xxxx-0000-1101-0101 */
/* 38 */	0x00d6,	/* terminating code: xxxx-0000-1101-0110 */
/* 39 */	0x00d7,	/* terminating code: xxxx-0000-1101-0111 */
/* 40 */	0x006c,	/* terminating code: xxxx-0000-0110-1100 */
/* 41 */	0x006d,	/* terminating code: xxxx-0000-0110-1101 */
/* 42 */	0x00da,	/* terminating code: xxxx-0000-1101-1010 */
/* 43 */	0x00db,	/* terminating code: xxxx-0000-1101-1011 */
/* 44 */	0x0054,	/* terminating code: xxxx-0000-0101-0100 */
/* 45 */	0x0055,	/* terminating code: xxxx-0000-0101-0101 */
/* 46 */	0x0056,	/* terminating code: xxxx-0000-0101-0110 */
/* 47 */	0x0057,	/* terminating code: xxxx-0000-0101-0111 */
/* 48 */	0x0064,	/* terminating code: xxxx-0000-0110-0100 */
/* 49 */	0x0065,	/* terminating code: xxxx-0000-0110-0101 */
/* 50 */	0x0052,	/* terminating code: xxxx-0000-0101-0010 */
/* 51 */	0x0053,	/* terminating code: xxxx-0000-0101-0011 */
/* 52 */	0x0024,	/* terminating code: xxxx-0000-0010-0100 */
/* 53 */	0x0037,	/* terminating code: xxxx-0000-0011-0111 */
/* 54 */	0x0038,	/* terminating code: xxxx-0000-0011-1000 */
/* 55 */	0x0027,	/* terminating code: xxxx-0000-0010-0111 */
/* 56 */	0x0028,	/* terminating code: xxxx-0000-0010-1000 */
/* 57 */	0x0058,	/* terminating code: xxxx-0000-0101-1000 */
/* 58 */	0x0059,	/* terminating code: xxxx-0000-0101-1001 */
/* 59 */	0x002b,	/* terminating code: xxxx-0000-0010-1011 */
/* 60 */	0x002c,	/* terminating code: xxxx-0000-0010-1100 */
/* 61 */	0x005a,	/* terminating code: xxxx-0000-0101-1010 */
/* 62 */	0x0066,	/* terminating code: xxxx-0000-0110-0110 */
/* 63 */	0x0067,	/* terminating code: xxxx-0000-0110-0111 */
};

/*
** In the EIA-538 specification, Table 2 lists the terminating
** codes or WHITE and BLACK runs. The second half of the table
** is specific to BLACK runs.
**
** The runs are in the range [0..63] - which is the index into
** this array.
**
** The length of the TERMINATING CODE (in BITS) is the value in the array.
*/

STATIC int nBRunLengthToTermCodeLength[64] = {
/*  0 */	10,	/* terminating code: 0000-1101-11xx-xxxx */
/*  1 */	3,	/* terminating code: 010x-xxxx-xxxx-xxxx */
/*  2 */	2,	/* terminating code: 11xx-xxxx-xxxx-xxxx */
/*  3 */	2,	/* terminating code: 10xx-xxxx-xxxx-xxxx */
/*  4 */	3,	/* terminating code: 011x-xxxx-xxxx-xxxx */
/*  5 */	4,	/* terminating code: 0011-xxxx-xxxx-xxxx */
/*  6 */	4,	/* terminating code: 0010-xxxx-xxxx-xxxx */
/*  7 */	5,	/* terminating code: 0001-1xxx-xxxx-xxxx */
/*  8 */	6,	/* terminating code: 0001-01xx-xxxx-xxxx */
/*  9 */	6,	/* terminating code: 0001-00xx-xxxx-xxxx */
/* 10 */	7,	/* terminating code: 0000-100x-xxxx-xxxx */
/* 11 */	7,	/* terminating code: 0000-101x-xxxx-xxxx */
/* 12 */	7,	/* terminating code: 0000-111x-xxxx-xxxx */
/* 13 */	8,	/* terminating code: 0000-0100-xxxx-xxxx */
/* 14 */	8,	/* terminating code: 0000-0111-xxxx-xxxx */
/* 15 */	9,	/* terminating code: 0000-1100-0xxx-xxxx */
/* 16 */	10,	/* terminating code: 0000-0101-11xx-xxxx */
/* 17 */	10,	/* terminating code: 0000-0110-00xx-xxxx */
/* 18 */	10,	/* terminating code: 0000-0010-00xx-xxxx */
/* 19 */	11,	/* terminating code: 0000-1100-111x-xxxx */
/* 20 */	11,	/* terminating code: 0000-1101-000x-xxxx */
/* 21 */	11,	/* terminating code: 0000-1101-100x-xxxx */
/* 22 */	11,	/* terminating code: 0000-0110-111x-xxxx */
/* 23 */	11,	/* terminating code: 0000-0101-000x-xxxx */
/* 24 */	11,	/* terminating code: 0000-0010-111x-xxxx */
/* 25 */	11,	/* terminating code: 0000-0011-000x-xxxx */
/* 26 */	12,	/* terminating code: 0000-1100-1010-xxxx */
/* 27 */	12,	/* terminating code: 0000-1100-1011-xxxx */
/* 28 */	12,	/* terminating code: 0000-1100-1100-xxxx */
/* 29 */	12,	/* terminating code: 0000-1100-1101-xxxx */
/* 30 */	12,	/* terminating code: 0000-0110-1000-xxxx */
/* 31 */	12,	/* terminating code: 0000-0110-1001-xxxx */
/* 32 */	12,	/* terminating code: 0000-0110-1010-xxxx */
/* 33 */	12,	/* terminating code: 0000-0110-1011-xxxx */
/* 34 */	12,	/* terminating code: 0000-1101-0010-xxxx */
/* 35 */	12,	/* terminating code: 0000-1101-0011-xxxx */
/* 36 */	12,	/* terminating code: 0000-1101-0100-xxxx */
/* 37 */	12,	/* terminating code: 0000-1101-0101-xxxx */
/* 38 */	12,	/* terminating code: 0000-1101-0110-xxxx */
/* 39 */	12,	/* terminating code: 0000-1101-0111-xxxx */
/* 40 */	12,	/* terminating code: 0000-0110-1100-xxxx */
/* 41 */	12,	/* terminating code: 0000-0110-1101-xxxx */
/* 42 */	12,	/* terminating code: 0000-1101-1010-xxxx */
/* 43 */	12,	/* terminating code: 0000-1101-1011-xxxx */
/* 44 */	12,	/* terminating code: 0000-0101-0100-xxxx */
/* 45 */	12,	/* terminating code: 0000-0101-0101-xxxx */
/* 46 */	12,	/* terminating code: 0000-0101-0110-xxxx */
/* 47 */	12,	/* terminating code: 0000-0101-0111-xxxx */
/* 48 */	12,	/* terminating code: 0000-0110-0100-xxxx */
/* 49 */	12,	/* terminating code: 0000-0110-0101-xxxx */
/* 50 */	12,	/* terminating code: 0000-0101-0010-xxxx */
/* 51 */	12,	/* terminating code: 0000-0101-0011-xxxx */
/* 52 */	12,	/* terminating code: 0000-0010-0100-xxxx */
/* 53 */	12,	/* terminating code: 0000-0011-0111-xxxx */
/* 54 */	12,	/* terminating code: 0000-0011-1000-xxxx */
/* 55 */	12,	/* terminating code: 0000-0010-0111-xxxx */
/* 56 */	12,	/* terminating code: 0000-0010-1000-xxxx */
/* 57 */	12,	/* terminating code: 0000-0101-1000-xxxx */
/* 58 */	12,	/* terminating code: 0000-0101-1001-xxxx */
/* 59 */	12,	/* terminating code: 0000-0010-1011-xxxx */
/* 60 */	12,	/* terminating code: 0000-0010-1100-xxxx */
/* 61 */	12,	/* terminating code: 0000-0101-1010-xxxx */
/* 62 */	12,	/* terminating code: 0000-0110-0110-xxxx */
/* 63 */	12,	/* terminating code: 0000-0110-0111-xxxx */
};

/*
** (int) is probably 32-bits, the largest value
** is 1664, so a WORD is probably fine.
**
** This table represents an 8-bit (Byte) lookup
** with an additional 0 bits. Hence, Byte 0.
**
** Any codeWords that have more than 8 bits are in some other tables.
** If a codeWord has less than 8 bits, it is padded on the right with
** 0's until it fills the byte.
*/

STATIC int nWCodeByte0ToRunLength[256] = {

/*   0 */	-4,	/* 0000-0000  - SPECIAL */
/*   1 */	-4,	/* 0000-0001  - SPECIAL */

/*   2 */	29,	/* 0000-0010, run length:   29, 0000-0010 */
/*   3 */	30,	/* 0000-0011, run length:   30, 0000-0011 */
/*   4 */	45,	/* 0000-0100, run length:   45, 0000-0100 */
/*   5 */	46,	/* 0000-0101, run length:   46, 0000-0101 */
/*   6 */	22,	/* 0000-0110, run length:   22, 0000-011x */
/*   7 */	22,	/* 0000-0111, run length:   22, 0000-011x */
/*   8 */	23,	/* 0000-1000, run length:   23, 0000-100x */
/*   9 */	23,	/* 0000-1001, run length:   23, 0000-100x */
/*  10 */	47,	/* 0000-1010, run length:   47, 0000-1010 */
/*  11 */	48,	/* 0000-1011, run length:   48, 0000-1011 */
/*  12 */	13,	/* 0000-1100, run length:   13, 0000-11xx */
/*  13 */	13,	/* 0000-1101, run length:   13, 0000-11xx */
/*  14 */	13,	/* 0000-1110, run length:   13, 0000-11xx */
/*  15 */	13,	/* 0000-1111, run length:   13, 0000-11xx */
/*  16 */	20,	/* 0001-0000, run length:   20, 0001-000x */
/*  17 */	20,	/* 0001-0001, run length:   20, 0001-000x */
/*  18 */	33,	/* 0001-0010, run length:   33, 0001-0010 */
/*  19 */	34,	/* 0001-0011, run length:   34, 0001-0011 */
/*  20 */	35,	/* 0001-0100, run length:   35, 0001-0100 */
/*  21 */	36,	/* 0001-0101, run length:   36, 0001-0101 */
/*  22 */	37,	/* 0001-0110, run length:   37, 0001-0110 */
/*  23 */	38,	/* 0001-0111, run length:   38, 0001-0111 */
/*  24 */	19,	/* 0001-1000, run length:   19, 0001-100x */
/*  25 */	19,	/* 0001-1001, run length:   19, 0001-100x */
/*  26 */	31,	/* 0001-1010, run length:   31, 0001-1010 */
/*  27 */	32,	/* 0001-1011, run length:   32, 0001-1011 */
/*  28 */	1,	/* 0001-1100, run length:    1, 0001-11xx */
/*  29 */	1,	/* 0001-1101, run length:    1, 0001-11xx */
/*  30 */	1,	/* 0001-1110, run length:    1, 0001-11xx */
/*  31 */	1,	/* 0001-1111, run length:    1, 0001-11xx */
/*  32 */	12,	/* 0010-0000, run length:   12, 0010-00xx */
/*  33 */	12,	/* 0010-0001, run length:   12, 0010-00xx */
/*  34 */	12,	/* 0010-0010, run length:   12, 0010-00xx */
/*  35 */	12,	/* 0010-0011, run length:   12, 0010-00xx */
/*  36 */	53,	/* 0010-0100, run length:   53, 0010-0100 */
/*  37 */	54,	/* 0010-0101, run length:   54, 0010-0101 */
/*  38 */	26,	/* 0010-0110, run length:   26, 0010-011x */
/*  39 */	26,	/* 0010-0111, run length:   26, 0010-011x */
/*  40 */	39,	/* 0010-1000, run length:   39, 0010-1000 */
/*  41 */	40,	/* 0010-1001, run length:   40, 0010-1001 */
/*  42 */	41,	/* 0010-1010, run length:   41, 0010-1010 */
/*  43 */	42,	/* 0010-1011, run length:   42, 0010-1011 */
/*  44 */	43,	/* 0010-1100, run length:   43, 0010-1100 */
/*  45 */	44,	/* 0010-1101, run length:   44, 0010-1101 */
/*  46 */	21,	/* 0010-1110, run length:   21, 0010-111x */
/*  47 */	21,	/* 0010-1111, run length:   21, 0010-111x */
/*  48 */	28,	/* 0011-0000, run length:   28, 0011-000x */
/*  49 */	28,	/* 0011-0001, run length:   28, 0011-000x */
/*  50 */	61,	/* 0011-0010, run length:   61, 0011-0010 */
/*  51 */	62,	/* 0011-0011, run length:   62, 0011-0011 */
/*  52 */	63,	/* 0011-0100, run length:   63, 0011-0100 */
/*  53 */	0,	/* 0011-0101, run length:    0, 0011-0101 */
/*  54 */	320,	/* 0011-0110, run length:  320, 0011-0110 */
/*  55 */	384,	/* 0011-0111, run length:  384, 0011-0111 */
/*  56 */	10,	/* 0011-1000, run length:   10, 0011-1xxx */
/*  57 */	10,	/* 0011-1001, run length:   10, 0011-1xxx */
/*  58 */	10,	/* 0011-1010, run length:   10, 0011-1xxx */
/*  59 */	10,	/* 0011-1011, run length:   10, 0011-1xxx */
/*  60 */	10,	/* 0011-1100, run length:   10, 0011-1xxx */
/*  61 */	10,	/* 0011-1101, run length:   10, 0011-1xxx */
/*  62 */	10,	/* 0011-1110, run length:   10, 0011-1xxx */
/*  63 */	10,	/* 0011-1111, run length:   10, 0011-1xxx */
/*  64 */	11,	/* 0100-0000, run length:   11, 0100-0xxx */
/*  65 */	11,	/* 0100-0001, run length:   11, 0100-0xxx */
/*  66 */	11,	/* 0100-0010, run length:   11, 0100-0xxx */
/*  67 */	11,	/* 0100-0011, run length:   11, 0100-0xxx */
/*  68 */	11,	/* 0100-0100, run length:   11, 0100-0xxx */
/*  69 */	11,	/* 0100-0101, run length:   11, 0100-0xxx */
/*  70 */	11,	/* 0100-0110, run length:   11, 0100-0xxx */
/*  71 */	11,	/* 0100-0111, run length:   11, 0100-0xxx */
/*  72 */	27,	/* 0100-1000, run length:   27, 0100-100x */
/*  73 */	27,	/* 0100-1001, run length:   27, 0100-100x */
/*  74 */	59,	/* 0100-1010, run length:   59, 0100-1010 */
/*  75 */	60,	/* 0100-1011, run length:   60, 0100-1011 */
/*  76 */	-1,	/* 0100-1100 */
/*  77 */	-1,	/* 0100-1101 */
/*  78 */	18,	/* 0100-1110, run length:   18, 0100-111x */
/*  79 */	18,	/* 0100-1111, run length:   18, 0100-111x */
/*  80 */	24,	/* 0101-0000, run length:   24, 0101-000x */
/*  81 */	24,	/* 0101-0001, run length:   24, 0101-000x */
/*  82 */	49,	/* 0101-0010, run length:   49, 0101-0010 */
/*  83 */	50,	/* 0101-0011, run length:   50, 0101-0011 */
/*  84 */	51,	/* 0101-0100, run length:   51, 0101-0100 */
/*  85 */	52,	/* 0101-0101, run length:   52, 0101-0101 */
/*  86 */	25,	/* 0101-0110, run length:   25, 0101-011x */
/*  87 */	25,	/* 0101-0111, run length:   25, 0101-011x */
/*  88 */	55,	/* 0101-1000, run length:   55, 0101-1000 */
/*  89 */	56,	/* 0101-1001, run length:   56, 0101-1001 */
/*  90 */	57,	/* 0101-1010, run length:   57, 0101-1010 */
/*  91 */	58,	/* 0101-1011, run length:   58, 0101-1011 */
/*  92 */	192,	/* 0101-1100, run length:  192, 0101-11xx */
/*  93 */	192,	/* 0101-1101, run length:  192, 0101-11xx */
/*  94 */	192,	/* 0101-1110, run length:  192, 0101-11xx */
/*  95 */	192,	/* 0101-1111, run length:  192, 0101-11xx */
/*  96 */	1664,	/* 0110-0000, run length: 1664, 0110-00xx */
/*  97 */	1664,	/* 0110-0001, run length: 1664, 0110-00xx */
/*  98 */	1664,	/* 0110-0010, run length: 1664, 0110-00xx */
/*  99 */	1664,	/* 0110-0011, run length: 1664, 0110-00xx */
/* 100 */	448,	/* 0110-0100, run length:  448, 0110-0100 */
/* 101 */	512,	/* 0110-0101, run length:  512, 0110-0101 */
/* 102 */	-1,	/* 0110-0110 */
/* 103 */	640,	/* 0110-0111, run length:  640, 0110-0111 */
/* 104 */	576,	/* 0110-1000, run length:  576, 0110-1000 */
/* 105 */	-1,	/* 0110-1001 */
/* 106 */	-1,	/* 0110-1010 */
/* 107 */	-1,	/* 0110-1011 */
/* 108 */	-1,	/* 0110-1100 */
/* 109 */	-1,	/* 0110-1101 */
/* 110 */	256,	/* 0110-1110, run length:  256, 0110-111x */
/* 111 */	256,	/* 0110-1111, run length:  256, 0110-111x */
/* 112 */	2,	/* 0111-0000, run length:    2, 0111-xxxx */
/* 113 */	2,	/* 0111-0001, run length:    2, 0111-xxxx */
/* 114 */	2,	/* 0111-0010, run length:    2, 0111-xxxx */
/* 115 */	2,	/* 0111-0011, run length:    2, 0111-xxxx */
/* 116 */	2,	/* 0111-0100, run length:    2, 0111-xxxx */
/* 117 */	2,	/* 0111-0101, run length:    2, 0111-xxxx */
/* 118 */	2,	/* 0111-0110, run length:    2, 0111-xxxx */
/* 119 */	2,	/* 0111-0111, run length:    2, 0111-xxxx */
/* 120 */	2,	/* 0111-1000, run length:    2, 0111-xxxx */
/* 121 */	2,	/* 0111-1001, run length:    2, 0111-xxxx */
/* 122 */	2,	/* 0111-1010, run length:    2, 0111-xxxx */
/* 123 */	2,	/* 0111-1011, run length:    2, 0111-xxxx */
/* 124 */	2,	/* 0111-1100, run length:    2, 0111-xxxx */
/* 125 */	2,	/* 0111-1101, run length:    2, 0111-xxxx */
/* 126 */	2,	/* 0111-1110, run length:    2, 0111-xxxx */
/* 127 */	2,	/* 0111-1111, run length:    2, 0111-xxxx */
/* 128 */	3,	/* 1000-0000, run length:    3, 1000-xxxx */
/* 129 */	3,	/* 1000-0001, run length:    3, 1000-xxxx */
/* 130 */	3,	/* 1000-0010, run length:    3, 1000-xxxx */
/* 131 */	3,	/* 1000-0011, run length:    3, 1000-xxxx */
/* 132 */	3,	/* 1000-0100, run length:    3, 1000-xxxx */
/* 133 */	3,	/* 1000-0101, run length:    3, 1000-xxxx */
/* 134 */	3,	/* 1000-0110, run length:    3, 1000-xxxx */
/* 135 */	3,	/* 1000-0111, run length:    3, 1000-xxxx */
/* 136 */	3,	/* 1000-1000, run length:    3, 1000-xxxx */
/* 137 */	3,	/* 1000-1001, run length:    3, 1000-xxxx */
/* 138 */	3,	/* 1000-1010, run length:    3, 1000-xxxx */
/* 139 */	3,	/* 1000-1011, run length:    3, 1000-xxxx */
/* 140 */	3,	/* 1000-1100, run length:    3, 1000-xxxx */
/* 141 */	3,	/* 1000-1101, run length:    3, 1000-xxxx */
/* 142 */	3,	/* 1000-1110, run length:    3, 1000-xxxx */
/* 143 */	3,	/* 1000-1111, run length:    3, 1000-xxxx */
/* 144 */	128,	/* 1001-0000, run length:  128, 1001-0xxx */
/* 145 */	128,	/* 1001-0001, run length:  128, 1001-0xxx */
/* 146 */	128,	/* 1001-0010, run length:  128, 1001-0xxx */
/* 147 */	128,	/* 1001-0011, run length:  128, 1001-0xxx */
/* 148 */	128,	/* 1001-0100, run length:  128, 1001-0xxx */
/* 149 */	128,	/* 1001-0101, run length:  128, 1001-0xxx */
/* 150 */	128,	/* 1001-0110, run length:  128, 1001-0xxx */
/* 151 */	128,	/* 1001-0111, run length:  128, 1001-0xxx */
/* 152 */	8,	/* 1001-1000, run length:    8, 1001-1xxx */
/* 153 */	8,	/* 1001-1001, run length:    8, 1001-1xxx */
/* 154 */	8,	/* 1001-1010, run length:    8, 1001-1xxx */
/* 155 */	8,	/* 1001-1011, run length:    8, 1001-1xxx */
/* 156 */	8,	/* 1001-1100, run length:    8, 1001-1xxx */
/* 157 */	8,	/* 1001-1101, run length:    8, 1001-1xxx */
/* 158 */	8,	/* 1001-1110, run length:    8, 1001-1xxx */
/* 159 */	8,	/* 1001-1111, run length:    8, 1001-1xxx */
/* 160 */	9,	/* 1010-0000, run length:    9, 1010-0xxx */
/* 161 */	9,	/* 1010-0001, run length:    9, 1010-0xxx */
/* 162 */	9,	/* 1010-0010, run length:    9, 1010-0xxx */
/* 163 */	9,	/* 1010-0011, run length:    9, 1010-0xxx */
/* 164 */	9,	/* 1010-0100, run length:    9, 1010-0xxx */
/* 165 */	9,	/* 1010-0101, run length:    9, 1010-0xxx */
/* 166 */	9,	/* 1010-0110, run length:    9, 1010-0xxx */
/* 167 */	9,	/* 1010-0111, run length:    9, 1010-0xxx */
/* 168 */	16,	/* 1010-1000, run length:   16, 1010-10xx */
/* 169 */	16,	/* 1010-1001, run length:   16, 1010-10xx */
/* 170 */	16,	/* 1010-1010, run length:   16, 1010-10xx */
/* 171 */	16,	/* 1010-1011, run length:   16, 1010-10xx */
/* 172 */	17,	/* 1010-1100, run length:   17, 1010-11xx */
/* 173 */	17,	/* 1010-1101, run length:   17, 1010-11xx */
/* 174 */	17,	/* 1010-1110, run length:   17, 1010-11xx */
/* 175 */	17,	/* 1010-1111, run length:   17, 1010-11xx */
/* 176 */	4,	/* 1011-0000, run length:    4, 1011-xxxx */
/* 177 */	4,	/* 1011-0001, run length:    4, 1011-xxxx */
/* 178 */	4,	/* 1011-0010, run length:    4, 1011-xxxx */
/* 179 */	4,	/* 1011-0011, run length:    4, 1011-xxxx */
/* 180 */	4,	/* 1011-0100, run length:    4, 1011-xxxx */
/* 181 */	4,	/* 1011-0101, run length:    4, 1011-xxxx */
/* 182 */	4,	/* 1011-0110, run length:    4, 1011-xxxx */
/* 183 */	4,	/* 1011-0111, run length:    4, 1011-xxxx */
/* 184 */	4,	/* 1011-1000, run length:    4, 1011-xxxx */
/* 185 */	4,	/* 1011-1001, run length:    4, 1011-xxxx */
/* 186 */	4,	/* 1011-1010, run length:    4, 1011-xxxx */
/* 187 */	4,	/* 1011-1011, run length:    4, 1011-xxxx */
/* 188 */	4,	/* 1011-1100, run length:    4, 1011-xxxx */
/* 189 */	4,	/* 1011-1101, run length:    4, 1011-xxxx */
/* 190 */	4,	/* 1011-1110, run length:    4, 1011-xxxx */
/* 191 */	4,	/* 1011-1111, run length:    4, 1011-xxxx */
/* 192 */	5,	/* 1100-0000, run length:    5, 1100-xxxx */
/* 193 */	5,	/* 1100-0001, run length:    5, 1100-xxxx */
/* 194 */	5,	/* 1100-0010, run length:    5, 1100-xxxx */
/* 195 */	5,	/* 1100-0011, run length:    5, 1100-xxxx */
/* 196 */	5,	/* 1100-0100, run length:    5, 1100-xxxx */
/* 197 */	5,	/* 1100-0101, run length:    5, 1100-xxxx */
/* 198 */	5,	/* 1100-0110, run length:    5, 1100-xxxx */
/* 199 */	5,	/* 1100-0111, run length:    5, 1100-xxxx */
/* 200 */	5,	/* 1100-1000, run length:    5, 1100-xxxx */
/* 201 */	5,	/* 1100-1001, run length:    5, 1100-xxxx */
/* 202 */	5,	/* 1100-1010, run length:    5, 1100-xxxx */
/* 203 */	5,	/* 1100-1011, run length:    5, 1100-xxxx */
/* 204 */	5,	/* 1100-1100, run length:    5, 1100-xxxx */
/* 205 */	5,	/* 1100-1101, run length:    5, 1100-xxxx */
/* 206 */	5,	/* 1100-1110, run length:    5, 1100-xxxx */
/* 207 */	5,	/* 1100-1111, run length:    5, 1100-xxxx */
/* 208 */	14,	/* 1101-0000, run length:   14, 1101-00xx */
/* 209 */	14,	/* 1101-0001, run length:   14, 1101-00xx */
/* 210 */	14,	/* 1101-0010, run length:   14, 1101-00xx */
/* 211 */	14,	/* 1101-0011, run length:   14, 1101-00xx */
/* 212 */	15,	/* 1101-0100, run length:   15, 1101-01xx */
/* 213 */	15,	/* 1101-0101, run length:   15, 1101-01xx */
/* 214 */	15,	/* 1101-0110, run length:   15, 1101-01xx */
/* 215 */	15,	/* 1101-0111, run length:   15, 1101-01xx */
/* 216 */	64,	/* 1101-1000, run length:   64, 1101-1xxx */
/* 217 */	64,	/* 1101-1001, run length:   64, 1101-1xxx */
/* 218 */	64,	/* 1101-1010, run length:   64, 1101-1xxx */
/* 219 */	64,	/* 1101-1011, run length:   64, 1101-1xxx */
/* 220 */	64,	/* 1101-1100, run length:   64, 1101-1xxx */
/* 221 */	64,	/* 1101-1101, run length:   64, 1101-1xxx */
/* 222 */	64,	/* 1101-1110, run length:   64, 1101-1xxx */
/* 223 */	64,	/* 1101-1111, run length:   64, 1101-1xxx */
/* 224 */	6,	/* 1110-0000, run length:    6, 1110-xxxx */
/* 225 */	6,	/* 1110-0001, run length:    6, 1110-xxxx */
/* 226 */	6,	/* 1110-0010, run length:    6, 1110-xxxx */
/* 227 */	6,	/* 1110-0011, run length:    6, 1110-xxxx */
/* 228 */	6,	/* 1110-0100, run length:    6, 1110-xxxx */
/* 229 */	6,	/* 1110-0101, run length:    6, 1110-xxxx */
/* 230 */	6,	/* 1110-0110, run length:    6, 1110-xxxx */
/* 231 */	6,	/* 1110-0111, run length:    6, 1110-xxxx */
/* 232 */	6,	/* 1110-1000, run length:    6, 1110-xxxx */
/* 233 */	6,	/* 1110-1001, run length:    6, 1110-xxxx */
/* 234 */	6,	/* 1110-1010, run length:    6, 1110-xxxx */
/* 235 */	6,	/* 1110-1011, run length:    6, 1110-xxxx */
/* 236 */	6,	/* 1110-1100, run length:    6, 1110-xxxx */
/* 237 */	6,	/* 1110-1101, run length:    6, 1110-xxxx */
/* 238 */	6,	/* 1110-1110, run length:    6, 1110-xxxx */
/* 239 */	6,	/* 1110-1111, run length:    6, 1110-xxxx */
/* 240 */	7,	/* 1111-0000, run length:    7, 1111-xxxx */
/* 241 */	7,	/* 1111-0001, run length:    7, 1111-xxxx */
/* 242 */	7,	/* 1111-0010, run length:    7, 1111-xxxx */
/* 243 */	7,	/* 1111-0011, run length:    7, 1111-xxxx */
/* 244 */	7,	/* 1111-0100, run length:    7, 1111-xxxx */
/* 245 */	7,	/* 1111-0101, run length:    7, 1111-xxxx */
/* 246 */	7,	/* 1111-0110, run length:    7, 1111-xxxx */
/* 247 */	7,	/* 1111-0111, run length:    7, 1111-xxxx */
/* 248 */	7,	/* 1111-1000, run length:    7, 1111-xxxx */
/* 249 */	7,	/* 1111-1001, run length:    7, 1111-xxxx */
/* 250 */	7,	/* 1111-1010, run length:    7, 1111-xxxx */
/* 251 */	7,	/* 1111-1011, run length:    7, 1111-xxxx */
/* 252 */	7,	/* 1111-1100, run length:    7, 1111-xxxx */
/* 253 */	7,	/* 1111-1101, run length:    7, 1111-xxxx */
/* 254 */	7,	/* 1111-1110, run length:    7, 1111-xxxx */
/* 255 */	7,	/* 1111-1111, run length:    7, 1111-xxxx */
};

/*
** int is probably 32-bits, the largest value
** is 8, so a BYTE is probably fine.
*/

STATIC BYTE nWCodeByte0ToCodeWordLength[256] = {

/*   0 */	4,	/* 0000-0000 - SPECIAL */
/*   1 */	4,	/* 0000-0001 - SPECIAL */

/*   2 */	8, 	/* 0000-0010, run length:   29, 0000-0010 */
/*   3 */	8, 	/* 0000-0011, run length:   30, 0000-0011 */
/*   4 */	8, 	/* 0000-0100, run length:   45, 0000-0100 */
/*   5 */	8, 	/* 0000-0101, run length:   46, 0000-0101 */
/*   6 */	7, 	/* 0000-0110, run length:   22, 0000-011x */
/*   7 */	7, 	/* 0000-0111, run length:   22, 0000-011x */
/*   8 */	7, 	/* 0000-1000, run length:   23, 0000-100x */
/*   9 */	7, 	/* 0000-1001, run length:   23, 0000-100x */
/*  10 */	8, 	/* 0000-1010, run length:   47, 0000-1010 */
/*  11 */	8, 	/* 0000-1011, run length:   48, 0000-1011 */
/*  12 */	6, 	/* 0000-1100, run length:   13, 0000-11xx */
/*  13 */	6, 	/* 0000-1101, run length:   13, 0000-11xx */
/*  14 */	6, 	/* 0000-1110, run length:   13, 0000-11xx */
/*  15 */	6, 	/* 0000-1111, run length:   13, 0000-11xx */
/*  16 */	7, 	/* 0001-0000, run length:   20, 0001-000x */
/*  17 */	7, 	/* 0001-0001, run length:   20, 0001-000x */
/*  18 */	8, 	/* 0001-0010, run length:   33, 0001-0010 */
/*  19 */	8, 	/* 0001-0011, run length:   34, 0001-0011 */
/*  20 */	8, 	/* 0001-0100, run length:   35, 0001-0100 */
/*  21 */	8, 	/* 0001-0101, run length:   36, 0001-0101 */
/*  22 */	8, 	/* 0001-0110, run length:   37, 0001-0110 */
/*  23 */	8, 	/* 0001-0111, run length:   38, 0001-0111 */
/*  24 */	7, 	/* 0001-1000, run length:   19, 0001-100x */
/*  25 */	7, 	/* 0001-1001, run length:   19, 0001-100x */
/*  26 */	8, 	/* 0001-1010, run length:   31, 0001-1010 */
/*  27 */	8, 	/* 0001-1011, run length:   32, 0001-1011 */
/*  28 */	6, 	/* 0001-1100, run length:    1, 0001-11xx */
/*  29 */	6, 	/* 0001-1101, run length:    1, 0001-11xx */
/*  30 */	6, 	/* 0001-1110, run length:    1, 0001-11xx */
/*  31 */	6, 	/* 0001-1111, run length:    1, 0001-11xx */
/*  32 */	6, 	/* 0010-0000, run length:   12, 0010-00xx */
/*  33 */	6, 	/* 0010-0001, run length:   12, 0010-00xx */
/*  34 */	6, 	/* 0010-0010, run length:   12, 0010-00xx */
/*  35 */	6, 	/* 0010-0011, run length:   12, 0010-00xx */
/*  36 */	8, 	/* 0010-0100, run length:   53, 0010-0100 */
/*  37 */	8, 	/* 0010-0101, run length:   54, 0010-0101 */
/*  38 */	7, 	/* 0010-0110, run length:   26, 0010-011x */
/*  39 */	7, 	/* 0010-0111, run length:   26, 0010-011x */
/*  40 */	8, 	/* 0010-1000, run length:   39, 0010-1000 */
/*  41 */	8, 	/* 0010-1001, run length:   40, 0010-1001 */
/*  42 */	8, 	/* 0010-1010, run length:   41, 0010-1010 */
/*  43 */	8, 	/* 0010-1011, run length:   42, 0010-1011 */
/*  44 */	8, 	/* 0010-1100, run length:   43, 0010-1100 */
/*  45 */	8, 	/* 0010-1101, run length:   44, 0010-1101 */
/*  46 */	7, 	/* 0010-1110, run length:   21, 0010-111x */
/*  47 */	7, 	/* 0010-1111, run length:   21, 0010-111x */
/*  48 */	7, 	/* 0011-0000, run length:   28, 0011-000x */
/*  49 */	7, 	/* 0011-0001, run length:   28, 0011-000x */
/*  50 */	8, 	/* 0011-0010, run length:   61, 0011-0010 */
/*  51 */	8, 	/* 0011-0011, run length:   62, 0011-0011 */
/*  52 */	8, 	/* 0011-0100, run length:   63, 0011-0100 */
/*  53 */	8, 	/* 0011-0101, run length:    0, 0011-0101 */
/*  54 */	8, 	/* 0011-0110, run length:  320, 0011-0110 */
/*  55 */	8, 	/* 0011-0111, run length:  384, 0011-0111 */
/*  56 */	5, 	/* 0011-1000, run length:   10, 0011-1xxx */
/*  57 */	5, 	/* 0011-1001, run length:   10, 0011-1xxx */
/*  58 */	5, 	/* 0011-1010, run length:   10, 0011-1xxx */
/*  59 */	5, 	/* 0011-1011, run length:   10, 0011-1xxx */
/*  60 */	5, 	/* 0011-1100, run length:   10, 0011-1xxx */
/*  61 */	5, 	/* 0011-1101, run length:   10, 0011-1xxx */
/*  62 */	5, 	/* 0011-1110, run length:   10, 0011-1xxx */
/*  63 */	5, 	/* 0011-1111, run length:   10, 0011-1xxx */
/*  64 */	5, 	/* 0100-0000, run length:   11, 0100-0xxx */
/*  65 */	5, 	/* 0100-0001, run length:   11, 0100-0xxx */
/*  66 */	5, 	/* 0100-0010, run length:   11, 0100-0xxx */
/*  67 */	5, 	/* 0100-0011, run length:   11, 0100-0xxx */
/*  68 */	5, 	/* 0100-0100, run length:   11, 0100-0xxx */
/*  69 */	5, 	/* 0100-0101, run length:   11, 0100-0xxx */
/*  70 */	5, 	/* 0100-0110, run length:   11, 0100-0xxx */
/*  71 */	5, 	/* 0100-0111, run length:   11, 0100-0xxx */
/*  72 */	7, 	/* 0100-1000, run length:   27, 0100-100x */
/*  73 */	7, 	/* 0100-1001, run length:   27, 0100-100x */
/*  74 */	8, 	/* 0100-1010, run length:   59, 0100-1010 */
/*  75 */	8, 	/* 0100-1011, run length:   60, 0100-1011 */
/*  76 */	1, 	/* 0100-1100 */
/*  77 */	1, 	/* 0100-1101 */
/*  78 */	7, 	/* 0100-1110, run length:   18, 0100-111x */
/*  79 */	7, 	/* 0100-1111, run length:   18, 0100-111x */
/*  80 */	7, 	/* 0101-0000, run length:   24, 0101-000x */
/*  81 */	7, 	/* 0101-0001, run length:   24, 0101-000x */
/*  82 */	8, 	/* 0101-0010, run length:   49, 0101-0010 */
/*  83 */	8, 	/* 0101-0011, run length:   50, 0101-0011 */
/*  84 */	8, 	/* 0101-0100, run length:   51, 0101-0100 */
/*  85 */	8, 	/* 0101-0101, run length:   52, 0101-0101 */
/*  86 */	7, 	/* 0101-0110, run length:   25, 0101-011x */
/*  87 */	7, 	/* 0101-0111, run length:   25, 0101-011x */
/*  88 */	8, 	/* 0101-1000, run length:   55, 0101-1000 */
/*  89 */	8, 	/* 0101-1001, run length:   56, 0101-1001 */
/*  90 */	8, 	/* 0101-1010, run length:   57, 0101-1010 */
/*  91 */	8, 	/* 0101-1011, run length:   58, 0101-1011 */
/*  92 */	6, 	/* 0101-1100, run length:  192, 0101-11xx */
/*  93 */	6, 	/* 0101-1101, run length:  192, 0101-11xx */
/*  94 */	6, 	/* 0101-1110, run length:  192, 0101-11xx */
/*  95 */	6, 	/* 0101-1111, run length:  192, 0101-11xx */
/*  96 */	6, 	/* 0110-0000, run length: 1664, 0110-00xx */
/*  97 */	6, 	/* 0110-0001, run length: 1664, 0110-00xx */
/*  98 */	6, 	/* 0110-0010, run length: 1664, 0110-00xx */
/*  99 */	6, 	/* 0110-0011, run length: 1664, 0110-00xx */
/* 100 */	8, 	/* 0110-0100, run length:  448, 0110-0100 */
/* 101 */	8, 	/* 0110-0101, run length:  512, 0110-0101 */
/* 102 */	1, 	/* 0110-0110 */
/* 103 */	8, 	/* 0110-0111, run length:  640, 0110-0111 */
/* 104 */	8, 	/* 0110-1000, run length:  576, 0110-1000 */
/* 105 */	1, 	/* 0110-1001 */
/* 106 */	1, 	/* 0110-1010 */
/* 107 */	1, 	/* 0110-1011 */
/* 108 */	1, 	/* 0110-1100 */
/* 109 */	1, 	/* 0110-1101 */
/* 110 */	7, 	/* 0110-1110, run length:  256, 0110-111x */
/* 111 */	7, 	/* 0110-1111, run length:  256, 0110-111x */
/* 112 */	4, 	/* 0111-0000, run length:    2, 0111-xxxx */
/* 113 */	4, 	/* 0111-0001, run length:    2, 0111-xxxx */
/* 114 */	4, 	/* 0111-0010, run length:    2, 0111-xxxx */
/* 115 */	4, 	/* 0111-0011, run length:    2, 0111-xxxx */
/* 116 */	4, 	/* 0111-0100, run length:    2, 0111-xxxx */
/* 117 */	4, 	/* 0111-0101, run length:    2, 0111-xxxx */
/* 118 */	4, 	/* 0111-0110, run length:    2, 0111-xxxx */
/* 119 */	4, 	/* 0111-0111, run length:    2, 0111-xxxx */
/* 120 */	4, 	/* 0111-1000, run length:    2, 0111-xxxx */
/* 121 */	4, 	/* 0111-1001, run length:    2, 0111-xxxx */
/* 122 */	4, 	/* 0111-1010, run length:    2, 0111-xxxx */
/* 123 */	4, 	/* 0111-1011, run length:    2, 0111-xxxx */
/* 124 */	4, 	/* 0111-1100, run length:    2, 0111-xxxx */
/* 125 */	4, 	/* 0111-1101, run length:    2, 0111-xxxx */
/* 126 */	4, 	/* 0111-1110, run length:    2, 0111-xxxx */
/* 127 */	4, 	/* 0111-1111, run length:    2, 0111-xxxx */
/* 128 */	4, 	/* 1000-0000, run length:    3, 1000-xxxx */
/* 129 */	4, 	/* 1000-0001, run length:    3, 1000-xxxx */
/* 130 */	4, 	/* 1000-0010, run length:    3, 1000-xxxx */
/* 131 */	4, 	/* 1000-0011, run length:    3, 1000-xxxx */
/* 132 */	4, 	/* 1000-0100, run length:    3, 1000-xxxx */
/* 133 */	4, 	/* 1000-0101, run length:    3, 1000-xxxx */
/* 134 */	4, 	/* 1000-0110, run length:    3, 1000-xxxx */
/* 135 */	4, 	/* 1000-0111, run length:    3, 1000-xxxx */
/* 136 */	4, 	/* 1000-1000, run length:    3, 1000-xxxx */
/* 137 */	4, 	/* 1000-1001, run length:    3, 1000-xxxx */
/* 138 */	4, 	/* 1000-1010, run length:    3, 1000-xxxx */
/* 139 */	4, 	/* 1000-1011, run length:    3, 1000-xxxx */
/* 140 */	4, 	/* 1000-1100, run length:    3, 1000-xxxx */
/* 141 */	4, 	/* 1000-1101, run length:    3, 1000-xxxx */
/* 142 */	4, 	/* 1000-1110, run length:    3, 1000-xxxx */
/* 143 */	4, 	/* 1000-1111, run length:    3, 1000-xxxx */
/* 144 */	5, 	/* 1001-0000, run length:  128, 1001-0xxx */
/* 145 */	5, 	/* 1001-0001, run length:  128, 1001-0xxx */
/* 146 */	5, 	/* 1001-0010, run length:  128, 1001-0xxx */
/* 147 */	5, 	/* 1001-0011, run length:  128, 1001-0xxx */
/* 148 */	5, 	/* 1001-0100, run length:  128, 1001-0xxx */
/* 149 */	5, 	/* 1001-0101, run length:  128, 1001-0xxx */
/* 150 */	5, 	/* 1001-0110, run length:  128, 1001-0xxx */
/* 151 */	5, 	/* 1001-0111, run length:  128, 1001-0xxx */
/* 152 */	5, 	/* 1001-1000, run length:    8, 1001-1xxx */
/* 153 */	5, 	/* 1001-1001, run length:    8, 1001-1xxx */
/* 154 */	5, 	/* 1001-1010, run length:    8, 1001-1xxx */
/* 155 */	5, 	/* 1001-1011, run length:    8, 1001-1xxx */
/* 156 */	5, 	/* 1001-1100, run length:    8, 1001-1xxx */
/* 157 */	5, 	/* 1001-1101, run length:    8, 1001-1xxx */
/* 158 */	5, 	/* 1001-1110, run length:    8, 1001-1xxx */
/* 159 */	5, 	/* 1001-1111, run length:    8, 1001-1xxx */
/* 160 */	5, 	/* 1010-0000, run length:    9, 1010-0xxx */
/* 161 */	5, 	/* 1010-0001, run length:    9, 1010-0xxx */
/* 162 */	5, 	/* 1010-0010, run length:    9, 1010-0xxx */
/* 163 */	5, 	/* 1010-0011, run length:    9, 1010-0xxx */
/* 164 */	5, 	/* 1010-0100, run length:    9, 1010-0xxx */
/* 165 */	5, 	/* 1010-0101, run length:    9, 1010-0xxx */
/* 166 */	5, 	/* 1010-0110, run length:    9, 1010-0xxx */
/* 167 */	5, 	/* 1010-0111, run length:    9, 1010-0xxx */
/* 168 */	6, 	/* 1010-1000, run length:   16, 1010-10xx */
/* 169 */	6, 	/* 1010-1001, run length:   16, 1010-10xx */
/* 170 */	6, 	/* 1010-1010, run length:   16, 1010-10xx */
/* 171 */	6, 	/* 1010-1011, run length:   16, 1010-10xx */
/* 172 */	6, 	/* 1010-1100, run length:   17, 1010-11xx */
/* 173 */	6, 	/* 1010-1101, run length:   17, 1010-11xx */
/* 174 */	6, 	/* 1010-1110, run length:   17, 1010-11xx */
/* 175 */	6, 	/* 1010-1111, run length:   17, 1010-11xx */
/* 176 */	4, 	/* 1011-0000, run length:    4, 1011-xxxx */
/* 177 */	4, 	/* 1011-0001, run length:    4, 1011-xxxx */
/* 178 */	4, 	/* 1011-0010, run length:    4, 1011-xxxx */
/* 179 */	4, 	/* 1011-0011, run length:    4, 1011-xxxx */
/* 180 */	4, 	/* 1011-0100, run length:    4, 1011-xxxx */
/* 181 */	4, 	/* 1011-0101, run length:    4, 1011-xxxx */
/* 182 */	4, 	/* 1011-0110, run length:    4, 1011-xxxx */
/* 183 */	4, 	/* 1011-0111, run length:    4, 1011-xxxx */
/* 184 */	4, 	/* 1011-1000, run length:    4, 1011-xxxx */
/* 185 */	4, 	/* 1011-1001, run length:    4, 1011-xxxx */
/* 186 */	4, 	/* 1011-1010, run length:    4, 1011-xxxx */
/* 187 */	4, 	/* 1011-1011, run length:    4, 1011-xxxx */
/* 188 */	4, 	/* 1011-1100, run length:    4, 1011-xxxx */
/* 189 */	4, 	/* 1011-1101, run length:    4, 1011-xxxx */
/* 190 */	4, 	/* 1011-1110, run length:    4, 1011-xxxx */
/* 191 */	4, 	/* 1011-1111, run length:    4, 1011-xxxx */
/* 192 */	4, 	/* 1100-0000, run length:    5, 1100-xxxx */
/* 193 */	4, 	/* 1100-0001, run length:    5, 1100-xxxx */
/* 194 */	4, 	/* 1100-0010, run length:    5, 1100-xxxx */
/* 195 */	4, 	/* 1100-0011, run length:    5, 1100-xxxx */
/* 196 */	4, 	/* 1100-0100, run length:    5, 1100-xxxx */
/* 197 */	4, 	/* 1100-0101, run length:    5, 1100-xxxx */
/* 198 */	4, 	/* 1100-0110, run length:    5, 1100-xxxx */
/* 199 */	4, 	/* 1100-0111, run length:    5, 1100-xxxx */
/* 200 */	4, 	/* 1100-1000, run length:    5, 1100-xxxx */
/* 201 */	4, 	/* 1100-1001, run length:    5, 1100-xxxx */
/* 202 */	4, 	/* 1100-1010, run length:    5, 1100-xxxx */
/* 203 */	4, 	/* 1100-1011, run length:    5, 1100-xxxx */
/* 204 */	4, 	/* 1100-1100, run length:    5, 1100-xxxx */
/* 205 */	4, 	/* 1100-1101, run length:    5, 1100-xxxx */
/* 206 */	4, 	/* 1100-1110, run length:    5, 1100-xxxx */
/* 207 */	4, 	/* 1100-1111, run length:    5, 1100-xxxx */
/* 208 */	6, 	/* 1101-0000, run length:   14, 1101-00xx */
/* 209 */	6, 	/* 1101-0001, run length:   14, 1101-00xx */
/* 210 */	6, 	/* 1101-0010, run length:   14, 1101-00xx */
/* 211 */	6, 	/* 1101-0011, run length:   14, 1101-00xx */
/* 212 */	6, 	/* 1101-0100, run length:   15, 1101-01xx */
/* 213 */	6, 	/* 1101-0101, run length:   15, 1101-01xx */
/* 214 */	6, 	/* 1101-0110, run length:   15, 1101-01xx */
/* 215 */	6, 	/* 1101-0111, run length:   15, 1101-01xx */
/* 216 */	5, 	/* 1101-1000, run length:   64, 1101-1xxx */
/* 217 */	5, 	/* 1101-1001, run length:   64, 1101-1xxx */
/* 218 */	5, 	/* 1101-1010, run length:   64, 1101-1xxx */
/* 219 */	5, 	/* 1101-1011, run length:   64, 1101-1xxx */
/* 220 */	5, 	/* 1101-1100, run length:   64, 1101-1xxx */
/* 221 */	5, 	/* 1101-1101, run length:   64, 1101-1xxx */
/* 222 */	5, 	/* 1101-1110, run length:   64, 1101-1xxx */
/* 223 */	5, 	/* 1101-1111, run length:   64, 1101-1xxx */
/* 224 */	4, 	/* 1110-0000, run length:    6, 1110-xxxx */
/* 225 */	4, 	/* 1110-0001, run length:    6, 1110-xxxx */
/* 226 */	4, 	/* 1110-0010, run length:    6, 1110-xxxx */
/* 227 */	4, 	/* 1110-0011, run length:    6, 1110-xxxx */
/* 228 */	4, 	/* 1110-0100, run length:    6, 1110-xxxx */
/* 229 */	4, 	/* 1110-0101, run length:    6, 1110-xxxx */
/* 230 */	4, 	/* 1110-0110, run length:    6, 1110-xxxx */
/* 231 */	4, 	/* 1110-0111, run length:    6, 1110-xxxx */
/* 232 */	4, 	/* 1110-1000, run length:    6, 1110-xxxx */
/* 233 */	4, 	/* 1110-1001, run length:    6, 1110-xxxx */
/* 234 */	4, 	/* 1110-1010, run length:    6, 1110-xxxx */
/* 235 */	4, 	/* 1110-1011, run length:    6, 1110-xxxx */
/* 236 */	4, 	/* 1110-1100, run length:    6, 1110-xxxx */
/* 237 */	4, 	/* 1110-1101, run length:    6, 1110-xxxx */
/* 238 */	4, 	/* 1110-1110, run length:    6, 1110-xxxx */
/* 239 */	4, 	/* 1110-1111, run length:    6, 1110-xxxx */
/* 240 */	4, 	/* 1111-0000, run length:    7, 1111-xxxx */
/* 241 */	4, 	/* 1111-0001, run length:    7, 1111-xxxx */
/* 242 */	4, 	/* 1111-0010, run length:    7, 1111-xxxx */
/* 243 */	4, 	/* 1111-0011, run length:    7, 1111-xxxx */
/* 244 */	4, 	/* 1111-0100, run length:    7, 1111-xxxx */
/* 245 */	4, 	/* 1111-0101, run length:    7, 1111-xxxx */
/* 246 */	4, 	/* 1111-0110, run length:    7, 1111-xxxx */
/* 247 */	4, 	/* 1111-0111, run length:    7, 1111-xxxx */
/* 248 */	4, 	/* 1111-1000, run length:    7, 1111-xxxx */
/* 249 */	4, 	/* 1111-1001, run length:    7, 1111-xxxx */
/* 250 */	4, 	/* 1111-1010, run length:    7, 1111-xxxx */
/* 251 */	4, 	/* 1111-1011, run length:    7, 1111-xxxx */
/* 252 */	4, 	/* 1111-1100, run length:    7, 1111-xxxx */
/* 253 */	4, 	/* 1111-1101, run length:    7, 1111-xxxx */
/* 254 */	4, 	/* 1111-1110, run length:    7, 1111-xxxx */
/* 255 */	4, 	/* 1111-1111, run length:    7, 1111-xxxx */
};

/*
** This table is called after Byte0 table is used.
** So, that means 8 bits have already been decoded.
** So, for a 9-bit codeWord, the remaining 1 bit
** left over is being decoded here.
*/

#define BAD_DATA	-9

STATIC int nWCodeByte1ToRunLength[256] = {
/*   0 */	BAD_DATA,	/* 0000-0000 */
/*   1 */	BAD_DATA,	/* 0000-0001 */
/*   2 */	BAD_DATA,	/* 0000-0010 */
/*   3 */	BAD_DATA,	/* 0000-0011 */
/*   4 */	BAD_DATA,	/* 0000-0100 */
/*   5 */	BAD_DATA,	/* 0000-0101 */
/*   6 */	BAD_DATA,	/* 0000-0110 */
/*   7 */	BAD_DATA,	/* 0000-0111 */
/*   8 */	BAD_DATA,	/* 0000-1000 */
/*   9 */	BAD_DATA,	/* 0000-1001 */
/*  10 */	BAD_DATA,	/* 0000-1010 */
/*  11 */	BAD_DATA,	/* 0000-1011 */
/*  12 */	BAD_DATA,	/* 0000-1100 */
/*  13 */	BAD_DATA,	/* 0000-1101 */
/*  14 */	BAD_DATA,	/* 0000-1110 */
/*  15 */	BAD_DATA,	/* 0000-1111 */
/*  16 */	BAD_DATA,	/* 0001-0000 */
/*  17 */	BAD_DATA,	/* 0001-0001 */
/*  18 */	BAD_DATA,	/* 0001-0010 */
/*  19 */	BAD_DATA,	/* 0001-0011 */
/*  20 */	BAD_DATA,	/* 0001-0100 */
/*  21 */	BAD_DATA,	/* 0001-0101 */
/*  22 */	BAD_DATA,	/* 0001-0110 */
/*  23 */	BAD_DATA,	/* 0001-0111 */
/*  24 */	BAD_DATA,	/* 0001-1000 */
/*  25 */	BAD_DATA,	/* 0001-1001 */
/*  26 */	BAD_DATA,	/* 0001-1010 */
/*  27 */	BAD_DATA,	/* 0001-1011 */
/*  28 */	BAD_DATA,	/* 0001-1100 */
/*  29 */	BAD_DATA,	/* 0001-1101 */
/*  30 */	BAD_DATA,	/* 0001-1110 */
/*  31 */	BAD_DATA,	/* 0001-1111 */
/*  32 */	BAD_DATA,	/* 0010-0000 */
/*  33 */	BAD_DATA,	/* 0010-0001 */
/*  34 */	BAD_DATA,	/* 0010-0010 */
/*  35 */	BAD_DATA,	/* 0010-0011 */
/*  36 */	BAD_DATA,	/* 0010-0100 */
/*  37 */	BAD_DATA,	/* 0010-0101 */
/*  38 */	BAD_DATA,	/* 0010-0110 */
/*  39 */	BAD_DATA,	/* 0010-0111 */
/*  40 */	BAD_DATA,	/* 0010-1000 */
/*  41 */	BAD_DATA,	/* 0010-1001 */
/*  42 */	BAD_DATA,	/* 0010-1010 */
/*  43 */	BAD_DATA,	/* 0010-1011 */
/*  44 */	BAD_DATA,	/* 0010-1100 */
/*  45 */	BAD_DATA,	/* 0010-1101 */
/*  46 */	BAD_DATA,	/* 0010-1110 */
/*  47 */	BAD_DATA,	/* 0010-1111 */
/*  48 */	BAD_DATA,	/* 0011-0000 */
/*  49 */	BAD_DATA,	/* 0011-0001 */
/*  50 */	BAD_DATA,	/* 0011-0010 */
/*  51 */	BAD_DATA,	/* 0011-0011 */
/*  52 */	BAD_DATA,	/* 0011-0100 */
/*  53 */	BAD_DATA,	/* 0011-0101 */
/*  54 */	BAD_DATA,	/* 0011-0110 */
/*  55 */	BAD_DATA,	/* 0011-0111 */
/*  56 */	BAD_DATA,	/* 0011-1000 */
/*  57 */	BAD_DATA,	/* 0011-1001 */
/*  58 */	BAD_DATA,	/* 0011-1010 */
/*  59 */	BAD_DATA,	/* 0011-1011 */
/*  60 */	BAD_DATA,	/* 0011-1100 */
/*  61 */	BAD_DATA,	/* 0011-1101 */
/*  62 */	BAD_DATA,	/* 0011-1110 */
/*  63 */	BAD_DATA,	/* 0011-1111 */
/*  64 */	BAD_DATA,	/* 0100-0000 */
/*  65 */	BAD_DATA,	/* 0100-0001 */
/*  66 */	BAD_DATA,	/* 0100-0010 */
/*  67 */	BAD_DATA,	/* 0100-0011 */
/*  68 */	BAD_DATA,	/* 0100-0100 */
/*  69 */	BAD_DATA,	/* 0100-0101 */
/*  70 */	BAD_DATA,	/* 0100-0110 */
/*  71 */	BAD_DATA,	/* 0100-0111 */
/*  72 */	BAD_DATA,	/* 0100-1000 */
/*  73 */	BAD_DATA,	/* 0100-1001 */
/*  74 */	BAD_DATA,	/* 0100-1010 */
/*  75 */	BAD_DATA,	/* 0100-1011 */
/*  76 */	BAD_DATA,	/* 0100-1100 */
/*  77 */	BAD_DATA,	/* 0100-1101 */
/*  78 */	BAD_DATA,	/* 0100-1110 */
/*  79 */	BAD_DATA,	/* 0100-1111 */
/*  80 */	BAD_DATA,	/* 0101-0000 */
/*  81 */	BAD_DATA,	/* 0101-0001 */
/*  82 */	BAD_DATA,	/* 0101-0010 */
/*  83 */	BAD_DATA,	/* 0101-0011 */
/*  84 */	BAD_DATA,	/* 0101-0100 */
/*  85 */	BAD_DATA,	/* 0101-0101 */
/*  86 */	BAD_DATA,	/* 0101-0110 */
/*  87 */	BAD_DATA,	/* 0101-0111 */
/*  88 */	BAD_DATA,	/* 0101-1000 */
/*  89 */	BAD_DATA,	/* 0101-1001 */
/*  90 */	BAD_DATA,	/* 0101-1010 */
/*  91 */	BAD_DATA,	/* 0101-1011 */
/*  92 */	BAD_DATA,	/* 0101-1100 */
/*  93 */	BAD_DATA,	/* 0101-1101 */
/*  94 */	BAD_DATA,	/* 0101-1110 */
/*  95 */	BAD_DATA,	/* 0101-1111 */
/*  96 */	BAD_DATA,	/* 0110-0000 */
/*  97 */	BAD_DATA,	/* 0110-0001 */
/*  98 */	BAD_DATA,	/* 0110-0010 */
/*  99 */	BAD_DATA,	/* 0110-0011 */
/* 100 */	BAD_DATA,	/* 0110-0100 */
/* 101 */	BAD_DATA,	/* 0110-0101 */
/* 102 */	BAD_DATA,	/* 0110-0110 */
/* 103 */	BAD_DATA,	/* 0110-0111 */
/* 104 */	BAD_DATA,	/* 0110-1000 */
/* 105 */	BAD_DATA,	/* 0110-1001 */
/* 106 */	BAD_DATA,	/* 0110-1010 */
/* 107 */	BAD_DATA,	/* 0110-1011 */
/* 108 */	BAD_DATA,	/* 0110-1100 */
/* 109 */	BAD_DATA,	/* 0110-1101 */
/* 110 */	BAD_DATA,	/* 0110-1110 */
/* 111 */	BAD_DATA,	/* 0110-1111 */
/* 112 */	BAD_DATA,	/* 0111-0000 */
/* 113 */	BAD_DATA,	/* 0111-0001 */
/* 114 */	BAD_DATA,	/* 0111-0010 */
/* 115 */	BAD_DATA,	/* 0111-0011 */
/* 116 */	BAD_DATA,	/* 0111-0100 */
/* 117 */	BAD_DATA,	/* 0111-0101 */
/* 118 */	BAD_DATA,	/* 0111-0110 */
/* 119 */	BAD_DATA,	/* 0111-0111 */
/* 120 */	BAD_DATA,	/* 0111-1000 */
/* 121 */	BAD_DATA,	/* 0111-1001 */
/* 122 */	BAD_DATA,	/* 0111-1010 */
/* 123 */	BAD_DATA,	/* 0111-1011 */
/* 124 */	BAD_DATA,	/* 0111-1100 */
/* 125 */	BAD_DATA,	/* 0111-1101 */
/* 126 */	BAD_DATA,	/* 0111-1110 */
/* 127 */	BAD_DATA,	/* 0111-1111 */
/* 128 */	BAD_DATA,	/* 1000-0000 */
/* 129 */	BAD_DATA,	/* 1000-0001 */
/* 130 */	BAD_DATA,	/* 1000-0010 */
/* 131 */	BAD_DATA,	/* 1000-0011 */
/* 132 */	BAD_DATA,	/* 1000-0100 */
/* 133 */	BAD_DATA,	/* 1000-0101 */
/* 134 */	BAD_DATA,	/* 1000-0110 */
/* 135 */	BAD_DATA,	/* 1000-0111 */
/* 136 */	BAD_DATA,	/* 1000-1000 */
/* 137 */	BAD_DATA,	/* 1000-1001 */
/* 138 */	BAD_DATA,	/* 1000-1010 */
/* 139 */	BAD_DATA,	/* 1000-1011 */
/* 140 */	BAD_DATA,	/* 1000-1100 */
/* 141 */	BAD_DATA,	/* 1000-1101 */
/* 142 */	BAD_DATA,	/* 1000-1110 */
/* 143 */	BAD_DATA,	/* 1000-1111 */
/* 144 */	BAD_DATA,	/* 1001-0000 */
/* 145 */	BAD_DATA,	/* 1001-0001 */
/* 146 */	BAD_DATA,	/* 1001-0010 */
/* 147 */	BAD_DATA,	/* 1001-0011 */
/* 148 */	BAD_DATA,	/* 1001-0100 */
/* 149 */	BAD_DATA,	/* 1001-0101 */
/* 150 */	BAD_DATA,	/* 1001-0110 */
/* 151 */	BAD_DATA,	/* 1001-0111 */
/* 152 */	1472,	/* 1001-1000, make-up code: 0- # 1001-1000 */
/* 153 */	1536,	/* 1001-1001, make-up code: 0- # 1001-1001 */
/* 154 */	1600,	/* 1001-1010, make-up code: 0- # 1001-1010 */
/* 155 */	1728,	/* 1001-1011, make-up code: 0- # 1001-1011 */
/* 156 */	BAD_DATA,	/* 1001-1100 */
/* 157 */	BAD_DATA,	/* 1001-1101 */
/* 158 */	BAD_DATA,	/* 1001-1110 */
/* 159 */	BAD_DATA,	/* 1001-1111 */
/* 160 */	BAD_DATA,	/* 1010-0000 */
/* 161 */	BAD_DATA,	/* 1010-0001 */
/* 162 */	BAD_DATA,	/* 1010-0010 */
/* 163 */	BAD_DATA,	/* 1010-0011 */
/* 164 */	BAD_DATA,	/* 1010-0100 */
/* 165 */	BAD_DATA,	/* 1010-0101 */
/* 166 */	BAD_DATA,	/* 1010-0110 */
/* 167 */	BAD_DATA,	/* 1010-0111 */
/* 168 */	BAD_DATA,	/* 1010-1000 */
/* 169 */	BAD_DATA,	/* 1010-1001 */
/* 170 */	BAD_DATA,	/* 1010-1010 */
/* 171 */	BAD_DATA,	/* 1010-1011 */
/* 172 */	BAD_DATA,	/* 1010-1100 */
/* 173 */	BAD_DATA,	/* 1010-1101 */
/* 174 */	BAD_DATA,	/* 1010-1110 */
/* 175 */	BAD_DATA,	/* 1010-1111 */
/* 176 */	BAD_DATA,	/* 1011-0000 */
/* 177 */	BAD_DATA,	/* 1011-0001 */
/* 178 */	BAD_DATA,	/* 1011-0010 */
/* 179 */	BAD_DATA,	/* 1011-0011 */
/* 180 */	BAD_DATA,	/* 1011-0100 */
/* 181 */	BAD_DATA,	/* 1011-0101 */
/* 182 */	BAD_DATA,	/* 1011-0110 */
/* 183 */	BAD_DATA,	/* 1011-0111 */
/* 184 */	BAD_DATA,	/* 1011-1000 */
/* 185 */	BAD_DATA,	/* 1011-1001 */
/* 186 */	BAD_DATA,	/* 1011-1010 */
/* 187 */	BAD_DATA,	/* 1011-1011 */
/* 188 */	BAD_DATA,	/* 1011-1100 */
/* 189 */	BAD_DATA,	/* 1011-1101 */
/* 190 */	BAD_DATA,	/* 1011-1110 */
/* 191 */	BAD_DATA,	/* 1011-1111 */
/* 192 */	BAD_DATA,	/* 1100-0000 */
/* 193 */	BAD_DATA,	/* 1100-0001 */
/* 194 */	BAD_DATA,	/* 1100-0010 */
/* 195 */	BAD_DATA,	/* 1100-0011 */
/* 196 */	BAD_DATA,	/* 1100-0100 */
/* 197 */	BAD_DATA,	/* 1100-0101 */
/* 198 */	BAD_DATA,	/* 1100-0110 */
/* 199 */	BAD_DATA,	/* 1100-0111 */
/* 200 */	BAD_DATA,	/* 1100-1000 */
/* 201 */	BAD_DATA,	/* 1100-1001 */
/* 202 */	BAD_DATA,	/* 1100-1010 */
/* 203 */	BAD_DATA,	/* 1100-1011 */
/* 204 */	704,	/* 1100-1100, make-up code: 0- # 1100-1100 */
/* 205 */	768,	/* 1100-1101, make-up code: 0- # 1100-1101 */
/* 206 */	BAD_DATA,	/* 1100-1110 */
/* 207 */	BAD_DATA,	/* 1100-1111 */
/* 208 */	BAD_DATA,	/* 1101-0000 */
/* 209 */	BAD_DATA,	/* 1101-0001 */
/* 210 */	832,	/* 1101-0010, make-up code: 0- # 1101-0010 */
/* 211 */	896,	/* 1101-0011, make-up code: 0- # 1101-0011 */
/* 212 */	960,	/* 1101-0100, make-up code: 0- # 1101-0100 */
/* 213 */	1024,	/* 1101-0101, make-up code: 0- # 1101-0101 */
/* 214 */	1088,	/* 1101-0110, make-up code: 0- # 1101-0110 */
/* 215 */	1152,	/* 1101-0111, make-up code: 0- # 1101-0111 */
/* 216 */	1216,	/* 1101-1000, make-up code: 0- # 1101-1000 */
/* 217 */	1280,	/* 1101-1001, make-up code: 0- # 1101-1001 */
/* 218 */	1344,	/* 1101-1010, make-up code: 0- # 1101-1010 */
/* 219 */	1408,	/* 1101-1011, make-up code: 0- # 1101-1011 */
/* 220 */	BAD_DATA,	/* 1101-1100 */
/* 221 */	BAD_DATA,	/* 1101-1101 */
/* 222 */	BAD_DATA,	/* 1101-1110 */
/* 223 */	BAD_DATA,	/* 1101-1111 */
/* 224 */	BAD_DATA,	/* 1110-0000 */
/* 225 */	BAD_DATA,	/* 1110-0001 */
/* 226 */	BAD_DATA,	/* 1110-0010 */
/* 227 */	BAD_DATA,	/* 1110-0011 */
/* 228 */	BAD_DATA,	/* 1110-0100 */
/* 229 */	BAD_DATA,	/* 1110-0101 */
/* 230 */	BAD_DATA,	/* 1110-0110 */
/* 231 */	BAD_DATA,	/* 1110-0111 */
/* 232 */	BAD_DATA,	/* 1110-1000 */
/* 233 */	BAD_DATA,	/* 1110-1001 */
/* 234 */	BAD_DATA,	/* 1110-1010 */
/* 235 */	BAD_DATA,	/* 1110-1011 */
/* 236 */	BAD_DATA,	/* 1110-1100 */
/* 237 */	BAD_DATA,	/* 1110-1101 */
/* 238 */	BAD_DATA,	/* 1110-1110 */
/* 239 */	BAD_DATA,	/* 1110-1111 */
/* 240 */	BAD_DATA,	/* 1111-0000 */
/* 241 */	BAD_DATA,	/* 1111-0001 */
/* 242 */	BAD_DATA,	/* 1111-0010 */
/* 243 */	BAD_DATA,	/* 1111-0011 */
/* 244 */	BAD_DATA,	/* 1111-0100 */
/* 245 */	BAD_DATA,	/* 1111-0101 */
/* 246 */	BAD_DATA,	/* 1111-0110 */
/* 247 */	BAD_DATA,	/* 1111-0111 */
/* 248 */	BAD_DATA,	/* 1111-1000 */
/* 249 */	BAD_DATA,	/* 1111-1001 */
/* 250 */	BAD_DATA,	/* 1111-1010 */
/* 251 */	BAD_DATA,	/* 1111-1011 */
/* 252 */	BAD_DATA,	/* 1111-1100 */
/* 253 */	BAD_DATA,	/* 1111-1101 */
/* 254 */	BAD_DATA,	/* 1111-1110 */
/* 255 */	BAD_DATA,	/* 1111-1111 */
};

/*
** The largest value is 8, so a BYTE will do.
** Don't waste space with an (int).
*/

STATIC BYTE nWCodeByte1ToCodeWordLength[256] = {
/*   0 */	0, 	/* 0000-0000 */
/*   1 */	0, 	/* 0000-0001 */
/*   2 */	0, 	/* 0000-0010 */
/*   3 */	0, 	/* 0000-0011 */
/*   4 */	0, 	/* 0000-0100 */
/*   5 */	0, 	/* 0000-0101 */
/*   6 */	0, 	/* 0000-0110 */
/*   7 */	0, 	/* 0000-0111 */
/*   8 */	0, 	/* 0000-1000 */
/*   9 */	0, 	/* 0000-1001 */
/*  10 */	0, 	/* 0000-1010 */
/*  11 */	0, 	/* 0000-1011 */
/*  12 */	0, 	/* 0000-1100 */
/*  13 */	0, 	/* 0000-1101 */
/*  14 */	0, 	/* 0000-1110 */
/*  15 */	0, 	/* 0000-1111 */
/*  16 */	0, 	/* 0001-0000 */
/*  17 */	0, 	/* 0001-0001 */
/*  18 */	0, 	/* 0001-0010 */
/*  19 */	0, 	/* 0001-0011 */
/*  20 */	0, 	/* 0001-0100 */
/*  21 */	0, 	/* 0001-0101 */
/*  22 */	0, 	/* 0001-0110 */
/*  23 */	0, 	/* 0001-0111 */
/*  24 */	0, 	/* 0001-1000 */
/*  25 */	0, 	/* 0001-1001 */
/*  26 */	0, 	/* 0001-1010 */
/*  27 */	0, 	/* 0001-1011 */
/*  28 */	0, 	/* 0001-1100 */
/*  29 */	0, 	/* 0001-1101 */
/*  30 */	0, 	/* 0001-1110 */
/*  31 */	0, 	/* 0001-1111 */
/*  32 */	0, 	/* 0010-0000 */
/*  33 */	0, 	/* 0010-0001 */
/*  34 */	0, 	/* 0010-0010 */
/*  35 */	0, 	/* 0010-0011 */
/*  36 */	0, 	/* 0010-0100 */
/*  37 */	0, 	/* 0010-0101 */
/*  38 */	0, 	/* 0010-0110 */
/*  39 */	0, 	/* 0010-0111 */
/*  40 */	0, 	/* 0010-1000 */
/*  41 */	0, 	/* 0010-1001 */
/*  42 */	0, 	/* 0010-1010 */
/*  43 */	0, 	/* 0010-1011 */
/*  44 */	0, 	/* 0010-1100 */
/*  45 */	0, 	/* 0010-1101 */
/*  46 */	0, 	/* 0010-1110 */
/*  47 */	0, 	/* 0010-1111 */
/*  48 */	0, 	/* 0011-0000 */
/*  49 */	0, 	/* 0011-0001 */
/*  50 */	0, 	/* 0011-0010 */
/*  51 */	0, 	/* 0011-0011 */
/*  52 */	0, 	/* 0011-0100 */
/*  53 */	0, 	/* 0011-0101 */
/*  54 */	0, 	/* 0011-0110 */
/*  55 */	0, 	/* 0011-0111 */
/*  56 */	0, 	/* 0011-1000 */
/*  57 */	0, 	/* 0011-1001 */
/*  58 */	0, 	/* 0011-1010 */
/*  59 */	0, 	/* 0011-1011 */
/*  60 */	0, 	/* 0011-1100 */
/*  61 */	0, 	/* 0011-1101 */
/*  62 */	0, 	/* 0011-1110 */
/*  63 */	0, 	/* 0011-1111 */
/*  64 */	0, 	/* 0100-0000 */
/*  65 */	0, 	/* 0100-0001 */
/*  66 */	0, 	/* 0100-0010 */
/*  67 */	0, 	/* 0100-0011 */
/*  68 */	0, 	/* 0100-0100 */
/*  69 */	0, 	/* 0100-0101 */
/*  70 */	0, 	/* 0100-0110 */
/*  71 */	0, 	/* 0100-0111 */
/*  72 */	0, 	/* 0100-1000 */
/*  73 */	0, 	/* 0100-1001 */
/*  74 */	0, 	/* 0100-1010 */
/*  75 */	0, 	/* 0100-1011 */
/*  76 */	0, 	/* 0100-1100 */
/*  77 */	0, 	/* 0100-1101 */
/*  78 */	0, 	/* 0100-1110 */
/*  79 */	0, 	/* 0100-1111 */
/*  80 */	0, 	/* 0101-0000 */
/*  81 */	0, 	/* 0101-0001 */
/*  82 */	0, 	/* 0101-0010 */
/*  83 */	0, 	/* 0101-0011 */
/*  84 */	0, 	/* 0101-0100 */
/*  85 */	0, 	/* 0101-0101 */
/*  86 */	0, 	/* 0101-0110 */
/*  87 */	0, 	/* 0101-0111 */
/*  88 */	0, 	/* 0101-1000 */
/*  89 */	0, 	/* 0101-1001 */
/*  90 */	0, 	/* 0101-1010 */
/*  91 */	0, 	/* 0101-1011 */
/*  92 */	0, 	/* 0101-1100 */
/*  93 */	0, 	/* 0101-1101 */
/*  94 */	0, 	/* 0101-1110 */
/*  95 */	0, 	/* 0101-1111 */
/*  96 */	0, 	/* 0110-0000 */
/*  97 */	0, 	/* 0110-0001 */
/*  98 */	0, 	/* 0110-0010 */
/*  99 */	0, 	/* 0110-0011 */
/* 100 */	0, 	/* 0110-0100 */
/* 101 */	0, 	/* 0110-0101 */
/* 102 */	0, 	/* 0110-0110 */
/* 103 */	0, 	/* 0110-0111 */
/* 104 */	0, 	/* 0110-1000 */
/* 105 */	0, 	/* 0110-1001 */
/* 106 */	0, 	/* 0110-1010 */
/* 107 */	0, 	/* 0110-1011 */
/* 108 */	0, 	/* 0110-1100 */
/* 109 */	0, 	/* 0110-1101 */
/* 110 */	0, 	/* 0110-1110 */
/* 111 */	0, 	/* 0110-1111 */
/* 112 */	0, 	/* 0111-0000 */
/* 113 */	0, 	/* 0111-0001 */
/* 114 */	0, 	/* 0111-0010 */
/* 115 */	0, 	/* 0111-0011 */
/* 116 */	0, 	/* 0111-0100 */
/* 117 */	0, 	/* 0111-0101 */
/* 118 */	0, 	/* 0111-0110 */
/* 119 */	0, 	/* 0111-0111 */
/* 120 */	0, 	/* 0111-1000 */
/* 121 */	0, 	/* 0111-1001 */
/* 122 */	0, 	/* 0111-1010 */
/* 123 */	0, 	/* 0111-1011 */
/* 124 */	0, 	/* 0111-1100 */
/* 125 */	0, 	/* 0111-1101 */
/* 126 */	0, 	/* 0111-1110 */
/* 127 */	0, 	/* 0111-1111 */
/* 128 */	0, 	/* 1000-0000 */
/* 129 */	0, 	/* 1000-0001 */
/* 130 */	0, 	/* 1000-0010 */
/* 131 */	0, 	/* 1000-0011 */
/* 132 */	0, 	/* 1000-0100 */
/* 133 */	0, 	/* 1000-0101 */
/* 134 */	0, 	/* 1000-0110 */
/* 135 */	0, 	/* 1000-0111 */
/* 136 */	0, 	/* 1000-1000 */
/* 137 */	0, 	/* 1000-1001 */
/* 138 */	0, 	/* 1000-1010 */
/* 139 */	0, 	/* 1000-1011 */
/* 140 */	0, 	/* 1000-1100 */
/* 141 */	0, 	/* 1000-1101 */
/* 142 */	0, 	/* 1000-1110 */
/* 143 */	0, 	/* 1000-1111 */
/* 144 */	0, 	/* 1001-0000 */
/* 145 */	0, 	/* 1001-0001 */
/* 146 */	0, 	/* 1001-0010 */
/* 147 */	0, 	/* 1001-0011 */
/* 148 */	0, 	/* 1001-0100 */
/* 149 */	0, 	/* 1001-0101 */
/* 150 */	0, 	/* 1001-0110 */
/* 151 */	0, 	/* 1001-0111 */
/* 152 */	8, 	/* 1001-1000, run length: 1472, 0- # 1001-1000 */
/* 153 */	8, 	/* 1001-1001, run length: 1536, 0- # 1001-1001 */
/* 154 */	8, 	/* 1001-1010, run length: 1600, 0- # 1001-1010 */
/* 155 */	8, 	/* 1001-1011, run length: 1728, 0- # 1001-1011 */
/* 156 */	0, 	/* 1001-1100 */
/* 157 */	0, 	/* 1001-1101 */
/* 158 */	0, 	/* 1001-1110 */
/* 159 */	0, 	/* 1001-1111 */
/* 160 */	0, 	/* 1010-0000 */
/* 161 */	0, 	/* 1010-0001 */
/* 162 */	0, 	/* 1010-0010 */
/* 163 */	0, 	/* 1010-0011 */
/* 164 */	0, 	/* 1010-0100 */
/* 165 */	0, 	/* 1010-0101 */
/* 166 */	0, 	/* 1010-0110 */
/* 167 */	0, 	/* 1010-0111 */
/* 168 */	0, 	/* 1010-1000 */
/* 169 */	0, 	/* 1010-1001 */
/* 170 */	0, 	/* 1010-1010 */
/* 171 */	0, 	/* 1010-1011 */
/* 172 */	0, 	/* 1010-1100 */
/* 173 */	0, 	/* 1010-1101 */
/* 174 */	0, 	/* 1010-1110 */
/* 175 */	0, 	/* 1010-1111 */
/* 176 */	0, 	/* 1011-0000 */
/* 177 */	0, 	/* 1011-0001 */
/* 178 */	0, 	/* 1011-0010 */
/* 179 */	0, 	/* 1011-0011 */
/* 180 */	0, 	/* 1011-0100 */
/* 181 */	0, 	/* 1011-0101 */
/* 182 */	0, 	/* 1011-0110 */
/* 183 */	0, 	/* 1011-0111 */
/* 184 */	0, 	/* 1011-1000 */
/* 185 */	0, 	/* 1011-1001 */
/* 186 */	0, 	/* 1011-1010 */
/* 187 */	0, 	/* 1011-1011 */
/* 188 */	0, 	/* 1011-1100 */
/* 189 */	0, 	/* 1011-1101 */
/* 190 */	0, 	/* 1011-1110 */
/* 191 */	0, 	/* 1011-1111 */
/* 192 */	0, 	/* 1100-0000 */
/* 193 */	0, 	/* 1100-0001 */
/* 194 */	0, 	/* 1100-0010 */
/* 195 */	0, 	/* 1100-0011 */
/* 196 */	0, 	/* 1100-0100 */
/* 197 */	0, 	/* 1100-0101 */
/* 198 */	0, 	/* 1100-0110 */
/* 199 */	0, 	/* 1100-0111 */
/* 200 */	0, 	/* 1100-1000 */
/* 201 */	0, 	/* 1100-1001 */
/* 202 */	0, 	/* 1100-1010 */
/* 203 */	0, 	/* 1100-1011 */
/* 204 */	8, 	/* 1100-1100, run length:  704, 0- # 1100-1100 */
/* 205 */	8, 	/* 1100-1101, run length:  768, 0- # 1100-1101 */
/* 206 */	0, 	/* 1100-1110 */
/* 207 */	0, 	/* 1100-1111 */
/* 208 */	0, 	/* 1101-0000 */
/* 209 */	0, 	/* 1101-0001 */
/* 210 */	8, 	/* 1101-0010, run length:  832, 0- # 1101-0010 */
/* 211 */	8, 	/* 1101-0011, run length:  896, 0- # 1101-0011 */
/* 212 */	8, 	/* 1101-0100, run length:  960, 0- # 1101-0100 */
/* 213 */	8, 	/* 1101-0101, run length: 1024, 0- # 1101-0101 */
/* 214 */	8, 	/* 1101-0110, run length: 1088, 0- # 1101-0110 */
/* 215 */	8, 	/* 1101-0111, run length: 1152, 0- # 1101-0111 */
/* 216 */	8, 	/* 1101-1000, run length: 1216, 0- # 1101-1000 */
/* 217 */	8, 	/* 1101-1001, run length: 1280, 0- # 1101-1001 */
/* 218 */	8, 	/* 1101-1010, run length: 1344, 0- # 1101-1010 */
/* 219 */	8, 	/* 1101-1011, run length: 1408, 0- # 1101-1011 */
/* 220 */	0, 	/* 1101-1100 */
/* 221 */	0, 	/* 1101-1101 */
/* 222 */	0, 	/* 1101-1110 */
/* 223 */	0, 	/* 1101-1111 */
/* 224 */	0, 	/* 1110-0000 */
/* 225 */	0, 	/* 1110-0001 */
/* 226 */	0, 	/* 1110-0010 */
/* 227 */	0, 	/* 1110-0011 */
/* 228 */	0, 	/* 1110-0100 */
/* 229 */	0, 	/* 1110-0101 */
/* 230 */	0, 	/* 1110-0110 */
/* 231 */	0, 	/* 1110-0111 */
/* 232 */	0, 	/* 1110-1000 */
/* 233 */	0, 	/* 1110-1001 */
/* 234 */	0, 	/* 1110-1010 */
/* 235 */	0, 	/* 1110-1011 */
/* 236 */	0, 	/* 1110-1100 */
/* 237 */	0, 	/* 1110-1101 */
/* 238 */	0, 	/* 1110-1110 */
/* 239 */	0, 	/* 1110-1111 */
/* 240 */	0, 	/* 1111-0000 */
/* 241 */	0, 	/* 1111-0001 */
/* 242 */	0, 	/* 1111-0010 */
/* 243 */	0, 	/* 1111-0011 */
/* 244 */	0, 	/* 1111-0100 */
/* 245 */	0, 	/* 1111-0101 */
/* 246 */	0, 	/* 1111-0110 */
/* 247 */	0, 	/* 1111-0111 */
/* 248 */	0, 	/* 1111-1000 */
/* 249 */	0, 	/* 1111-1001 */
/* 250 */	0, 	/* 1111-1010 */
/* 251 */	0, 	/* 1111-1011 */
/* 252 */	0, 	/* 1111-1100 */
/* 253 */	0, 	/* 1111-1101 */
/* 254 */	0, 	/* 1111-1110 */
/* 255 */	0, 	/* 1111-1111 */
};

/*
** This table is called after Byte0 table is used.
** So, that means 8 bits have already been decoded.
** So, for a 12-bit codeWord, the remaining 4 bits
** left over is being decoded here.
**
** Not quite. The top (left) 4 bits are already gobbled.
** So, match the remaining 7 or 8 bits.
*/

STATIC int nWCodeByte4ToRunLength[256] = {

/*   0 */	-7,	/* 0000-0000 - SPECIAL */

/*   1 */	BAD_DATA, 	/* 0000-0001 */
/*   2 */	BAD_DATA, 	/* 0000-0010 */
/*   3 */	BAD_DATA, 	/* 0000-0011 */
/*   4 */	BAD_DATA, 	/* 0000-0100 */
/*   5 */	BAD_DATA, 	/* 0000-0101 */
/*   6 */	BAD_DATA, 	/* 0000-0110 */
/*   7 */	BAD_DATA, 	/* 0000-0111 */
/*   8 */	BAD_DATA, 	/* 0000-1000 */
/*   9 */	BAD_DATA, 	/* 0000-1001 */
/*  10 */	BAD_DATA, 	/* 0000-1010 */
/*  11 */	BAD_DATA, 	/* 0000-1011 */
/*  12 */	BAD_DATA, 	/* 0000-1100 */
/*  13 */	BAD_DATA, 	/* 0000-1101 */
/*  14 */	BAD_DATA, 	/* 0000-1110 */
/*  15 */	BAD_DATA, 	/* 0000-1111 */
/*  16 */	1792, 	/* 0001-0000, make-up code: 000-0 # 000-1000x */
/*  17 */	1792, 	/* 0001-0001, make-up code: 000-0 # 000-1000x */
/*  18 */	1984, 	/* 0001-0010, make-up code: 0000- # 0001-0010 */
/*  19 */	2048, 	/* 0001-0011, make-up code: 0000- # 0001-0011 */
/*  20 */	2112, 	/* 0001-0100, make-up code: 0000- # 0001-0100 */
/*  21 */	2176, 	/* 0001-0101, make-up code: 0000- # 0001-0101 */
/*  22 */	2240, 	/* 0001-0110, make-up code: 0000- # 0001-0110 */
/*  23 */	2304, 	/* 0001-0111, make-up code: 0000- # 0001-0111 */
/*  24 */	1856, 	/* 0001-1000, make-up code: 000-0 # 000-1100x */
/*  25 */	1856, 	/* 0001-1001, make-up code: 000-0 # 000-1100x */
/*  26 */	1920, 	/* 0001-1010, make-up code: 000-0 # 000-1101x */
/*  27 */	1920, 	/* 0001-1011, make-up code: 000-0 # 000-1101x */
/*  28 */	2368, 	/* 0001-1100, make-up code: 0000- # 0001-1100 */
/*  29 */	2432, 	/* 0001-1101, make-up code: 0000- # 0001-1101 */
/*  30 */	2496, 	/* 0001-1110, make-up code: 0000- # 0001-1110 */
/*  31 */	2560, 	/* 0001-1111, make-up code: 0000- # 0001-1111 */
/*  32 */	BAD_DATA, 	/* 0010-0000 */
/*  33 */	BAD_DATA, 	/* 0010-0001 */
/*  34 */	BAD_DATA, 	/* 0010-0010 */
/*  35 */	BAD_DATA, 	/* 0010-0011 */
/*  36 */	BAD_DATA, 	/* 0010-0100 */
/*  37 */	BAD_DATA, 	/* 0010-0101 */
/*  38 */	BAD_DATA, 	/* 0010-0110 */
/*  39 */	BAD_DATA, 	/* 0010-0111 */
/*  40 */	BAD_DATA, 	/* 0010-1000 */
/*  41 */	BAD_DATA, 	/* 0010-1001 */
/*  42 */	BAD_DATA, 	/* 0010-1010 */
/*  43 */	BAD_DATA, 	/* 0010-1011 */
/*  44 */	BAD_DATA, 	/* 0010-1100 */
/*  45 */	BAD_DATA, 	/* 0010-1101 */
/*  46 */	BAD_DATA, 	/* 0010-1110 */
/*  47 */	BAD_DATA, 	/* 0010-1111 */
/*  48 */	BAD_DATA, 	/* 0011-0000 */
/*  49 */	BAD_DATA, 	/* 0011-0001 */
/*  50 */	BAD_DATA, 	/* 0011-0010 */
/*  51 */	BAD_DATA, 	/* 0011-0011 */
/*  52 */	BAD_DATA, 	/* 0011-0100 */
/*  53 */	BAD_DATA, 	/* 0011-0101 */
/*  54 */	BAD_DATA, 	/* 0011-0110 */
/*  55 */	BAD_DATA, 	/* 0011-0111 */
/*  56 */	BAD_DATA, 	/* 0011-1000 */
/*  57 */	BAD_DATA, 	/* 0011-1001 */
/*  58 */	BAD_DATA, 	/* 0011-1010 */
/*  59 */	BAD_DATA, 	/* 0011-1011 */
/*  60 */	BAD_DATA, 	/* 0011-1100 */
/*  61 */	BAD_DATA, 	/* 0011-1101 */
/*  62 */	BAD_DATA, 	/* 0011-1110 */
/*  63 */	BAD_DATA, 	/* 0011-1111 */
/*  64 */	BAD_DATA, 	/* 0100-0000 */
/*  65 */	BAD_DATA, 	/* 0100-0001 */
/*  66 */	BAD_DATA, 	/* 0100-0010 */
/*  67 */	BAD_DATA, 	/* 0100-0011 */
/*  68 */	BAD_DATA, 	/* 0100-0100 */
/*  69 */	BAD_DATA, 	/* 0100-0101 */
/*  70 */	BAD_DATA, 	/* 0100-0110 */
/*  71 */	BAD_DATA, 	/* 0100-0111 */
/*  72 */	BAD_DATA, 	/* 0100-1000 */
/*  73 */	BAD_DATA, 	/* 0100-1001 */
/*  74 */	BAD_DATA, 	/* 0100-1010 */
/*  75 */	BAD_DATA, 	/* 0100-1011 */
/*  76 */	BAD_DATA, 	/* 0100-1100 */
/*  77 */	BAD_DATA, 	/* 0100-1101 */
/*  78 */	BAD_DATA, 	/* 0100-1110 */
/*  79 */	BAD_DATA, 	/* 0100-1111 */
/*  80 */	BAD_DATA, 	/* 0101-0000 */
/*  81 */	BAD_DATA, 	/* 0101-0001 */
/*  82 */	BAD_DATA, 	/* 0101-0010 */
/*  83 */	BAD_DATA, 	/* 0101-0011 */
/*  84 */	BAD_DATA, 	/* 0101-0100 */
/*  85 */	BAD_DATA, 	/* 0101-0101 */
/*  86 */	BAD_DATA, 	/* 0101-0110 */
/*  87 */	BAD_DATA, 	/* 0101-0111 */
/*  88 */	BAD_DATA, 	/* 0101-1000 */
/*  89 */	BAD_DATA, 	/* 0101-1001 */
/*  90 */	BAD_DATA, 	/* 0101-1010 */
/*  91 */	BAD_DATA, 	/* 0101-1011 */
/*  92 */	BAD_DATA, 	/* 0101-1100 */
/*  93 */	BAD_DATA, 	/* 0101-1101 */
/*  94 */	BAD_DATA, 	/* 0101-1110 */
/*  95 */	BAD_DATA, 	/* 0101-1111 */
/*  96 */	BAD_DATA, 	/* 0110-0000 */
/*  97 */	BAD_DATA, 	/* 0110-0001 */
/*  98 */	BAD_DATA, 	/* 0110-0010 */
/*  99 */	BAD_DATA, 	/* 0110-0011 */
/* 100 */	BAD_DATA, 	/* 0110-0100 */
/* 101 */	BAD_DATA, 	/* 0110-0101 */
/* 102 */	BAD_DATA, 	/* 0110-0110 */
/* 103 */	BAD_DATA, 	/* 0110-0111 */
/* 104 */	BAD_DATA, 	/* 0110-1000 */
/* 105 */	BAD_DATA, 	/* 0110-1001 */
/* 106 */	BAD_DATA, 	/* 0110-1010 */
/* 107 */	BAD_DATA, 	/* 0110-1011 */
/* 108 */	BAD_DATA, 	/* 0110-1100 */
/* 109 */	BAD_DATA, 	/* 0110-1101 */
/* 110 */	BAD_DATA, 	/* 0110-1110 */
/* 111 */	BAD_DATA, 	/* 0110-1111 */
/* 112 */	BAD_DATA, 	/* 0111-0000 */
/* 113 */	BAD_DATA, 	/* 0111-0001 */
/* 114 */	BAD_DATA, 	/* 0111-0010 */
/* 115 */	BAD_DATA, 	/* 0111-0011 */
/* 116 */	BAD_DATA, 	/* 0111-0100 */
/* 117 */	BAD_DATA, 	/* 0111-0101 */
/* 118 */	BAD_DATA, 	/* 0111-0110 */
/* 119 */	BAD_DATA, 	/* 0111-0111 */
/* 120 */	BAD_DATA, 	/* 0111-1000 */
/* 121 */	BAD_DATA, 	/* 0111-1001 */
/* 122 */	BAD_DATA, 	/* 0111-1010 */
/* 123 */	BAD_DATA, 	/* 0111-1011 */
/* 124 */	BAD_DATA, 	/* 0111-1100 */
/* 125 */	BAD_DATA, 	/* 0111-1101 */
/* 126 */	BAD_DATA, 	/* 0111-1110 */
/* 127 */	BAD_DATA, 	/* 0111-1111 */
/* 128 */	BAD_DATA, 	/* 1000-0000 */
/* 129 */	BAD_DATA, 	/* 1000-0001 */
/* 130 */	BAD_DATA, 	/* 1000-0010 */
/* 131 */	BAD_DATA, 	/* 1000-0011 */
/* 132 */	BAD_DATA, 	/* 1000-0100 */
/* 133 */	BAD_DATA, 	/* 1000-0101 */
/* 134 */	BAD_DATA, 	/* 1000-0110 */
/* 135 */	BAD_DATA, 	/* 1000-0111 */
/* 136 */	BAD_DATA, 	/* 1000-1000 */
/* 137 */	BAD_DATA, 	/* 1000-1001 */
/* 138 */	BAD_DATA, 	/* 1000-1010 */
/* 139 */	BAD_DATA, 	/* 1000-1011 */
/* 140 */	BAD_DATA, 	/* 1000-1100 */
/* 141 */	BAD_DATA, 	/* 1000-1101 */
/* 142 */	BAD_DATA, 	/* 1000-1110 */
/* 143 */	BAD_DATA, 	/* 1000-1111 */
/* 144 */	BAD_DATA, 	/* 1001-0000 */
/* 145 */	BAD_DATA, 	/* 1001-0001 */
/* 146 */	BAD_DATA, 	/* 1001-0010 */
/* 147 */	BAD_DATA, 	/* 1001-0011 */
/* 148 */	BAD_DATA, 	/* 1001-0100 */
/* 149 */	BAD_DATA, 	/* 1001-0101 */
/* 150 */	BAD_DATA, 	/* 1001-0110 */
/* 151 */	BAD_DATA, 	/* 1001-0111 */
/* 152 */	BAD_DATA, 	/* 1001-1000 */
/* 153 */	BAD_DATA, 	/* 1001-1001 */
/* 154 */	BAD_DATA, 	/* 1001-1010 */
/* 155 */	BAD_DATA, 	/* 1001-1011 */
/* 156 */	BAD_DATA, 	/* 1001-1100 */
/* 157 */	BAD_DATA, 	/* 1001-1101 */
/* 158 */	BAD_DATA, 	/* 1001-1110 */
/* 159 */	BAD_DATA, 	/* 1001-1111 */
/* 160 */	BAD_DATA, 	/* 1010-0000 */
/* 161 */	BAD_DATA, 	/* 1010-0001 */
/* 162 */	BAD_DATA, 	/* 1010-0010 */
/* 163 */	BAD_DATA, 	/* 1010-0011 */
/* 164 */	BAD_DATA, 	/* 1010-0100 */
/* 165 */	BAD_DATA, 	/* 1010-0101 */
/* 166 */	BAD_DATA, 	/* 1010-0110 */
/* 167 */	BAD_DATA, 	/* 1010-0111 */
/* 168 */	BAD_DATA, 	/* 1010-1000 */
/* 169 */	BAD_DATA, 	/* 1010-1001 */
/* 170 */	BAD_DATA, 	/* 1010-1010 */
/* 171 */	BAD_DATA, 	/* 1010-1011 */
/* 172 */	BAD_DATA, 	/* 1010-1100 */
/* 173 */	BAD_DATA, 	/* 1010-1101 */
/* 174 */	BAD_DATA, 	/* 1010-1110 */
/* 175 */	BAD_DATA, 	/* 1010-1111 */
/* 176 */	BAD_DATA, 	/* 1011-0000 */
/* 177 */	BAD_DATA, 	/* 1011-0001 */
/* 178 */	BAD_DATA, 	/* 1011-0010 */
/* 179 */	BAD_DATA, 	/* 1011-0011 */
/* 180 */	BAD_DATA, 	/* 1011-0100 */
/* 181 */	BAD_DATA, 	/* 1011-0101 */
/* 182 */	BAD_DATA, 	/* 1011-0110 */
/* 183 */	BAD_DATA, 	/* 1011-0111 */
/* 184 */	BAD_DATA, 	/* 1011-1000 */
/* 185 */	BAD_DATA, 	/* 1011-1001 */
/* 186 */	BAD_DATA, 	/* 1011-1010 */
/* 187 */	BAD_DATA, 	/* 1011-1011 */
/* 188 */	BAD_DATA, 	/* 1011-1100 */
/* 189 */	BAD_DATA, 	/* 1011-1101 */
/* 190 */	BAD_DATA, 	/* 1011-1110 */
/* 191 */	BAD_DATA, 	/* 1011-1111 */
/* 192 */	BAD_DATA, 	/* 1100-0000 */
/* 193 */	BAD_DATA, 	/* 1100-0001 */
/* 194 */	BAD_DATA, 	/* 1100-0010 */
/* 195 */	BAD_DATA, 	/* 1100-0011 */
/* 196 */	BAD_DATA, 	/* 1100-0100 */
/* 197 */	BAD_DATA, 	/* 1100-0101 */
/* 198 */	BAD_DATA, 	/* 1100-0110 */
/* 199 */	BAD_DATA, 	/* 1100-0111 */
/* 200 */	BAD_DATA, 	/* 1100-1000 */
/* 201 */	BAD_DATA, 	/* 1100-1001 */
/* 202 */	BAD_DATA, 	/* 1100-1010 */
/* 203 */	BAD_DATA, 	/* 1100-1011 */
/* 204 */	BAD_DATA, 	/* 1100-1100 */
/* 205 */	BAD_DATA, 	/* 1100-1101 */
/* 206 */	BAD_DATA, 	/* 1100-1110 */
/* 207 */	BAD_DATA, 	/* 1100-1111 */
/* 208 */	BAD_DATA, 	/* 1101-0000 */
/* 209 */	BAD_DATA, 	/* 1101-0001 */
/* 210 */	BAD_DATA, 	/* 1101-0010 */
/* 211 */	BAD_DATA, 	/* 1101-0011 */
/* 212 */	BAD_DATA, 	/* 1101-0100 */
/* 213 */	BAD_DATA, 	/* 1101-0101 */
/* 214 */	BAD_DATA, 	/* 1101-0110 */
/* 215 */	BAD_DATA, 	/* 1101-0111 */
/* 216 */	BAD_DATA, 	/* 1101-1000 */
/* 217 */	BAD_DATA, 	/* 1101-1001 */
/* 218 */	BAD_DATA, 	/* 1101-1010 */
/* 219 */	BAD_DATA, 	/* 1101-1011 */
/* 220 */	BAD_DATA, 	/* 1101-1100 */
/* 221 */	BAD_DATA, 	/* 1101-1101 */
/* 222 */	BAD_DATA, 	/* 1101-1110 */
/* 223 */	BAD_DATA, 	/* 1101-1111 */
/* 224 */	BAD_DATA, 	/* 1110-0000 */
/* 225 */	BAD_DATA, 	/* 1110-0001 */
/* 226 */	BAD_DATA, 	/* 1110-0010 */
/* 227 */	BAD_DATA, 	/* 1110-0011 */
/* 228 */	BAD_DATA, 	/* 1110-0100 */
/* 229 */	BAD_DATA, 	/* 1110-0101 */
/* 230 */	BAD_DATA, 	/* 1110-0110 */
/* 231 */	BAD_DATA, 	/* 1110-0111 */
/* 232 */	BAD_DATA, 	/* 1110-1000 */
/* 233 */	BAD_DATA, 	/* 1110-1001 */
/* 234 */	BAD_DATA, 	/* 1110-1010 */
/* 235 */	BAD_DATA, 	/* 1110-1011 */
/* 236 */	BAD_DATA, 	/* 1110-1100 */
/* 237 */	BAD_DATA, 	/* 1110-1101 */
/* 238 */	BAD_DATA, 	/* 1110-1110 */
/* 239 */	BAD_DATA, 	/* 1110-1111 */
/* 240 */	BAD_DATA, 	/* 1111-0000 */
/* 241 */	BAD_DATA, 	/* 1111-0001 */
/* 242 */	BAD_DATA, 	/* 1111-0010 */
/* 243 */	BAD_DATA, 	/* 1111-0011 */
/* 244 */	BAD_DATA, 	/* 1111-0100 */
/* 245 */	BAD_DATA, 	/* 1111-0101 */
/* 246 */	BAD_DATA, 	/* 1111-0110 */
/* 247 */	BAD_DATA, 	/* 1111-0111 */
/* 248 */	BAD_DATA, 	/* 1111-1000 */
/* 249 */	BAD_DATA, 	/* 1111-1001 */
/* 250 */	BAD_DATA, 	/* 1111-1010 */
/* 251 */	BAD_DATA, 	/* 1111-1011 */
/* 252 */	BAD_DATA, 	/* 1111-1100 */
/* 253 */	BAD_DATA, 	/* 1111-1101 */
/* 254 */	BAD_DATA, 	/* 1111-1110 */
/* 255 */	BAD_DATA, 	/* 1111-1111 */
};

/*
** Once again, BYTE vs. (int) - save some space.
*/

STATIC BYTE nWCodeByte4ToCodeWordLength[256] = {

/*   0 */	8,	/* 0000-0000 - SPECIAL */

/*   1 */	0, 	/* 0000-0001 */
/*   2 */	0, 	/* 0000-0010 */
/*   3 */	0, 	/* 0000-0011 */
/*   4 */	0, 	/* 0000-0100 */
/*   5 */	0, 	/* 0000-0101 */
/*   6 */	0, 	/* 0000-0110 */
/*   7 */	0, 	/* 0000-0111 */
/*   8 */	0, 	/* 0000-1000 */
/*   9 */	0, 	/* 0000-1001 */
/*  10 */	0, 	/* 0000-1010 */
/*  11 */	0, 	/* 0000-1011 */
/*  12 */	0, 	/* 0000-1100 */
/*  13 */	0, 	/* 0000-1101 */
/*  14 */	0, 	/* 0000-1110 */
/*  15 */	0, 	/* 0000-1111 */
/*  16 */	7, 	/* 0001-0000, run length: 1792, 000-0 # 000-1000x */
/*  17 */	7, 	/* 0001-0001, run length: 1792, 000-0 # 000-1000x */
/*  18 */	8, 	/* 0001-0010, run length: 1984, 0000- # 0001-0010 */
/*  19 */	8, 	/* 0001-0011, run length: 2048, 0000- # 0001-0011 */
/*  20 */	8, 	/* 0001-0100, run length: 2112, 0000- # 0001-0100 */
/*  21 */	8, 	/* 0001-0101, run length: 2176, 0000- # 0001-0101 */
/*  22 */	8, 	/* 0001-0110, run length: 2240, 0000- # 0001-0110 */
/*  23 */	8, 	/* 0001-0111, run length: 2304, 0000- # 0001-0111 */
/*  24 */	7, 	/* 0001-1000, run length: 1856, 000-0 # 000-1100x */
/*  25 */	7, 	/* 0001-1001, run length: 1856, 000-0 # 000-1100x */
/*  26 */	7, 	/* 0001-1010, run length: 1920, 000-0 # 000-1101x */
/*  27 */	7, 	/* 0001-1011, run length: 1920, 000-0 # 000-1101x */
/*  28 */	8, 	/* 0001-1100, run length: 2368, 0000- # 0001-1100 */
/*  29 */	8, 	/* 0001-1101, run length: 2432, 0000- # 0001-1101 */
/*  30 */	8, 	/* 0001-1110, run length: 2496, 0000- # 0001-1110 */
/*  31 */	8, 	/* 0001-1111, run length: 2560, 0000- # 0001-1111 */
/*  32 */	0, 	/* 0010-0000 */
/*  33 */	0, 	/* 0010-0001 */
/*  34 */	0, 	/* 0010-0010 */
/*  35 */	0, 	/* 0010-0011 */
/*  36 */	0, 	/* 0010-0100 */
/*  37 */	0, 	/* 0010-0101 */
/*  38 */	0, 	/* 0010-0110 */
/*  39 */	0, 	/* 0010-0111 */
/*  40 */	0, 	/* 0010-1000 */
/*  41 */	0, 	/* 0010-1001 */
/*  42 */	0, 	/* 0010-1010 */
/*  43 */	0, 	/* 0010-1011 */
/*  44 */	0, 	/* 0010-1100 */
/*  45 */	0, 	/* 0010-1101 */
/*  46 */	0, 	/* 0010-1110 */
/*  47 */	0, 	/* 0010-1111 */
/*  48 */	0, 	/* 0011-0000 */
/*  49 */	0, 	/* 0011-0001 */
/*  50 */	0, 	/* 0011-0010 */
/*  51 */	0, 	/* 0011-0011 */
/*  52 */	0, 	/* 0011-0100 */
/*  53 */	0, 	/* 0011-0101 */
/*  54 */	0, 	/* 0011-0110 */
/*  55 */	0, 	/* 0011-0111 */
/*  56 */	0, 	/* 0011-1000 */
/*  57 */	0, 	/* 0011-1001 */
/*  58 */	0, 	/* 0011-1010 */
/*  59 */	0, 	/* 0011-1011 */
/*  60 */	0, 	/* 0011-1100 */
/*  61 */	0, 	/* 0011-1101 */
/*  62 */	0, 	/* 0011-1110 */
/*  63 */	0, 	/* 0011-1111 */
/*  64 */	0, 	/* 0100-0000 */
/*  65 */	0, 	/* 0100-0001 */
/*  66 */	0, 	/* 0100-0010 */
/*  67 */	0, 	/* 0100-0011 */
/*  68 */	0, 	/* 0100-0100 */
/*  69 */	0, 	/* 0100-0101 */
/*  70 */	0, 	/* 0100-0110 */
/*  71 */	0, 	/* 0100-0111 */
/*  72 */	0, 	/* 0100-1000 */
/*  73 */	0, 	/* 0100-1001 */
/*  74 */	0, 	/* 0100-1010 */
/*  75 */	0, 	/* 0100-1011 */
/*  76 */	0, 	/* 0100-1100 */
/*  77 */	0, 	/* 0100-1101 */
/*  78 */	0, 	/* 0100-1110 */
/*  79 */	0, 	/* 0100-1111 */
/*  80 */	0, 	/* 0101-0000 */
/*  81 */	0, 	/* 0101-0001 */
/*  82 */	0, 	/* 0101-0010 */
/*  83 */	0, 	/* 0101-0011 */
/*  84 */	0, 	/* 0101-0100 */
/*  85 */	0, 	/* 0101-0101 */
/*  86 */	0, 	/* 0101-0110 */
/*  87 */	0, 	/* 0101-0111 */
/*  88 */	0, 	/* 0101-1000 */
/*  89 */	0, 	/* 0101-1001 */
/*  90 */	0, 	/* 0101-1010 */
/*  91 */	0, 	/* 0101-1011 */
/*  92 */	0, 	/* 0101-1100 */
/*  93 */	0, 	/* 0101-1101 */
/*  94 */	0, 	/* 0101-1110 */
/*  95 */	0, 	/* 0101-1111 */
/*  96 */	0, 	/* 0110-0000 */
/*  97 */	0, 	/* 0110-0001 */
/*  98 */	0, 	/* 0110-0010 */
/*  99 */	0, 	/* 0110-0011 */
/* 100 */	0, 	/* 0110-0100 */
/* 101 */	0, 	/* 0110-0101 */
/* 102 */	0, 	/* 0110-0110 */
/* 103 */	0, 	/* 0110-0111 */
/* 104 */	0, 	/* 0110-1000 */
/* 105 */	0, 	/* 0110-1001 */
/* 106 */	0, 	/* 0110-1010 */
/* 107 */	0, 	/* 0110-1011 */
/* 108 */	0, 	/* 0110-1100 */
/* 109 */	0, 	/* 0110-1101 */
/* 110 */	0, 	/* 0110-1110 */
/* 111 */	0, 	/* 0110-1111 */
/* 112 */	0, 	/* 0111-0000 */
/* 113 */	0, 	/* 0111-0001 */
/* 114 */	0, 	/* 0111-0010 */
/* 115 */	0, 	/* 0111-0011 */
/* 116 */	0, 	/* 0111-0100 */
/* 117 */	0, 	/* 0111-0101 */
/* 118 */	0, 	/* 0111-0110 */
/* 119 */	0, 	/* 0111-0111 */
/* 120 */	0, 	/* 0111-1000 */
/* 121 */	0, 	/* 0111-1001 */
/* 122 */	0, 	/* 0111-1010 */
/* 123 */	0, 	/* 0111-1011 */
/* 124 */	0, 	/* 0111-1100 */
/* 125 */	0, 	/* 0111-1101 */
/* 126 */	0, 	/* 0111-1110 */
/* 127 */	0, 	/* 0111-1111 */
/* 128 */	0, 	/* 1000-0000 */
/* 129 */	0, 	/* 1000-0001 */
/* 130 */	0, 	/* 1000-0010 */
/* 131 */	0, 	/* 1000-0011 */
/* 132 */	0, 	/* 1000-0100 */
/* 133 */	0, 	/* 1000-0101 */
/* 134 */	0, 	/* 1000-0110 */
/* 135 */	0, 	/* 1000-0111 */
/* 136 */	0, 	/* 1000-1000 */
/* 137 */	0, 	/* 1000-1001 */
/* 138 */	0, 	/* 1000-1010 */
/* 139 */	0, 	/* 1000-1011 */
/* 140 */	0, 	/* 1000-1100 */
/* 141 */	0, 	/* 1000-1101 */
/* 142 */	0, 	/* 1000-1110 */
/* 143 */	0, 	/* 1000-1111 */
/* 144 */	0, 	/* 1001-0000 */
/* 145 */	0, 	/* 1001-0001 */
/* 146 */	0, 	/* 1001-0010 */
/* 147 */	0, 	/* 1001-0011 */
/* 148 */	0, 	/* 1001-0100 */
/* 149 */	0, 	/* 1001-0101 */
/* 150 */	0, 	/* 1001-0110 */
/* 151 */	0, 	/* 1001-0111 */
/* 152 */	0, 	/* 1001-1000 */
/* 153 */	0, 	/* 1001-1001 */
/* 154 */	0, 	/* 1001-1010 */
/* 155 */	0, 	/* 1001-1011 */
/* 156 */	0, 	/* 1001-1100 */
/* 157 */	0, 	/* 1001-1101 */
/* 158 */	0, 	/* 1001-1110 */
/* 159 */	0, 	/* 1001-1111 */
/* 160 */	0, 	/* 1010-0000 */
/* 161 */	0, 	/* 1010-0001 */
/* 162 */	0, 	/* 1010-0010 */
/* 163 */	0, 	/* 1010-0011 */
/* 164 */	0, 	/* 1010-0100 */
/* 165 */	0, 	/* 1010-0101 */
/* 166 */	0, 	/* 1010-0110 */
/* 167 */	0, 	/* 1010-0111 */
/* 168 */	0, 	/* 1010-1000 */
/* 169 */	0, 	/* 1010-1001 */
/* 170 */	0, 	/* 1010-1010 */
/* 171 */	0, 	/* 1010-1011 */
/* 172 */	0, 	/* 1010-1100 */
/* 173 */	0, 	/* 1010-1101 */
/* 174 */	0, 	/* 1010-1110 */
/* 175 */	0, 	/* 1010-1111 */
/* 176 */	0, 	/* 1011-0000 */
/* 177 */	0, 	/* 1011-0001 */
/* 178 */	0, 	/* 1011-0010 */
/* 179 */	0, 	/* 1011-0011 */
/* 180 */	0, 	/* 1011-0100 */
/* 181 */	0, 	/* 1011-0101 */
/* 182 */	0, 	/* 1011-0110 */
/* 183 */	0, 	/* 1011-0111 */
/* 184 */	0, 	/* 1011-1000 */
/* 185 */	0, 	/* 1011-1001 */
/* 186 */	0, 	/* 1011-1010 */
/* 187 */	0, 	/* 1011-1011 */
/* 188 */	0, 	/* 1011-1100 */
/* 189 */	0, 	/* 1011-1101 */
/* 190 */	0, 	/* 1011-1110 */
/* 191 */	0, 	/* 1011-1111 */
/* 192 */	0, 	/* 1100-0000 */
/* 193 */	0, 	/* 1100-0001 */
/* 194 */	0, 	/* 1100-0010 */
/* 195 */	0, 	/* 1100-0011 */
/* 196 */	0, 	/* 1100-0100 */
/* 197 */	0, 	/* 1100-0101 */
/* 198 */	0, 	/* 1100-0110 */
/* 199 */	0, 	/* 1100-0111 */
/* 200 */	0, 	/* 1100-1000 */
/* 201 */	0, 	/* 1100-1001 */
/* 202 */	0, 	/* 1100-1010 */
/* 203 */	0, 	/* 1100-1011 */
/* 204 */	0, 	/* 1100-1100 */
/* 205 */	0, 	/* 1100-1101 */
/* 206 */	0, 	/* 1100-1110 */
/* 207 */	0, 	/* 1100-1111 */
/* 208 */	0, 	/* 1101-0000 */
/* 209 */	0, 	/* 1101-0001 */
/* 210 */	0, 	/* 1101-0010 */
/* 211 */	0, 	/* 1101-0011 */
/* 212 */	0, 	/* 1101-0100 */
/* 213 */	0, 	/* 1101-0101 */
/* 214 */	0, 	/* 1101-0110 */
/* 215 */	0, 	/* 1101-0111 */
/* 216 */	0, 	/* 1101-1000 */
/* 217 */	0, 	/* 1101-1001 */
/* 218 */	0, 	/* 1101-1010 */
/* 219 */	0, 	/* 1101-1011 */
/* 220 */	0, 	/* 1101-1100 */
/* 221 */	0, 	/* 1101-1101 */
/* 222 */	0, 	/* 1101-1110 */
/* 223 */	0, 	/* 1101-1111 */
/* 224 */	0, 	/* 1110-0000 */
/* 225 */	0, 	/* 1110-0001 */
/* 226 */	0, 	/* 1110-0010 */
/* 227 */	0, 	/* 1110-0011 */
/* 228 */	0, 	/* 1110-0100 */
/* 229 */	0, 	/* 1110-0101 */
/* 230 */	0, 	/* 1110-0110 */
/* 231 */	0, 	/* 1110-0111 */
/* 232 */	0, 	/* 1110-1000 */
/* 233 */	0, 	/* 1110-1001 */
/* 234 */	0, 	/* 1110-1010 */
/* 235 */	0, 	/* 1110-1011 */
/* 236 */	0, 	/* 1110-1100 */
/* 237 */	0, 	/* 1110-1101 */
/* 238 */	0, 	/* 1110-1110 */
/* 239 */	0, 	/* 1110-1111 */
/* 240 */	0, 	/* 1111-0000 */
/* 241 */	0, 	/* 1111-0001 */
/* 242 */	0, 	/* 1111-0010 */
/* 243 */	0, 	/* 1111-0011 */
/* 244 */	0, 	/* 1111-0100 */
/* 245 */	0, 	/* 1111-0101 */
/* 246 */	0, 	/* 1111-0110 */
/* 247 */	0, 	/* 1111-0111 */
/* 248 */	0, 	/* 1111-1000 */
/* 249 */	0, 	/* 1111-1001 */
/* 250 */	0, 	/* 1111-1010 */
/* 251 */	0, 	/* 1111-1011 */
/* 252 */	0, 	/* 1111-1100 */
/* 253 */	0, 	/* 1111-1101 */
/* 254 */	0, 	/* 1111-1110 */
/* 255 */	0, 	/* 1111-1111 */
};

STATIC int nBCodeByte0ToRunLength[256] = {

/*   0 */	-5,	/* 0000-0000  - SPECIAL */
/*   1 */	-5,	/* 0000-0001  - SPECIAL */
/*   2 */	-5,	/* 0000-0010  - SPECIAL */
/*   3 */	-5,	/* 0000-0011  - SPECIAL */

/*   4 */	13,	/* 0000-0100, run length:  13, 0000-0100 */

/*   5 */	-4,	/* 0000-0101 - SPECIAL */
/*   6 */	-4,	/* 0000-0110 - SPECIAL */

/*   7 */	14,	/* 0000-0111, run length:  14, 0000-0111 */
/*   8 */	10,	/* 0000-1000, run length:  10, 0000-100x */
/*   9 */	10,	/* 0000-1001, run length:  10, 0000-100x */
/*  10 */	11,	/* 0000-1010, run length:  11, 0000-101x */
/*  11 */	11,	/* 0000-1011, run length:  11, 0000-101x */

/*  12 */	-4,	/* 0000-1100 - SPECIAL */
/*  13 */	-4,	/* 0000-1101 - SPECIAL */

/*  14 */	12, 	/* 0000-1110, run length:   12, 0000-111x */
/*  15 */	12, 	/* 0000-1111, run length:   12, 0000-111x */
/*  16 */	9, 	/* 0001-0000, run length:    9, 0001-00xx */
/*  17 */	9, 	/* 0001-0001, run length:    9, 0001-00xx */
/*  18 */	9, 	/* 0001-0010, run length:    9, 0001-00xx */
/*  19 */	9, 	/* 0001-0011, run length:    9, 0001-00xx */
/*  20 */	8, 	/* 0001-0100, run length:    8, 0001-01xx */
/*  21 */	8, 	/* 0001-0101, run length:    8, 0001-01xx */
/*  22 */	8, 	/* 0001-0110, run length:    8, 0001-01xx */
/*  23 */	8, 	/* 0001-0111, run length:    8, 0001-01xx */
/*  24 */	7, 	/* 0001-1000, run length:    7, 0001-1xxx */
/*  25 */	7, 	/* 0001-1001, run length:    7, 0001-1xxx */
/*  26 */	7, 	/* 0001-1010, run length:    7, 0001-1xxx */
/*  27 */	7, 	/* 0001-1011, run length:    7, 0001-1xxx */
/*  28 */	7, 	/* 0001-1100, run length:    7, 0001-1xxx */
/*  29 */	7, 	/* 0001-1101, run length:    7, 0001-1xxx */
/*  30 */	7, 	/* 0001-1110, run length:    7, 0001-1xxx */
/*  31 */	7, 	/* 0001-1111, run length:    7, 0001-1xxx */
/*  32 */	6, 	/* 0010-0000, run length:    6, 0010-xxxx */
/*  33 */	6, 	/* 0010-0001, run length:    6, 0010-xxxx */
/*  34 */	6, 	/* 0010-0010, run length:    6, 0010-xxxx */
/*  35 */	6, 	/* 0010-0011, run length:    6, 0010-xxxx */
/*  36 */	6, 	/* 0010-0100, run length:    6, 0010-xxxx */
/*  37 */	6, 	/* 0010-0101, run length:    6, 0010-xxxx */
/*  38 */	6, 	/* 0010-0110, run length:    6, 0010-xxxx */
/*  39 */	6, 	/* 0010-0111, run length:    6, 0010-xxxx */
/*  40 */	6, 	/* 0010-1000, run length:    6, 0010-xxxx */
/*  41 */	6, 	/* 0010-1001, run length:    6, 0010-xxxx */
/*  42 */	6, 	/* 0010-1010, run length:    6, 0010-xxxx */
/*  43 */	6, 	/* 0010-1011, run length:    6, 0010-xxxx */
/*  44 */	6, 	/* 0010-1100, run length:    6, 0010-xxxx */
/*  45 */	6, 	/* 0010-1101, run length:    6, 0010-xxxx */
/*  46 */	6, 	/* 0010-1110, run length:    6, 0010-xxxx */
/*  47 */	6, 	/* 0010-1111, run length:    6, 0010-xxxx */
/*  48 */	5, 	/* 0011-0000, run length:    5, 0011-xxxx */
/*  49 */	5, 	/* 0011-0001, run length:    5, 0011-xxxx */
/*  50 */	5, 	/* 0011-0010, run length:    5, 0011-xxxx */
/*  51 */	5, 	/* 0011-0011, run length:    5, 0011-xxxx */
/*  52 */	5, 	/* 0011-0100, run length:    5, 0011-xxxx */
/*  53 */	5, 	/* 0011-0101, run length:    5, 0011-xxxx */
/*  54 */	5, 	/* 0011-0110, run length:    5, 0011-xxxx */
/*  55 */	5, 	/* 0011-0111, run length:    5, 0011-xxxx */
/*  56 */	5, 	/* 0011-1000, run length:    5, 0011-xxxx */
/*  57 */	5, 	/* 0011-1001, run length:    5, 0011-xxxx */
/*  58 */	5, 	/* 0011-1010, run length:    5, 0011-xxxx */
/*  59 */	5, 	/* 0011-1011, run length:    5, 0011-xxxx */
/*  60 */	5, 	/* 0011-1100, run length:    5, 0011-xxxx */
/*  61 */	5, 	/* 0011-1101, run length:    5, 0011-xxxx */
/*  62 */	5, 	/* 0011-1110, run length:    5, 0011-xxxx */
/*  63 */	5, 	/* 0011-1111, run length:    5, 0011-xxxx */
/*  64 */	1, 	/* 0100-0000, run length:    1, 010x-xxxx */
/*  65 */	1, 	/* 0100-0001, run length:    1, 010x-xxxx */
/*  66 */	1, 	/* 0100-0010, run length:    1, 010x-xxxx */
/*  67 */	1, 	/* 0100-0011, run length:    1, 010x-xxxx */
/*  68 */	1, 	/* 0100-0100, run length:    1, 010x-xxxx */
/*  69 */	1, 	/* 0100-0101, run length:    1, 010x-xxxx */
/*  70 */	1, 	/* 0100-0110, run length:    1, 010x-xxxx */
/*  71 */	1, 	/* 0100-0111, run length:    1, 010x-xxxx */
/*  72 */	1, 	/* 0100-1000, run length:    1, 010x-xxxx */
/*  73 */	1, 	/* 0100-1001, run length:    1, 010x-xxxx */
/*  74 */	1, 	/* 0100-1010, run length:    1, 010x-xxxx */
/*  75 */	1, 	/* 0100-1011, run length:    1, 010x-xxxx */
/*  76 */	1, 	/* 0100-1100, run length:    1, 010x-xxxx */
/*  77 */	1, 	/* 0100-1101, run length:    1, 010x-xxxx */
/*  78 */	1, 	/* 0100-1110, run length:    1, 010x-xxxx */
/*  79 */	1, 	/* 0100-1111, run length:    1, 010x-xxxx */
/*  80 */	1, 	/* 0101-0000, run length:    1, 010x-xxxx */
/*  81 */	1, 	/* 0101-0001, run length:    1, 010x-xxxx */
/*  82 */	1, 	/* 0101-0010, run length:    1, 010x-xxxx */
/*  83 */	1, 	/* 0101-0011, run length:    1, 010x-xxxx */
/*  84 */	1, 	/* 0101-0100, run length:    1, 010x-xxxx */
/*  85 */	1, 	/* 0101-0101, run length:    1, 010x-xxxx */
/*  86 */	1, 	/* 0101-0110, run length:    1, 010x-xxxx */
/*  87 */	1, 	/* 0101-0111, run length:    1, 010x-xxxx */
/*  88 */	1, 	/* 0101-1000, run length:    1, 010x-xxxx */
/*  89 */	1, 	/* 0101-1001, run length:    1, 010x-xxxx */
/*  90 */	1, 	/* 0101-1010, run length:    1, 010x-xxxx */
/*  91 */	1, 	/* 0101-1011, run length:    1, 010x-xxxx */
/*  92 */	1, 	/* 0101-1100, run length:    1, 010x-xxxx */
/*  93 */	1, 	/* 0101-1101, run length:    1, 010x-xxxx */
/*  94 */	1, 	/* 0101-1110, run length:    1, 010x-xxxx */
/*  95 */	1, 	/* 0101-1111, run length:    1, 010x-xxxx */
/*  96 */	4, 	/* 0110-0000, run length:    4, 011x-xxxx */
/*  97 */	4, 	/* 0110-0001, run length:    4, 011x-xxxx */
/*  98 */	4, 	/* 0110-0010, run length:    4, 011x-xxxx */
/*  99 */	4, 	/* 0110-0011, run length:    4, 011x-xxxx */
/* 100 */	4, 	/* 0110-0100, run length:    4, 011x-xxxx */
/* 101 */	4, 	/* 0110-0101, run length:    4, 011x-xxxx */
/* 102 */	4, 	/* 0110-0110, run length:    4, 011x-xxxx */
/* 103 */	4, 	/* 0110-0111, run length:    4, 011x-xxxx */
/* 104 */	4, 	/* 0110-1000, run length:    4, 011x-xxxx */
/* 105 */	4, 	/* 0110-1001, run length:    4, 011x-xxxx */
/* 106 */	4, 	/* 0110-1010, run length:    4, 011x-xxxx */
/* 107 */	4, 	/* 0110-1011, run length:    4, 011x-xxxx */
/* 108 */	4, 	/* 0110-1100, run length:    4, 011x-xxxx */
/* 109 */	4, 	/* 0110-1101, run length:    4, 011x-xxxx */
/* 110 */	4, 	/* 0110-1110, run length:    4, 011x-xxxx */
/* 111 */	4, 	/* 0110-1111, run length:    4, 011x-xxxx */
/* 112 */	4, 	/* 0111-0000, run length:    4, 011x-xxxx */
/* 113 */	4, 	/* 0111-0001, run length:    4, 011x-xxxx */
/* 114 */	4, 	/* 0111-0010, run length:    4, 011x-xxxx */
/* 115 */	4, 	/* 0111-0011, run length:    4, 011x-xxxx */
/* 116 */	4, 	/* 0111-0100, run length:    4, 011x-xxxx */
/* 117 */	4, 	/* 0111-0101, run length:    4, 011x-xxxx */
/* 118 */	4, 	/* 0111-0110, run length:    4, 011x-xxxx */
/* 119 */	4, 	/* 0111-0111, run length:    4, 011x-xxxx */
/* 120 */	4, 	/* 0111-1000, run length:    4, 011x-xxxx */
/* 121 */	4, 	/* 0111-1001, run length:    4, 011x-xxxx */
/* 122 */	4, 	/* 0111-1010, run length:    4, 011x-xxxx */
/* 123 */	4, 	/* 0111-1011, run length:    4, 011x-xxxx */
/* 124 */	4, 	/* 0111-1100, run length:    4, 011x-xxxx */
/* 125 */	4, 	/* 0111-1101, run length:    4, 011x-xxxx */
/* 126 */	4, 	/* 0111-1110, run length:    4, 011x-xxxx */
/* 127 */	4, 	/* 0111-1111, run length:    4, 011x-xxxx */
/* 128 */	3, 	/* 1000-0000, run length:    3, 10xx-xxxx */
/* 129 */	3, 	/* 1000-0001, run length:    3, 10xx-xxxx */
/* 130 */	3, 	/* 1000-0010, run length:    3, 10xx-xxxx */
/* 131 */	3, 	/* 1000-0011, run length:    3, 10xx-xxxx */
/* 132 */	3, 	/* 1000-0100, run length:    3, 10xx-xxxx */
/* 133 */	3, 	/* 1000-0101, run length:    3, 10xx-xxxx */
/* 134 */	3, 	/* 1000-0110, run length:    3, 10xx-xxxx */
/* 135 */	3, 	/* 1000-0111, run length:    3, 10xx-xxxx */
/* 136 */	3, 	/* 1000-1000, run length:    3, 10xx-xxxx */
/* 137 */	3, 	/* 1000-1001, run length:    3, 10xx-xxxx */
/* 138 */	3, 	/* 1000-1010, run length:    3, 10xx-xxxx */
/* 139 */	3, 	/* 1000-1011, run length:    3, 10xx-xxxx */
/* 140 */	3, 	/* 1000-1100, run length:    3, 10xx-xxxx */
/* 141 */	3, 	/* 1000-1101, run length:    3, 10xx-xxxx */
/* 142 */	3, 	/* 1000-1110, run length:    3, 10xx-xxxx */
/* 143 */	3, 	/* 1000-1111, run length:    3, 10xx-xxxx */
/* 144 */	3, 	/* 1001-0000, run length:    3, 10xx-xxxx */
/* 145 */	3, 	/* 1001-0001, run length:    3, 10xx-xxxx */
/* 146 */	3, 	/* 1001-0010, run length:    3, 10xx-xxxx */
/* 147 */	3, 	/* 1001-0011, run length:    3, 10xx-xxxx */
/* 148 */	3, 	/* 1001-0100, run length:    3, 10xx-xxxx */
/* 149 */	3, 	/* 1001-0101, run length:    3, 10xx-xxxx */
/* 150 */	3, 	/* 1001-0110, run length:    3, 10xx-xxxx */
/* 151 */	3, 	/* 1001-0111, run length:    3, 10xx-xxxx */
/* 152 */	3, 	/* 1001-1000, run length:    3, 10xx-xxxx */
/* 153 */	3, 	/* 1001-1001, run length:    3, 10xx-xxxx */
/* 154 */	3, 	/* 1001-1010, run length:    3, 10xx-xxxx */
/* 155 */	3, 	/* 1001-1011, run length:    3, 10xx-xxxx */
/* 156 */	3, 	/* 1001-1100, run length:    3, 10xx-xxxx */
/* 157 */	3, 	/* 1001-1101, run length:    3, 10xx-xxxx */
/* 158 */	3, 	/* 1001-1110, run length:    3, 10xx-xxxx */
/* 159 */	3, 	/* 1001-1111, run length:    3, 10xx-xxxx */
/* 160 */	3, 	/* 1010-0000, run length:    3, 10xx-xxxx */
/* 161 */	3, 	/* 1010-0001, run length:    3, 10xx-xxxx */
/* 162 */	3, 	/* 1010-0010, run length:    3, 10xx-xxxx */
/* 163 */	3, 	/* 1010-0011, run length:    3, 10xx-xxxx */
/* 164 */	3, 	/* 1010-0100, run length:    3, 10xx-xxxx */
/* 165 */	3, 	/* 1010-0101, run length:    3, 10xx-xxxx */
/* 166 */	3, 	/* 1010-0110, run length:    3, 10xx-xxxx */
/* 167 */	3, 	/* 1010-0111, run length:    3, 10xx-xxxx */
/* 168 */	3, 	/* 1010-1000, run length:    3, 10xx-xxxx */
/* 169 */	3, 	/* 1010-1001, run length:    3, 10xx-xxxx */
/* 170 */	3, 	/* 1010-1010, run length:    3, 10xx-xxxx */
/* 171 */	3, 	/* 1010-1011, run length:    3, 10xx-xxxx */
/* 172 */	3, 	/* 1010-1100, run length:    3, 10xx-xxxx */
/* 173 */	3, 	/* 1010-1101, run length:    3, 10xx-xxxx */
/* 174 */	3, 	/* 1010-1110, run length:    3, 10xx-xxxx */
/* 175 */	3, 	/* 1010-1111, run length:    3, 10xx-xxxx */
/* 176 */	3, 	/* 1011-0000, run length:    3, 10xx-xxxx */
/* 177 */	3, 	/* 1011-0001, run length:    3, 10xx-xxxx */
/* 178 */	3, 	/* 1011-0010, run length:    3, 10xx-xxxx */
/* 179 */	3, 	/* 1011-0011, run length:    3, 10xx-xxxx */
/* 180 */	3, 	/* 1011-0100, run length:    3, 10xx-xxxx */
/* 181 */	3, 	/* 1011-0101, run length:    3, 10xx-xxxx */
/* 182 */	3, 	/* 1011-0110, run length:    3, 10xx-xxxx */
/* 183 */	3, 	/* 1011-0111, run length:    3, 10xx-xxxx */
/* 184 */	3, 	/* 1011-1000, run length:    3, 10xx-xxxx */
/* 185 */	3, 	/* 1011-1001, run length:    3, 10xx-xxxx */
/* 186 */	3, 	/* 1011-1010, run length:    3, 10xx-xxxx */
/* 187 */	3, 	/* 1011-1011, run length:    3, 10xx-xxxx */
/* 188 */	3, 	/* 1011-1100, run length:    3, 10xx-xxxx */
/* 189 */	3, 	/* 1011-1101, run length:    3, 10xx-xxxx */
/* 190 */	3, 	/* 1011-1110, run length:    3, 10xx-xxxx */
/* 191 */	3, 	/* 1011-1111, run length:    3, 10xx-xxxx */
/* 192 */	2, 	/* 1100-0000, run length:    2, 11xx-xxxx */
/* 193 */	2, 	/* 1100-0001, run length:    2, 11xx-xxxx */
/* 194 */	2, 	/* 1100-0010, run length:    2, 11xx-xxxx */
/* 195 */	2, 	/* 1100-0011, run length:    2, 11xx-xxxx */
/* 196 */	2, 	/* 1100-0100, run length:    2, 11xx-xxxx */
/* 197 */	2, 	/* 1100-0101, run length:    2, 11xx-xxxx */
/* 198 */	2, 	/* 1100-0110, run length:    2, 11xx-xxxx */
/* 199 */	2, 	/* 1100-0111, run length:    2, 11xx-xxxx */
/* 200 */	2, 	/* 1100-1000, run length:    2, 11xx-xxxx */
/* 201 */	2, 	/* 1100-1001, run length:    2, 11xx-xxxx */
/* 202 */	2, 	/* 1100-1010, run length:    2, 11xx-xxxx */
/* 203 */	2, 	/* 1100-1011, run length:    2, 11xx-xxxx */
/* 204 */	2, 	/* 1100-1100, run length:    2, 11xx-xxxx */
/* 205 */	2, 	/* 1100-1101, run length:    2, 11xx-xxxx */
/* 206 */	2, 	/* 1100-1110, run length:    2, 11xx-xxxx */
/* 207 */	2, 	/* 1100-1111, run length:    2, 11xx-xxxx */
/* 208 */	2, 	/* 1101-0000, run length:    2, 11xx-xxxx */
/* 209 */	2, 	/* 1101-0001, run length:    2, 11xx-xxxx */
/* 210 */	2, 	/* 1101-0010, run length:    2, 11xx-xxxx */
/* 211 */	2, 	/* 1101-0011, run length:    2, 11xx-xxxx */
/* 212 */	2, 	/* 1101-0100, run length:    2, 11xx-xxxx */
/* 213 */	2, 	/* 1101-0101, run length:    2, 11xx-xxxx */
/* 214 */	2, 	/* 1101-0110, run length:    2, 11xx-xxxx */
/* 215 */	2, 	/* 1101-0111, run length:    2, 11xx-xxxx */
/* 216 */	2, 	/* 1101-1000, run length:    2, 11xx-xxxx */
/* 217 */	2, 	/* 1101-1001, run length:    2, 11xx-xxxx */
/* 218 */	2, 	/* 1101-1010, run length:    2, 11xx-xxxx */
/* 219 */	2, 	/* 1101-1011, run length:    2, 11xx-xxxx */
/* 220 */	2, 	/* 1101-1100, run length:    2, 11xx-xxxx */
/* 221 */	2, 	/* 1101-1101, run length:    2, 11xx-xxxx */
/* 222 */	2, 	/* 1101-1110, run length:    2, 11xx-xxxx */
/* 223 */	2, 	/* 1101-1111, run length:    2, 11xx-xxxx */
/* 224 */	2, 	/* 1110-0000, run length:    2, 11xx-xxxx */
/* 225 */	2, 	/* 1110-0001, run length:    2, 11xx-xxxx */
/* 226 */	2, 	/* 1110-0010, run length:    2, 11xx-xxxx */
/* 227 */	2, 	/* 1110-0011, run length:    2, 11xx-xxxx */
/* 228 */	2, 	/* 1110-0100, run length:    2, 11xx-xxxx */
/* 229 */	2, 	/* 1110-0101, run length:    2, 11xx-xxxx */
/* 230 */	2, 	/* 1110-0110, run length:    2, 11xx-xxxx */
/* 231 */	2, 	/* 1110-0111, run length:    2, 11xx-xxxx */
/* 232 */	2, 	/* 1110-1000, run length:    2, 11xx-xxxx */
/* 233 */	2, 	/* 1110-1001, run length:    2, 11xx-xxxx */
/* 234 */	2, 	/* 1110-1010, run length:    2, 11xx-xxxx */
/* 235 */	2, 	/* 1110-1011, run length:    2, 11xx-xxxx */
/* 236 */	2, 	/* 1110-1100, run length:    2, 11xx-xxxx */
/* 237 */	2, 	/* 1110-1101, run length:    2, 11xx-xxxx */
/* 238 */	2, 	/* 1110-1110, run length:    2, 11xx-xxxx */
/* 239 */	2, 	/* 1110-1111, run length:    2, 11xx-xxxx */
/* 240 */	2, 	/* 1111-0000, run length:    2, 11xx-xxxx */
/* 241 */	2, 	/* 1111-0001, run length:    2, 11xx-xxxx */
/* 242 */	2, 	/* 1111-0010, run length:    2, 11xx-xxxx */
/* 243 */	2, 	/* 1111-0011, run length:    2, 11xx-xxxx */
/* 244 */	2, 	/* 1111-0100, run length:    2, 11xx-xxxx */
/* 245 */	2, 	/* 1111-0101, run length:    2, 11xx-xxxx */
/* 246 */	2, 	/* 1111-0110, run length:    2, 11xx-xxxx */
/* 247 */	2, 	/* 1111-0111, run length:    2, 11xx-xxxx */
/* 248 */	2, 	/* 1111-1000, run length:    2, 11xx-xxxx */
/* 249 */	2, 	/* 1111-1001, run length:    2, 11xx-xxxx */
/* 250 */	2, 	/* 1111-1010, run length:    2, 11xx-xxxx */
/* 251 */	2, 	/* 1111-1011, run length:    2, 11xx-xxxx */
/* 252 */	2, 	/* 1111-1100, run length:    2, 11xx-xxxx */
/* 253 */	2, 	/* 1111-1101, run length:    2, 11xx-xxxx */
/* 254 */	2, 	/* 1111-1110, run length:    2, 11xx-xxxx */
/* 255 */	2, 	/* 1111-1111, run length:    2, 11xx-xxxx */
};

/*
** Tis another case of BYTE vs (int).
*/

STATIC BYTE nBCodeByte0ToCodeWordLength[256] = {

/*   0 */	5,	/* 0000-0000 - SPECIAL */
/*   1 */	5,	/* 0000-0001 - SPECIAL */
/*   2 */	5,	/* 0000-0010 - SPECIAL */
/*   3 */	5,	/* 0000-0011 - SPECIAL */

/*   4 */	8,	/* 0000-0100, run length:  13, 0000-0100 */

/*   5 */	4,	/* 0000-0101 - SPECIAL */
/*   6 */	4,	/* 0000-0110 - SPECIAL */

/*   7 */	8,	/* 0000-0111 */
/*   8 */	7,	/* 0000-1000, run length:  10, 0000-100x */
/*   9 */	7,	/* 0000-1001, run length:  10, 0000-100x */
/*  10 */	7,	/* 0000-1010, run length:  11, 0000-101x */
/*  11 */	7,	/* 0000-1011, run length:  11, 0000-101x */

/*  12 */	4,	/* 0000-1100 - SPECIAL */
/*  13 */	4,	/* 0000-1101 - SPECIAL */

/*  14 */	7, 	/* 0000-1110, run length:   12, 0000-111x */
/*  15 */	7, 	/* 0000-1111, run length:   12, 0000-111x */
/*  16 */	6, 	/* 0001-0000, run length:    9, 0001-00xx */
/*  17 */	6, 	/* 0001-0001, run length:    9, 0001-00xx */
/*  18 */	6, 	/* 0001-0010, run length:    9, 0001-00xx */
/*  19 */	6, 	/* 0001-0011, run length:    9, 0001-00xx */
/*  20 */	6, 	/* 0001-0100, run length:    8, 0001-01xx */
/*  21 */	6, 	/* 0001-0101, run length:    8, 0001-01xx */
/*  22 */	6, 	/* 0001-0110, run length:    8, 0001-01xx */
/*  23 */	6, 	/* 0001-0111, run length:    8, 0001-01xx */
/*  24 */	5, 	/* 0001-1000, run length:    7, 0001-1xxx */
/*  25 */	5, 	/* 0001-1001, run length:    7, 0001-1xxx */
/*  26 */	5, 	/* 0001-1010, run length:    7, 0001-1xxx */
/*  27 */	5, 	/* 0001-1011, run length:    7, 0001-1xxx */
/*  28 */	5, 	/* 0001-1100, run length:    7, 0001-1xxx */
/*  29 */	5, 	/* 0001-1101, run length:    7, 0001-1xxx */
/*  30 */	5, 	/* 0001-1110, run length:    7, 0001-1xxx */
/*  31 */	5, 	/* 0001-1111, run length:    7, 0001-1xxx */
/*  32 */	4, 	/* 0010-0000, run length:    6, 0010-xxxx */
/*  33 */	4, 	/* 0010-0001, run length:    6, 0010-xxxx */
/*  34 */	4, 	/* 0010-0010, run length:    6, 0010-xxxx */
/*  35 */	4, 	/* 0010-0011, run length:    6, 0010-xxxx */
/*  36 */	4, 	/* 0010-0100, run length:    6, 0010-xxxx */
/*  37 */	4, 	/* 0010-0101, run length:    6, 0010-xxxx */
/*  38 */	4, 	/* 0010-0110, run length:    6, 0010-xxxx */
/*  39 */	4, 	/* 0010-0111, run length:    6, 0010-xxxx */
/*  40 */	4, 	/* 0010-1000, run length:    6, 0010-xxxx */
/*  41 */	4, 	/* 0010-1001, run length:    6, 0010-xxxx */
/*  42 */	4, 	/* 0010-1010, run length:    6, 0010-xxxx */
/*  43 */	4, 	/* 0010-1011, run length:    6, 0010-xxxx */
/*  44 */	4, 	/* 0010-1100, run length:    6, 0010-xxxx */
/*  45 */	4, 	/* 0010-1101, run length:    6, 0010-xxxx */
/*  46 */	4, 	/* 0010-1110, run length:    6, 0010-xxxx */
/*  47 */	4, 	/* 0010-1111, run length:    6, 0010-xxxx */
/*  48 */	4, 	/* 0011-0000, run length:    5, 0011-xxxx */
/*  49 */	4, 	/* 0011-0001, run length:    5, 0011-xxxx */
/*  50 */	4, 	/* 0011-0010, run length:    5, 0011-xxxx */
/*  51 */	4, 	/* 0011-0011, run length:    5, 0011-xxxx */
/*  52 */	4, 	/* 0011-0100, run length:    5, 0011-xxxx */
/*  53 */	4, 	/* 0011-0101, run length:    5, 0011-xxxx */
/*  54 */	4, 	/* 0011-0110, run length:    5, 0011-xxxx */
/*  55 */	4, 	/* 0011-0111, run length:    5, 0011-xxxx */
/*  56 */	4, 	/* 0011-1000, run length:    5, 0011-xxxx */
/*  57 */	4, 	/* 0011-1001, run length:    5, 0011-xxxx */
/*  58 */	4, 	/* 0011-1010, run length:    5, 0011-xxxx */
/*  59 */	4, 	/* 0011-1011, run length:    5, 0011-xxxx */
/*  60 */	4, 	/* 0011-1100, run length:    5, 0011-xxxx */
/*  61 */	4, 	/* 0011-1101, run length:    5, 0011-xxxx */
/*  62 */	4, 	/* 0011-1110, run length:    5, 0011-xxxx */
/*  63 */	4, 	/* 0011-1111, run length:    5, 0011-xxxx */
/*  64 */	3, 	/* 0100-0000, run length:    1, 010x-xxxx */
/*  65 */	3, 	/* 0100-0001, run length:    1, 010x-xxxx */
/*  66 */	3, 	/* 0100-0010, run length:    1, 010x-xxxx */
/*  67 */	3, 	/* 0100-0011, run length:    1, 010x-xxxx */
/*  68 */	3, 	/* 0100-0100, run length:    1, 010x-xxxx */
/*  69 */	3, 	/* 0100-0101, run length:    1, 010x-xxxx */
/*  70 */	3, 	/* 0100-0110, run length:    1, 010x-xxxx */
/*  71 */	3, 	/* 0100-0111, run length:    1, 010x-xxxx */
/*  72 */	3, 	/* 0100-1000, run length:    1, 010x-xxxx */
/*  73 */	3, 	/* 0100-1001, run length:    1, 010x-xxxx */
/*  74 */	3, 	/* 0100-1010, run length:    1, 010x-xxxx */
/*  75 */	3, 	/* 0100-1011, run length:    1, 010x-xxxx */
/*  76 */	3, 	/* 0100-1100, run length:    1, 010x-xxxx */
/*  77 */	3, 	/* 0100-1101, run length:    1, 010x-xxxx */
/*  78 */	3, 	/* 0100-1110, run length:    1, 010x-xxxx */
/*  79 */	3, 	/* 0100-1111, run length:    1, 010x-xxxx */
/*  80 */	3, 	/* 0101-0000, run length:    1, 010x-xxxx */
/*  81 */	3, 	/* 0101-0001, run length:    1, 010x-xxxx */
/*  82 */	3, 	/* 0101-0010, run length:    1, 010x-xxxx */
/*  83 */	3, 	/* 0101-0011, run length:    1, 010x-xxxx */
/*  84 */	3, 	/* 0101-0100, run length:    1, 010x-xxxx */
/*  85 */	3, 	/* 0101-0101, run length:    1, 010x-xxxx */
/*  86 */	3, 	/* 0101-0110, run length:    1, 010x-xxxx */
/*  87 */	3, 	/* 0101-0111, run length:    1, 010x-xxxx */
/*  88 */	3, 	/* 0101-1000, run length:    1, 010x-xxxx */
/*  89 */	3, 	/* 0101-1001, run length:    1, 010x-xxxx */
/*  90 */	3, 	/* 0101-1010, run length:    1, 010x-xxxx */
/*  91 */	3, 	/* 0101-1011, run length:    1, 010x-xxxx */
/*  92 */	3, 	/* 0101-1100, run length:    1, 010x-xxxx */
/*  93 */	3, 	/* 0101-1101, run length:    1, 010x-xxxx */
/*  94 */	3, 	/* 0101-1110, run length:    1, 010x-xxxx */
/*  95 */	3, 	/* 0101-1111, run length:    1, 010x-xxxx */
/*  96 */	3, 	/* 0110-0000, run length:    4, 011x-xxxx */
/*  97 */	3, 	/* 0110-0001, run length:    4, 011x-xxxx */
/*  98 */	3, 	/* 0110-0010, run length:    4, 011x-xxxx */
/*  99 */	3, 	/* 0110-0011, run length:    4, 011x-xxxx */
/* 100 */	3, 	/* 0110-0100, run length:    4, 011x-xxxx */
/* 101 */	3, 	/* 0110-0101, run length:    4, 011x-xxxx */
/* 102 */	3, 	/* 0110-0110, run length:    4, 011x-xxxx */
/* 103 */	3, 	/* 0110-0111, run length:    4, 011x-xxxx */
/* 104 */	3, 	/* 0110-1000, run length:    4, 011x-xxxx */
/* 105 */	3, 	/* 0110-1001, run length:    4, 011x-xxxx */
/* 106 */	3, 	/* 0110-1010, run length:    4, 011x-xxxx */
/* 107 */	3, 	/* 0110-1011, run length:    4, 011x-xxxx */
/* 108 */	3, 	/* 0110-1100, run length:    4, 011x-xxxx */
/* 109 */	3, 	/* 0110-1101, run length:    4, 011x-xxxx */
/* 110 */	3, 	/* 0110-1110, run length:    4, 011x-xxxx */
/* 111 */	3, 	/* 0110-1111, run length:    4, 011x-xxxx */
/* 112 */	3, 	/* 0111-0000, run length:    4, 011x-xxxx */
/* 113 */	3, 	/* 0111-0001, run length:    4, 011x-xxxx */
/* 114 */	3, 	/* 0111-0010, run length:    4, 011x-xxxx */
/* 115 */	3, 	/* 0111-0011, run length:    4, 011x-xxxx */
/* 116 */	3, 	/* 0111-0100, run length:    4, 011x-xxxx */
/* 117 */	3, 	/* 0111-0101, run length:    4, 011x-xxxx */
/* 118 */	3, 	/* 0111-0110, run length:    4, 011x-xxxx */
/* 119 */	3, 	/* 0111-0111, run length:    4, 011x-xxxx */
/* 120 */	3, 	/* 0111-1000, run length:    4, 011x-xxxx */
/* 121 */	3, 	/* 0111-1001, run length:    4, 011x-xxxx */
/* 122 */	3, 	/* 0111-1010, run length:    4, 011x-xxxx */
/* 123 */	3, 	/* 0111-1011, run length:    4, 011x-xxxx */
/* 124 */	3, 	/* 0111-1100, run length:    4, 011x-xxxx */
/* 125 */	3, 	/* 0111-1101, run length:    4, 011x-xxxx */
/* 126 */	3, 	/* 0111-1110, run length:    4, 011x-xxxx */
/* 127 */	3, 	/* 0111-1111, run length:    4, 011x-xxxx */
/* 128 */	2, 	/* 1000-0000, run length:    3, 10xx-xxxx */
/* 129 */	2, 	/* 1000-0001, run length:    3, 10xx-xxxx */
/* 130 */	2, 	/* 1000-0010, run length:    3, 10xx-xxxx */
/* 131 */	2, 	/* 1000-0011, run length:    3, 10xx-xxxx */
/* 132 */	2, 	/* 1000-0100, run length:    3, 10xx-xxxx */
/* 133 */	2, 	/* 1000-0101, run length:    3, 10xx-xxxx */
/* 134 */	2, 	/* 1000-0110, run length:    3, 10xx-xxxx */
/* 135 */	2, 	/* 1000-0111, run length:    3, 10xx-xxxx */
/* 136 */	2, 	/* 1000-1000, run length:    3, 10xx-xxxx */
/* 137 */	2, 	/* 1000-1001, run length:    3, 10xx-xxxx */
/* 138 */	2, 	/* 1000-1010, run length:    3, 10xx-xxxx */
/* 139 */	2, 	/* 1000-1011, run length:    3, 10xx-xxxx */
/* 140 */	2, 	/* 1000-1100, run length:    3, 10xx-xxxx */
/* 141 */	2, 	/* 1000-1101, run length:    3, 10xx-xxxx */
/* 142 */	2, 	/* 1000-1110, run length:    3, 10xx-xxxx */
/* 143 */	2, 	/* 1000-1111, run length:    3, 10xx-xxxx */
/* 144 */	2, 	/* 1001-0000, run length:    3, 10xx-xxxx */
/* 145 */	2, 	/* 1001-0001, run length:    3, 10xx-xxxx */
/* 146 */	2, 	/* 1001-0010, run length:    3, 10xx-xxxx */
/* 147 */	2, 	/* 1001-0011, run length:    3, 10xx-xxxx */
/* 148 */	2, 	/* 1001-0100, run length:    3, 10xx-xxxx */
/* 149 */	2, 	/* 1001-0101, run length:    3, 10xx-xxxx */
/* 150 */	2, 	/* 1001-0110, run length:    3, 10xx-xxxx */
/* 151 */	2, 	/* 1001-0111, run length:    3, 10xx-xxxx */
/* 152 */	2, 	/* 1001-1000, run length:    3, 10xx-xxxx */
/* 153 */	2, 	/* 1001-1001, run length:    3, 10xx-xxxx */
/* 154 */	2, 	/* 1001-1010, run length:    3, 10xx-xxxx */
/* 155 */	2, 	/* 1001-1011, run length:    3, 10xx-xxxx */
/* 156 */	2, 	/* 1001-1100, run length:    3, 10xx-xxxx */
/* 157 */	2, 	/* 1001-1101, run length:    3, 10xx-xxxx */
/* 158 */	2, 	/* 1001-1110, run length:    3, 10xx-xxxx */
/* 159 */	2, 	/* 1001-1111, run length:    3, 10xx-xxxx */
/* 160 */	2, 	/* 1010-0000, run length:    3, 10xx-xxxx */
/* 161 */	2, 	/* 1010-0001, run length:    3, 10xx-xxxx */
/* 162 */	2, 	/* 1010-0010, run length:    3, 10xx-xxxx */
/* 163 */	2, 	/* 1010-0011, run length:    3, 10xx-xxxx */
/* 164 */	2, 	/* 1010-0100, run length:    3, 10xx-xxxx */
/* 165 */	2, 	/* 1010-0101, run length:    3, 10xx-xxxx */
/* 166 */	2, 	/* 1010-0110, run length:    3, 10xx-xxxx */
/* 167 */	2, 	/* 1010-0111, run length:    3, 10xx-xxxx */
/* 168 */	2, 	/* 1010-1000, run length:    3, 10xx-xxxx */
/* 169 */	2, 	/* 1010-1001, run length:    3, 10xx-xxxx */
/* 170 */	2, 	/* 1010-1010, run length:    3, 10xx-xxxx */
/* 171 */	2, 	/* 1010-1011, run length:    3, 10xx-xxxx */
/* 172 */	2, 	/* 1010-1100, run length:    3, 10xx-xxxx */
/* 173 */	2, 	/* 1010-1101, run length:    3, 10xx-xxxx */
/* 174 */	2, 	/* 1010-1110, run length:    3, 10xx-xxxx */
/* 175 */	2, 	/* 1010-1111, run length:    3, 10xx-xxxx */
/* 176 */	2, 	/* 1011-0000, run length:    3, 10xx-xxxx */
/* 177 */	2, 	/* 1011-0001, run length:    3, 10xx-xxxx */
/* 178 */	2, 	/* 1011-0010, run length:    3, 10xx-xxxx */
/* 179 */	2, 	/* 1011-0011, run length:    3, 10xx-xxxx */
/* 180 */	2, 	/* 1011-0100, run length:    3, 10xx-xxxx */
/* 181 */	2, 	/* 1011-0101, run length:    3, 10xx-xxxx */
/* 182 */	2, 	/* 1011-0110, run length:    3, 10xx-xxxx */
/* 183 */	2, 	/* 1011-0111, run length:    3, 10xx-xxxx */
/* 184 */	2, 	/* 1011-1000, run length:    3, 10xx-xxxx */
/* 185 */	2, 	/* 1011-1001, run length:    3, 10xx-xxxx */
/* 186 */	2, 	/* 1011-1010, run length:    3, 10xx-xxxx */
/* 187 */	2, 	/* 1011-1011, run length:    3, 10xx-xxxx */
/* 188 */	2, 	/* 1011-1100, run length:    3, 10xx-xxxx */
/* 189 */	2, 	/* 1011-1101, run length:    3, 10xx-xxxx */
/* 190 */	2, 	/* 1011-1110, run length:    3, 10xx-xxxx */
/* 191 */	2, 	/* 1011-1111, run length:    3, 10xx-xxxx */
/* 192 */	2, 	/* 1100-0000, run length:    2, 11xx-xxxx */
/* 193 */	2, 	/* 1100-0001, run length:    2, 11xx-xxxx */
/* 194 */	2, 	/* 1100-0010, run length:    2, 11xx-xxxx */
/* 195 */	2, 	/* 1100-0011, run length:    2, 11xx-xxxx */
/* 196 */	2, 	/* 1100-0100, run length:    2, 11xx-xxxx */
/* 197 */	2, 	/* 1100-0101, run length:    2, 11xx-xxxx */
/* 198 */	2, 	/* 1100-0110, run length:    2, 11xx-xxxx */
/* 199 */	2, 	/* 1100-0111, run length:    2, 11xx-xxxx */
/* 200 */	2, 	/* 1100-1000, run length:    2, 11xx-xxxx */
/* 201 */	2, 	/* 1100-1001, run length:    2, 11xx-xxxx */
/* 202 */	2, 	/* 1100-1010, run length:    2, 11xx-xxxx */
/* 203 */	2, 	/* 1100-1011, run length:    2, 11xx-xxxx */
/* 204 */	2, 	/* 1100-1100, run length:    2, 11xx-xxxx */
/* 205 */	2, 	/* 1100-1101, run length:    2, 11xx-xxxx */
/* 206 */	2, 	/* 1100-1110, run length:    2, 11xx-xxxx */
/* 207 */	2, 	/* 1100-1111, run length:    2, 11xx-xxxx */
/* 208 */	2, 	/* 1101-0000, run length:    2, 11xx-xxxx */
/* 209 */	2, 	/* 1101-0001, run length:    2, 11xx-xxxx */
/* 210 */	2, 	/* 1101-0010, run length:    2, 11xx-xxxx */
/* 211 */	2, 	/* 1101-0011, run length:    2, 11xx-xxxx */
/* 212 */	2, 	/* 1101-0100, run length:    2, 11xx-xxxx */
/* 213 */	2, 	/* 1101-0101, run length:    2, 11xx-xxxx */
/* 214 */	2, 	/* 1101-0110, run length:    2, 11xx-xxxx */
/* 215 */	2, 	/* 1101-0111, run length:    2, 11xx-xxxx */
/* 216 */	2, 	/* 1101-1000, run length:    2, 11xx-xxxx */
/* 217 */	2, 	/* 1101-1001, run length:    2, 11xx-xxxx */
/* 218 */	2, 	/* 1101-1010, run length:    2, 11xx-xxxx */
/* 219 */	2, 	/* 1101-1011, run length:    2, 11xx-xxxx */
/* 220 */	2, 	/* 1101-1100, run length:    2, 11xx-xxxx */
/* 221 */	2, 	/* 1101-1101, run length:    2, 11xx-xxxx */
/* 222 */	2, 	/* 1101-1110, run length:    2, 11xx-xxxx */
/* 223 */	2, 	/* 1101-1111, run length:    2, 11xx-xxxx */
/* 224 */	2, 	/* 1110-0000, run length:    2, 11xx-xxxx */
/* 225 */	2, 	/* 1110-0001, run length:    2, 11xx-xxxx */
/* 226 */	2, 	/* 1110-0010, run length:    2, 11xx-xxxx */
/* 227 */	2, 	/* 1110-0011, run length:    2, 11xx-xxxx */
/* 228 */	2, 	/* 1110-0100, run length:    2, 11xx-xxxx */
/* 229 */	2, 	/* 1110-0101, run length:    2, 11xx-xxxx */
/* 230 */	2, 	/* 1110-0110, run length:    2, 11xx-xxxx */
/* 231 */	2, 	/* 1110-0111, run length:    2, 11xx-xxxx */
/* 232 */	2, 	/* 1110-1000, run length:    2, 11xx-xxxx */
/* 233 */	2, 	/* 1110-1001, run length:    2, 11xx-xxxx */
/* 234 */	2, 	/* 1110-1010, run length:    2, 11xx-xxxx */
/* 235 */	2, 	/* 1110-1011, run length:    2, 11xx-xxxx */
/* 236 */	2, 	/* 1110-1100, run length:    2, 11xx-xxxx */
/* 237 */	2, 	/* 1110-1101, run length:    2, 11xx-xxxx */
/* 238 */	2, 	/* 1110-1110, run length:    2, 11xx-xxxx */
/* 239 */	2, 	/* 1110-1111, run length:    2, 11xx-xxxx */
/* 240 */	2, 	/* 1111-0000, run length:    2, 11xx-xxxx */
/* 241 */	2, 	/* 1111-0001, run length:    2, 11xx-xxxx */
/* 242 */	2, 	/* 1111-0010, run length:    2, 11xx-xxxx */
/* 243 */	2, 	/* 1111-0011, run length:    2, 11xx-xxxx */
/* 244 */	2, 	/* 1111-0100, run length:    2, 11xx-xxxx */
/* 245 */	2, 	/* 1111-0101, run length:    2, 11xx-xxxx */
/* 246 */	2, 	/* 1111-0110, run length:    2, 11xx-xxxx */
/* 247 */	2, 	/* 1111-0111, run length:    2, 11xx-xxxx */
/* 248 */	2, 	/* 1111-1000, run length:    2, 11xx-xxxx */
/* 249 */	2, 	/* 1111-1001, run length:    2, 11xx-xxxx */
/* 250 */	2, 	/* 1111-1010, run length:    2, 11xx-xxxx */
/* 251 */	2, 	/* 1111-1011, run length:    2, 11xx-xxxx */
/* 252 */	2, 	/* 1111-1100, run length:    2, 11xx-xxxx */
/* 253 */	2, 	/* 1111-1101, run length:    2, 11xx-xxxx */
/* 254 */	2, 	/* 1111-1110, run length:    2, 11xx-xxxx */
/* 255 */	2, 	/* 1111-1111, run length:    2, 11xx-xxxx */
};

/*
** XXX - end of generated tables
*/

/* ********************************************************************** */
/*
** The code below is ONLY included as developmental because it is
** live code that will generate all 17 tables above except for those
** entries tagged as SPECIAL.
**
** This helps give you an idea of how things fit together and also helps
** verify that the tables are correct. Somehow, the original code had
** no documentation on what the tables meant nor how they were generated.
** With this stuff, at least you get a warm fuzzy about where the values
** came from.
*/

/* ********************************************************************** */

#ifdef GEN_TABLES

// #include "g4tables.cpp"

#include <stdio.h>
#include <string.h>

#define STATIC	static

#define ULONG	unsigned long
#define BYTE	unsigned char
#define WORD	unsigned short
#define BOOL	unsigned char

#define DWORD	unsigned long

#define DEBUG	1	/* HACK */

/* Define "run length" value to mark the end-of-line (EOL) code */

#define EOL_CODE	-1

/* Structure of a code description table entry */

struct asciiTable {
	int run_len;
	char *code;
};

/* Descriptions from which we will build the black synonym table */

STATIC struct asciiTable blackTable[] = {
	{ 0, "0000110111"},
	{ 1, "010"},
	{ 2, "11"},
	{ 3, "10"},
	{ 4, "011"},
	{ 5, "0011"},
	{ 6, "0010"},
	{ 7, "00011"},
	{ 8, "000101"},
	{ 9, "000100"},
	{ 10, "0000100"},
	{ 11, "0000101"},
	{ 12, "0000111"},
	{ 13, "00000100"},
	{ 14, "00000111"},
	{ 15, "000011000"},
	{ 16, "0000010111"},
	{ 17, "0000011000"},
	{ 18, "0000001000"},
	{ 19, "00001100111"},
	{ 20, "00001101000"},
	{ 21, "00001101100"},
	{ 22, "00000110111"},
	{ 23, "00000101000"},
	{ 24, "00000010111"},
	{ 25, "00000011000"},
	{ 26, "000011001010"},
	{ 27, "000011001011"},
	{ 28, "000011001100"},
	{ 29, "000011001101"},
	{ 30, "000001101000"},
	{ 31, "000001101001"},
	{ 32, "000001101010"},
	{ 33, "000001101011"},
	{ 34, "000011010010"},
	{ 35, "000011010011"},
	{ 36, "000011010100"},
	{ 37, "000011010101"},
	{ 38, "000011010110"},
	{ 39, "000011010111"},
	{ 40, "000001101100"},
	{ 41, "000001101101"},
	{ 42, "000011011010"},
	{ 43, "000011011011"},
	{ 44, "000001010100"},
	{ 45, "000001010101"},
	{ 46, "000001010110"},
	{ 47, "000001010111"},
	{ 48, "000001100100"},
	{ 49, "000001100101"},
	{ 50, "000001010010"},
	{ 51, "000001010011"},
	{ 52, "000000100100"},
	{ 53, "000000110111"},
	{ 54, "000000111000"},
	{ 55, "000000100111"},
	{ 56, "000000101000"},
	{ 57, "000001011000"},
	{ 58, "000001011001"},
	{ 59, "000000101011"},
	{ 60, "000000101100"},
	{ 61, "000001011010"},
	{ 62, "000001100110"},
	{ 63, "000001100111"},
	{ 64, "0000001111"},
	{ 128, "000011001000"},
	{ 192, "000011001001"},
	{ 256, "000001011011"},
	{ 320, "000000110011"},
	{ 384, "000000110100"},
	{ 448, "000000110101"},
	{ 512, "0000001101100"},
	{ 576, "0000001101101"},
	{ 640, "0000001001010"},
	{ 704, "0000001001011"},
	{ 768, "0000001001100"},
	{ 832, "0000001001101"},
	{ 896, "0000001110010"},
	{ 960, "0000001110011"},
	{ 1024, "0000001110100"},
	{ 1088, "0000001110101"},
	{ 1152, "0000001110110"},
	{ 1216, "0000001110111"},
	{ 1280, "0000001010010"},
	{ 1344, "0000001010011"},
	{ 1408, "0000001010100"},
	{ 1472, "0000001010101"},
	{ 1536, "0000001011010"},
	{ 1600, "0000001011011"},
	{ 1664, "0000001100100"},
	{ 1728, "0000001100101"},
	{ 1792, "00000001000"},
	{ 1856, "00000001100"},
	{ 1920, "00000001101"},
	{ 1984, "000000010010"},
	{ 2048, "000000010011"},
	{ 2112, "000000010100"},
	{ 2176, "000000010101"},
	{ 2240, "000000010110"},
	{ 2304, "000000010111"},
	{ 2368, "000000011100"},
	{ 2432, "000000011101"},
	{ 2496, "000000011110"},
	{ 2560, "000000011111"},
	{ EOL_CODE, "00000000000"}
};

/* Descriptions from which we will build the white synonym table */

STATIC struct asciiTable whiteTable[] = {
	{ 0, "00110101"},
	{ 1, "000111"},
	{ 2, "0111"},
	{ 3, "1000"},
	{ 4, "1011"},
	{ 5, "1100"},
	{ 6, "1110"},
	{ 7, "1111"},
	{ 8, "10011"},
	{ 9, "10100"},
	{ 10, "00111"},
	{ 11, "01000"},
	{ 12, "001000"},
	{ 13, "000011"},
	{ 14, "110100"},
	{ 15, "110101"},
	{ 16, "101010"},
	{ 17, "101011"},
	{ 18, "0100111"},
	{ 19, "0001100"},
	{ 20, "0001000"},
	{ 21, "0010111"},
	{ 22, "0000011"},
	{ 23, "0000100"},
	{ 24, "0101000"},
	{ 25, "0101011"},
	{ 26, "0010011"},
	{ 27, "0100100"},
	{ 28, "0011000"},
	{ 29, "00000010"},
	{ 30, "00000011"},
	{ 31, "00011010"},
	{ 32, "00011011"},
	{ 33, "00010010"},
	{ 34, "00010011"},
	{ 35, "00010100"},
	{ 36, "00010101"},
	{ 37, "00010110"},
	{ 38, "00010111"},
	{ 39, "00101000"},
	{ 40, "00101001"},
	{ 41, "00101010"},
	{ 42, "00101011"},
	{ 43, "00101100"},
	{ 44, "00101101"},
	{ 45, "00000100"},
	{ 46, "00000101"},
	{ 47, "00001010"},
	{ 48, "00001011"},
	{ 49, "01010010"},
	{ 50, "01010011"},
	{ 51, "01010100"},
	{ 52, "01010101"},
	{ 53, "00100100"},
	{ 54, "00100101"},
	{ 55, "01011000"},
	{ 56, "01011001"},
	{ 57, "01011010"},
	{ 58, "01011011"},
	{ 59, "01001010"},
	{ 60, "01001011"},
	{ 61, "00110010"},
	{ 62, "00110011"},
	{ 63, "00110100"},
	{ 64, "11011"},
	{ 128, "10010"},
	{ 192, "010111"},
	{ 256, "0110111"},
	{ 320, "00110110"},
	{ 384, "00110111"},
	{ 448, "01100100"},
	{ 512, "01100101"},
	{ 576, "01101000"},
	{ 640, "01100111"},
	{ 704, "011001100"},
	{ 768, "011001101"},
	{ 832, "011010010"},
	{ 896, "011010011"},
	{ 960, "011010100"},
	{ 1024, "011010101"},
	{ 1088, "011010110"},
	{ 1152, "011010111"},
	{ 1216, "011011000"},
	{ 1280, "011011001"},
	{ 1344, "011011010"},
	{ 1408, "011011011"},
	{ 1472, "010011000"},
	{ 1536, "010011001"},
	{ 1600, "010011010"},
	{ 1664, "011000"},
	{ 1728, "010011011"},
	{ 1792, "00000001000"},
	{ 1856, "00000001100"},
	{ 1920, "00000001101"},
	{ 1984, "000000010010"},
	{ 2048, "000000010011"},
	{ 2112, "000000010100"},
	{ 2176, "000000010101"},
	{ 2240, "000000010110"},
	{ 2304, "000000010111"},
	{ 2368, "000000011100"},
	{ 2432, "000000011101"},
	{ 2496, "000000011110"},
	{ 2560, "000000011111"},
	{ EOL_CODE, "00000000000"}
};

/* ********************************************************************** */

void
g4Print16BitsXFill(char *ptr)
{
int ln;
int x;

	ln = strlen(ptr);
	for (x = 0; x < 16; x++) {
		if (x < ln) {
			printf("%c", *ptr);
			ptr++;
		}
		else {
			printf("x");
		}
		if ( ((x + 1) % 4) == 0) {
			if ( (x + 1) != 16) {
				printf("-");
			}
		}
	}
}

/* ********************************************************************** */

void
g4Print16BitsPreXFill(char *ptr)
{
int ln;
int x;
int y;

	ln = strlen(ptr);
	for (x = 0; x < (16 - ln); x++) {
		printf("x");
		if ( ((x + 1) % 4) == 0) {
			printf("-");
		}
	}

	for (y = 0; y < ln; y++) {
		printf("%c", *ptr);
		if ( ((x + 1) % 4) == 0) {
			if ( (y + 1) != ln) {
				printf("-");
			}
		}
		x++;
		ptr++;
	}
}

/* ********************************************************************** */

WORD
g4CodeLeftJustified(char *ptr)
{
int ln;
int x;
WORD bits;

	ln = strlen(ptr);
	bits = 0x0000;
	for (x = 0; x < ln; x++) {
		if (*ptr == '0') {
			bits |= 0;
		}
		else
		if (*ptr == '1') {
			bits |= 1;
		}
		bits <<= 1;
		ptr++;
	}
	bits <<= (15 - ln);
	return(bits);
}

/* ********************************************************************** */

WORD
g4CodeRightJustified(char *ptr)
{
int ln;
int x;
WORD bits;

	ln = strlen(ptr);
	bits = 0x0000;
	for (x = 0; x < ln; x++) {
		bits <<= 1;
		if (*ptr == '0') {
			bits |= 0;
		}
		else
		if (*ptr == '1') {
			bits |= 1;
		}
		ptr++;
	}
	return(bits);
}

/* ********************************************************************** */

/*
** This code generates a 64 entry table that contains the WHITE
** run lengths as the index array.
**
** The associated TERMINATING CODE is a bit pattern and is LEFT
** justified in a 16-bit word.
*/

void
g4Table1()
{
int i;
DWORD bits;
char *ptr;

#define NCODES	64

	printf("STATIC int nWRunLengthToTermCode[%d] = {\n", NCODES);

	for (i = 0; i < NCODES; i++) {

		printf("/* %2d */\t", i);

		bits = 0x00000000;

		/*
		** Make sure the current entry matches the
		** array index.
		*/

		if (whiteTable[i].run_len == i) {

			/*
			** Convert code to binary pattern
			*/

			ptr = whiteTable[i].code;
			bits = g4CodeLeftJustified(ptr);
			printf("0x%4.4x,", bits);

			/*
			** Output binary for readable
			*/

			printf("\t\t/* terminating code: ");
			ptr = whiteTable[i].code;
			g4Print16BitsXFill(ptr);
			printf(" */\n");

		}
	}
	printf("};\n");
}

/* ********************************************************************** */

/*
** This code generates a 64 entry table that contains the WHITE
** run lengths as the index array.
**
** The associated TERMINATING CODE is a bit pattern and is RIGHT
** justified in a 16-bit word.
*/

void
g4Table2()
{
int i;
DWORD bits;
char *ptr;

#define NCODES	64

	printf("STATIC int nWRunLengthToTermCodeR[%d] = {\n", NCODES);

	for (i = 0; i < NCODES; i++) {

		printf("/* %2d */\t", i);

		bits = 0x00000000;

		/*
		** Make sure the current entry matches the
		** array index.
		*/

		if (whiteTable[i].run_len == i) {

			ptr = whiteTable[i].code;
			bits = g4CodeRightJustified(ptr);
			printf("0x%4.4x,", bits);

			/*
			** Output binary for readable
			*/

			printf("\t\t/* terminating code: ");

			ptr = whiteTable[i].code;
			g4Print16BitsPreXFill(ptr);
			printf(" */\n");

		}
	}
	printf("};\n");
}

/* ********************************************************************** */

/*
** This code generates a 64 entry table that contains the WHITE
** run lengths as the index array.
**
** The associated TERMINATING CODE has a length, expressed as an integer,
** which represents the LENGTH in bits.
**
** This array can and is used for both the left and right justified
** versions of the tables created above.
*/

void
g4Table3()
{
int i;
int ln;
DWORD bits;
char *ptr;

#define NCODES	64

	printf("STATIC int nWRunLengthToTermCodeLength[%d] = {\n", NCODES);

	for (i = 0; i < NCODES; i++) {

		printf("/* %2d */\t", i);

		bits = 0x00000000;

		/*
		** Make sure the current entry matches the
		** array index.
		*/

		if (whiteTable[i].run_len == i) {

			ln = strlen(whiteTable[i].code);
			printf("%d,", ln);

			/*
			** Output binary for readable
			*/

			printf("\t/* terminating code: ");
			ptr = whiteTable[i].code;
			g4Print16BitsXFill(ptr);
			printf(" */\n");

		}
	}
	printf("};\n");
}

/* ********************************************************************** */

/*
** This code generates a 64 entry table that contains the BLACK
** run lengths as the index array.
**
** The associated TERMINATING CODE is a bit pattern and is RIGHT
** justified in a 16-bit word.
*/

void
g4Table4()
{
int i;
DWORD bits;
char *ptr;

#define NCODES	64

	printf("STATIC int nBRunLengthToTermCodeR[%d] = {\n", NCODES);

	for (i = 0; i < NCODES; i++) {

		printf("/* %2d */\t", i);

		bits = 0x00000000;

		/*
		** Make sure the current entry matches the
		** array index.
		*/

		if (blackTable[i].run_len == i) {

			ptr = blackTable[i].code;
			bits = g4CodeRightJustified(ptr);
			printf("0x%4.4x,", bits);

			/*
			** Output binary for readable
			*/

			printf("\t/* terminating code: ");
			ptr = blackTable[i].code;
			g4Print16BitsPreXFill(ptr);
			printf(" */\n");

		}
	}
	printf("};\n");
}

/* ********************************************************************** */

/*
** This code generates a 64 entry table that contains the BLACK
** run lengths as the index array.
**
** The associated TERMINATING CODE has a length, expressed as an integer,
** which represents the LENGTH in bits.
**
** This array can and is used for both the left and right justified
** versions of the tables created above.
*/

void
g4Table5()
{
int i;
int ln;
DWORD bits;
char *ptr;

#define NCODES	64

	printf("STATIC int nBRunLengthToTermCodeLength[%d] = {\n", NCODES);

	for (i = 0; i < NCODES; i++) {

		printf("/* %2d */\t", i);

		bits = 0x00000000;

		/*
		** Make sure the current entry matches the
		** array index.
		*/

		if (blackTable[i].run_len == i) {

			ln = strlen(blackTable[i].code);
			printf("%d,", ln);

			/*
			** Output binary for readable
			*/

			printf("\t/* terminating code: ");
			ptr = blackTable[i].code;
			g4Print16BitsXFill(ptr);
			printf(" */\n");

		}
	}
	printf("};\n");
}

/* ********************************************************************** */

/*
** This code generates a 64 entry table that contains the WHITE
** run lengths as the index array, mod 64.
**
** The associated MAKE UP CODE is a bit pattern and is RIGHT
** justified in a 16-bit word.
*/

void
g4Table6()
{
int nSize;
int str;
int i;
int idx;
DWORD bits;
char *ptr;

	nSize = (sizeof(whiteTable) / sizeof(whiteTable[0]) );
	printf("(): nSize = %d\n", nSize);

#define MCODES	41

	/*
	** First, find #64
	*/

	for (i = 0; i < nSize; i++) {
		if (whiteTable[i].run_len == 64) {
			str = i;
			break;
		}
	}

	printf("STATIC int nWRunLengthToMakeUpCodeR[%d] = {\n", MCODES);

	printf("/* %2d */\t", 0);
	printf("0x%4.4x,", 0);
	printf("\n");

	for (i = 0; i < (MCODES - 1); i++) {

		printf("/* %2d */\t", i + 1);

		bits = 0x00000000;

		/*
		** Convert code to binary pattern
		*/

		idx = (str + i);
		ptr = whiteTable[idx].code;
		bits = g4CodeRightJustified(ptr);
		printf("0x%4.4x,", bits);

		/*
		** Output binary for readable
		*/

		printf("\t/* run: %4d, make-up code: ", whiteTable[idx].run_len);

		ptr = whiteTable[idx].code;
		g4Print16BitsPreXFill(ptr);
		printf(" */\n");
	}
	printf("};\n");
}

/* ********************************************************************** */

/*
** This code generates a 64 entry table that contains the WHITE
** run lengths as the index array, mod 64.
**
** The associated MAKE UP CODE's length (in bits) is the value.
*/

void
g4Table7()
{
int nSize;
int str;
int i;
int ln;
int idx;
DWORD bits;
char *ptr;

	nSize = (sizeof(whiteTable) / sizeof(whiteTable[0]) );
	printf("(): nSize = %d\n", nSize);

#define MCODES	41

	/*
	** First, find #64
	*/

	for (i = 0; i < nSize; i++) {
		if (whiteTable[i].run_len == 64) {
			str = i;
			break;
		}
	}

	printf("STATIC int nWRunLengthToMakeUpCodeLength[%d] = {\n", MCODES);

	printf("/* %2d */\t", 0);
	printf("%d,", 0);
	printf("\n");

	for (i = 0; i < (MCODES - 1); i++) {

		printf("/* %2d */\t", i + 1);

		bits = 0x00000000;

		/*
		** Convert code to binary pattern
		*/

		idx = (str + i);
		ln = strlen(whiteTable[idx].code);
		printf("%d,", ln);

		/*
		** Output binary for readable
		*/

		printf("\t/* run: %4d, make-up code: ", whiteTable[idx].run_len);

		ptr = whiteTable[idx].code;
		g4Print16BitsPreXFill(ptr);
		printf(" */\n");
	}
	printf("};\n");
}

/* ********************************************************************** */

/*
** This code generates a 64 entry table that contains the BLACK
** run lengths as the index array, mod 64.
**
** The associated MAKE UP CODE is a bit pattern and is RIGHT
** justified in a 16-bit word.
*/

void
g4Table8()
{
int nSize;
int str;
int i;
int idx;
DWORD bits;
char *ptr;

	nSize = (sizeof(blackTable) / sizeof(blackTable[0]) );
	printf("(): nSize = %d\n", nSize);

#define MCODES	41

	/*
	** First, find #64
	*/

	for (i = 0; i < nSize; i++) {
		if (blackTable[i].run_len == 64) {
			str = i;
			break;
		}
	}

	printf("STATIC int nBRunLengthToMakeUpCodeR[%d] = {\n", MCODES);

	printf("/* %2d */\t", 0);
	printf("0x%4.4x,", 0);
	printf("\n");

	for (i = 0; i < (MCODES - 1); i++) {

		printf("/* %2d */\t", i + 1);

		bits = 0x00000000;

		/*
		** Convert code to binary pattern
		*/

		idx = (str + i);
		ptr = blackTable[idx].code;
		bits = g4CodeRightJustified(ptr);
		printf("0x%4.4x,", bits);

		/*
		** Output binary for readable
		*/

		printf("\t/* run: %4d, make-up code: ", blackTable[idx].run_len);

		ptr = blackTable[idx].code;
		g4Print16BitsPreXFill(ptr);
		printf(" */\n");
	}
	printf("};\n");
}

/* ********************************************************************** */

/*
** This code generates a 64 entry table that contains the BLACK
** run lengths as the index array, mod 64.
**
** The associated MAKE UP CODE's length (in bits) is the value.
*/

void
g4Table9()
{
int nSize;
int str;
int i;
int ln;
int idx;
DWORD bits;
char *ptr;

	nSize = (sizeof(blackTable) / sizeof(blackTable[0]) );
	printf("(): nSize = %d\n", nSize);

#define MCODES	41

	/*
	** First, find #64
	*/

	for (i = 0; i < nSize; i++) {
		if (blackTable[i].run_len == 64) {
			str = i;
			break;
		}
	}

	printf("STATIC int nBRunLengthToMakeUpCodeLength[%d] = {\n", MCODES);

	printf("/* %2d */\t", 0);
	printf("%d,", 0);
	printf("\n");

	for (i = 0; i < (MCODES - 1); i++) {

		printf("/* %2d */\t", i + 1);

		bits = 0x00000000;

		/*
		** Convert code to binary pattern
		*/

		idx = (str + i);
		ln = strlen(blackTable[idx].code);
		printf("%d,", ln);

		/*
		** Output binary for readable
		*/

		printf("\t/* run: %4d, make-up code: ", blackTable[idx].run_len);
		ptr = blackTable[idx].code;
		g4Print16BitsPreXFill(ptr);
		printf(" */\n");
	}
	printf("};\n");
}

/* ********************************************************************** */

#define BYTE4(x)	(BYTE) ( ( (x) & 0xff000000) >> 24)
#define BYTE3(x)	(BYTE) ( ( (x) & 0x00ff0000) >> 16)
#define BYTE2(x)	(BYTE) ( ( (x) & 0x0000ff00) >> 8)
#define BYTE1(x)	(BYTE) ( (x) & 0x000000ff)

/* ********************************************************************** */

void
g4PrintByte(BYTE ch)
{
int i;

	for (i = 0; i < 8; i++) {
		if ( (ch & 0x80) == 0x80) {
			printf("1");
		}
		else {
			printf("0");
		}
		if (i == 3) {
			printf("-");
		}
		ch <<= 1;
	}
}

/* ********************************************************************** */

void
g4PrintRegister(DWORD r)
{
#if 0
	g4PrintByte(BYTE4(r));
	printf("-");

	g4PrintByte(BYTE3(r));
	printf("-");
#endif
	g4PrintByte(BYTE2(r));
	printf("-");

	g4PrintByte(BYTE1(r));
	printf(" ");
}

/*
** This code generates a 64 entry table that contains the WHITE
** run lengths as the index array.
**
** The associated TERMINATING CODE is a bit pattern and is LEFT
** justified in a 16-bit word.
*/

struct myTable {
	int bitLength;
	int bits;
};

WORD bitMasks[] = {
/*  0 */	0x0000,	/* 0000-0000-0000-0000 */
/*  1 */	0x8000,	/* 1000-0000-0000-0000 */
/*  2 */	0xc000,	/* 1100-0000-0000-0000 */
/*  3 */	0xe000,	/* 1110-0000-0000-0000 */
/*  4 */	0xf000,	/* 1111-0000-0000-0000 */
/*  5 */	0xf800,	/* 1111-1000-0000-0000 */
/*  6 */	0xfc00,	/* 1111-1100-0000-0000 */
/*  7 */	0xfe00,	/* 1111-1110-0000-0000 */
/*  8 */	0xff00,	/* 1111-1111-0000-0000 */
/*  9 */	0xff80,	/* 1111-1111-1000-0000 */
/* 10 */	0xffc0,	/* 1111-1111-1100-0000 */
/* 11 */	0xffe0,	/* 1111-1111-1110-0000 */
/* 12 */	0xfff0,	/* 1111-1111-1111-0000 */
/* 13 */	0xfff8,	/* 1111-1111-1111-1000 */
/* 14 */	0xfffc,	/* 1111-1111-1111-1100 */
/* 15 */	0xfffe,	/* 1111-1111-1111-1110 */
/* 16 */	0xffff,	/* 1111-1111-1111-1111 */
};

STATIC BYTE myTableInit = 0;

struct myTable myWhite[105];
struct myTable myBlack[105];

void
g5TableInit()
{
int nSize;
int i;
int x;
int ln;
DWORD bits;
char *ptr;

	nSize = (sizeof(whiteTable) / sizeof(whiteTable[0]) );
	printf("(): nSize = %d\n", nSize);

	/*
	** First thing first, generate the bit pattern
	*/

	for (i = 0; i < nSize; i++) {
		bits = 0x00000000;
		ln = strlen(whiteTable[i].code);
		ptr = whiteTable[i].code;
		for (x = 0; x < ln; x++) {
			if (*ptr == '0') {
				bits |= 0;
			}
			else
			if (*ptr == '1') {
				bits |= 1;
			}
			bits <<= 1;
			ptr++;
		}
		bits <<= (15 - ln);
		myWhite[i].bitLength = strlen(whiteTable[i].code);
		myWhite[i].bits = bits;
		printf("%d, ", i);
		printf("%s, ", whiteTable[i].code);
		g4PrintRegister(bits);
		printf("\n");
	}

	nSize = (sizeof(blackTable) / sizeof(blackTable[0]) );
	printf("(): nSize = %d\n", nSize);

	/*
	** First thing first, generate the bit pattern
	*/

	for (i = 0; i < nSize; i++) {
		bits = 0x00000000;
		ln = strlen(blackTable[i].code);
		ptr = blackTable[i].code;
		for (x = 0; x < ln; x++) {
			if (*ptr == '0') {
				bits |= 0;
			}
			else
			if (*ptr == '1') {
				bits |= 1;
			}
			bits <<= 1;
			ptr++;
		}
		bits <<= (15 - ln);
		myBlack[i].bitLength = strlen(blackTable[i].code);
		myBlack[i].bits = bits;
		printf("%d, ", i);
		printf("%s, ", blackTable[i].code);
		g4PrintRegister(bits);
		printf("\n");
	}

	myTableInit = 1;
}

/* ********************************************************************** */

void
g4Print8BitsXFill(char *ptr)
{
int ln;
int x;

	ln = strlen(ptr);
	for (x = 0; x < 8; x++) {
		if (x < ln) {
			printf("%c", *ptr);
			ptr++;
		}
		else {
			printf("x");
		}
		if ( ((x + 1) % 4) == 0) {
			if ( (x + 1) != 8) {
				printf("-");
			}
		}
	}
}

/* ********************************************************************** */

void
g4PrintByteN(char *ptr, int bitLength, int bCount)
{
int x;
int ln;
int val;
int i;

	ln = strlen(ptr);
	val = bitLength;

	x = 0;
	for (i = val; i > 0; i--) {

		if ( (i % 4) == 0) {
			if (i != 0) {
				printf("-");
			}
		}

		if (x == bCount) {
			printf(" # ");
		}

		if (x < ln) {
			printf("%c", *ptr);
			ptr++;
		}
		else {
			printf("x");
		}

		x++;
	}
}

/* ********************************************************************** */

void
g4PrintByteNxFill(char *ptr, int bitLength, int bCount)
{
int x;
int ln;
int val;
int i;

	ln = strlen(ptr);
	val = bitLength;

	x = 0;
	for (i = val; i > 0; i--) {

		if ( (i % 4) == 0) {
			if (i != val) {
				printf("-");
			}
		}

		if (x == bCount) {
			printf(" # ");
		}

		if (x < ln) {
			printf("%c", *ptr);
			ptr++;
		}
		else {
			printf("x");
		}

		x++;
	}

	if ( (val % 4) != 0) {
		for (i = 0; i < (4 - (val % 4)); i++) {
			printf("x");
		}
	}
}

/* ********************************************************************** */

void
g5Table1()
{
int i;
int x;
int match;
WORD mask;
DWORD bits;

	if (myTableInit == 0) {
		g5TableInit();
	}

#define MAX_CODES	256

	printf("STATIC int nWCodeByte0ToRunLength[%d] = {\n", MAX_CODES);

	for (i = 0; i < MAX_CODES; i++) {

		printf("/* %3d */\t", i);

		bits = 0x00000000;

		/*
		** Make sure the current entry matches the
		** array index.
		*/

#define MAX_LOOK	104

		match = -1;

		for (x = 0; x < MAX_LOOK; x++) {

			/*
			** We're trying to match 8 bits
			** If the bit pattern is > 8, we
			** can't match - it will be ambiguous.
			*/

			if (myWhite[x].bitLength > 8) {
				continue;
			}

			mask = bitMasks[myWhite[x].bitLength];

			if ( (BYTE) (i & (mask >> 8)) == (BYTE) ((myWhite[x].bits & mask) >> 8) ) {
				/*
				** We have a match.
				** Keep the shorter of the patterns.
				*/
				if (match == -1) {
					match = x;
				}
				else {
					if (myWhite[x].bitLength < myWhite[match].bitLength) {
						match = x;
					}
				}
			}
		}

		if (match == -1) {
			printf("%d,", match);
		}
		else {
			printf("%d,", whiteTable[match].run_len);
		}

		printf("\t/* ");
		g4PrintByte(i);
		if (match != -1) {
			printf(", run length: %4d, ", whiteTable[match].run_len);
			g4Print8BitsXFill(whiteTable[match].code);
		}
		printf(" */\n");
	}
	printf("};\n");
}

/* ********************************************************************** */

void
g5Table2()
{
int i;
int x;
int match;
WORD mask;
DWORD bits;

	if (myTableInit == 0) {
		g5TableInit();
	}

#define MAX_CODES	256

	printf("STATIC BYTE nWCodeByte0ToCodeWordLength[%d] = {\n", MAX_CODES);

	for (i = 0; i < MAX_CODES; i++) {

		printf("/* %3d */\t", i);

		bits = 0x00000000;

		/*
		** Make sure the current entry matches the
		** array index.
		*/

#define MAX_LOOK	104

		match = -1;

		for (x = 0; x < MAX_LOOK; x++) {

			/*
			** We're trying to match 8 bits
			** If the bit pattern is > 8, we
			** can't match - it will be ambiguous.
			*/

			if (myWhite[x].bitLength > 8) {
				continue;
			}


			mask = bitMasks[myWhite[x].bitLength];

			if ( (BYTE) (i & (mask >> 8)) == (BYTE) ((myWhite[x].bits & mask) >> 8) ) {
				/*
				** We have a match.
				** Keep the shorter of the patterns.
				*/
				if (match == -1) {
					match = x;
				}
				else {
					if (myWhite[x].bitLength < myWhite[match].bitLength) {
						match = x;
					}
				}
			}
		}

		if (match == -1) {
			printf("%d, ", 1);
		}
		else {
			printf("%d, ", myWhite[match].bitLength);
		}

		printf("\t/* ");
		g4PrintByte(i);
		if (match != -1) {
			printf(", run length: %4d, ", whiteTable[match].run_len);

			g4Print8BitsXFill(whiteTable[match].code);
		}
		printf(" */\n");
	}
	printf("};\n");
}

/* ********************************************************************** */

void
g5Table3()
{
int i;
int x;
int match;
WORD mask;
DWORD bits;
int val;

	if (myTableInit == 0) {
		g5TableInit();
	}

#define MAX_CODES	256

	printf("STATIC int nWCodeByte1ToRunLength[%d] = {\n", MAX_CODES);

	for (i = 0; i < MAX_CODES; i++) {

		printf("/* %3d */\t", i);

		bits = 0x00000000;

		/*
		** Make sure the current entry matches the
		** array index.
		*/

#define MAX_LOOK	104

		match = -1;

		for (x = 0; x < MAX_LOOK; x++) {

			/*
			** We're trying to match 8 bits
			** If the bit pattern is > 8, we
			** can't match - it will be ambiguous.
			*/

			if (myWhite[x].bitLength != 9) {
				continue;
			}


			mask = bitMasks[myWhite[x].bitLength];

			val = myWhite[x].bits;

			/*
			** Shift out the top bits
			*/

			val <<= (myWhite[x].bitLength - 8);

			if ( i == (BYTE) ((val & 0xff00) >> 8) ) {
				/*
				** We have a match.
				** Keep the shorter of the patterns.
				*/
				if (match == -1) {
					match = x;
				}
				else {
					if (myWhite[x].bitLength < myWhite[match].bitLength) {
						match = x;
					}
				}
			}
		}

		if (match == -1) {
			printf("BAD_DATA,");
		}
		else {
			printf("%d,", whiteTable[match].run_len);
		}

		printf("\t/* ");
		g4PrintByte(i);
		if (match != -1) {
			printf(", make-up code: ");
			g4PrintByteN(whiteTable[match].code,
				myWhite[match].bitLength,
				1);
		}
		printf(" */\n");
	}
	printf("};\n");
}

/* ********************************************************************** */

void
g5Table4()
{
int i;
int x;
int match;
WORD mask;
DWORD bits;
int val;

	if (myTableInit == 0) {
		g5TableInit();
	}

#define MAX_CODES	256

	printf("STATIC int nWCodeByte1ToCodeWordLength[%d] = {\n", MAX_CODES);

	for (i = 0; i < MAX_CODES; i++) {

		printf("/* %3d */\t", i);

		bits = 0x00000000;

		/*
		** Make sure the current entry matches the
		** array index.
		*/

#define MAX_LOOK	104

		match = -1;

		for (x = 0; x < MAX_LOOK; x++) {

			/*
			** We're trying to match 8 bits
			** If the bit pattern is > 8, we
			** can't match - it will be ambiguous.
			*/

			if (myWhite[x].bitLength != 9) {
				continue;
			}


			mask = bitMasks[myWhite[x].bitLength];

			val = myWhite[x].bits;

			/*
			** Shift out the top bits
			*/

			val <<= (myWhite[x].bitLength - 8);

			if ( i == (BYTE) ((val & 0xff00) >> 8) ) {
				/*
				** We have a match.
				** Keep the shorter of the patterns.
				*/
				if (match == -1) {
					match = x;
				}
				else {
					if (myWhite[x].bitLength < myWhite[match].bitLength) {
						match = x;
					}
				}
			}
		}

		if (match == -1) {
			printf("%d, ", 0);
		}
		else {
			if (myWhite[match].bitLength > 8) {
				printf("%d, ", 8);
			}
			else {
				printf("%d, ", myWhite[match].bitLength);
			}
		}

		printf("\t/* ");
		g4PrintByte(i);
		if (match != -1) {
			printf(", run length: %4d, ", whiteTable[match].run_len);

			g4PrintByteN(whiteTable[match].code,
				myWhite[match].bitLength,
				1);
		}
		printf(" */\n");
	}
	printf("};\n");
}

/* ********************************************************************** */

void
g5Table5()
{
int i;
int x;
int match;
WORD mask;
DWORD bits;
int val;

	if (myTableInit == 0) {
		g5TableInit();
	}

#define MAX_CODES	256

	printf("STATIC int nWCodeByte4ToRunLength[%d] = {\n", MAX_CODES);

	for (i = 0; i < MAX_CODES; i++) {

		printf("/* %3d */\t", i);

		bits = 0x00000000;

		/*
		** Make sure the current entry matches the
		** array index.
		*/

#define MAX_LOOK	104

		match = -1;

		for (x = 0; x < MAX_LOOK; x++) {

			/*
			** We're trying to match 8 bits
			** If the bit pattern is > 8, we
			** can't match - it will be ambiguous.
			*/

			if (myWhite[x].bitLength < 10) {
				continue;
			}


			mask = bitMasks[myWhite[x].bitLength];

			val = myWhite[x].bits;

			/*
			** Shift out the top bits
			*/

			val <<= 4;
			mask = bitMasks[ (myWhite[x].bitLength - 4) ];

			if ( (BYTE) (i & (mask >> 8)) == (BYTE) ((val & mask) >> 8) ) {
				/*
				** We have a match.
				** Keep the shorter of the patterns.
				*/
				if (match == -1) {
					match = x;
				}
				else {
					if (myWhite[x].bitLength < myWhite[match].bitLength) {
						match = x;
					}
				}
			}
		}

		if (match == -1) {
			printf("BAD_DATA, ");
		}
		else {
			printf("%d, ", whiteTable[match].run_len);
		}

		printf("\t/* ");
		g4PrintByte(i);
		if (match != -1) {
			printf(", make-up code: ");
			g4PrintByteNxFill(whiteTable[match].code,
				myWhite[match].bitLength,
				4);

		}
		printf(" */\n");
	}
	printf("};\n");
}

/* ********************************************************************** */

void
g5Table6()
{
int i;
int x;
int match;
WORD mask;
DWORD bits;
int val;

	if (myTableInit == 0) {
		g5TableInit();
	}

#define MAX_CODES	256

	printf("STATIC int nWCodeByte4ToCodeWordLength[%d] = {\n", MAX_CODES);

	for (i = 0; i < MAX_CODES; i++) {

		printf("/* %3d */\t", i);

		bits = 0x00000000;

		/*
		** Make sure the current entry matches the
		** array index.
		*/

#define MAX_LOOK	104

		match = -1;

		for (x = 0; x < MAX_LOOK; x++) {

			/*
			** We're trying to match 8 bits
			** If the bit pattern is > 8, we
			** can't match - it will be ambiguous.
			*/

			if (myWhite[x].bitLength < 10) {
				continue;
			}


			mask = bitMasks[myWhite[x].bitLength];

			val = myWhite[x].bits;

			/*
			** Shift out the top bits
			*/

			val <<= 4;
			mask = bitMasks[ (myWhite[x].bitLength - 4) ];

			if ( (BYTE) (i & (mask >> 8)) == (BYTE) ((val & mask) >> 8) ) {
				/*
				** We have a match.
				** Keep the shorter of the patterns.
				*/
				if (match == -1) {
					match = x;
				}
				else {
					if (myWhite[x].bitLength < myWhite[match].bitLength) {
						match = x;
					}
				}
			}
		}

		if (match == -1) {
			printf("%d, ", 0);
		}
		else {
			printf("%d, ", (myWhite[match].bitLength - 4) );
		}

		printf("\t/* ");
		g4PrintByte(i);
		if (match != -1) {
			printf(", run length: %4d, ", whiteTable[match].run_len);

			g4PrintByteNxFill(whiteTable[match].code,
				myWhite[match].bitLength,
				4);
		}
		printf(" */\n");
	}
	printf("};\n");
}

/* ********************************************************************** */

void
g5Table7()
{
int i;
int x;
int match;
WORD mask;
DWORD bits;

	if (myTableInit == 0) {
		g5TableInit();
	}

#define MAX_CODES	256

	printf("STATIC int nBCodeByte0ToRunLength[%d] = {\n", MAX_CODES);

	for (i = 0; i < MAX_CODES; i++) {

		printf("/* %3d */\t", i);

		bits = 0x00000000;

		/*
		** Make sure the current entry matches the
		** array index.
		*/

#define MAX_LOOK	104

		match = -1;

		for (x = 0; x < MAX_LOOK; x++) {

			/*
			** We're trying to match 8 bits
			** If the bit pattern is > 8, we
			** can't match - it will be ambiguous.
			*/

			if (myBlack[x].bitLength > 8) {
				continue;
			}


			mask = bitMasks[myBlack[x].bitLength];

			if ( (BYTE) (i & (mask >> 8)) == (BYTE) ((myBlack[x].bits & mask) >> 8) ) {
				/*
				** We have a match.
				** Keep the shorter of the patterns.
				*/
				if (match == -1) {
					match = x;
				}
				else {
					if (myBlack[x].bitLength < myBlack[match].bitLength) {
						match = x;
					}
				}
			}
		}

		if (match == -1) {
			printf("%d, ", match);
		}
		else {
			printf("%d, ", blackTable[match].run_len);
		}

		printf("\t/* ");
		g4PrintByte(i);
		if (match != -1) {
			printf(", run length: %4d, ", blackTable[match].run_len);

			g4Print8BitsXFill(blackTable[match].code);
		}
		printf(" */\n");
	}
	printf("};\n");
}

/* ********************************************************************** */

void
g5Table8()
{
int i;
int x;
int match;
WORD mask;
DWORD bits;

	if (myTableInit == 0) {
		g5TableInit();
	}

#define MAX_CODES	256

	printf("STATIC int nBCodeByte0ToCodeWordLength[%d] = {\n", MAX_CODES);

	for (i = 0; i < MAX_CODES; i++) {

		printf("/* %3d */\t", i);

		bits = 0x00000000;

		/*
		** Make sure the current entry matches the
		** array index.
		*/

#define MAX_LOOK	104

		match = -1;

		for (x = 0; x < MAX_LOOK; x++) {

			/*
			** We're trying to match 8 bits
			** If the bit pattern is > 8, we
			** can't match - it will be ambiguous.
			*/

			if (myBlack[x].bitLength > 8) {
				continue;
			}


			mask = bitMasks[myBlack[x].bitLength];

			if ( (BYTE) (i & (mask >> 8)) == (BYTE) ((myBlack[x].bits & mask) >> 8) ) {
				/*
				** We have a match.
				** Keep the shorter of the patterns.
				*/
				if (match == -1) {
					match = x;
				}
				else {
					if (myBlack[x].bitLength < myBlack[match].bitLength) {
						match = x;
					}
				}
			}
		}

		if (match == -1) {
			printf("%d, ", match);
		}
		else {
			printf("%d, ", myBlack[match].bitLength);
		}

		printf("\t/* ");
		g4PrintByte(i);
		if (match != -1) {
			printf(", run length: %4d, ", blackTable[match].run_len);

			g4Print8BitsXFill(blackTable[match].code);
		}
		printf(" */\n");
	}
	printf("};\n");
}

#endif	/* GEN_TABLES */

/* ********************************************************************** */

STATIC int nBCodeByte4ToRunLength[256] = {
/*   0 */	-9,  -9,  -9,  -9,  -9,  -9,  -9,  -9,
/*   8 */	-9,  -9,  -9,  -9,  -9,  -9,  -9,  -9,
/*  16 */	-9,  -9,  -9,  -9,  -9,  -9,  -9,  -9,
/*  24 */	-9,  -9,  -9,  -9,  -9,  -9,  -9,  -9,
/*  32 */	-9,  -9,  -9,  -9,  -9,  -9,  -9,  -9,
/*  40 */	-9,  -9,  -9,  -9,  -9,  -9,  -9,  -9,
/*  48 */	-9,  -9,  -9,  -9,  -9,  -9,  -9,  -9,
/*  56 */	-9,  -9,  -9,  -9,  -9,  -9,  -9,  -9,
/*  64 */	-9,  -9,  -9,  -9,  -9,  -9,  -9,  -9,
/*  72 */	-9,  -9,  -9,  -9,  -9,  -9,  -9,  -9,

/*  80 */	23,	/* 0101-0000, run length:  23, 000-0 # 010-1000x */
/*  81 */	23,	/* 0101-0001, run length:  23, 000-0 # 010-1000x */
/*  82 */	50,	/* 0101-0010, run length:  50, 0000- # 0101-0010 */
/*  83 */	51,	/* 0101-0011, run length:  51, 0000- # 0101-0011 */
/*  84 */	44,	/* 0101-0100, run length:  44, 0000- # 0101-0100 */
/*  85 */	45,	/* 0101-0101, run length:  45, 0000- # 0101-0101 */
/*  86 */	46,	/* 0101-0110, run length:  46, 0000- # 0101-0110 */
/*  87 */	47,	/* 0101-0111, run length:  47, 0000- # 0101-0111 */
/*  88 */	57,	/* 0101-1000, run length:  57, 0000- # 0101-1000 */
/*  89 */	58,	/* 0101-1001, run length:  58, 0000- # 0101-1001 */
/*  90 */	61,	/* 0101-1010, run length:  61, 0000- # 0101-1010 */
/*  91 */	256,	/* 0101-1011, run length: 256, 0000- # 0101-1011 */
/*  92 */	16,	/* 0101-1100, run length:  16, 00-00 # 01-0111xx */
/*  93 */	16,	/* 0101-1101, run length:  16, 00-00 # 01-0111xx */
/*  94 */	16,	/* 0101-1110, run length:  16, 00-00 # 01-0111xx */
/*  95 */	16,	/* 0101-1111, run length:  16, 00-00 # 01-0111xx */
/*  96 */	17,	/* 0110-0000, run length:  17, 00-00 # 01-1000xx */
/*  97 */	17,	/* 0110-0001, run length:  17, 00-00 # 01-1000xx */
/*  98 */	17,	/* 0110-0010, run length:  17, 00-00 # 01-1000xx */
/*  99 */	17,	/* 0110-0011, run length:  17, 00-00 # 01-1000xx */
/* 100 */	48,	/* 0110-0100, run length:  48, 0000- # 0110-0100 */
/* 101 */	49,	/* 0110-0101, run length:  49, 0000- # 0110-0101 */
/* 102 */	62,	/* 0110-0110, run length:  62, 0000- # 0110-0110 */
/* 103 */	63,	/* 0110-0111, run length:  63, 0000- # 0110-0111 */
/* 104 */	30,	/* 0110-1000, run length:  30, 0000- # 0110-1000 */
/* 105 */	31,	/* 0110-1001, run length:  31, 0000- # 0110-1001 */
/* 106 */	32,	/* 0110-1010, run length:  32, 0000- # 0110-1010 */
/* 107 */	33,	/* 0110-1011, run length:  33, 0000- # 0110-1011 */
/* 108 */	40,	/* 0110-1100, run length:  40, 0000- # 0110-1100 */
/* 109 */	41,	/* 0110-1101, run length:  41, 0000- # 0110-1101 */
/* 110 */	22,	/* 0110-1110, run length:  22, 000-0 # 011-0111x */
/* 111 */	22,	/* 0110-1111, run length:  22, 000-0 # 011-0111x */
/* 112 */	-9,  -9,  -9,  -9,  -9,  -9,  -9,  -9,
/* 120 */	-9,  -9,  -9,  -9,  -9,  -9,  -9,  -9,
/* 128 */	-9,  -9,  -9,  -9,  -9,  -9,  -9,  -9,
/* 136 */	-9,  -9,  -9,  -9,  -9,  -9,  -9,  -9,
/* 144 */	-9,  -9,  -9,  -9,  -9,  -9,  -9,  -9,
/* 152 */	-9,  -9,  -9,  -9,  -9,  -9,  -9,  -9,
/* 160 */	-9,  -9,  -9,  -9,  -9,  -9,  -9,  -9,
/* 168 */	-9,  -9,  -9,  -9,  -9,  -9,  -9,  -9,
/* 176 */	-9,  -9,  -9,  -9,  -9,  -9,  -9,  -9,
/* 184 */	-9,  -9,  -9,  -9,  -9,  -9,  -9,  -9,
/* 192 */	15,	/* 1100-0000, run length:  15, 0-000 # 1-1000xx */
/* 193 */	15,	/* 1100-0001, run length:  15, 0-000 # 1-1000xx */
/* 194 */	15,	/* 1100-0010, run length:  15, 0-000 # 1-1000xx */
/* 195 */	15,	/* 1100-0011, run length:  15, 0-000 # 1-1000xx */
/* 196 */	15,	/* 1100-0100, run length:  15, 0-000 # 1-1000xx */
/* 197 */	15,	/* 1100-0101, run length:  15, 0-000 # 1-1000xx */
/* 198 */	15,	/* 1100-0110, run length:  15, 0-000 # 1-1000xx */
/* 199 */	15,	/* 1100-0111, run length:  15, 0-000 # 1-1000xx */
/* 200 */	128,	/* 1100-1000, run length: 128, 0000- # 1100-1000 */
/* 201 */	192,	/* 1100-1001, run length: 192, 0000- # 1100-1001 */
/* 202 */	26,	/* 1100-1010, run length:  26, 0000- # 1100-1010 */
/* 203 */	27,	/* 1100-1011, run length:  27, 0000- # 1100-1011 */
/* 204 */	28,	/* 1100-1100, run length:  28, 0000- # 1100-1100 */
/* 205 */	29,	/* 1100-1101, run length:  29, 0000- # 1100-1101 */
/* 206 */	19,	/* 1100-1110, run length:  19, 000-0 # 110-0111x */
/* 207 */	19,	/* 1100-1111, run length:  19, 000-0 # 110-0111x */
/* 208 */	20,	/* 1101-0000, run length:  20, 000-0 # 110-1000x */
/* 209 */	20,	/* 1101-0001, run length:  20, 000-0 # 110-1000x */
/* 210 */	34,	/* 1101-0010, run length:  34, 0000- # 1101-0010 */
/* 211 */	35,	/* 1101-0011, run length:  35, 0000- # 1101-0011 */
/* 212 */	36,	/* 1101-0100, run length:  36, 0000- # 1101-0100 */
/* 213 */	37,	/* 1101-0101, run length:  37, 0000- # 1101-0101 */
/* 214 */	38,	/* 1101-0110, run length:  38, 0000- # 1101-0110 */
/* 215 */	39,	/* 1101-0111, run length:  39, 0000- # 1101-0111 */
/* 216 */	21,	/* 1101-1000, run length:  21, 000-0 # 110-1100x */
/* 217 */	21,	/* 1101-1001, run length:  21, 000-0 # 110-1100x */
/* 218 */	42,	/* 1101-1010, run length:  42, 0000- # 1101-1010 */
/* 219 */	43,	/* 1101-1011, run length:  43, 0000- # 1101-1011 */
/* 220 */	0,	/* 1101-1100, run length:   0, 00-00 # 11-0111xx */
/* 221 */	0,	/* 1101-1101, run length:   0, 00-00 # 11-0111xx */
/* 222 */	0,	/* 1101-1110, run length:   0, 00-00 # 11-0111xx */
/* 223 */	0,	/* 1101-1111, run length:   0, 00-00 # 11-0111xx */
/* 224 */	12,	/* 1110-0000, run length:  12, 000-0 # 111xxxxxx */
/* 225 */	12,	/* 1110-0001, run length:  12, 000-0 # 111xxxxxx */
/* 226 */	12,	/* 1110-0010, run length:  12, 000-0 # 111xxxxxx */
/* 227 */	12,	/* 1110-0011, run length:  12, 000-0 # 111xxxxxx */
/* 228 */	12,	/* 1110-0100, run length:  12, 000-0 # 111xxxxxx */
/* 229 */	12,	/* 1110-0101, run length:  12, 000-0 # 111xxxxxx */
/* 230 */	12,	/* 1110-0110, run length:  12, 000-0 # 111xxxxxx */
/* 231 */	12,	/* 1110-0111, run length:  12, 000-0 # 111xxxxxx */
/* 232 */	12,	/* 1110-1000, run length:  12, 000-0 # 111xxxxxx */
/* 233 */	12,	/* 1110-1001, run length:  12, 000-0 # 111xxxxxx */
/* 234 */	12,	/* 1110-1010, run length:  12, 000-0 # 111xxxxxx */
/* 235 */	12,	/* 1110-1011, run length:  12, 000-0 # 111xxxxxx */
/* 236 */	12,	/* 1110-1100, run length:  12, 000-0 # 111xxxxxx */
/* 237 */	12,	/* 1110-1101, run length:  12, 000-0 # 111xxxxxx */
/* 238 */	12,	/* 1110-1110, run length:  12, 000-0 # 111xxxxxx */
/* 239 */	12,	/* 1110-1111, run length:  12, 000-0 # 111xxxxxx */
/* 240 */	12,	/* 1111-0000, run length:  12, 000-0 # 111xxxxxx */
/* 241 */	12,	/* 1111-0001, run length:  12, 000-0 # 111xxxxxx */
/* 242 */	12,	/* 1111-0010, run length:  12, 000-0 # 111xxxxxx */
/* 243 */	12,	/* 1111-0011, run length:  12, 000-0 # 111xxxxxx */
/* 244 */	12,	/* 1111-0100, run length:  12, 000-0 # 111xxxxxx */
/* 245 */	12,	/* 1111-0101, run length:  12, 000-0 # 111xxxxxx */
/* 246 */	12,	/* 1111-0110, run length:  12, 000-0 # 111xxxxxx */
/* 247 */	12,	/* 1111-0111, run length:  12, 000-0 # 111xxxxxx */
/* 248 */	12,	/* 1111-1000, run length:  12, 000-0 # 111xxxxxx */
/* 249 */	12,	/* 1111-1001, run length:  12, 000-0 # 111xxxxxx */
/* 250 */	12,	/* 1111-1010, run length:  12, 000-0 # 111xxxxxx */
/* 251 */	12,	/* 1111-1011, run length:  12, 000-0 # 111xxxxxx */
/* 252 */	12,	/* 1111-1100, run length:  12, 000-0 # 111xxxxxx */
/* 253 */	12,	/* 1111-1101, run length:  12, 000-0 # 111xxxxxx */
/* 254 */	12,	/* 1111-1110, run length:  12, 000-0 # 111xxxxxx */
/* 255 */	12	/* 1111-1111, run length:  12, 000-0 # 111xxxxxx */
};

STATIC BYTE nBCodeByte4ToCodeWordLength[256] = {
/*   0 */	0,   0,   0,   0,   0,   0,   0,   0,
/*   8 */	0,   0,   0,   0,   0,   0,   0,   0,
/*  16 */	0,   0,   0,   0,   0,   0,   0,   0,
/*  24 */	0,   0,   0,   0,   0,   0,   0,   0,
/*  32 */	0,   0,   0,   0,   0,   0,   0,   0,
/*  40 */	0,   0,   0,   0,   0,   0,   0,   0,
/*  48 */	0,   0,   0,   0,   0,   0,   0,   0,
/*  56 */	0,   0,   0,   0,   0,   0,   0,   0,
/*  64 */	0,   0,   0,   0,   0,   0,   0,   0,
/*  72 */	0,   0,   0,   0,   0,   0,   0,   0,
/*  80 */	7,	/* 0101-0000, run length:  23, 000-0 # 010-1000x */
/*  81 */	7,	/* 0101-0001, run length:  23, 000-0 # 010-1000x */
/*  82 */	8,	/* 0101-0010, run length:  50, 0000- # 0101-0010 */
/*  83 */	8,	/* 0101-0011, run length:  51, 0000- # 0101-0011 */
/*  84 */	8,	/* 0101-0100, run length:  44, 0000- # 0101-0100 */
/*  85 */	8,	/* 0101-0101, run length:  45, 0000- # 0101-0101 */
/*  86 */	8,	/* 0101-0110, run length:  46, 0000- # 0101-0110 */
/*  87 */	8,	/* 0101-0111, run length:  47, 0000- # 0101-0111 */
/*  88 */	8,	/* 0101-1000, run length:  57, 0000- # 0101-1000 */
/*  89 */	8,	/* 0101-1001, run length:  58, 0000- # 0101-1001 */
/*  90 */	8,	/* 0101-1010, run length:  61, 0000- # 0101-1010 */
/*  91 */	8,	/* 0101-1011, run length: 256, 0000- # 0101-1011 */
/*  92 */	6,	/* 0101-1100, run length:  16, 00-00 # 01-0111xx */
/*  93 */	6,	/* 0101-1101, run length:  16, 00-00 # 01-0111xx */
/*  94 */	6,	/* 0101-1110, run length:  16, 00-00 # 01-0111xx */
/*  95 */	6,	/* 0101-1111, run length:  16, 00-00 # 01-0111xx */
/*  96 */	6,	/* 0110-0000, run length:  17, 00-00 # 01-1000xx */
/*  97 */	6,	/* 0110-0001, run length:  17, 00-00 # 01-1000xx */
/*  98 */	6,	/* 0110-0010, run length:  17, 00-00 # 01-1000xx */
/*  99 */	6,	/* 0110-0011, run length:  17, 00-00 # 01-1000xx */
/* 100 */	8,	/* 0110-0100, run length:  48, 0000- # 0110-0100 */
/* 101 */	8,	/* 0110-0101, run length:  49, 0000- # 0110-0101 */
/* 102 */	8,	/* 0110-0110, run length:  62, 0000- # 0110-0110 */
/* 103 */	8,	/* 0110-0111, run length:  63, 0000- # 0110-0111 */
/* 104 */	8,	/* 0110-1000, run length:  30, 0000- # 0110-1000 */
/* 105 */	8,	/* 0110-1001, run length:  31, 0000- # 0110-1001 */
/* 106 */	8,	/* 0110-1010, run length:  32, 0000- # 0110-1010 */
/* 107 */	8,	/* 0110-1011, run length:  33, 0000- # 0110-1011 */
/* 108 */	8,	/* 0110-1100, run length:  40, 0000- # 0110-1100 */
/* 109 */	8,	/* 0110-1101, run length:  41, 0000- # 0110-1101 */
/* 110 */	7,	/* 0110-1110, run length:  22, 000-0 # 011-0111x */
/* 111 */	7,	/* 0110-1111, run length:  22, 000-0 # 011-0111x */
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
/* 192 */	5,	/* 1100-0000, run length:  15, 0-000 # 1-1000xx */
/* 193 */	5,	/* 1100-0001, run length:  15, 0-000 # 1-1000xx */
/* 194 */	5,	/* 1100-0010, run length:  15, 0-000 # 1-1000xx */
/* 195 */	5,	/* 1100-0011, run length:  15, 0-000 # 1-1000xx */
/* 196 */	5,	/* 1100-0100, run length:  15, 0-000 # 1-1000xx */
/* 197 */	5,	/* 1100-0101, run length:  15, 0-000 # 1-1000xx */
/* 198 */	5,	/* 1100-0110, run length:  15, 0-000 # 1-1000xx */
/* 199 */	5,	/* 1100-0111, run length:  15, 0-000 # 1-1000xx */
/* 200 */	8,	/* 1100-1000, run length: 128, 0000- # 1100-1000 */
/* 201 */	8,	/* 1100-1001, run length: 192, 0000- # 1100-1001 */
/* 202 */	8,	/* 1100-1010, run length:  26, 0000- # 1100-1010 */
/* 203 */	8,	/* 1100-1011, run length:  27, 0000- # 1100-1011 */
/* 204 */	8,	/* 1100-1100, run length:  28, 0000- # 1100-1100 */
/* 205 */	8,	/* 1100-1101, run length:  29, 0000- # 1100-1101 */
/* 206 */	7,	/* 1100-1110, run length:  19, 000-0 # 110-0111x */
/* 207 */	7,	/* 1100-1111, run length:  19, 000-0 # 110-0111x */
/* 208 */	7,	/* 1101-0000, run length:  20, 000-0 # 110-1000x */
/* 209 */	7,	/* 1101-0001, run length:  20, 000-0 # 110-1000x */
/* 210 */	8,	/* 1101-0010, run length:  34, 0000- # 1101-0010 */
/* 211 */	8,	/* 1101-0011, run length:  35, 0000- # 1101-0011 */
/* 212 */	8,	/* 1101-0100, run length:  36, 0000- # 1101-0100 */
/* 213 */	8,	/* 1101-0101, run length:  37, 0000- # 1101-0101 */
/* 214 */	8,	/* 1101-0110, run length:  38, 0000- # 1101-0110 */
/* 215 */	8,	/* 1101-0111, run length:  39, 0000- # 1101-0111 */
/* 216 */	7,	/* 1101-1000, run length:  21, 000-0 # 110-1100x */
/* 217 */	7,	/* 1101-1001, run length:  21, 000-0 # 110-1100x */
/* 218 */	8,	/* 1101-1010, run length:  42, 0000- # 1101-1010 */
/* 219 */	8,	/* 1101-1011, run length:  43, 0000- # 1101-1011 */
/* 220 */	6,	/* 1101-1100, run length:   0, 00-00 # 11-0111xx */
/* 221 */	6,	/* 1101-1101, run length:   0, 00-00 # 11-0111xx */
/* 222 */	6,	/* 1101-1110, run length:   0, 00-00 # 11-0111xx */
/* 223 */	6,	/* 1101-1111, run length:   0, 00-00 # 11-0111xx */
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0
};

STATIC int nBCodeByte5ToRunLength[256] = {
/*   0 */	-7,   -7,   -7,   -7,   -9,   -9,   -9,   -9,
/*   8 */	-9,   -9,   -9,   -9,   -9,   -9,   -9,   -9,
/*  16 */	-9,   -9,   -9,   -9,   -9,   -9,   -9,   -9,
/*  24 */	-9,   -9,   -9,   -9,   -9,   -9,   -9,   -9,
/*  32 */	1792,	/* 0010-0000, run length: 1792, 000-00 # 00-1000xx */
/*  33 */	1792,	/* 0010-0001, run length: 1792, 000-00 # 00-1000xx */
/*  34 */	1792,	/* 0010-0010, run length: 1792, 000-00 # 00-1000xx */
/*  35 */	1792,	/* 0010-0011, run length: 1792, 000-00 # 00-1000xx */
/*  36 */	1984,	/* 0010-0100, run length: 1984, 0000-0 # 001-0010x */
/*  37 */	1984,	/* 0010-0101, run length: 1984, 0000-0 # 001-0010x */
/*  38 */	2048,	/* 0010-0110, run length: 2048, 0000-0 # 001-0011x */
/*  39 */	2048,	/* 0010-0111, run length: 2048, 0000-0 # 001-0011x */
/*  40 */	2112,	/* 0010-1000, run length: 2112, 0000-0 # 001-0100x */
/*  41 */	2112,	/* 0010-1001, run length: 2112, 0000-0 # 001-0100x */
/*  42 */	2176,	/* 0010-1010, run length: 2176, 0000-0 # 001-0101x */
/*  43 */	2176,	/* 0010-1011, run length: 2176, 0000-0 # 001-0101x */
/*  44 */	2240,	/* 0010-1100, run length: 2240, 0000-0 # 001-0110x */
/*  45 */	2240,	/* 0010-1101, run length: 2240, 0000-0 # 001-0110x */
/*  46 */	2304,	/* 0010-1110, run length: 2304, 0000-0 # 001-0111x */
/*  47 */	2304,	/* 0010-1111, run length: 2304, 0000-0 # 001-0111x */
/*  48 */	1856,	/* 0011-0000, run length: 1856, 000-00 # 00-1100xx */
/*  49 */	1856,	/* 0011-0001, run length: 1856, 000-00 # 00-1100xx */
/*  50 */	1856,	/* 0011-0010, run length: 1856, 000-00 # 00-1100xx */
/*  51 */	1856,	/* 0011-0011, run length: 1856, 000-00 # 00-1100xx */
/*  52 */	1920,	/* 0011-0100, run length: 1920, 000-00 # 00-1101xx */
/*  53 */	1920,	/* 0011-0101, run length: 1920, 000-00 # 00-1101xx */
/*  54 */	1920,	/* 0011-0110, run length: 1920, 000-00 # 00-1101xx */
/*  55 */	1920,	/* 0011-0111, run length: 1920, 000-00 # 00-1101xx */
/*  56 */	2368,	/* 0011-1000, run length: 2368, 0000-0 # 001-1100x */
/*  57 */	2368,	/* 0011-1001, run length: 2368, 0000-0 # 001-1100x */
/*  58 */	2432,	/* 0011-1010, run length: 2432, 0000-0 # 001-1101x */
/*  59 */	2432,	/* 0011-1011, run length: 2432, 0000-0 # 001-1101x */
/*  60 */	2496,	/* 0011-1100, run length: 2496, 0000-0 # 001-1110x */
/*  61 */	2496,	/* 0011-1101, run length: 2496, 0000-0 # 001-1110x */
/*  62 */	2560,	/* 0011-1110, run length: 2560, 0000-0 # 001-1111x */
/*  63 */	2560,	/* 0011-1111, run length: 2560, 0000-0 # 001-1111x */
/*  64 */	18,	/* 0100-0000, run length:   18, 00-000 # 01-000xxx */
/*  65 */	18,	/* 0100-0001, run length:   18, 00-000 # 01-000xxx */
/*  66 */	18,	/* 0100-0010, run length:   18, 00-000 # 01-000xxx */
/*  67 */	18,	/* 0100-0011, run length:   18, 00-000 # 01-000xxx */
/*  68 */	18,	/* 0100-0100, run length:   18, 00-000 # 01-000xxx */
/*  69 */	18,	/* 0100-0101, run length:   18, 00-000 # 01-000xxx */
/*  70 */	18,	/* 0100-0110, run length:   18, 00-000 # 01-000xxx */
/*  71 */	18,	/* 0100-0111, run length:   18, 00-000 # 01-000xxx */
/*  72 */	52,	/* 0100-1000, run length:   52, 0000-0 # 010-0100x */
/*  73 */	52,	/* 0100-1001, run length:   52, 0000-0 # 010-0100x */
/*  74 */	640,	/* 0100-1010, run length:  640, 0-0000 # 0100-1010 */
/*  75 */	704,	/* 0100-1011, run length:  704, 0-0000 # 0100-1011 */
/*  76 */	768,	/* 0100-1100, run length:  768, 0-0000 # 0100-1100 */
/*  77 */	832,	/* 0100-1101, run length:  832, 0-0000 # 0100-1101 */
/*  78 */	55,	/* 0100-1110, run length:   55, 0000-0 # 010-0111x */
/*  79 */	55,	/* 0100-1111, run length:   55, 0000-0 # 010-0111x */
/*  80 */	56,	/* 0101-0000, run length:   56, 0000-0 # 010-1000x */
/*  81 */	56,	/* 0101-0001, run length:   56, 0000-0 # 010-1000x */
/*  82 */	1280,	/* 0101-0010, run length: 1280, 0-0000 # 0101-0010 */
/*  83 */	1344,	/* 0101-0011, run length: 1344, 0-0000 # 0101-0011 */
/*  84 */	1408,	/* 0101-0100, run length: 1408, 0-0000 # 0101-0100 */
/*  85 */	1472,	/* 0101-0101, run length: 1472, 0-0000 # 0101-0101 */
/*  86 */	59,	/* 0101-0110, run length:   59, 0000-0 # 010-1011x */
/*  87 */	59,	/* 0101-0111, run length:   59, 0000-0 # 010-1011x */
/*  88 */	60,	/* 0101-1000, run length:   60, 0000-0 # 010-1100x */
/*  89 */	60,	/* 0101-1001, run length:   60, 0000-0 # 010-1100x */
/*  90 */	1536,	/* 0101-1010, run length: 1536, 0-0000 # 0101-1010 */
/*  91 */	1600,	/* 0101-1011, run length: 1600, 0-0000 # 0101-1011 */
/*  91 */	24,	/* 0101-1100, run length:   24, 000-00 # 01-0111xx */
/*  92 */	24,	/* 0101-1101, run length:   24, 000-00 # 01-0111xx */
/*  93 */	24,	/* 0101-1110, run length:   24, 000-00 # 01-0111xx */
/*  94 */	24,	/* 0101-1111, run length:   24, 000-00 # 01-0111xx */
/*  95 */	25,	/* 0110-0000, run length:   25, 000-00 # 01-1000xx */
/*  96 */	25,	/* 0110-0001, run length:   25, 000-00 # 01-1000xx */
/*  97 */	25,	/* 0110-0010, run length:   25, 000-00 # 01-1000xx */
/*  98 */	25,	/* 0110-0011, run length:   25, 000-00 # 01-1000xx */
/*  99 */	1664,	/* 0110-0100, run length: 1664, 0-0000 # 0110-0100 */
/* 100 */	1728,	/* 0110-0101, run length: 1728, 0-0000 # 0110-0101 */
/* 101 */	320,	/* 0110-0110, run length:  320, 0000-0 # 011-0011x */
/* 102 */	320,	/* 0110-0111, run length:  320, 0000-0 # 011-0011x */
/* 103 */	384,	/* 0110-1000, run length:  384, 0000-0 # 011-0100x */
/* 104 */	384,	/* 0110-1001, run length:  384, 0000-0 # 011-0100x */
/* 105 */	448,	/* 0110-1010, run length:  448, 0000-0 # 011-0101x */
/* 106 */	448,	/* 0110-1011, run length:  448, 0000-0 # 011-0101x */
/* 107 */	512,	/* 0110-1100, run length:  512, 0-0000 # 0110-1100 */
/* 108 */	576,	/* 0110-1101, run length:  576, 0-0000 # 0110-1101 */
/* 109 */	53,	/* 0110-1110, run length:   53, 0000-0 # 011-0111x */
/* 110 */	53,	/* 0110-1111, run length:   53, 0000-0 # 011-0111x */
/* 111 */	54,	/* 0111-0000, run length:   54, 0000-0 # 011-1000x */
/* 112 */	54,	/* 0111-0001, run length:   54, 0000-0 # 011-1000x */
/* 113 */	896,	/* 0111-0010, run length:  896, 0-0000 # 0111-0010 */
/* 114 */	960,	/* 0111-0011, run length:  960, 0-0000 # 0111-0011 */
/* 115 */	1024,	/* 0111-0100, run length: 1024, 0-0000 # 0111-0100 */
/* 116 */	1088,	/* 0111-0101, run length: 1088, 0-0000 # 0111-0101 */
/* 117 */	1152,	/* 0111-0110, run length: 1152, 0-0000 # 0111-0110 */
/* 118 */	1216,	/* 0111-0111, run length: 1216, 0-0000 # 0111-0111 */
/* 119 */	64,	/* 0111-1000, run length:   64, 00-000 # 0-1111xxx */
/* 120 */	64,	/* 0111-1001, run length:   64, 00-000 # 0-1111xxx */
/* 121 */	64,	/* 0111-1010, run length:   64, 00-000 # 0-1111xxx */
/* 122 */	64,	/* 0111-1011, run length:   64, 00-000 # 0-1111xxx */
/* 123 */	64,	/* 0111-1100, run length:   64, 00-000 # 0-1111xxx */
/* 124 */	64,	/* 0111-1101, run length:   64, 00-000 # 0-1111xxx */
/* 125 */	64,	/* 0111-1110, run length:   64, 00-000 # 0-1111xxx */
/* 126 */	64,	/* 0111-1111, run length:   64, 00-000 # 0-1111xxx */
     -9,   -9,   -9,   -9,   -9,   -9,   -9,   -9,
     -9,   -9,   -9,   -9,   -9,   -9,   -9,   -9,
     -9,   -9,   -9,   -9,   -9,   -9,   -9,   -9,
     -9,   -9,   -9,   -9,   -9,   -9,   -9,   -9,
     -9,   -9,   -9,   -9,   -9,   -9,   -9,   -9,
     -9,   -9,   -9,   -9,   -9,   -9,   -9,   -9,
     -9,   -9,   -9,   -9,   -9,   -9,   -9,   -9,
     -9,   -9,   -9,   -9,   -9,   -9,   -9,   -9,
     -9,   -9,   -9,   -9,   -9,   -9,   -9,   -9,
     -9,   -9,   -9,   -9,   -9,   -9,   -9,   -9,
     -9,   -9,   -9,   -9,   -9,   -9,   -9,   -9,
     -9,   -9,   -9,   -9,   -9,   -9,   -9,   -9,
     -9,   -9,   -9,   -9,   -9,   -9,   -9,   -9,
     -9,   -9,   -9,   -9,   -9,   -9,   -9,   -9,
     -9,   -9,   -9,   -9,   -9,   -9,   -9,   -9,
     -9,   -9,   -9,   -9,   -9,   -9,   -9,   -9
};

STATIC BYTE nBCodeByte5ToCodeWordLength[256] ={
/*   0 */	7,   7,   7,   7,   0,   0,   0,   0,
/*   8 */	0,   0,   0,   0,   0,   0,   0,   0,
/*  16 */	0,   0,   0,   0,   0,   0,   0,   0,
/*  24 */	0,   0,   0,   0,   0,   0,   0,   0,
/*  32 */	6,	/* 0010-0000, run length: 1792, 000-00 # 00-1000xx */
/*  33 */	6,	/* 0010-0001, run length: 1792, 000-00 # 00-1000xx */
/*  34 */	6,	/* 0010-0010, run length: 1792, 000-00 # 00-1000xx */
/*  35 */	6,	/* 0010-0011, run length: 1792, 000-00 # 00-1000xx */
/*  36 */	7,	/* 0010-0100, run length: 1984, 0000-0 # 001-0010x */
/*  37 */	7,	/* 0010-0101, run length: 1984, 0000-0 # 001-0010x */
/*  38 */	7,	/* 0010-0110, run length: 2048, 0000-0 # 001-0011x */
/*  39 */	7,	/* 0010-0111, run length: 2048, 0000-0 # 001-0011x */
/*  40 */	7,	/* 0010-1000, run length: 2112, 0000-0 # 001-0100x */
/*  41 */	7,	/* 0010-1001, run length: 2112, 0000-0 # 001-0100x */
/*  42 */	7,	/* 0010-1010, run length: 2176, 0000-0 # 001-0101x */
/*  43 */	7,	/* 0010-1011, run length: 2176, 0000-0 # 001-0101x */
/*  44 */	7,	/* 0010-1100, run length: 2240, 0000-0 # 001-0110x */
/*  45 */	7,	/* 0010-1101, run length: 2240, 0000-0 # 001-0110x */
/*  46 */	7,	/* 0010-1110, run length: 2304, 0000-0 # 001-0111x */
/*  47 */	7,	/* 0010-1111, run length: 2304, 0000-0 # 001-0111x */
/*  48 */	6,	/* 0011-0000, run length: 1856, 000-00 # 00-1100xx */
/*  49 */	6,	/* 0011-0001, run length: 1856, 000-00 # 00-1100xx */
/*  50 */	6,	/* 0011-0010, run length: 1856, 000-00 # 00-1100xx */
/*  51 */	6,	/* 0011-0011, run length: 1856, 000-00 # 00-1100xx */
/*  52 */	6,	/* 0011-0100, run length: 1920, 000-00 # 00-1101xx */
/*  53 */	6,	/* 0011-0101, run length: 1920, 000-00 # 00-1101xx */
/*  54 */	6,	/* 0011-0110, run length: 1920, 000-00 # 00-1101xx */
/*  55 */	6,	/* 0011-0111, run length: 1920, 000-00 # 00-1101xx */
/*  56 */	7,	/* 0011-1000, run length: 2368, 0000-0 # 001-1100x */
/*  57 */	7,	/* 0011-1001, run length: 2368, 0000-0 # 001-1100x */
/*  58 */	7,	/* 0011-1010, run length: 2432, 0000-0 # 001-1101x */
/*  59 */	7,	/* 0011-1011, run length: 2432, 0000-0 # 001-1101x */
/*  60 */	7,	/* 0011-1100, run length: 2496, 0000-0 # 001-1110x */
/*  61 */	7,	/* 0011-1101, run length: 2496, 0000-0 # 001-1110x */
/*  62 */	7,	/* 0011-1110, run length: 2560, 0000-0 # 001-1111x */
/*  63 */	7,	/* 0011-1111, run length: 2560, 0000-0 # 001-1111x */
/*  64 */	5,	/* 0100-0000, run length:   18, 00-000 # 01-000xxx */
/*  65 */	5,	/* 0100-0001, run length:   18, 00-000 # 01-000xxx */
/*  66 */	5,	/* 0100-0010, run length:   18, 00-000 # 01-000xxx */
/*  67 */	5,	/* 0100-0011, run length:   18, 00-000 # 01-000xxx */
/*  68 */	5,	/* 0100-0100, run length:   18, 00-000 # 01-000xxx */
/*  69 */	5,	/* 0100-0101, run length:   18, 00-000 # 01-000xxx */
/*  70 */	5,	/* 0100-0110, run length:   18, 00-000 # 01-000xxx */
/*  71 */	5,	/* 0100-0111, run length:   18, 00-000 # 01-000xxx */
/*  72 */	7,	/* 0100-1000, run length:   52, 0000-0 # 010-0100x */
/*  73 */	7,	/* 0100-1001, run length:   52, 0000-0 # 010-0100x */
/*  74 */	8,	/* 0100-1010, run length:  640, 0-0000 # 0100-1010 */
/*  75 */	8,	/* 0100-1011, run length:  704, 0-0000 # 0100-1011 */
/*  76 */	8,	/* 0100-1100, run length:  768, 0-0000 # 0100-1100 */
/*  77 */	8,	/* 0100-1101, run length:  832, 0-0000 # 0100-1101 */
/*  78 */	7,	/* 0100-1110, run length:   55, 0000-0 # 010-0111x */
/*  79 */	7,	/* 0100-1111, run length:   55, 0000-0 # 010-0111x */
/*  80 */	7,	/* 0101-0000, run length:   56, 0000-0 # 010-1000x */
/*  81 */	7,	/* 0101-0001, run length:   56, 0000-0 # 010-1000x */
/*  82 */	8,	/* 0101-0010, run length: 1280, 0-0000 # 0101-0010 */
/*  83 */	8,	/* 0101-0011, run length: 1344, 0-0000 # 0101-0011 */
/*  84 */	8,	/* 0101-0100, run length: 1408, 0-0000 # 0101-0100 */
/*  85 */	8,	/* 0101-0101, run length: 1472, 0-0000 # 0101-0101 */
/*  86 */	7,	/* 0101-0110, run length:   59, 0000-0 # 010-1011x */
/*  87 */	7,	/* 0101-0111, run length:   59, 0000-0 # 010-1011x */
/*  88 */	7,	/* 0101-1000, run length:   60, 0000-0 # 010-1100x */
/*  89 */	7,	/* 0101-1001, run length:   60, 0000-0 # 010-1100x */
/*  90 */	8,	/* 0101-1010, run length: 1536, 0-0000 # 0101-1010 */
/*  91 */	8,	/* 0101-1011, run length: 1600, 0-0000 # 0101-1011 */
/*  91 */	6,	/* 0101-1100, run length:   24, 000-00 # 01-0111xx */
/*  92 */	6,	/* 0101-1101, run length:   24, 000-00 # 01-0111xx */
/*  93 */	6,	/* 0101-1110, run length:   24, 000-00 # 01-0111xx */
/*  94 */	6,	/* 0101-1111, run length:   24, 000-00 # 01-0111xx */
/*  95 */	6,	/* 0110-0000, run length:   25, 000-00 # 01-1000xx */
/*  96 */	6,	/* 0110-0001, run length:   25, 000-00 # 01-1000xx */
/*  97 */	6,	/* 0110-0010, run length:   25, 000-00 # 01-1000xx */
/*  98 */	6,	/* 0110-0011, run length:   25, 000-00 # 01-1000xx */
/*  99 */	8,	/* 0110-0100, run length: 1664, 0-0000 # 0110-0100 */
/* 100 */	8,	/* 0110-0101, run length: 1728, 0-0000 # 0110-0101 */
/* 101 */	7,	/* 0110-0110, run length:  320, 0000-0 # 011-0011x */
/* 102 */	7,	/* 0110-0111, run length:  320, 0000-0 # 011-0011x */
/* 103 */	7,	/* 0110-1000, run length:  384, 0000-0 # 011-0100x */
/* 104 */	7,	/* 0110-1001, run length:  384, 0000-0 # 011-0100x */
/* 105 */	7,	/* 0110-1010, run length:  448, 0000-0 # 011-0101x */
/* 106 */	7,	/* 0110-1011, run length:  448, 0000-0 # 011-0101x */
/* 107 */	8,	/* 0110-1100, run length:  512, 0-0000 # 0110-1100 */
/* 108 */	8,	/* 0110-1101, run length:  576, 0-0000 # 0110-1101 */
/* 109 */	7,	/* 0110-1110, run length:   53, 0000-0 # 011-0111x */
/* 110 */	7,	/* 0110-1111, run length:   53, 0000-0 # 011-0111x */
/* 111 */	7,	/* 0111-0000, run length:   54, 0000-0 # 011-1000x */
/* 112 */	7,	/* 0111-0001, run length:   54, 0000-0 # 011-1000x */
/* 113 */	8,	/* 0111-0010, run length:  896, 0-0000 # 0111-0010 */
/* 114 */	8,	/* 0111-0011, run length:  960, 0-0000 # 0111-0011 */
/* 115 */	8,	/* 0111-0100, run length: 1024, 0-0000 # 0111-0100 */
/* 116 */	8,	/* 0111-0101, run length: 1088, 0-0000 # 0111-0101 */
/* 117 */	8,	/* 0111-0110, run length: 1152, 0-0000 # 0111-0110 */
/* 118 */	8,	/* 0111-0111, run length: 1216, 0-0000 # 0111-0111 */
/* 119 */	5,	/* 0111-1000, run length:   64, 00-000 # 0-1111xxx */
/* 120 */	5,	/* 0111-1001, run length:   64, 00-000 # 0-1111xxx */
/* 121 */	5,	/* 0111-1010, run length:   64, 00-000 # 0-1111xxx */
/* 122 */	5,	/* 0111-1011, run length:   64, 00-000 # 0-1111xxx */
/* 123 */	5,	/* 0111-1100, run length:   64, 00-000 # 0-1111xxx */
/* 124 */	5,	/* 0111-1101, run length:   64, 00-000 # 0-1111xxx */
/* 125 */	5,	/* 0111-1110, run length:   64, 00-000 # 0-1111xxx */
/* 126 */	5,	/* 0111-1111, run length:   64, 00-000 # 0-1111xxx */
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0,
     0,   0,   0,   0,   0,   0,   0,   0
};

STATIC int nRunLengthTo1Bits[9] = {
/*  1 */	0x000,	/* 0000-0000 */
/*  2 */	0x080,	/* 1000-0000 */
/*  3 */	0x0c0,	/* 1100-0000 */
/*  4 */	0x0e0,	/* 1110-0000 */
/*  5 */	0x0f0,	/* 1111-0000 */
/*  6 */	0x0f8,	/* 1111-1000 */
/*  7 */	0x0fc,	/* 1111-1100 */
/*  8 */	0x0fe,	/* 1111-1110 */
/*  9 */	0x0ff	/* 1111-1111 */
};

STATIC int nRunLengthTo0Bits[9] = {
/*  1 */	0x0ff,	/* 1111-1111 */
/*  2 */	0x07f,	/* 0111-1111 */
/*  3 */	0x03f,	/* 0011-1111 */
/*  4 */	0x01f,	/* 0001-1111 */
/*  5 */	0x00f,	/* 0000-1111 */
/*  6 */	0x007,	/* 0000-0111 */
/*  7 */	0x003,	/* 0000-0011 */
/*  8 */	0x001,	/* 0000-0001 */
/*  9 */	0x000	/* 0000-0000 */
};

STATIC int nRunLengthTo1BitsR[9] = {
/*  1 */	0x000,	/* 0000-0000 */
/*  2 */	0x001,	/* 0000-0001 */
/*  3 */	0x003,	/* 0000-0011 */
/*  4 */	0x007,	/* 0000-0111 */
/*  5 */	0x00f,	/* 0000-1111 */
/*  6 */	0x01f,	/* 0001-1111 */
/*  7 */	0x03f,	/* 0011-1111 */
/*  8 */	0x07f,	/* 0111-1111 */
/*  9 */	0x0ff	/* 1111-1111 */
};

STATIC int nRunLengthTo0BitsR[9] ={
/*  1 */	0x0ff,	/* 1111-1111 */
/*  2 */	0x0fe,	/* 1111-1110 */
/*  3 */	0x0fc,	/* 1111-1100 */
/*  4 */	0x0f8,	/* 1111-1000 */
/*  5 */	0x0f0,	/* 1111-0000 */
/*  6 */	0x0e0,	/* 1110-0000 */
/*  7 */	0x0c0,	/* 1100-0000 */
/*  8 */	0x080,	/* 1000-0000 */
/*  9 */	0x000	/* 0000-0000 */
};

#define DE_STATE_PASS		0
#define DE_STATE_HORIZONTAL	1
#define DE_STATE_V0		2	/* A1 = B1 */
#define DE_STATE_VR1		3	/* A1 = B1 + 1 */
#define DE_STATE_VR2		4	/* A1 = B1 + 2 */
#define DE_STATE_VR3		5	/* A1 = B1 + 3 */
#define DE_STATE_VL1		6	/* A1 = B1 - 1 */
#define DE_STATE_VL2		7	/* A1 = B1 - 2 */
#define DE_STATE_VL3		8	/* A1 = B1 - 3 */
#define DE_STATE_EOL		9
#define DE_STATE_ERROR		-9

#define DE_STATE_EXTENSION	10	/* uncompressed */

/*
** This is only used in 1 place and only takes on the
** values of -9 to 9, so why is it an int (32-bits)?
*/

// STATIC int  n2DCodeByteToState[256] = {
STATIC BYTE n2DCodeByteToState[256] = {

/*   1 */	(BYTE)DE_STATE_EOL,			/* 0000-0000 */

/*   2 */	(BYTE)DE_STATE_ERROR,		/* 0000-0001 */

/*
****************************************************************
** According to Table 1: Code Table in EIA Standard EIA-538-1988
** "Facsimile Coding Schemes and Coding Control Functions for
** Group 4 Facsimile Equipment":
**
** Extension Mode:                                 0000001xxx
****************************************************************
*/

/*   3 */	(BYTE)DE_STATE_ERROR,			/* 0000-001,0 */
/*   4 */	(BYTE)DE_STATE_ERROR,			/* 0000-001,1 */

/*
****************************************************************
** According to Table 1: Code Table in EIA Standard EIA-538-1988
** "Facsimile Coding Schemes and Coding Control Functions for
** Group 4 Facsimile Equipment":
**
** Vertical Mode: VL(3):                Code word: 0000010
**                (a1 to the left of b1)
****************************************************************
*/

/*   5 */	DE_STATE_VL3,			/* 0000-010,0 */
/*   6 */	DE_STATE_VL3,			/* 0000-010,1 */

/*
****************************************************************
** According to Table 1: Code Table in EIA Standard EIA-538-1988
** "Facsimile Coding Schemes and Coding Control Functions for
** Group 4 Facsimile Equipment":
**
** Vertical Mode: VR(3):                Code word: 0000011
**                (a1 to the right of b1)
****************************************************************
*/

/*   7 */	DE_STATE_VR3,			/* 0000-011,0 */
/*   8 */	DE_STATE_VR3,			/* 0000-011,1 */

/*
****************************************************************
** According to Table 1: Code Table in EIA Standard EIA-538-1988
** "Facsimile Coding Schemes and Coding Control Functions for
** Group 4 Facsimile Equipment":
**
** Vertical Mode: VL(2):                Code word: 000010
**                (a1 to the left of b1)
****************************************************************
*/

/*   9 */	DE_STATE_VL2,			/* 0000-10,00 */
/*  10 */	DE_STATE_VL2,			/* 0000-10,01 */
/*  11 */	DE_STATE_VL2,			/* 0000-10,10 */
/*  12 */	DE_STATE_VL2,			/* 0000-10,11 */

/*
****************************************************************
** According to Table 1: Code Table in EIA Standard EIA-538-1988
** "Facsimile Coding Schemes and Coding Control Functions for
** Group 4 Facsimile Equipment":
**
** Vertical Mode: VR(2):                Code word: 000011
**                (a1 to the right of b1)
****************************************************************
*/

/*  13 */	DE_STATE_VR2,			/* 0000-11,00 */
/*  14 */	DE_STATE_VR2,			/* 0000-11,01 */
/*  15 */	DE_STATE_VR2,			/* 0000-11,10 */
/*  16 */	DE_STATE_VR2,			/* 0000-11,11 */

/*
****************************************************************
** According to Table 1: Code Table in EIA Standard EIA-538-1988
** "Facsimile Coding Schemes and Coding Control Functions for
** Group 4 Facsimile Equipment":
**
** Pass Mode: (b1,b2)                   Code word: 0001
****************************************************************
*/

/*  17 */	DE_STATE_PASS,			/* 0001,-0000 */
/*  18 */	DE_STATE_PASS,			/* 0001,-0001 */
/*  19 */	DE_STATE_PASS,			/* 0001,-0010 */
/*  20 */	DE_STATE_PASS,			/* 0001,-0011 */
/*  21 */	DE_STATE_PASS,			/* 0001,-0100 */
/*  22 */	DE_STATE_PASS,			/* 0001,-0101 */
/*  23 */	DE_STATE_PASS,			/* 0001,-0110 */
/*  24 */	DE_STATE_PASS,			/* 0001,-0111 */
/*  25 */	DE_STATE_PASS,			/* 0001,-1000 */
/*  26 */	DE_STATE_PASS,			/* 0001,-1001 */
/*  27 */	DE_STATE_PASS,			/* 0001,-1010 */
/*  28 */	DE_STATE_PASS,			/* 0001,-1011 */
/*  29 */	DE_STATE_PASS,			/* 0001,-1100 */
/*  30 */	DE_STATE_PASS,			/* 0001,-1101 */
/*  31 */	DE_STATE_PASS,			/* 0001,-1110 */
/*  32 */	DE_STATE_PASS,			/* 0001,-1111 */

/*
****************************************************************
** According to Table 1: Code Table in EIA Standard EIA-538-1988
** "Facsimile Coding Schemes and Coding Control Functions for
** Group 4 Facsimile Equipment":
**
** Horizontal Mode: (a0a1,a1a2)         Code word: 001+M(a0a1) + M(a1a2)
****************************************************************
*/

/*  33 */	DE_STATE_HORIZONTAL,		/* 001,0-0000 */
/*  34 */	DE_STATE_HORIZONTAL,		/* 001,0-0001 */
/*  35 */	DE_STATE_HORIZONTAL,		/* 001,0-0010 */
/*  36 */	DE_STATE_HORIZONTAL,		/* 001,0-0011 */
/*  37 */	DE_STATE_HORIZONTAL,		/* 001,0-0100 */
/*  38 */	DE_STATE_HORIZONTAL,		/* 001,0-0101 */
/*  39 */	DE_STATE_HORIZONTAL,		/* 001,0-0110 */
/*  40 */	DE_STATE_HORIZONTAL,		/* 001,0-0111 */
/*  41 */	DE_STATE_HORIZONTAL,		/* 001,0-1000 */
/*  42 */	DE_STATE_HORIZONTAL,		/* 001,0-1001 */
/*  43 */	DE_STATE_HORIZONTAL,		/* 001,0-1010 */
/*  44 */	DE_STATE_HORIZONTAL,		/* 001,0-1011 */
/*  45 */	DE_STATE_HORIZONTAL,		/* 001,0-1100 */
/*  46 */	DE_STATE_HORIZONTAL,		/* 001,0-1101 */
/*  47 */	DE_STATE_HORIZONTAL,		/* 001,0-1110 */
/*  48 */	DE_STATE_HORIZONTAL,		/* 001,0-1111 */
/*  49 */	DE_STATE_HORIZONTAL,		/* 001,1-0000 */
/*  50 */	DE_STATE_HORIZONTAL,		/* 001,1-0001 */
/*  51 */	DE_STATE_HORIZONTAL,		/* 001,1-0010 */
/*  52 */	DE_STATE_HORIZONTAL,		/* 001,1-0011 */
/*  53 */	DE_STATE_HORIZONTAL,		/* 001,1-0100 */
/*  54 */	DE_STATE_HORIZONTAL,		/* 001,1-0101 */
/*  55 */	DE_STATE_HORIZONTAL,		/* 001,1-0110 */
/*  56 */	DE_STATE_HORIZONTAL,		/* 001,1-0111 */
/*  57 */	DE_STATE_HORIZONTAL,		/* 001,1-1000 */
/*  58 */	DE_STATE_HORIZONTAL,		/* 001,1-1001 */
/*  59 */	DE_STATE_HORIZONTAL,		/* 001,1-1010 */
/*  60 */	DE_STATE_HORIZONTAL,		/* 001,1-1011 */
/*  61 */	DE_STATE_HORIZONTAL,		/* 001,1-1100 */
/*  62 */	DE_STATE_HORIZONTAL,		/* 001,1-1101 */
/*  63 */	DE_STATE_HORIZONTAL,		/* 001,1-1110 */
/*  64 */	DE_STATE_HORIZONTAL,		/* 001,1-1111 */

/*
****************************************************************
** According to Table 1: Code Table in EIA Standard EIA-538-1988
** "Facsimile Coding Schemes and Coding Control Functions for
** Group 4 Facsimile Equipment":
**
** Vertical Mode: VL(1):                Code word: 010
**                (a1 to the left of b1)
****************************************************************
*/

/*  65 */	DE_STATE_VL1,			/* 010,0-0000 */
/*  66 */	DE_STATE_VL1,			/* 010,0-0001 */
/*  67 */	DE_STATE_VL1,			/* 010,0-0010 */
/*  68 */	DE_STATE_VL1,			/* 010,0-0011 */
/*  69 */	DE_STATE_VL1,			/* 010,0-0100 */
/*  70 */	DE_STATE_VL1,			/* 010,0-0101 */
/*  71 */	DE_STATE_VL1,			/* 010,0-0110 */
/*  72 */	DE_STATE_VL1,			/* 010,0-0111 */
/*  73 */	DE_STATE_VL1,			/* 010,0-1000 */
/*  74 */	DE_STATE_VL1,			/* 010,0-1001 */
/*  75 */	DE_STATE_VL1,			/* 010,0-1010 */
/*  76 */	DE_STATE_VL1,			/* 010,0-1011 */
/*  77 */	DE_STATE_VL1,			/* 010,0-1100 */
/*  78 */	DE_STATE_VL1,			/* 010,0-1101 */
/*  79 */	DE_STATE_VL1,			/* 010,0-1110 */
/*  80 */	DE_STATE_VL1,			/* 010,0-1111 */
/*  81 */	DE_STATE_VL1,			/* 010,1-0000 */
/*  82 */	DE_STATE_VL1,			/* 010,1-0001 */
/*  83 */	DE_STATE_VL1,			/* 010,1-0010 */
/*  84 */	DE_STATE_VL1,			/* 010,1-0011 */
/*  85 */	DE_STATE_VL1,			/* 010,1-0100 */
/*  86 */	DE_STATE_VL1,			/* 010,1-0101 */
/*  87 */	DE_STATE_VL1,			/* 010,1-0110 */
/*  88 */	DE_STATE_VL1,			/* 010,1-0111 */
/*  89 */	DE_STATE_VL1,			/* 010,1-1000 */
/*  90 */	DE_STATE_VL1,			/* 010,1-1001 */
/*  91 */	DE_STATE_VL1,			/* 010,1-1010 */
/*  92 */	DE_STATE_VL1,			/* 010,1-1011 */
/*  93 */	DE_STATE_VL1,			/* 010,1-1100 */
/*  94 */	DE_STATE_VL1,			/* 010,1-1101 */
/*  95 */	DE_STATE_VL1,			/* 010,1-1110 */
/*  96 */	DE_STATE_VL1,			/* 010,1-1111 */

/*
****************************************************************
** According to Table 1: Code Table in EIA Standard EIA-538-1988
** "Facsimile Coding Schemes and Coding Control Functions for
** Group 4 Facsimile Equipment":
**
** Vertical Mode: VR(1):                Code word: 011
**                (a1 to the right of b1)
****************************************************************
*/

/*  97 */	DE_STATE_VR1,			/* 011,0-0000 */
/*  98 */	DE_STATE_VR1,			/* 011,0-0001 */
/*  99 */	DE_STATE_VR1,			/* 011,0-0010 */
/* 100 */	DE_STATE_VR1,			/* 011,0-0011 */
/* 101 */	DE_STATE_VR1,			/* 011,0-0100 */
/* 102 */	DE_STATE_VR1,			/* 011,0-0101 */
/* 103 */	DE_STATE_VR1,			/* 011,0-0110 */
/* 104 */	DE_STATE_VR1,			/* 011,0-0111 */
/* 105 */	DE_STATE_VR1,			/* 011,0-1000 */
/* 106 */	DE_STATE_VR1,			/* 011,0-1001 */
/* 107 */	DE_STATE_VR1,			/* 011,0-1010 */
/* 108 */	DE_STATE_VR1,			/* 011,0-1011 */
/* 109 */	DE_STATE_VR1,			/* 011,0-1100 */
/* 110 */	DE_STATE_VR1,			/* 011,0-1101 */
/* 111 */	DE_STATE_VR1,			/* 011,0-1110 */
/* 112 */	DE_STATE_VR1,			/* 011,0-1111 */
/* 113 */	DE_STATE_VR1,			/* 011,1-0000 */
/* 114 */	DE_STATE_VR1,			/* 011,1-0001 */
/* 115 */	DE_STATE_VR1,			/* 011,1-0010 */
/* 116 */	DE_STATE_VR1,			/* 011,1-0011 */
/* 117 */	DE_STATE_VR1,			/* 011,1-0100 */
/* 118 */	DE_STATE_VR1,			/* 011,1-0101 */
/* 119 */	DE_STATE_VR1,			/* 011,1-0110 */
/* 120 */	DE_STATE_VR1,			/* 011,1-0111 */
/* 121 */	DE_STATE_VR1,			/* 011,1-1000 */
/* 122 */	DE_STATE_VR1,			/* 011,1-1001 */
/* 123 */	DE_STATE_VR1,			/* 011,1-1010 */
/* 124 */	DE_STATE_VR1,			/* 011,1-1011 */
/* 125 */	DE_STATE_VR1,			/* 011,1-1100 */
/* 126 */	DE_STATE_VR1,			/* 011,1-1101 */
/* 127 */	DE_STATE_VR1,			/* 011,1-1110 */
/* 128 */	DE_STATE_VR1,			/* 011,1-1111 */

/*
****************************************************************
** According to Table 1: Code Table in EIA Standard EIA-538-1988
** "Facsimile Coding Schemes and Coding Control Functions for
** Group 4 Facsimile Equipment":
**
** Vertical Mode: V(0):                 Code word: 1
**                (a1 just under b1)
****************************************************************
*/

/* 129 */	DE_STATE_V0,			/* 1,000-0000 */
/* 130 */	DE_STATE_V0,			/* 1,000-0001 */
/* 131 */	DE_STATE_V0,			/* 1,000-0010 */
/* 132 */	DE_STATE_V0,			/* 1,000-0011 */
/* 133 */	DE_STATE_V0,			/* 1,000-0100 */
/* 134 */	DE_STATE_V0,			/* 1,000-0101 */
/* 135 */	DE_STATE_V0,			/* 1,000-0110 */
/* 136 */	DE_STATE_V0,			/* 1,000-0111 */
/* 137 */	DE_STATE_V0,			/* 1,000-1000 */
/* 138 */	DE_STATE_V0,			/* 1,000-1001 */
/* 139 */	DE_STATE_V0,			/* 1,000-1010 */
/* 140 */	DE_STATE_V0,			/* 1,000-1011 */
/* 141 */	DE_STATE_V0,			/* 1,000-1100 */
/* 142 */	DE_STATE_V0,			/* 1,000-1101 */
/* 143 */	DE_STATE_V0,			/* 1,000-1110 */
/* 144 */	DE_STATE_V0,			/* 1,000-1111 */
/* 145 */	DE_STATE_V0,			/* 1,001-0000 */
/* 146 */	DE_STATE_V0,			/* 1,001-0001 */
/* 147 */	DE_STATE_V0,			/* 1,001-0010 */
/* 148 */	DE_STATE_V0,			/* 1,001-0011 */
/* 149 */	DE_STATE_V0,			/* 1,001-0100 */
/* 150 */	DE_STATE_V0,			/* 1,001-0101 */
/* 151 */	DE_STATE_V0,			/* 1,001-0110 */
/* 152 */	DE_STATE_V0,			/* 1,001-0111 */
/* 153 */	DE_STATE_V0,			/* 1,001-1000 */
/* 154 */	DE_STATE_V0,			/* 1,001-1001 */
/* 155 */	DE_STATE_V0,			/* 1,001-1010 */
/* 156 */	DE_STATE_V0,			/* 1,001-1011 */
/* 157 */	DE_STATE_V0,			/* 1,001-1100 */
/* 158 */	DE_STATE_V0,			/* 1,001-1101 */
/* 159 */	DE_STATE_V0,			/* 1,001-1110 */
/* 160 */	DE_STATE_V0,			/* 1,001-1111 */
/* 161 */	DE_STATE_V0,			/* 1,010-0000 */
/* 162 */	DE_STATE_V0,			/* 1,010-0001 */
/* 163 */	DE_STATE_V0,			/* 1,010-0010 */
/* 164 */	DE_STATE_V0,			/* 1,010-0011 */
/* 165 */	DE_STATE_V0,			/* 1,010-0100 */
/* 166 */	DE_STATE_V0,			/* 1,010-0101 */
/* 167 */	DE_STATE_V0,			/* 1,010-0110 */
/* 168 */	DE_STATE_V0,			/* 1,010-0111 */
/* 169 */	DE_STATE_V0,			/* 1,010-1000 */
/* 170 */	DE_STATE_V0,			/* 1,010-1001 */
/* 171 */	DE_STATE_V0,			/* 1,010-1010 */
/* 172 */	DE_STATE_V0,			/* 1,010-1011 */
/* 173 */	DE_STATE_V0,			/* 1,010-1100 */
/* 174 */	DE_STATE_V0,			/* 1,010-1101 */
/* 175 */	DE_STATE_V0,			/* 1,010-1110 */
/* 176 */	DE_STATE_V0,			/* 1,010-1111 */
/* 177 */	DE_STATE_V0,			/* 1,011-0000 */
/* 178 */	DE_STATE_V0,			/* 1,011-0001 */
/* 179 */	DE_STATE_V0,			/* 1,011-0010 */
/* 180 */	DE_STATE_V0,			/* 1,011-0011 */
/* 181 */	DE_STATE_V0,			/* 1,011-0100 */
/* 182 */	DE_STATE_V0,			/* 1,011-0101 */
/* 183 */	DE_STATE_V0,			/* 1,011-0110 */
/* 184 */	DE_STATE_V0,			/* 1,011-0111 */
/* 185 */	DE_STATE_V0,			/* 1,011-1000 */
/* 186 */	DE_STATE_V0,			/* 1,011-1001 */
/* 187 */	DE_STATE_V0,			/* 1,011-1010 */
/* 188 */	DE_STATE_V0,			/* 1,011-1011 */
/* 189 */	DE_STATE_V0,			/* 1,011-1100 */
/* 190 */	DE_STATE_V0,			/* 1,011-1101 */
/* 191 */	DE_STATE_V0,			/* 1,011-1110 */
/* 192 */	DE_STATE_V0,			/* 1,011-1111 */
/* 193 */	DE_STATE_V0,			/* 1,100-0000 */
/* 194 */	DE_STATE_V0,			/* 1,100-0001 */
/* 195 */	DE_STATE_V0,			/* 1,100-0010 */
/* 196 */	DE_STATE_V0,			/* 1,100-0011 */
/* 197 */	DE_STATE_V0,			/* 1,100-0100 */
/* 198 */	DE_STATE_V0,			/* 1,100-0101 */
/* 199 */	DE_STATE_V0,			/* 1,100-0110 */
/* 200 */	DE_STATE_V0,			/* 1,100-0111 */
/* 201 */	DE_STATE_V0,			/* 1,100-1000 */
/* 202 */	DE_STATE_V0,			/* 1,100-1001 */
/* 203 */	DE_STATE_V0,			/* 1,100-1010 */
/* 204 */	DE_STATE_V0,			/* 1,100-1011 */
/* 205 */	DE_STATE_V0,			/* 1,100-1100 */
/* 206 */	DE_STATE_V0,			/* 1,100-1101 */
/* 207 */	DE_STATE_V0,			/* 1,100-1110 */
/* 208 */	DE_STATE_V0,			/* 1,100-1111 */
/* 209 */	DE_STATE_V0,			/* 1,101-0000 */
/* 210 */	DE_STATE_V0,			/* 1,101-0001 */
/* 211 */	DE_STATE_V0,			/* 1,101-0010 */
/* 212 */	DE_STATE_V0,			/* 1,101-0011 */
/* 213 */	DE_STATE_V0,			/* 1,101-0100 */
/* 214 */	DE_STATE_V0,			/* 1,101-0101 */
/* 215 */	DE_STATE_V0,			/* 1,101-0110 */
/* 216 */	DE_STATE_V0,			/* 1,101-0111 */
/* 217 */	DE_STATE_V0,			/* 1,101-1000 */
/* 218 */	DE_STATE_V0,			/* 1,101-1001 */
/* 219 */	DE_STATE_V0,			/* 1,101-1010 */
/* 220 */	DE_STATE_V0,			/* 1,101-1011 */
/* 221 */	DE_STATE_V0,			/* 1,101-1100 */
/* 222 */	DE_STATE_V0,			/* 1,101-1101 */
/* 223 */	DE_STATE_V0,			/* 1,101-1110 */
/* 224 */	DE_STATE_V0,			/* 1,101-1111 */
/* 225 */	DE_STATE_V0,			/* 1,110-0000 */
/* 226 */	DE_STATE_V0,			/* 1,110-0001 */
/* 227 */	DE_STATE_V0,			/* 1,110-0010 */
/* 228 */	DE_STATE_V0,			/* 1,110-0011 */
/* 229 */	DE_STATE_V0,			/* 1,110-0100 */
/* 230 */	DE_STATE_V0,			/* 1,110-0101 */
/* 231 */	DE_STATE_V0,			/* 1,110-0110 */
/* 232 */	DE_STATE_V0,			/* 1,110-0111 */
/* 233 */	DE_STATE_V0,			/* 1,110-1000 */
/* 234 */	DE_STATE_V0,			/* 1,110-1001 */
/* 235 */	DE_STATE_V0,			/* 1,110-1010 */
/* 236 */	DE_STATE_V0,			/* 1,110-1011 */
/* 237 */	DE_STATE_V0,			/* 1,110-1100 */
/* 238 */	DE_STATE_V0,			/* 1,110-1101 */
/* 239 */	DE_STATE_V0,			/* 1,110-1110 */
/* 240 */	DE_STATE_V0,			/* 1,110-1111 */
/* 241 */	DE_STATE_V0,			/* 1,111-0000 */
/* 242 */	DE_STATE_V0,			/* 1,111-0001 */
/* 243 */	DE_STATE_V0,			/* 1,111-0010 */
/* 244 */	DE_STATE_V0,			/* 1,111-0011 */
/* 245 */	DE_STATE_V0,			/* 1,111-0100 */
/* 246 */	DE_STATE_V0,			/* 1,111-0101 */
/* 247 */	DE_STATE_V0,			/* 1,111-0110 */
/* 248 */	DE_STATE_V0,			/* 1,111-0111 */
/* 249 */	DE_STATE_V0,			/* 1,111-1000 */
/* 250 */	DE_STATE_V0,			/* 1,111-1001 */
/* 251 */	DE_STATE_V0,			/* 1,111-1010 */
/* 252 */	DE_STATE_V0,			/* 1,111-1011 */
/* 253 */	DE_STATE_V0,			/* 1,111-1100 */
/* 254 */	DE_STATE_V0,			/* 1,111-1101 */
/* 255 */	DE_STATE_V0,			/* 1,111-1110 */
/* 256 */	DE_STATE_V0			/* 1,111-1111 */
};

/*
** Table to swap all bits in a byte.
*/

#ifndef BYTESWAP_H
#define BYTESWAP_H

#ifdef WIN_NT
#include <stdio.h>
#endif	/* WIN_NT */


#define MAX_SWAP	256

extern const BYTE bySwapByteTable[MAX_SWAP];

#endif /* BYTESWAP_H */

const BYTE bySwapByteTable[MAX_SWAP] = {

/*   0 */	0x00,	/* 0000-0000 -> 0000-0000 */
/*   1 */	0x80,	/* 0000-0001 -> 1000-0000 */
/*   2 */	0x40,	/* 0000-0010 -> 0100-0000 */
/*   3 */	0xC0,	/* 0000-0011 -> 1100-0000 */
/*   4 */	0x20,	/* 0000-0100 -> 0010-0000 */
/*   5 */	0xA0,	/* 0000-0101 -> 1010-0000 */
/*   6 */	0x60,	/* 0000-0110 -> 0110-0000 */
/*   7 */	0xE0,	/* 0000-0111 -> 1110-0000 */

/*   8 */	0x10,	/* 0000-1000 -> 0001-0000 */
/*   9 */	0x90,	/* 0000-1001 -> 1001-0000 */
/*  10 */	0x50,	/* 0000-1010 -> 0101-0000 */
/*  11 */	0xD0,	/* 0000-1011 -> 1101-0000 */
/*  12 */	0x30,	/* 0000-1100 -> 0011-0000 */
/*  13 */	0xB0,	/* 0000-1101 -> 1011-0000 */
/*  14 */	0x70,	/* 0000-1110 -> 0111-0000 */
/*  15 */	0xF0, 	/* 0000-1111 -> 1111-0000 */

/*  16 */	0x08,	/* 0001-0000 -> 0000-1000 */
/*  17 */	0x88,	/* 0001-0001 -> 1000-1000 */
/*  18 */	0x48,	/* 0001-0010 -> 0100-1000 */
/*  19 */	0xC8,	/* 0001-0011 -> 1100-1000 */
/*  20 */	0x28,	/* 0001-0100 -> 0010-1000 */
/*  21 */	0xA8,	/* 0001-0101 -> 1010-1000 */
/*  22 */	0x68,	/* 0001-0110 -> 0110-1000 */
/*  23 */	0xE8, 	/* 0001-0111 -> 1110-1000 */

/*  24 */	0x18,	/* 0001-1000 -> 0001-1000 */
/*  25 */	0x98,	/* 0001-1001 -> 1001-1000 */
/*  26 */	0x58,	/* 0001-1010 -> 0101-1000 */
/*  27 */	0xD8,	/* 0001-1011 -> 1101-1000 */
/*  28 */	0x38,	/* 0001-1100 -> 0011-1000 */
/*  29 */	0xB8,	/* 0001-1101 -> 1011-1000 */
/*  30 */	0x78,	/* 0001-1110 -> 0111-1000 */
/*  31 */	0xF8, 	/* 0001-1111 -> 1111-1000 */

/*  32 */	0x04,	/* 0010-0000 -> 0000-0100 */
/*  33 */	0x84,	/* 0010-0001 -> 1000-0100 */
/*  34 */	0x44,	/* 0010-0010 -> 0100-0100 */
/*  35 */	0xC4,	/* 0010-0011 -> 1100-0100 */
/*  36 */	0x24,	/* 0010-0100 -> 0010-0100 */
/*  37 */	0xA4,	/* 0010-0101 -> 1010-0100 */
/*  38 */	0x64,	/* 0010-0110 -> 0110-0100 */
/*  39 */	0xE4, 	/* 0010-0111 -> 1110-0100 */

/*  40 */	0x14,	/* 0010-1000 -> 0001-0100 */
/*  41 */	0x94,	/* 0010-1001 -> 1001-0100 */
/*  42 */	0x54,	/* 0010-1010 -> 0101-0100 */
/*  43 */	0xD4,	/* 0010-1011 -> 1101-0100 */
/*  44 */	0x34,	/* 0010-1100 -> 0011-0100 */
/*  45 */	0xB4,	/* 0010-1101 -> 1011-0100 */
/*  46 */	0x74,	/* 0010-1110 -> 0111-0100 */
/*  47 */	0xF4,	/* 0010-1111 -> 1111-0100 */
	
/*  48 */	0x0C,	/* 0011-0000 -> 0000-1100 */
/*  49 */	0x8C,	/* 0011-0001 -> 1000-1100 */
/*  50 */	0x4C,	/* 0011-0010 -> 0100-1100 */
/*  51 */	0xCC,	/* 0011-0011 -> 1100-1100 */
/*  52 */	0x2C,	/* 0011-0100 -> 0010-1100 */
/*  53 */	0xAC,	/* 0011-0101 -> 1010-1100 */
/*  54 */	0x6C,	/* 0011-0110 -> 0110-1100 */
/*  55 */	0xEC,	/* 0011-0111 -> 1110-1100 */
	
/*  56 */	0x1C,	/* 0011-1000 -> 0001-1100 */
/*  57 */	0x9C,	/* 0011-1001 -> 1001-1100 */
/*  58 */	0x5C,	/* 0011-1010 -> 0101-1100 */
/*  59 */	0xDC,	/* 0011-1011 -> 1101-1100 */
/*  60 */	0x3C,	/* 0011-1100 -> 0011-1100 */
/*  61 */	0xBC,	/* 0011-1101 -> 1011-1100 */
/*  62 */	0x7C,	/* 0011-1110 -> 0111-1100 */
/*  63 */	0xFC,	/* 0011-1111 -> 1111-1100 */
	
/*  64 */	0x02,	/* 0100-0000 -> 0000-0010 */
/*  65 */	0x82,	/* 0100-0001 -> 1000-0010 */
/*  66 */	0x42,	/* 0100-0010 -> 0100-0010 */
/*  67 */	0xC2,	/* 0100-0011 -> 1100-0010 */
/*  68 */	0x22,	/* 0100-0100 -> 0010-0010 */
/*  69 */	0xA2,	/* 0100-0101 -> 1010-0010 */
/*  70 */	0x62,	/* 0100-0110 -> 0110-0010 */
/*  71 */	0xE2,	/* 0100-0111 -> 1110-0010 */
	
/*  72 */	0x12,	/* 0100-1000 -> 0001-0010 */
/*  73 */	0x92,	/* 0100-1001 -> 1001-0010 */
/*  74 */	0x52,	/* 0100-1010 -> 0101-0010 */
/*  75 */	0xD2,	/* 0100-1011 -> 1101-0010 */
/*  76 */	0x32,	/* 0100-1100 -> 0011-0010 */
/*  77 */	0xB2,	/* 0100-1101 -> 1011-0010 */
/*  78 */	0x72,	/* 0100-1110 -> 0111-0010 */
/*  79 */	0xF2,	/* 0100-1111 -> 1111-0010 */
	
/*  80 */	0x0A,	/* 0101-0000 -> 0000-1010 */
/*  81 */	0x8A,	/* 0101-0001 -> 1000-1010 */
/*  82 */	0x4A,	/* 0101-0010 -> 0100-1010 */
/*  83 */	0xCA,	/* 0101-0011 -> 1100-1010 */
/*  84 */	0x2A,	/* 0101-0100 -> 0010-1010 */
/*  85 */	0xAA,	/* 0101-0101 -> 1010-1010 */
/*  86 */	0x6A,	/* 0101-0110 -> 0110-1010 */
/*  87 */	0xEA,	/* 0101-0111 -> 1110-1010 */
	
/*  88 */	0x1A,	/* 0101-1000 -> 0001-1010 */
/*  89 */	0x9A,	/* 0101-1001 -> 1001-1010 */
/*  90 */	0x5A,	/* 0101-1010 -> 0101-1010 */
/*  91 */	0xDA,	/* 0101-1011 -> 1101-1010 */
/*  92 */	0x3A,	/* 0101-1100 -> 0011-1010 */
/*  93 */	0xBA,	/* 0101-1101 -> 1011-1010 */
/*  94 */	0x7A,	/* 0101-1110 -> 0111-1010 */
/*  95 */	0xFA,	/* 0101-1111 -> 1111-1010 */
	
/*  96 */	0x06,	/* 0110-0000 -> 0000-0110 */
/*  97 */	0x86,	/* 0110-0001 -> 1000-0110 */
/*  98 */	0x46,	/* 0110-0010 -> 0100-0110 */
/*  99 */	0xC6,	/* 0110-0011 -> 1100-0110 */
/* 100 */	0x26,	/* 0110-0100 -> 0010-0110 */
/* 101 */	0xA6,	/* 0110-0101 -> 1010-0110 */
/* 102 */	0x66,	/* 0110-0110 -> 0110-0110 */
/* 103 */	0xE6,	/* 0110-0111 -> 1110-0110 */
	
/* 104 */	0x16,	/* 0110-1000 -> 0001-0110 */
/* 105 */	0x96,	/* 0110-1001 -> 1001-0110 */
/* 106 */	0x56,	/* 0110-1010 -> 0101-0110 */
/* 107 */	0xD6,	/* 0110-1011 -> 1101-0110 */
/* 108 */	0x36,	/* 0110-1100 -> 0011-0110 */
/* 109 */	0xB6,	/* 0110-1101 -> 1011-0110 */
/* 110 */	0x76,	/* 0110-1110 -> 0111-0110 */
/* 111 */	0xF6,	/* 0110-1111 -> 1111-0110 */
	
/* 112 */	0x0E,	/* 0111-0000 -> 0000-1110 */
/* 113 */	0x8E,	/* 0111-0001 -> 1000-1110 */
/* 114 */	0x4E,	/* 0111-0010 -> 0100-1110 */
/* 115 */	0xCE,	/* 0111-0011 -> 1100-1110 */
/* 116 */	0x2E,	/* 0111-0100 -> 0010-1110 */
/* 117 */	0xAE,	/* 0111-0101 -> 1010-1110 */
/* 118 */	0x6E,	/* 0111-0110 -> 0110-1110 */
/* 119 */	0xEE,	/* 0111-0111 -> 1110-1110 */
	
/* 120 */	0x1E,	/* 0111-1000 -> 0001-1110 */
/* 121 */	0x9E,	/* 0111-1001 -> 1001-1110 */
/* 122 */	0x5E,	/* 0111-1010 -> 0101-1110 */
/* 123 */	0xDE,	/* 0111-1011 -> 1101-1110 */
/* 124 */	0x3E,	/* 0111-1100 -> 0011-1110 */
/* 125 */	0xBE,	/* 0111-1101 -> 1011-1110 */
/* 126 */	0x7E,	/* 0111-1110 -> 0111-1110 */
/* 127 */	0xFE,	/* 0111-1111 -> 1111-1110 */
	
/* 128 */	0x01,	/* 1000-0000 -> 0000-0001 */
/* 129 */	0x81,	/* 1000-0001 -> 1000-0001 */
/* 130 */	0x41,	/* 1000-0010 -> 0100-0001 */
/* 131 */	0xC1,	/* 1000-0011 -> 1100-0001 */
/* 132 */	0x21,	/* 1000-0100 -> 0010-0001 */
/* 133 */	0xA1,	/* 1000-0101 -> 1010-0001 */
/* 134 */	0x61,	/* 1000-0110 -> 0110-0001 */
/* 135 */	0xE1,	/* 1000-0111 -> 1110-0001 */
	
/* 136 */	0x11,	/* 1000-1000 -> 0001-0001 */
/* 137 */	0x91,	/* 1000-1001 -> 1001-0001 */
/* 138 */	0x51,	/* 1000-1010 -> 0101-0001 */
/* 139 */	0xD1,	/* 1000-1011 -> 1101-0001 */
/* 140 */	0x31,	/* 1000-1100 -> 0011-0001 */
/* 141 */	0xB1,	/* 1000-1101 -> 1011-0001 */
/* 142 */	0x71,	/* 1000-1110 -> 0111-0001 */
/* 143 */	0xF1,	/* 1000-1111 -> 1111-0001 */
	
/* 144 */	0x09,	/* 1001-0000 -> 0000-1001 */
/* 145 */	0x89,	/* 1001-0001 -> 1000-1001 */
/* 146 */	0x49,	/* 1001-0010 -> 0100-1001 */
/* 147 */	0xC9,	/* 1001-0011 -> 1100-1001 */
/* 148 */	0x29,	/* 1001-0100 -> 0010-1001 */
/* 149 */	0xA9,	/* 1001-0101 -> 1010-1001 */
/* 150 */	0x69,	/* 1001-0110 -> 0110-1001 */
/* 151 */	0xE9,	/* 1001-0111 -> 1110-1001 */
	
/* 152 */	0x19,	/* 1001-1000 -> 0001-1001 */
/* 153 */	0x99,	/* 1001-1001 -> 1001-1001 */
/* 154 */	0x59,	/* 1001-1010 -> 0101-1001 */
/* 155 */	0xD9,	/* 1001-1011 -> 1101-1001 */
/* 156 */	0x39,	/* 1001-1100 -> 0011-1001 */
/* 157 */	0xB9,	/* 1001-1101 -> 1011-1001 */
/* 158 */	0x79,	/* 1001-1110 -> 0111-1001 */
/* 159 */	0xF9,	/* 1001-1111 -> 1111-1001 */
	
/* 160 */	0x05,	/* 1010-0000 -> 0000-0101 */
/* 161 */	0x85,	/* 1010-0001 -> 1000-0101 */
/* 162 */	0x45,	/* 1010-0010 -> 0100-0101 */
/* 163 */	0xC5,	/* 1010-0011 -> 1100-0101 */
/* 164 */	0x25,	/* 1010-0100 -> 0010-0101 */
/* 165 */	0xA5,	/* 1010-0101 -> 1010-0101 */
/* 166 */	0x65,	/* 1010-0110 -> 0110-0101 */
/* 167 */	0xE5,	/* 1010-0111 -> 1110-0101 */
	
/* 168 */	0x15,	/* 1010-1000 -> 0001-0101 */
/* 169 */	0x95,	/* 1010-1001 -> 1001-0101 */
/* 170 */	0x55,	/* 1010-1010 -> 0101-0101 */
/* 171 */	0xD5,	/* 1010-1011 -> 1101-0101 */
/* 172 */	0x35,	/* 1010-1100 -> 0011-0101 */
/* 173 */	0xB5,	/* 1010-1101 -> 1011-0101 */
/* 174 */	0x75,	/* 1010-1110 -> 0111-0101 */
/* 175 */	0xF5,	/* 1010-1111 -> 1111-0101 */
	
/* 176 */	0x0D,	/* 1011-0000 -> 0000-1101 */
/* 177 */	0x8D,	/* 1011-0001 -> 1000-1101 */
/* 178 */	0x4D,	/* 1011-0010 -> 0100-1101 */
/* 179 */	0xCD,	/* 1011-0011 -> 1100-1101 */
/* 180 */	0x2D,	/* 1011-0100 -> 0010-1101 */
/* 181 */	0xAD,	/* 1011-0101 -> 1010-1101 */
/* 182 */	0x6D,	/* 1011-0110 -> 0110-1101 */
/* 183 */	0xED,	/* 1011-0111 -> 1110-1101 */
	
/* 184 */	0x1D,	/* 1011-1000 -> 0001-1101 */
/* 185 */	0x9D,	/* 1011-1001 -> 1001-1101 */
/* 186 */	0x5D,	/* 1011-1010 -> 0101-1101 */
/* 187 */	0xDD,	/* 1011-1011 -> 1101-1101 */
/* 188 */	0x3D,	/* 1011-1100 -> 0011-1101 */
/* 189 */	0xBD,	/* 1011-1101 -> 1011-1101 */
/* 190 */	0x7D,	/* 1011-1110 -> 0111-1101 */
/* 191 */	0xFD,	/* 1011-1111 -> 1111-1101 */
	
/* 192 */	0x03,	/* 1100-0000 -> 0000-0011 */
/* 193 */	0x83,	/* 1100-0001 -> 1000-0011 */
/* 194 */	0x43,	/* 1100-0010 -> 0100-0011 */
/* 195 */	0xC3,	/* 1100-0011 -> 1100-0011 */
/* 196 */	0x23,	/* 1100-0100 -> 0010-0011 */
/* 197 */	0xA3,	/* 1100-0101 -> 1010-0011 */
/* 198 */	0x63,	/* 1100-0110 -> 0110-0011 */
/* 199 */	0xE3,	/* 1100-0111 -> 1110-0011 */
	
/* 200 */	0x13,	/* 1100-1000 -> 0001-0011 */
/* 201 */	0x93,	/* 1100-1001 -> 1001-0011 */
/* 202 */	0x53,	/* 1100-1010 -> 0101-0011 */
/* 203 */	0xD3,	/* 1100-1011 -> 1101-0011 */
/* 204 */	0x33,	/* 1100-1100 -> 0011-0011 */
/* 205 */	0xB3,	/* 1100-1101 -> 1011-0011 */
/* 206 */	0x73,	/* 1100-1110 -> 0111-0011 */
/* 207 */	0xF3,	/* 1100-1111 -> 1111-0011 */
	
/* 208 */	0x0B,	/* 1101-0000 -> 0000-1011 */
/* 209 */	0x8B,	/* 1101-0001 -> 1000-1011 */
/* 210 */	0x4B,	/* 1101-0010 -> 0100-1011 */
/* 211 */	0xCB,	/* 1101-0011 -> 1100-1011 */
/* 212 */	0x2B,	/* 1101-0100 -> 0010-1011 */
/* 213 */	0xAB,	/* 1101-0101 -> 1010-1011 */
/* 214 */	0x6B,	/* 1101-0110 -> 0110-1011 */
/* 215 */	0xEB,	/* 1101-0111 -> 1110-1011 */
	
/* 216 */	0x1B,	/* 1101-1000 -> 0001-1011 */
/* 217 */	0x9B,	/* 1101-1001 -> 1001-1011 */
/* 218 */	0x5B,	/* 1101-1010 -> 0101-1011 */
/* 219 */	0xDB,	/* 1101-1011 -> 1101-1011 */
/* 220 */	0x3B,	/* 1101-1100 -> 0011-1011 */
/* 221 */	0xBB,	/* 1101-1101 -> 1011-1011 */
/* 222 */	0x7B,	/* 1101-1110 -> 0111-1011 */
/* 223 */	0xFB,	/* 1101-1111 -> 1111-1011 */
	
/* 224 */	0x07,	/* 1110-0000 -> 0000-0111 */
/* 225 */	0x87,	/* 1110-0001 -> 1000-0111 */
/* 226 */	0x47,	/* 1110-0010 -> 0100-0111 */
/* 227 */	0xC7,	/* 1110-0011 -> 1100-0111 */
/* 228 */	0x27,	/* 1110-0100 -> 0010-0111 */
/* 229 */	0xA7,	/* 1110-0101 -> 1010-0111 */
/* 230 */	0x67,	/* 1110-0110 -> 0110-0111 */
/* 231 */	0xE7,	/* 1110-0111 -> 1110-0111 */
	
/* 232 */	0x17,	/* 1110-1000 -> 0001-0111 */
/* 233 */	0x97,	/* 1110-1001 -> 1001-0111 */
/* 234 */	0x57,	/* 1110-1010 -> 0101-0111 */
/* 235 */	0xD7,	/* 1110-1011 -> 1101-0111 */
/* 236 */	0x37,	/* 1110-1100 -> 0011-0111 */
/* 237 */	0xB7,	/* 1110-1101 -> 1011-0111 */
/* 238 */	0x77,	/* 1110-1110 -> 0111-0111 */
/* 239 */	0xF7,	/* 1110-1111 -> 1111-0111 */
	
/* 240 */	0x0F,	/* 1111-0000 -> 0000-1111 */
/* 241 */	0x8F,	/* 1111-0001 -> 1000-1111 */
/* 242 */	0x4F,	/* 1111-0010 -> 0100-1111 */
/* 243 */	0xCF,	/* 1111-0011 -> 1100-1111 */
/* 244 */	0x2F,	/* 1111-0100 -> 0010-1111 */
/* 245 */	0xAF,	/* 1111-0101 -> 1010-1111 */
/* 246 */	0x6F,	/* 1111-0110 -> 0110-1111 */
/* 247 */	0xEF,	/* 1111-0111 -> 1110-1111 */

/* 248 */	0x1F,	/* 1111-1000 -> 0001-1111 */
/* 249 */	0x9F,	/* 1111-1001 -> 1001-1111 */
/* 250 */	0x5F,	/* 1111-1010 -> 0101-1111 */
/* 251 */	0xDF,	/* 1111-1011 -> 1101-1111 */
/* 252 */	0x3F,	/* 1111-1100 -> 0011-1111 */
/* 253 */	0xBF,	/* 1111-1101 -> 1011-1111 */
/* 254 */	0x7F,	/* 1111-1110 -> 0111-1111 */
/* 255 */	0xFF	/* 1111-1111 -> 1111-1111 */
	
};

#ifdef DEBUG

#define MAX_BUF	256

BYTE swapBuf1[MAX_BUF];
BYTE swapBuf2[MAX_BUF];
BYTE swapBuf3[MAX_BUF];

void
byteSwapTest()
{
int i;
int cnt;

	/*
	** The table has only 256 entries, so that is
	** all that needs to be tested.
	**
	** Pass 1, take a sequence of 0..256 and convert it.
	** Pass 2, take the converted value, and reverse it -
	** you should get the original back.
	**
	** Pass 3 - what went in had better come back out.
	*/

	cnt = 0;
	for (i = 0; i < MAX_BUF; i++) {
		swapBuf1[i] = i;
		printf("0x%2.2x ", swapBuf1[i]);
		if ( ( (i + 1) % 8) == 0) {
			printf("\n");
		}
		swapBuf2[i] = bySwapByteTable[i];
		swapBuf3[i] = bySwapByteTable[swapBuf2[i]];
		if (swapBuf1[i] != swapBuf3[i]) {
			printf("GAK!");
		}
		else {
			cnt++;
		}
	}

	if (cnt == MAX_BUF) {
		printf("byteSwapTest: Tables match and checkout.\n");
	}

}

#endif	/* DEBUG */


/*
** This table returns the bit position of the first 1 bit in the byte.
**
**
**   Current BYTE                  | Next BYTE
** +---+---+---+---+---+---+---+---|---+
** | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |
** +---+---+---+---+---+---+---+---|---+
**                                 |
*/

BYTE nFirstOneBit[256] = {
/*   0 */	8,	/* 0000-0000 */
/*   1 */	7,	/* 0000-0001 */
/*   2 */	6,	/* 0000-0010 */
/*   3 */	6,	/* 0000-0011 */
/*   4 */	5,	/* 0000-0100 */
/*   5 */	5,	/* 0000-0101 */
/*   6 */	5,	/* 0000-0110 */
/*   7 */	5,	/* 0000-0111 */
/*   8 */	4,	/* 0000-1000 */
/*   9 */	4,	/* 0000-1001 */
/*  10 */	4,	/* 0000-1010 */
/*  11 */	4,	/* 0000-1011 */
/*  12 */	4,	/* 0000-1100 */
/*  13 */	4,	/* 0000-1101 */
/*  14 */	4,	/* 0000-1110 */
/*  15 */	4,	/* 0000-1111 */
/*  16 */	3,	/* 0001-0000 */
/*  17 */	3,	/* 0001-0001 */
/*  18 */	3,	/* 0001-0010 */
/*  19 */	3,	/* 0001-0011 */
/*  20 */	3,	/* 0001-0100 */
/*  21 */	3,	/* 0001-0101 */
/*  22 */	3,	/* 0001-0110 */
/*  23 */	3,	/* 0001-0111 */
/*  24 */	3,	/* 0001-1000 */
/*  25 */	3,	/* 0001-1001 */
/*  26 */	3,	/* 0001-1010 */
/*  27 */	3,	/* 0001-1011 */
/*  28 */	3,	/* 0001-1100 */
/*  29 */	3,	/* 0001-1101 */
/*  30 */	3,	/* 0001-1110 */
/*  31 */	3,	/* 0001-1111 */
/*  32 */	2,	/* 0010-0000 */
/*  33 */	2,	/* 0010-0001 */
/*  34 */	2,	/* 0010-0010 */
/*  35 */	2,	/* 0010-0011 */
/*  36 */	2,	/* 0010-0100 */
/*  37 */	2,	/* 0010-0101 */
/*  38 */	2,	/* 0010-0110 */
/*  39 */	2,	/* 0010-0111 */
/*  40 */	2,	/* 0010-1000 */
/*  41 */	2,	/* 0010-1001 */
/*  42 */	2,	/* 0010-1010 */
/*  43 */	2,	/* 0010-1011 */
/*  44 */	2,	/* 0010-1100 */
/*  45 */	2,	/* 0010-1101 */
/*  46 */	2,	/* 0010-1110 */
/*  47 */	2,	/* 0010-1111 */
/*  48 */	2,	/* 0011-0000 */
/*  49 */	2,	/* 0011-0001 */
/*  50 */	2,	/* 0011-0010 */
/*  51 */	2,	/* 0011-0011 */
/*  52 */	2,	/* 0011-0100 */
/*  53 */	2,	/* 0011-0101 */
/*  54 */	2,	/* 0011-0110 */
/*  55 */	2,	/* 0011-0111 */
/*  56 */	2,	/* 0011-1000 */
/*  57 */	2,	/* 0011-1001 */
/*  58 */	2,	/* 0011-1010 */
/*  59 */	2,	/* 0011-1011 */
/*  60 */	2,	/* 0011-1100 */
/*  61 */	2,	/* 0011-1101 */
/*  62 */	2,	/* 0011-1110 */
/*  63 */	2,	/* 0011-1111 */
/*  64 */	1,	/* 0100-0000 */
/*  65 */	1,	/* 0100-0001 */
/*  66 */	1,	/* 0100-0010 */
/*  67 */	1,	/* 0100-0011 */
/*  68 */	1,	/* 0100-0100 */
/*  69 */	1,	/* 0100-0101 */
/*  70 */	1,	/* 0100-0110 */
/*  71 */	1,	/* 0100-0111 */
/*  72 */	1,	/* 0100-1000 */
/*  73 */	1,	/* 0100-1001 */
/*  74 */	1,	/* 0100-1010 */
/*  75 */	1,	/* 0100-1011 */
/*  76 */	1,	/* 0100-1100 */
/*  77 */	1,	/* 0100-1101 */
/*  78 */	1,	/* 0100-1110 */
/*  79 */	1,	/* 0100-1111 */
/*  80 */	1,	/* 0101-0000 */
/*  81 */	1,	/* 0101-0001 */
/*  82 */	1,	/* 0101-0010 */
/*  83 */	1,	/* 0101-0011 */
/*  84 */	1,	/* 0101-0100 */
/*  85 */	1,	/* 0101-0101 */
/*  86 */	1,	/* 0101-0110 */
/*  87 */	1,	/* 0101-0111 */
/*  88 */	1,	/* 0101-1000 */
/*  89 */	1,	/* 0101-1001 */
/*  90 */	1,	/* 0101-1010 */
/*  91 */	1,	/* 0101-1011 */
/*  92 */	1,	/* 0101-1100 */
/*  93 */	1,	/* 0101-1101 */
/*  94 */	1,	/* 0101-1110 */
/*  95 */	1,	/* 0101-1111 */
/*  96 */	1,	/* 0110-0000 */
/*  97 */	1,	/* 0110-0001 */
/*  98 */	1,	/* 0110-0010 */
/*  99 */	1,	/* 0110-0011 */
/* 100 */	1,	/* 0110-0100 */
/* 101 */	1,	/* 0110-0101 */
/* 102 */	1,	/* 0110-0110 */
/* 103 */	1,	/* 0110-0111 */
/* 104 */	1,	/* 0110-1000 */
/* 105 */	1,	/* 0110-1001 */
/* 106 */	1,	/* 0110-1010 */
/* 107 */	1,	/* 0110-1011 */
/* 108 */	1,	/* 0110-1100 */
/* 109 */	1,	/* 0110-1101 */
/* 110 */	1,	/* 0110-1110 */
/* 111 */	1,	/* 0110-1111 */
/* 112 */	1,	/* 0111-0000 */
/* 113 */	1,	/* 0111-0001 */
/* 114 */	1,	/* 0111-0010 */
/* 115 */	1,	/* 0111-0011 */
/* 116 */	1,	/* 0111-0100 */
/* 117 */	1,	/* 0111-0101 */
/* 118 */	1,	/* 0111-0110 */
/* 119 */	1,	/* 0111-0111 */
/* 120 */	1,	/* 0111-1000 */
/* 121 */	1,	/* 0111-1001 */
/* 122 */	1,	/* 0111-1010 */
/* 123 */	1,	/* 0111-1011 */
/* 124 */	1,	/* 0111-1100 */
/* 125 */	1,	/* 0111-1101 */
/* 126 */	1,	/* 0111-1110 */
/* 127 */	1,	/* 0111-1111 */
/* 128 */	0,	/* 1000-0000 */
/* 129 */	0,	/* 1000-0001 */
/* 130 */	0,	/* 1000-0010 */
/* 131 */	0,	/* 1000-0011 */
/* 132 */	0,	/* 1000-0100 */
/* 133 */	0,	/* 1000-0101 */
/* 134 */	0,	/* 1000-0110 */
/* 135 */	0,	/* 1000-0111 */
/* 136 */	0,	/* 1000-1000 */
/* 137 */	0,	/* 1000-1001 */
/* 138 */	0,	/* 1000-1010 */
/* 139 */	0,	/* 1000-1011 */
/* 140 */	0,	/* 1000-1100 */
/* 141 */	0,	/* 1000-1101 */
/* 142 */	0,	/* 1000-1110 */
/* 143 */	0,	/* 1000-1111 */
/* 144 */	0,	/* 1001-0000 */
/* 145 */	0,	/* 1001-0001 */
/* 146 */	0,	/* 1001-0010 */
/* 147 */	0,	/* 1001-0011 */
/* 148 */	0,	/* 1001-0100 */
/* 149 */	0,	/* 1001-0101 */
/* 150 */	0,	/* 1001-0110 */
/* 151 */	0,	/* 1001-0111 */
/* 152 */	0,	/* 1001-1000 */
/* 153 */	0,	/* 1001-1001 */
/* 154 */	0,	/* 1001-1010 */
/* 155 */	0,	/* 1001-1011 */
/* 156 */	0,	/* 1001-1100 */
/* 157 */	0,	/* 1001-1101 */
/* 158 */	0,	/* 1001-1110 */
/* 159 */	0,	/* 1001-1111 */
/* 160 */	0,	/* 1010-0000 */
/* 161 */	0,	/* 1010-0001 */
/* 162 */	0,	/* 1010-0010 */
/* 163 */	0,	/* 1010-0011 */
/* 164 */	0,	/* 1010-0100 */
/* 165 */	0,	/* 1010-0101 */
/* 166 */	0,	/* 1010-0110 */
/* 167 */	0,	/* 1010-0111 */
/* 168 */	0,	/* 1010-1000 */
/* 169 */	0,	/* 1010-1001 */
/* 170 */	0,	/* 1010-1010 */
/* 171 */	0,	/* 1010-1011 */
/* 172 */	0,	/* 1010-1100 */
/* 173 */	0,	/* 1010-1101 */
/* 174 */	0,	/* 1010-1110 */
/* 175 */	0,	/* 1010-1111 */
/* 176 */	0,	/* 1011-0000 */
/* 177 */	0,	/* 1011-0001 */
/* 178 */	0,	/* 1011-0010 */
/* 179 */	0,	/* 1011-0011 */
/* 180 */	0,	/* 1011-0100 */
/* 181 */	0,	/* 1011-0101 */
/* 182 */	0,	/* 1011-0110 */
/* 183 */	0,	/* 1011-0111 */
/* 184 */	0,	/* 1011-1000 */
/* 185 */	0,	/* 1011-1001 */
/* 186 */	0,	/* 1011-1010 */
/* 187 */	0,	/* 1011-1011 */
/* 188 */	0,	/* 1011-1100 */
/* 189 */	0,	/* 1011-1101 */
/* 190 */	0,	/* 1011-1110 */
/* 191 */	0,	/* 1011-1111 */
/* 192 */	0,	/* 1100-0000 */
/* 193 */	0,	/* 1100-0001 */
/* 194 */	0,	/* 1100-0010 */
/* 195 */	0,	/* 1100-0011 */
/* 196 */	0,	/* 1100-0100 */
/* 197 */	0,	/* 1100-0101 */
/* 198 */	0,	/* 1100-0110 */
/* 199 */	0,	/* 1100-0111 */
/* 200 */	0,	/* 1100-1000 */
/* 201 */	0,	/* 1100-1001 */
/* 202 */	0,	/* 1100-1010 */
/* 203 */	0,	/* 1100-1011 */
/* 204 */	0,	/* 1100-1100 */
/* 205 */	0,	/* 1100-1101 */
/* 206 */	0,	/* 1100-1110 */
/* 207 */	0,	/* 1100-1111 */
/* 208 */	0,	/* 1101-0000 */
/* 209 */	0,	/* 1101-0001 */
/* 210 */	0,	/* 1101-0010 */
/* 211 */	0,	/* 1101-0011 */
/* 212 */	0,	/* 1101-0100 */
/* 213 */	0,	/* 1101-0101 */
/* 214 */	0,	/* 1101-0110 */
/* 215 */	0,	/* 1101-0111 */
/* 216 */	0,	/* 1101-1000 */
/* 217 */	0,	/* 1101-1001 */
/* 218 */	0,	/* 1101-1010 */
/* 219 */	0,	/* 1101-1011 */
/* 220 */	0,	/* 1101-1100 */
/* 221 */	0,	/* 1101-1101 */
/* 222 */	0,	/* 1101-1110 */
/* 223 */	0,	/* 1101-1111 */
/* 224 */	0,	/* 1110-0000 */
/* 225 */	0,	/* 1110-0001 */
/* 226 */	0,	/* 1110-0010 */
/* 227 */	0,	/* 1110-0011 */
/* 228 */	0,	/* 1110-0100 */
/* 229 */	0,	/* 1110-0101 */
/* 230 */	0,	/* 1110-0110 */
/* 231 */	0,	/* 1110-0111 */
/* 232 */	0,	/* 1110-1000 */
/* 233 */	0,	/* 1110-1001 */
/* 234 */	0,	/* 1110-1010 */
/* 235 */	0,	/* 1110-1011 */
/* 236 */	0,	/* 1110-1100 */
/* 237 */	0,	/* 1110-1101 */
/* 238 */	0,	/* 1110-1110 */
/* 239 */	0,	/* 1110-1111 */
/* 240 */	0,	/* 1111-0000 */
/* 241 */	0,	/* 1111-0001 */
/* 242 */	0,	/* 1111-0010 */
/* 243 */	0,	/* 1111-0011 */
/* 244 */	0,	/* 1111-0100 */
/* 245 */	0,	/* 1111-0101 */
/* 246 */	0,	/* 1111-0110 */
/* 247 */	0,	/* 1111-0111 */
/* 248 */	0,	/* 1111-1000 */
/* 249 */	0,	/* 1111-1001 */
/* 250 */	0,	/* 1111-1010 */
/* 251 */	0,	/* 1111-1011 */
/* 252 */	0,	/* 1111-1100 */
/* 253 */	0,	/* 1111-1101 */
/* 254 */	0,	/* 1111-1110 */
/* 255 */	0	/* 1111-1111 */
};

#ifdef GEN_TABLES

void
printByte(BYTE ch)
{
int i;

	for (i = 0; i < 8; i++) {
		if ( (ch & 0x80) == 0x80) {
			printf("1");
		}
		else {
			printf("0");
		}
		ch <<= 1;
		if (i == 3) {
			printf("-");
		}
	}
}

void
genFirstBit()
{
int i;
int pos;
int j;
BYTE ch;

	for (i = 0; i < 256; i++) {

		printf("/* %3d */", i);
		printf("\t");

		pos = 0;

		ch = (BYTE) i;
		for (j = 0; j < 8; j++) {
			if ( (ch & 0x80) == 0x80) {
				break;
			}
			ch <<= 1;
			pos++;
		}

		printf("%d,", pos);

		printf("\t");
		printf("/* ");
		printByte(i);
		printf(" */");
		printf("\n");
	}
}
#endif	/* GEN_TABLES */

/****************************************************************************

FUNCTION: ReverseBits

PURPOSE:  This routine reverses the bit orders within the bytes of a buffer.

****************************************************************************/

int  WINAPI ReverseBits(PBYTE pBuffer, int nSize)
{
int nStatus = 0;
int nLoop;

    for (nLoop = nSize >> 4; nLoop; nLoop--)
	{
        *(pBuffer) = (unsigned char) bySwapByteTable [*pBuffer]; pBuffer++;
        *(pBuffer) = (unsigned char) bySwapByteTable [*pBuffer]; pBuffer++;
        *(pBuffer) = (unsigned char) bySwapByteTable [*pBuffer]; pBuffer++;
        *(pBuffer) = (unsigned char) bySwapByteTable [*pBuffer]; pBuffer++;
        *(pBuffer) = (unsigned char) bySwapByteTable [*pBuffer]; pBuffer++;
        *(pBuffer) = (unsigned char) bySwapByteTable [*pBuffer]; pBuffer++;
        *(pBuffer) = (unsigned char) bySwapByteTable [*pBuffer]; pBuffer++;
        *(pBuffer) = (unsigned char) bySwapByteTable [*pBuffer]; pBuffer++;
        *(pBuffer) = (unsigned char) bySwapByteTable [*pBuffer]; pBuffer++;
        *(pBuffer) = (unsigned char) bySwapByteTable [*pBuffer]; pBuffer++;
        *(pBuffer) = (unsigned char) bySwapByteTable [*pBuffer]; pBuffer++;
        *(pBuffer) = (unsigned char) bySwapByteTable [*pBuffer]; pBuffer++;
        *(pBuffer) = (unsigned char) bySwapByteTable [*pBuffer]; pBuffer++;
        *(pBuffer) = (unsigned char) bySwapByteTable [*pBuffer]; pBuffer++;
        *(pBuffer) = (unsigned char) bySwapByteTable [*pBuffer]; pBuffer++;
        *(pBuffer) = (unsigned char) bySwapByteTable [*pBuffer]; pBuffer++;
    }
    for (nLoop = (nSize >> 2) & 3; nLoop; nLoop--)
	{
        *(pBuffer) = (unsigned char) bySwapByteTable [*pBuffer]; pBuffer++;
        *(pBuffer) = (unsigned char) bySwapByteTable [*pBuffer]; pBuffer++;
        *(pBuffer) = (unsigned char) bySwapByteTable [*pBuffer]; pBuffer++;
        *(pBuffer) = (unsigned char) bySwapByteTable [*pBuffer]; pBuffer++;
    }
    for (nLoop = nSize & 3; nLoop; nLoop--)
	{
        *(pBuffer) = (unsigned char) bySwapByteTable [*pBuffer]; pBuffer++;
    }

    return(nStatus);
}

/****************************************************************************

    FUNCTION:   NegateBits

    PURPOSE:    This routine negates the bits within the bytes of a buffer.

****************************************************************************/

int  WINAPI NegateBits(PBYTE pBuffer, int nSize){

int  nStatus = 0;
int  nLoop;
PLONG pLong;


    nLoop = min(nSize, (int)((INT_PTR)sizeof(LONG) - (((INT_PTR)pBuffer) & 3 )));
    nSize -= nLoop;
    for (; nLoop; nLoop--){
        *(pBuffer++) ^= 0x0ff;
    }

    pLong = (PLONG) pBuffer;
    for (nLoop = nSize >> 5; nLoop; nLoop--){
        *(pLong++) ^= 0x0ffffffff;
        *(pLong++) ^= 0x0ffffffff;
        *(pLong++) ^= 0x0ffffffff;
        *(pLong++) ^= 0x0ffffffff;
        *(pLong++) ^= 0x0ffffffff;
        *(pLong++) ^= 0x0ffffffff;
        *(pLong++) ^= 0x0ffffffff;
        *(pLong++) ^= 0x0ffffffff;
    }
    for (nLoop = (nSize >> 2) & 7; nLoop; nLoop--){
        *(pLong++) ^= 0x0ffffffff;
    }

    pBuffer = (PBYTE) pLong;
    for (nLoop = nSize & 3; nLoop; nLoop--){
        *(pBuffer++) ^= 0x0ff;
    }

    return(nStatus);
}
/****************************************************************************

    FUNCTION:   RunLengthsTo1DLine

    PURPOSE:    This routine compresses the image data using Group 3 1D.

****************************************************************************/

int  WINAPI RunLengthsTo1DLine(PINT pnRunLengths, PBYTE *ppCompressedBuffer,
                        PUINT puCodeWord, PINT pnCodeWordBits,
                        int nWidthBytes, int nFlags){

int  nStatus = 0;

int  nRunLengthIndex;
int  nRunLength;
UINT uCodeWord;
int  nCodeWordBits;
int  nIndex;
PBYTE pCompressedBuffer;

	nWidthBytes = nWidthBytes;

    uCodeWord = *puCodeWord;
    nCodeWordBits = *pnCodeWordBits;
    pCompressedBuffer = *ppCompressedBuffer;

    // Translate Runlengths into Codewords.
    // Labels use Prefix = C1D (Compress 1D), Suffix = W or B (White or Black).

    if (nFlags & COMPRESS_BEGINNING_EOLS){
        // Byte align the EOLs.
        if (nCodeWordBits <= 4){
            uCodeWord = uCodeWord << (4 - nCodeWordBits);
            nCodeWordBits += (4 - nCodeWordBits);
        }else if (nCodeWordBits <= 12){
            uCodeWord = uCodeWord << (12 - nCodeWordBits);
            nCodeWordBits += (12 - nCodeWordBits);
        }else if (nCodeWordBits <= 20){
            uCodeWord = uCodeWord << (20 - nCodeWordBits);
            nCodeWordBits += (20 - nCodeWordBits);
        }else{
            uCodeWord = uCodeWord << (28 - nCodeWordBits);
            nCodeWordBits += (28 - nCodeWordBits);
        }
        uCodeWord = (uCodeWord << 12) | 0x01;
        nCodeWordBits += 12;
    }

    if (!pnRunLengths[0]){
        uCodeWord = (uCodeWord << 8) | 0x35;
        *(pCompressedBuffer++) = (unsigned char)(uCodeWord >> nCodeWordBits);
        nRunLengthIndex = 1;
        goto C1DB;
    }else{
        nRunLengthIndex = 0;
    }

C1DW:
    while(nCodeWordBits >= 8){
        nCodeWordBits -= 8;
        *(pCompressedBuffer++) = (unsigned char)(uCodeWord >> nCodeWordBits);
    }
	nRunLength = pnRunLengths[nRunLengthIndex++];
    if (!nRunLength){
        goto C1DDone;
    }
    while(nRunLength > 63){
        nIndex = min(40, nRunLength >> 6);
        uCodeWord = (uCodeWord << nWRunLengthToMakeUpCodeLength[nIndex])
                | nWRunLengthToMakeUpCodeR[nIndex];
        nCodeWordBits += nWRunLengthToMakeUpCodeLength[nIndex];
        nRunLength -= nIndex << 6;
        while(nCodeWordBits >= 8){
            nCodeWordBits -= 8;
            *(pCompressedBuffer++) = (unsigned char)(uCodeWord >> nCodeWordBits);
        }
    }
    uCodeWord = (uCodeWord << nWRunLengthToTermCodeLength[nRunLength])
            | nWRunLengthToTermCodeR[nRunLength];
    nCodeWordBits += nWRunLengthToTermCodeLength[nRunLength];

C1DB:
    while(nCodeWordBits >= 8){
        nCodeWordBits -= 8;
        *(pCompressedBuffer++) = (unsigned char)(uCodeWord >> nCodeWordBits);
    }
	nRunLength = pnRunLengths[nRunLengthIndex++];
    if (!nRunLength){
        goto C1DDone;
    }
    while(nRunLength > 63){
        nIndex = min(40, nRunLength >> 6);
        uCodeWord = (uCodeWord << nBRunLengthToMakeUpCodeLength[nIndex])
                | nBRunLengthToMakeUpCodeR[nIndex];
        nCodeWordBits += nBRunLengthToMakeUpCodeLength[nIndex];
        nRunLength -= nIndex << 6;
        while(nCodeWordBits >= 8){
            nCodeWordBits -= 8;
            *(pCompressedBuffer++) = (unsigned char)(uCodeWord >> nCodeWordBits);
        }
    }
    uCodeWord = (uCodeWord << nBRunLengthToTermCodeLength[nRunLength])
            | nBRunLengthToTermCodeR[nRunLength];
    nCodeWordBits += nBRunLengthToTermCodeLength[nRunLength];
    goto C1DW;


C1DDone:
    if ((nFlags & COMPRESS_BYTE_ALIGN_LINES) && (nFlags & COMPRESS_ENDING_EOLS)){
        // Byte align the EOLs.
        if (nCodeWordBits <= 4){
            uCodeWord = uCodeWord << (4 - nCodeWordBits);
            nCodeWordBits += (4 - nCodeWordBits);
        }else if (nCodeWordBits <= 12){
            uCodeWord = uCodeWord << (12 - nCodeWordBits);
            nCodeWordBits += (12 - nCodeWordBits);
        }else if (nCodeWordBits <= 20){
            uCodeWord = uCodeWord << (20 - nCodeWordBits);
            nCodeWordBits += (20 - nCodeWordBits);
        }else{
            uCodeWord = uCodeWord << (28 - nCodeWordBits);
            nCodeWordBits += (28 - nCodeWordBits);
        }
        uCodeWord = (uCodeWord << 12) | 0x01;
        nCodeWordBits += 12;
    }else if (nFlags & COMPRESS_BYTE_ALIGN_LINES){  // && !bAddEndingEols
        if (nCodeWordBits){
            uCodeWord <<= 8 - nCodeWordBits;
            nCodeWordBits = 8;
        }
    }else if (nFlags & COMPRESS_ENDING_EOLS){  // && !bByteAlignLines
        uCodeWord = (uCodeWord << 12) | 0x001;
        nCodeWordBits += 12;
    }
    while(nCodeWordBits >= 8){
        nCodeWordBits -= 8;
        *(pCompressedBuffer++) = (unsigned char)(uCodeWord >> nCodeWordBits);
    }

    *puCodeWord = uCodeWord;
    *pnCodeWordBits = nCodeWordBits;
    *ppCompressedBuffer = pCompressedBuffer;


//Exit:
    return(nStatus);
}
/****************************************************************************

    FUNCTION:   RunLengthsTo2DLine

    PURPOSE:    This routine compresses the image data using Group 3 1D.

****************************************************************************/

int  WINAPI RunLengthsTo2DLine(PINT pnRunLengths, PINT pnOldRunLengths,
                        PBYTE *ppCompressedBuffer, PUINT puCodeWord,
                        PINT pnCodeWordBits, int nWidthBytes, int nFlags){

int  nStatus = 0;
UINT uCodeWord;
int  nCodeWordBits;
int  nIndex;
int  nRunLength;
int  nLoop;
PBYTE pCompressedBuffer;

int  nOldRunLength;
int  nB1;
int  nB2;
int  nOldRunLenthIndex;
int  nOldRunLenthLastIndex;

int  nA1;        // Run length left till A1.
int  nA1Index;

	nWidthBytes = nWidthBytes;

    uCodeWord = *puCodeWord;
    nCodeWordBits = *pnCodeWordBits;
    pCompressedBuffer = *ppCompressedBuffer;

    // Translate Runlengths into Codewords.
    // Labels use Prefix = C2D (Compress 2D), Suffix = W or B (White or Black).

    if (nFlags & COMPRESS_BEGINNING_EOLS){
        uCodeWord = (uCodeWord << 12) | 0x01;
        nCodeWordBits += 12;
    }

    // Set the Runlength after the last one to 99,999 to force it out of the calculations.
    // There is no body to this for loop.
    for (nOldRunLenthLastIndex = 1; pnOldRunLengths[nOldRunLenthLastIndex]
            && pnOldRunLengths[nOldRunLenthLastIndex] != 99999; nOldRunLenthLastIndex++);
    pnOldRunLengths[nOldRunLenthLastIndex    ] = 99999;
    pnOldRunLengths[nOldRunLenthLastIndex + 1] = 99999;
    pnOldRunLengths[nOldRunLenthLastIndex + 2] = 99999;
    pnOldRunLengths[nOldRunLenthLastIndex + 3] = 99999;

    nOldRunLength = pnOldRunLengths[0];
    nOldRunLenthIndex = 1;

    nA1 = pnRunLengths[0];
    nA1Index = 1;
    nRunLength = 0;
    goto C2DStart;

C2DNext:
    while(nCodeWordBits >= 8){
        nCodeWordBits -= 8;
        *(pCompressedBuffer++) = (unsigned char)(uCodeWord >> nCodeWordBits);
    }
    if (!nA1){
        goto C2DDone;
    }

    nOldRunLength -= nRunLength;
    while(nOldRunLength <= 0){
        nOldRunLength += pnOldRunLengths[nOldRunLenthIndex++];
    }

C2DStart:
    if ((nOldRunLenthIndex & 1) == (nA1Index & 1)){
        nB1 = nOldRunLength;
        nB2 = nB1 + pnOldRunLengths[nOldRunLenthIndex];
    }else{
        nB1 = nOldRunLength + pnOldRunLengths[nOldRunLenthIndex];
        nB2 = nB1 + pnOldRunLengths[nOldRunLenthIndex + 1];
    }


    switch ((nA1 - nB1) + 3){
        case 0: // A1 = B1 - 3.
            uCodeWord = (uCodeWord << 7) | 0x02;
            nCodeWordBits += 7;
            nRunLength = nA1;
            nA1 = pnRunLengths[nA1Index++];
            goto C2DNext;
        case 1: // A1 = B1 - 2.
            uCodeWord = (uCodeWord << 6) | 0x02;
            nCodeWordBits += 6;
            nRunLength = nA1;
            nA1 = pnRunLengths[nA1Index++];
            goto C2DNext;
        case 2: // A1 = B1 - 1.
            uCodeWord = (uCodeWord << 3) | 0x02;
            nCodeWordBits += 3;
            nRunLength = nA1;
            nA1 = pnRunLengths[nA1Index++];
            goto C2DNext;
        case 3: // A1 = B1.
            uCodeWord = (uCodeWord << 1) | 0x1;
            nCodeWordBits += 1;
            nRunLength = nA1;
            nA1 = pnRunLengths[nA1Index++];
            goto C2DNext;
        case 4: // A1 = B1 + 1.
            uCodeWord = (uCodeWord << 3) | 0x03;
            nCodeWordBits += 3;
            nRunLength = nA1;
            nA1 = pnRunLengths[nA1Index++];
            goto C2DNext;
        case 5: // A1 = B1 + 2.
            uCodeWord = (uCodeWord << 6) | 0x03;
            nCodeWordBits += 6;
            nRunLength = nA1;
            nA1 = pnRunLengths[nA1Index++];
            goto C2DNext;
        case 6: // A1 = B1 + 3.
            uCodeWord = (uCodeWord << 7) | 0x03;
            nCodeWordBits += 7;
            nRunLength = nA1;
            nA1 = pnRunLengths[nA1Index++];
            goto C2DNext;

        default: // Pass or Horz mode.
            if (nB2 < nA1){
                // Check to see if there will be 3 or more passes.
                if (!(nOldRunLenthIndex & 1)){
                    nIndex = nOldRunLenthIndex + 1;
                }else{
                    nIndex = nOldRunLenthIndex + 2;
                }
                nRunLength = nB2;
                for (nLoop = 0; nLoop < 3 && nRunLength < nA1; nLoop++){
                    nRunLength += pnOldRunLengths[nIndex++];
                    nRunLength += pnOldRunLengths[nIndex++];
                }
                if (nLoop < 3){
                    // Pass mode.
                    uCodeWord = (uCodeWord << 4) | 0x01;
                    nCodeWordBits += 4;
                    nRunLength = nB2;
                    nA1 -= nRunLength;
                    goto C2DNext;
                }
            }

            // Horizontal mode.
            uCodeWord = (uCodeWord << 3) | 0x001;
            nCodeWordBits += 3;
            nRunLength = nA1;

            if ((nA1Index & 1)){
                // nA1 is a white run length;
                while(nA1 > 63){
                    nIndex = min(40, nA1 >> 6);
                    uCodeWord = (uCodeWord << nWRunLengthToMakeUpCodeLength[nIndex])
                            | nWRunLengthToMakeUpCodeR[nIndex];
                    nCodeWordBits += nWRunLengthToMakeUpCodeLength[nIndex];
                    nA1 -= nIndex << 6;
                    while(nCodeWordBits >= 8){
                        nCodeWordBits -= 8;
                        *(pCompressedBuffer++) = (unsigned char)(uCodeWord >> nCodeWordBits);
                    }
                }
                uCodeWord = (uCodeWord << nWRunLengthToTermCodeLength[nA1])
                        | nWRunLengthToTermCodeR[nA1];
                nCodeWordBits += nWRunLengthToTermCodeLength[nA1];
                while(nCodeWordBits >= 8){
                    nCodeWordBits -= 8;
                    *(pCompressedBuffer++) = (unsigned char)(uCodeWord >> nCodeWordBits);
                }

                nA1 = pnRunLengths[nA1Index++];
                nRunLength += nA1;
                while(nA1 > 63){
                    nIndex = min(40, nA1 >> 6);
                    uCodeWord = (uCodeWord << nBRunLengthToMakeUpCodeLength[nIndex])
                            | nBRunLengthToMakeUpCodeR[nIndex];
                    nCodeWordBits += nBRunLengthToMakeUpCodeLength[nIndex];
                    nA1 -= nIndex << 6;

                    while(nCodeWordBits >= 8){
                        nCodeWordBits -= 8;
                        *(pCompressedBuffer++) = (unsigned char)(uCodeWord >> nCodeWordBits);
                    }
                }
                uCodeWord = (uCodeWord << nBRunLengthToTermCodeLength[nA1])
                        | nBRunLengthToTermCodeR[nA1];
                nCodeWordBits += nBRunLengthToTermCodeLength[nA1];
                nA1 = pnRunLengths[nA1Index++];
                goto C2DNext;
            }else{
                // nA1 is a black run length;
                while(nA1 > 63){
                    nIndex = min(40, nA1 >> 6);
                    uCodeWord = (uCodeWord << nBRunLengthToMakeUpCodeLength[nIndex])
                            | nBRunLengthToMakeUpCodeR[nIndex];
                    nCodeWordBits += nBRunLengthToMakeUpCodeLength[nIndex];
                    nA1 -= nIndex << 6;
                    while(nCodeWordBits >= 8){
                        nCodeWordBits -= 8;
                        *(pCompressedBuffer++) = (unsigned char)(uCodeWord >> nCodeWordBits);
                    }
                }
                uCodeWord = (uCodeWord << nBRunLengthToTermCodeLength[nA1])
                        | nBRunLengthToTermCodeR[nA1];
                nCodeWordBits += nBRunLengthToTermCodeLength[nA1];
                while(nCodeWordBits >= 8){
                    nCodeWordBits -= 8;
                    *(pCompressedBuffer++) = (unsigned char)(uCodeWord >> nCodeWordBits);
                }

                nA1 = pnRunLengths[nA1Index++];
                nRunLength += nA1;
                while(nA1 > 63){
                    nIndex = min(40, nA1 >> 6);
                    uCodeWord = (uCodeWord << nWRunLengthToMakeUpCodeLength[nIndex])
                            | nWRunLengthToMakeUpCodeR[nIndex];
                    nCodeWordBits += nWRunLengthToMakeUpCodeLength[nIndex];
                    nA1 -= nIndex << 6;

                    while(nCodeWordBits >= 8){
                        nCodeWordBits -= 8;
                        *(pCompressedBuffer++) = (unsigned char)(uCodeWord >> nCodeWordBits);
                    }
                }
                uCodeWord = (uCodeWord << nWRunLengthToTermCodeLength[nA1])
                        | nWRunLengthToTermCodeR[nA1];
                nCodeWordBits += nWRunLengthToTermCodeLength[nA1];
                nA1 = pnRunLengths[nA1Index++];
                goto C2DNext;
            }
    }


C2DDone:
    pnOldRunLengths[nOldRunLenthLastIndex    ] = 0;
    pnOldRunLengths[nOldRunLenthLastIndex + 1] = 0;
    pnOldRunLengths[nOldRunLenthLastIndex + 2] = 0;
    pnOldRunLengths[nOldRunLenthLastIndex + 3] = 0;
    *puCodeWord = uCodeWord;
    *pnCodeWordBits = nCodeWordBits;
    *ppCompressedBuffer = pCompressedBuffer;


//Exit:
    return(nStatus);
}



/****************************************************************************

    FUNCTION:   CompressG42D

    PURPOSE:    This routine compresses the image data using Group 4 2D.

****************************************************************************/

#define MAX_RUNS	65536

int memg4_compress
(
	int nWidth,
	int nHeight,
	PBYTE pImageData,
	PBYTE *ppCompressedBuffer,
	PINT pnCompressedBufferSize,
	int nFlags
)
{
int  nStatus = 0;
int  nLine;
STATIC int nOldRunLengths[MAX_RUNS];
STATIC int nRunLengths[MAX_RUNS];
int  nWidthBytes;
UINT uCodeWord;
int  nCodeWordBits;
int  nLoop;
PBYTE pCompressedBuffer;
int  nCompressedBufferMaxSize;
BOOL bReverseImage = FALSE;
BOOL bNegateImage = FALSE;
STATIC int nLastCompressedBufferMaxSize = 0;
STATIC PBYTE pCompressedBufferStart = 0;

	bReverseImage = bReverseImage;

	// Free...
	if (!nWidth) {
#if 0
if (pCompressedBufferStart) VirtualFree(pCompressedBufferStart,0,MEM_RELEASE);
#endif
		pCompressedBufferStart = 0;
		return(0);
	}

	pCompressedBufferStart = *ppCompressedBuffer;

	nWidthBytes = (nWidth + 7) >> 3;
	uCodeWord = 0;
	nCodeWordBits = 0;

	if ((nFlags & COMPRESS_NEGATE_BITS)) {
		bNegateImage = TRUE;
		CheckError2( NegateBits(pImageData, nWidthBytes * nHeight))
	}

	// Init to all white line.

	nOldRunLengths[0] = nWidth;
	nOldRunLengths[1] = 0;

	nCompressedBufferMaxSize = max(10000, (nHeight * nWidthBytes) * 6);

	if (nLastCompressedBufferMaxSize < nCompressedBufferMaxSize) {
		nLastCompressedBufferMaxSize = nCompressedBufferMaxSize;
#if 0
		if (pCompressedBufferStart)
			VirtualFree(pCompressedBufferStart,0,MEM_RELEASE);
		pCompressedBufferStart = (UCHAR *) VirtualAlloc(NULL,
			nCompressedBufferMaxSize,
			MEM_COMMIT,
			PAGE_READWRITE);
		if (!pCompressedBufferStart) {
			nStatus = MEMGRP_DISPLAY_CANTALLOC;
			goto Exit;
		}
#endif
	}
	pCompressedBuffer = pCompressedBufferStart;

    for (nLine = 0; nLine < nHeight; nLine++){
        CheckError2( LineToRunLengths(pImageData + (nLine * nWidthBytes),
                &nRunLengths[0], nWidth, nWidthBytes, nFlags))
        CheckError2( RunLengthsTo2DLine(&nRunLengths[0], &nOldRunLengths[0],
                &pCompressedBuffer, &uCodeWord, &nCodeWordBits, nWidthBytes, nFlags))

        nOldRunLengths[0] = nRunLengths[0]; // The first entry may be 0.
        for (nLoop = 1; nRunLengths[nLoop]; nLoop++){
            nOldRunLengths[nLoop] = nRunLengths[nLoop];
        }
        nOldRunLengths[nLoop++] = 0;
        nOldRunLengths[nLoop++] = 0;
        nOldRunLengths[nLoop++] = 0;
        nOldRunLengths[nLoop] = 0;
    }

    uCodeWord = (uCodeWord << 24) | 0x001001;
    nCodeWordBits += 24;

    while(nCodeWordBits >= 8){
        nCodeWordBits -= 8;
        *(pCompressedBuffer++) = (UCHAR)(uCodeWord >> nCodeWordBits);
    }
    if (nCodeWordBits > 0){
        *(pCompressedBuffer++) = (UCHAR)(uCodeWord << (8 - nCodeWordBits));
    }


	nCompressedBufferMaxSize = (int)((pCompressedBuffer - pCompressedBufferStart) + 4);

#if 0
	nStatus = ReduceMemory(nCompressedBufferMaxSize, &pCompressedBufferStart);
	if (nStatus) {
		goto Exit;
	}
#endif
	*ppCompressedBuffer = pCompressedBufferStart;
	*pnCompressedBufferSize = nCompressedBufferMaxSize - 4;

    if (!(nFlags & COMPRESS_COMPRESSED_IS_LTR)){
        CheckError2( ReverseBits(pCompressedBufferStart, nCompressedBufferMaxSize - 4))
    }


Exit:
    if (bNegateImage){
        NegateBits(pImageData, nWidthBytes * nHeight);
    }
    return(nStatus);
}



/****************************************************************************

    FUNCTION:   D2DLineToRunLengths

    PURPOSE:    This routine decompresses the image data using Group 4 2D.

****************************************************************************/

int  WINAPI
D2DLineToRunLengths(PINT pnRunLengths,
	PINT pnOldRunLengths,
	PBYTE *ppCompressedBuffer,
	PUINT puCodeWord,
	PINT pnCodeWordBits,
	int nWidth,
	int nFlags)
{
int  nStatus = 0;
UINT uCodeWord;
int  nCodeWordBits;
BOOL bEOLReceived;
int  nLoop;
int  nRunLengthIndex;
int  nRunLength;
int  nRunLengthTotal;
int  nCodeWordLength;
int  nCodeByte;
PBYTE pCompressedBuffer;

int  nOldRunLength;
int  nOldRunLenthIndex;
int  nShift;


    uCodeWord = *puCodeWord;
    nCodeWordBits = *pnCodeWordBits;
    nRunLength = 0;
    nRunLengthTotal = 0;
    nRunLengthIndex = 0;
    bEOLReceived = FALSE;
    pCompressedBuffer = *ppCompressedBuffer;

    // Translate Codewords into Runlengths.
    // Labels use Prefix = D2D (Decompress 2D), Suffix = W or B (White or Black).

    while (nCodeWordBits <= CODE_WORD_SHIFT){
        uCodeWord |= *(pCompressedBuffer++) << (CODE_WORD_SHIFT - nCodeWordBits);
        nCodeWordBits += 8;
    }

    if (!(uCodeWord >> (CODE_WORD_SHIFT - 3))){
        // Must have an EOL.
        if (nFlags & COMPRESS_DONT_DELETE_EOLS){
			nStatus = MEMGRP_DISPLAY_COMPRESS_BAD_DATA;
            goto Exit;
        }
        uCodeWord <<= 11;
        nCodeWordBits -= 11;
        uCodeWord |= *(pCompressedBuffer++) << (CODE_WORD_SHIFT - nCodeWordBits);
        nCodeWordBits += 8;
        for (nLoop = 0; nLoop < 16; nLoop++){
			nShift = nFirstOneBit[uCodeWord >> CODE_WORD_SHIFT];
            if (!nShift){
                break;
            }
            uCodeWord <<= nShift;
            nCodeWordBits -= nShift;
            if (nCodeWordBits <= CODE_WORD_SHIFT){
                uCodeWord |= *(pCompressedBuffer++) << (CODE_WORD_SHIFT - nCodeWordBits);
                nCodeWordBits += 8;
            }
        }
        if (!(uCodeWord & CODE_WORD_BIT_MASK)){
			nStatus = MEMGRP_DISPLAY_COMPRESS_BAD_DATA;
            goto Exit;
        }
        uCodeWord <<= 1;
        nCodeWordBits -= 1;
    }

    nOldRunLength = pnOldRunLengths[0];
    nOldRunLenthIndex = 1;
    pnRunLengths[nRunLengthIndex] = 0;
    while (nCodeWordBits <= CODE_WORD_SHIFT){
        uCodeWord |= *(pCompressedBuffer++) << (CODE_WORD_SHIFT - nCodeWordBits);
        nCodeWordBits += 8;
    }
    goto D2DDecodeCodeWord;

D2DNextCodeWord:
    if (nCodeWordBits <= CODE_WORD_SHIFT){
        uCodeWord |= *(pCompressedBuffer++) << (CODE_WORD_SHIFT - nCodeWordBits);
        nCodeWordBits += 8;
    }

    nRunLengthTotal += nRunLength;
    if (nRunLengthTotal >= nWidth){
        if (nRunLengthTotal > nWidth) {
			nStatus = MEMGRP_DISPLAY_COMPRESS_BAD_DATA;
            goto Exit;
        }
        goto D2DDone;
    }

    nOldRunLength -= nRunLength;
    while(nOldRunLength <= 0){
        nOldRunLength += pnOldRunLengths[nOldRunLenthIndex++];
    }


D2DDecodeCodeWord:
    switch (n2DCodeByteToState[uCodeWord >> CODE_WORD_SHIFT]){
        case 0: // Pass.
            uCodeWord <<= 4;
            nCodeWordBits -= 4;
            nRunLength = nOldRunLength + pnOldRunLengths[nOldRunLenthIndex];
            if ((nOldRunLenthIndex & 1) == (nRunLengthIndex & 1)){
                nRunLength += pnOldRunLengths[nOldRunLenthIndex + 1];
            }
            pnRunLengths[nRunLengthIndex] += nRunLength;
            goto D2DNextCodeWord;

        case 1: // Horizontal.
            uCodeWord <<= 3;
            nCodeWordBits -= 3;
            if (!(nRunLengthIndex & 1)){
                // White run length.
                do{
                    if (nCodeWordBits <= CODE_WORD_SHIFT){
                        uCodeWord |= *(pCompressedBuffer++) << (CODE_WORD_SHIFT - nCodeWordBits);
                        nCodeWordBits += 8;
                    }
                    nRunLength = nWCodeByte0ToRunLength[uCodeWord >> CODE_WORD_SHIFT];
                    nCodeWordLength = nWCodeByte0ToCodeWordLength[uCodeWord >> CODE_WORD_SHIFT];
                    uCodeWord <<= nCodeWordLength;
                    nCodeWordBits -= nCodeWordLength;
                    if (nRunLength < 0){
                        if (nCodeWordBits <= CODE_WORD_SHIFT){
                            uCodeWord |= *(pCompressedBuffer++) << (CODE_WORD_SHIFT - nCodeWordBits);
                            nCodeWordBits += 8;
                        }
                        if (nRunLength == -1){
                            nRunLength = nWCodeByte1ToRunLength[uCodeWord >> CODE_WORD_SHIFT];
                            nCodeWordLength = nWCodeByte1ToCodeWordLength[uCodeWord >> CODE_WORD_SHIFT];
                            uCodeWord <<= nCodeWordLength;
                            nCodeWordBits -= nCodeWordLength;
                        }else if (nRunLength == -4){
                            nRunLength = nWCodeByte4ToRunLength[uCodeWord >> CODE_WORD_SHIFT];
                            nCodeWordLength = nWCodeByte4ToCodeWordLength[uCodeWord >> CODE_WORD_SHIFT];
                            uCodeWord <<= nCodeWordLength;
                            nCodeWordBits -= nCodeWordLength;
                        }else {
							nStatus = MEMGRP_DISPLAY_COMPRESS_BAD_DATA;
                            goto Exit;
                        }
                        if (nRunLength < 0){
                            if (nRunLength == -7){
                                if (nFlags & COMPRESS_DONT_DELETE_EOLS){
									nStatus = MEMGRP_DISPLAY_COMPRESS_BAD_DATA;
                                    goto Exit;
                                }
                                pnRunLengths[nRunLengthIndex++] += nWidth - nRunLengthTotal;
                                pnRunLengths[nRunLengthIndex] = 0;
                                goto D2DEOL2;
                            }else{
								nStatus = MEMGRP_DISPLAY_COMPRESS_BAD_DATA;
                                goto Exit;
                            }
                        }
                    }

                    pnRunLengths[nRunLengthIndex] += nRunLength;
                    nRunLengthTotal += nRunLength;
                    nOldRunLength -= nRunLength;
                    while(nOldRunLength <= 0){
                        nOldRunLength += pnOldRunLengths[nOldRunLenthIndex++];
                    }
                }while(nRunLength >= 64);
                nRunLengthIndex++;
                pnRunLengths[nRunLengthIndex] = 0;

                // Black run length.
                do{
                    if (nCodeWordBits <= CODE_WORD_SHIFT){
                        uCodeWord |= *(pCompressedBuffer++) << (CODE_WORD_SHIFT - nCodeWordBits);
                        nCodeWordBits += 8;
                    }
                    nRunLength = nBCodeByte0ToRunLength[uCodeWord >> CODE_WORD_SHIFT];
                    nCodeWordLength = nBCodeByte0ToCodeWordLength[uCodeWord >> CODE_WORD_SHIFT];
                    uCodeWord <<= nCodeWordLength;
                    nCodeWordBits -= nCodeWordLength;
                    if (nRunLength < 0){
                        if (nCodeWordBits <= CODE_WORD_SHIFT){
                            uCodeWord |= *(pCompressedBuffer++) << (CODE_WORD_SHIFT - nCodeWordBits);
                            nCodeWordBits += 8;
                        }
                        if (nRunLength == -4){
                            nRunLength = nBCodeByte4ToRunLength[uCodeWord >> CODE_WORD_SHIFT];
                            nCodeWordLength = nBCodeByte4ToCodeWordLength[uCodeWord >> CODE_WORD_SHIFT];
                            uCodeWord <<= nCodeWordLength;
                            nCodeWordBits -= nCodeWordLength;
                        }else if (nRunLength == -5){
                            nRunLength = nBCodeByte5ToRunLength[uCodeWord >> CODE_WORD_SHIFT];
                            nCodeWordLength = nBCodeByte5ToCodeWordLength[uCodeWord >> CODE_WORD_SHIFT];
                            uCodeWord <<= nCodeWordLength;
                            nCodeWordBits -= nCodeWordLength;
                        }else{
							nStatus = MEMGRP_DISPLAY_COMPRESS_BAD_DATA;
                            goto Exit;
                        }
                        if (nRunLength < 0){
                            if (nRunLength == -7){
                                if (nFlags & COMPRESS_DONT_DELETE_EOLS){
									nStatus = MEMGRP_DISPLAY_COMPRESS_BAD_DATA;
                                    goto Exit;
                                }
                                pnRunLengths[nRunLengthIndex++] += nWidth - nRunLengthTotal;
                                pnRunLengths[nRunLengthIndex] = 0;
                                goto D2DEOL2;
                            }else{
								nStatus = MEMGRP_DISPLAY_COMPRESS_BAD_DATA;
                                goto Exit;
                            }
                        }
                    }

                    pnRunLengths[nRunLengthIndex] += nRunLength;
                    nRunLengthTotal += nRunLength;
                    nOldRunLength -= nRunLength;
                    while(nOldRunLength <= 0){
                        nOldRunLength += pnOldRunLengths[nOldRunLenthIndex++];
                    }
                }while(nRunLength >= 64);
            }else{
                // Black run length.
                do{
                    if (nCodeWordBits <= CODE_WORD_SHIFT){
                        uCodeWord |= *(pCompressedBuffer++) << (CODE_WORD_SHIFT - nCodeWordBits);
                        nCodeWordBits += 8;
                    }
                    nRunLength = nBCodeByte0ToRunLength[uCodeWord >> CODE_WORD_SHIFT];
                    nCodeWordLength = nBCodeByte0ToCodeWordLength[uCodeWord >> CODE_WORD_SHIFT];
                    uCodeWord <<= nCodeWordLength;
                    nCodeWordBits -= nCodeWordLength;
                    if (nRunLength < 0){
                        if (nCodeWordBits <= CODE_WORD_SHIFT){
                            uCodeWord |= *(pCompressedBuffer++) << (CODE_WORD_SHIFT - nCodeWordBits);
                            nCodeWordBits += 8;
                        }
                        if (nRunLength == -4){
                            nRunLength = nBCodeByte4ToRunLength[uCodeWord >> CODE_WORD_SHIFT];
                            nCodeWordLength = nBCodeByte4ToCodeWordLength[uCodeWord >> CODE_WORD_SHIFT];
                            uCodeWord <<= nCodeWordLength;
                            nCodeWordBits -= nCodeWordLength;
                        }else if (nRunLength == -5){
                            nRunLength = nBCodeByte5ToRunLength[uCodeWord >> CODE_WORD_SHIFT];
                            nCodeWordLength = nBCodeByte5ToCodeWordLength[uCodeWord >> CODE_WORD_SHIFT];
                            uCodeWord <<= nCodeWordLength;
                            nCodeWordBits -= nCodeWordLength;
                        }else{
							nStatus = MEMGRP_DISPLAY_COMPRESS_BAD_DATA;
                            goto Exit;
                        }
                        if (nRunLength < 0){
                            if (nRunLength == -7){
                                if (nFlags & COMPRESS_DONT_DELETE_EOLS){
									nStatus = MEMGRP_DISPLAY_COMPRESS_BAD_DATA;
                                    goto Exit;
                                }
                                pnRunLengths[nRunLengthIndex++] += nWidth - nRunLengthTotal;
                                pnRunLengths[nRunLengthIndex] = 0;
                                goto D2DEOL2;
                            }else{
								nStatus = MEMGRP_DISPLAY_COMPRESS_BAD_DATA;
                                goto Exit;
                            }
                        }
                    }

                    pnRunLengths[nRunLengthIndex] += nRunLength;
                    nRunLengthTotal += nRunLength;
                    nOldRunLength -= nRunLength;
                    while(nOldRunLength <= 0){
                        nOldRunLength += pnOldRunLengths[nOldRunLenthIndex++];
                    }
                }while(nRunLength >= 64);
                nRunLengthIndex++;
                pnRunLengths[nRunLengthIndex] = 0;

                // White run length.
                do{
                    if (nCodeWordBits <= CODE_WORD_SHIFT){
                        uCodeWord |= *(pCompressedBuffer++) << (CODE_WORD_SHIFT - nCodeWordBits);
                        nCodeWordBits += 8;
                    }
                    nRunLength = nWCodeByte0ToRunLength[uCodeWord >> CODE_WORD_SHIFT];
                    nCodeWordLength = nWCodeByte0ToCodeWordLength[uCodeWord >> CODE_WORD_SHIFT];
                    uCodeWord <<= nCodeWordLength;
                    nCodeWordBits -= nCodeWordLength;
                    if (nRunLength < 0){
                        if (nCodeWordBits <= CODE_WORD_SHIFT){
                            uCodeWord |= *(pCompressedBuffer++) << (CODE_WORD_SHIFT - nCodeWordBits);
                            nCodeWordBits += 8;
                        }
                        if (nRunLength == -1){
                            nRunLength = nWCodeByte1ToRunLength[uCodeWord >> CODE_WORD_SHIFT];
                            nCodeWordLength = nWCodeByte1ToCodeWordLength[uCodeWord >> CODE_WORD_SHIFT];
                            uCodeWord <<= nCodeWordLength;
                            nCodeWordBits -= nCodeWordLength;
                        }else if (nRunLength == -4){
                            nRunLength = nWCodeByte4ToRunLength[uCodeWord >> CODE_WORD_SHIFT];
                            nCodeWordLength = nWCodeByte4ToCodeWordLength[uCodeWord >> CODE_WORD_SHIFT];
                            uCodeWord <<= nCodeWordLength;
                            nCodeWordBits -= nCodeWordLength;
                        }else{
							nStatus = MEMGRP_DISPLAY_COMPRESS_BAD_DATA;
                            goto Exit;
                        }
                        if (nRunLength < 0){
                            if (nRunLength == -7){
                                if (nFlags & COMPRESS_DONT_DELETE_EOLS){
									nStatus = MEMGRP_DISPLAY_COMPRESS_BAD_DATA;
                                    goto Exit;
                                }
                                pnRunLengths[nRunLengthIndex++] += nWidth - nRunLengthTotal;
                                pnRunLengths[nRunLengthIndex] = 0;
                                goto D2DEOL2;
                            }else{
								nStatus = MEMGRP_DISPLAY_COMPRESS_BAD_DATA;
                                goto Exit;
                            }
                        }
                    }

                    pnRunLengths[nRunLengthIndex] += nRunLength;
                    nRunLengthTotal += nRunLength;
                    nOldRunLength -= nRunLength;
                    while(nOldRunLength <= 0){
                        nOldRunLength += pnOldRunLengths[nOldRunLenthIndex++];
                    }
                }while(nRunLength >= 64);
            }

            nRunLengthIndex++;
            pnRunLengths[nRunLengthIndex] = 0;
            nRunLength = 0;
            goto D2DNextCodeWord;

        case 2: // A1 = B1.
            uCodeWord <<= 1;
            nCodeWordBits -= 1;
            nRunLength = nOldRunLength;
            if ((nOldRunLenthIndex & 1) == (nRunLengthIndex & 1)){
                nRunLength += pnOldRunLengths[nOldRunLenthIndex];
            }
            pnRunLengths[nRunLengthIndex++] += nRunLength;
            pnRunLengths[nRunLengthIndex] = 0;
            goto D2DNextCodeWord;

        case 3: // A1 = B1 + 1.
            uCodeWord <<= 3;
            nCodeWordBits -= 3;
            nRunLength = nOldRunLength + 1;
            if ((nOldRunLenthIndex & 1) == (nRunLengthIndex & 1)){
                nRunLength += pnOldRunLengths[nOldRunLenthIndex];
            }
            pnRunLengths[nRunLengthIndex++] += nRunLength;
            pnRunLengths[nRunLengthIndex] = 0;
            goto D2DNextCodeWord;

        case 4: // A1 = B1 + 2.
            uCodeWord <<= 6;
            nCodeWordBits -= 6;
            nRunLength = nOldRunLength + 2;
            if ((nOldRunLenthIndex & 1) == (nRunLengthIndex & 1)){
                nRunLength += pnOldRunLengths[nOldRunLenthIndex];
            }
            pnRunLengths[nRunLengthIndex++] += nRunLength;
            pnRunLengths[nRunLengthIndex] = 0;
            goto D2DNextCodeWord;

        case 5: // A1 = B1 + 3.
            uCodeWord <<= 7;
            nCodeWordBits -= 7;
            nRunLength = nOldRunLength + 3;
            if ((nOldRunLenthIndex & 1) == (nRunLengthIndex & 1)){
                nRunLength += pnOldRunLengths[nOldRunLenthIndex];
            }
            pnRunLengths[nRunLengthIndex++] += nRunLength;
            pnRunLengths[nRunLengthIndex] = 0;
            goto D2DNextCodeWord;

        case 6: // A1 = B1 - 1.
            uCodeWord <<= 3;
            nCodeWordBits -= 3;
            nRunLength = nOldRunLength - 1;
            if ((nOldRunLenthIndex & 1) == (nRunLengthIndex & 1)){
                nRunLength += pnOldRunLengths[nOldRunLenthIndex];
            }
            pnRunLengths[nRunLengthIndex++] += nRunLength;
            pnRunLengths[nRunLengthIndex] = 0;
            goto D2DNextCodeWord;

        case 7: // A1 = B1 - 2.
            uCodeWord <<= 6;
            nCodeWordBits -= 6;
            nRunLength = nOldRunLength - 2;
            if ((nOldRunLenthIndex & 1) == (nRunLengthIndex & 1)){
                nRunLength += pnOldRunLengths[nOldRunLenthIndex];
            }
            pnRunLengths[nRunLengthIndex++] += nRunLength;
            pnRunLengths[nRunLengthIndex] = 0;
            goto D2DNextCodeWord;

        case 8: // A1 = B1 - 3.
            uCodeWord <<= 7;
            nCodeWordBits -= 7;
            nRunLength = nOldRunLength - 3;
            if ((nOldRunLenthIndex & 1) == (nRunLengthIndex & 1)){
                nRunLength += pnOldRunLengths[nOldRunLenthIndex];
            }
            pnRunLengths[nRunLengthIndex++] += nRunLength;
            pnRunLengths[nRunLengthIndex] = 0;
            goto D2DNextCodeWord;

        case 9: // EOL
            uCodeWord <<= 8;
            nCodeWordBits -= 8;
            goto D2DEOL;

        default: // Error.
			nStatus = MEMGRP_DISPLAY_COMPRESS_BAD_DATA;
            goto Exit;
    }


D2DEOL:
    // The first 8 bits of an EOL have been found.
    uCodeWord |= *(pCompressedBuffer++) << (CODE_WORD_SHIFT - nCodeWordBits);
    nCodeWordBits += 8;

    nCodeByte = uCodeWord >> CODE_WORD_SHIFT;
    if (!((uCodeWord >> (CODE_WORD_SHIFT + 5)))){
        // Not enough zeros for an EOL.
		nStatus = MEMGRP_DISPLAY_COMPRESS_BAD_DATA;
        goto Exit;
    }
    uCodeWord <<= 3;
    nCodeWordBits -= 3;
D2DEOL2:
    while (nCodeWordBits <= CODE_WORD_SHIFT){
        uCodeWord |= *(pCompressedBuffer++) << (CODE_WORD_SHIFT - nCodeWordBits);
        nCodeWordBits += 8;
    }

    for (nLoop = 0; nLoop < 16; nLoop++){
		nShift = nFirstOneBit[uCodeWord >> CODE_WORD_SHIFT];
        if (!nShift){
            break;
        }
        uCodeWord <<= nShift;
        nCodeWordBits -= nShift;
        if (nCodeWordBits <= CODE_WORD_SHIFT){
            uCodeWord |= *(pCompressedBuffer++) << (CODE_WORD_SHIFT - nCodeWordBits);
            nCodeWordBits += 8;
        }
    }
    if (!(uCodeWord & CODE_WORD_BIT_MASK)){
		nStatus = MEMGRP_DISPLAY_COMPRESS_BAD_DATA;
        goto Exit;
    }
    uCodeWord <<= 1;
    nCodeWordBits -= 1;

    if (nRunLengthTotal != nWidth){
          nRunLengthTotal = min(nRunLengthTotal,nWidth);
          nStatus = MEMGRP_DISPLAY_COMPRESS_BAD_DATA;
          goto Exit;
    }
    bEOLReceived = TRUE;
    goto D2DDone;

D2DDone:
    pnRunLengths[nRunLengthIndex++] = 0;

    if (!bEOLReceived && !(nFlags & COMPRESS_DONT_DELETE_EOLS)
            && !(uCodeWord >> (CODE_WORD_SHIFT - 3))){
        // Must have an EOL.
        uCodeWord <<= 11;
        nCodeWordBits -= 11;
        uCodeWord |= *(pCompressedBuffer++) << (CODE_WORD_SHIFT - nCodeWordBits);
        nCodeWordBits += 8;
        for (nLoop = 0; nLoop < 16; nLoop++){
			nShift = nFirstOneBit[uCodeWord >> CODE_WORD_SHIFT];
            if (!nShift){
                break;
            }
            uCodeWord <<= nShift;
            nCodeWordBits -= nShift;
            if (nCodeWordBits <= CODE_WORD_SHIFT){
                uCodeWord |= *(pCompressedBuffer++) << (CODE_WORD_SHIFT - nCodeWordBits);
                nCodeWordBits += 8;
            }
        }
        if (!(uCodeWord & CODE_WORD_BIT_MASK)){
			nStatus = MEMGRP_DISPLAY_COMPRESS_BAD_DATA;
            goto Exit;
        }
        uCodeWord <<= 1;
        nCodeWordBits -= 1;
    }

    pnRunLengths[++nRunLengthIndex] = 0;
    pnRunLengths[++nRunLengthIndex] = 0;
    pnRunLengths[++nRunLengthIndex] = 0;
    pnRunLengths[++nRunLengthIndex] = 0;
    pnRunLengths[++nRunLengthIndex] = 0;

    *puCodeWord = uCodeWord;
    *pnCodeWordBits = nCodeWordBits;
    *ppCompressedBuffer = pCompressedBuffer;


Exit:
	return(nStatus);
}
/****************************************************************************

    FUNCTION:   RunLengthsToLine

    PURPOSE:    This routine calculates the line of image data from run lengths.

****************************************************************************/

int  WINAPI RunLengthsToLine(PBYTE pImageData, PINT pnRunLengths,
                        int nWidthPixels, int nWidthBytes, int nFlags){

int  nStatus = 0;

int  nRunLengthIndex;
int  nRunLength;
int  nRLTotal;
PBYTE pImageData2;
int  nBit;

	nWidthBytes = nWidthBytes;

    nRLTotal = 0;
    nRunLengthIndex = 0;

    if (nFlags & COMPRESS_NEGATE_BITS){
        // White = 0, Black = 1.
        if (nFlags & COMPRESS_EXPANDED_IS_LTR){
            // Don't reverse the bits.
            while(nRLTotal < nWidthPixels){
                // Ignor white runlengths.
                nRLTotal += pnRunLengths[nRunLengthIndex++];

                // Set black pixels.
				nRunLength = pnRunLengths[nRunLengthIndex++];
                if (!nRunLength){
                    continue;
                }
                pImageData2 = pImageData + (nRLTotal >> 3);

                // Do first byte.
                nBit = nRLTotal & 7;
                nRLTotal += nRunLength;
                if (nRunLength <= (8 - nBit)){
                    *pImageData2 ^= nRunLengthTo1Bits[nRunLength] >> nBit;
                    continue;
                }else{
                    *(pImageData2++) ^= 0x0ff >> nBit;
                    nRunLength -= 8 - nBit;
                }

                // Do middle bytes.
                while(nRunLength >= 8){
                    *(pImageData2++) = 0x0ff;
                    nRunLength -= 8;
                }

                // Do last byte.
                *pImageData2 = (UCHAR) nRunLengthTo1Bits[nRunLength];
            }
        }else{
            // Reverse the bits.
            while(nRLTotal < nWidthPixels){
                // Ignor white runlengths.
                nRLTotal += pnRunLengths[nRunLengthIndex++];

                // Set black pixels.
				nRunLength = pnRunLengths[nRunLengthIndex++];
                if (!nRunLength){
                    continue;
                }
                pImageData2 = pImageData + (nRLTotal >> 3);

                // Do first byte.
                nBit = nRLTotal & 7;
                nRLTotal += nRunLength;
                if (nRunLength <= (8 - nBit)){
                    *pImageData2 ^= (nRunLengthTo1BitsR[nRunLength] << nBit) & 0x0ff;
                    continue;
                }else{
                    *(pImageData2++) ^= 0x0ff >> nBit;
                    nRunLength -= 8 - nBit;
                }

                // Do middle bytes.
                while(nRunLength >= 8){
                    *(pImageData2++) = 0x0ff;
                    nRunLength -= 8;
                }

                // Do last byte.
                *pImageData2 = (unsigned char)nRunLengthTo1BitsR[nRunLength];
            }
        }
    }else{
        // White = 1, Black = 0.
        if (nFlags & COMPRESS_EXPANDED_IS_LTR){
            // Don't reverse the bits.
            while(nRLTotal < nWidthPixels){
                // Ignor white runlengths.
                nRLTotal += pnRunLengths[nRunLengthIndex++];

                // Set black pixels.
				nRunLength = pnRunLengths[nRunLengthIndex++];
                if (!nRunLength){
                    continue;
                }
                pImageData2 = pImageData + (nRLTotal >> 3);

                // Do first byte.
                nBit = nRLTotal & 7;
                nRLTotal += nRunLength;
                if (nRunLength <= (8 - nBit)){
                    *pImageData2 ^= nRunLengthTo1Bits[nRunLength] >> nBit;
                    continue;
                }else{
                    *(pImageData2++) ^= 0x0ff >> nBit;
                    nRunLength -= 8 - nBit;
                }

                // Do middle bytes.
                while(nRunLength >= 8){
                    *(pImageData2++) = 0;
                    nRunLength -= 8;
                }

                // Do last byte.
                *pImageData2 = (unsigned char)nRunLengthTo0Bits[nRunLength];
            }
        }else{
            // Reverse the bits.
            while(nRLTotal < nWidthPixels){
                // Ignor white runlengths.
                nRLTotal += pnRunLengths[nRunLengthIndex++];

                // Set black pixels.
				nRunLength = pnRunLengths[nRunLengthIndex++];
                if (!nRunLength){
                    continue;
                }
                pImageData2 = pImageData + (nRLTotal >> 3);

                // Do first byte.
                nBit = nRLTotal & 7;
                nRLTotal += nRunLength;
                if (nRunLength <= (8 - nBit)){
                    *pImageData2 ^= (nRunLengthTo1BitsR[nRunLength] << nBit) & 0x0ff;
                    continue;
                }else{
                    *(pImageData2++) ^= 0x0ff >> nBit;
                    nRunLength -= 8 - nBit;
                }

                // Do middle bytes.
                while(nRunLength >= 8){
                    *(pImageData2++) = 0;
                    nRunLength -= 8;
                }

                // Do last byte.
                *pImageData2 = (unsigned char)nRunLengthTo0BitsR[nRunLength];
            }
        }
    }


    return(nStatus);
}


/****************************************************************************

    FUNCTION:   DecompressG42D

    PURPOSE:    This routine decompresses the image data using Group 4 2D.

****************************************************************************/
int memg4_decompress
(
	int nWidth,
	int nHeight,
	int nWidthBytes,
	PBYTE pImageData,
	PBYTE pCompressedBuffer,
	int nCompressedBufferSize,
	int nFlags
)
{

int  nStatus = 0;
int  nLine;
PINT pnRunLengths;
PINT pnOldRunLengths;
UINT uCodeWord;
int  nCodeWordBits;
PBYTE pCompressedBufferEnd;
static int  nRunLengths1[20000];
static int  nRunLengths2[20000];


    if (!(nFlags & COMPRESS_COMPRESSED_IS_LTR)){
        CheckError2( ReverseBits(pCompressedBuffer, nCompressedBufferSize))
    }

    if (nFlags & COMPRESS_NEGATE_BITS){
        memset(pImageData,0,nHeight*nWidthBytes);
    }else{
        memset(pImageData,0xff,nHeight*nWidthBytes);
    }

    pCompressedBufferEnd = pCompressedBuffer + nCompressedBufferSize;
    *(pCompressedBufferEnd++) = 0x00;
    *(pCompressedBufferEnd++) = 0x01;
    *(pCompressedBufferEnd++) = 0x00;
    *(pCompressedBufferEnd++) = 0x01;

    // Init to all white line.
    nRunLengths1[0] = nWidth;
    nRunLengths1[1] = 0;
    nRunLengths1[2] = 0;
    nRunLengths1[3] = 0;
    nRunLengths1[4] = 0;
    nRunLengths1[5] = 0;

    uCodeWord = 0;
    nCodeWordBits = 0;
    while (nCodeWordBits <= CODE_WORD_SHIFT){
        uCodeWord |= *(pCompressedBuffer++) << (CODE_WORD_SHIFT - nCodeWordBits);
        nCodeWordBits += 8;
    }

    for (nLine = 0; nLine < nHeight; nLine++){
        if (nLine & 1){
            pnRunLengths = &nRunLengths1[0];
            pnOldRunLengths = &nRunLengths2[0];
        }else{
            pnRunLengths = &nRunLengths2[0];
            pnOldRunLengths = &nRunLengths1[0];
        }
        if (!(uCodeWord >> (CODE_WORD_SHIFT - 3))){ // EOFB. Fill image with white lines.
            pnRunLengths[0] = nWidth;
            pnRunLengths[1] = 0;
            pnRunLengths[2] = 0;
            pnRunLengths[3] = 0;
            pnRunLengths[4] = 0;
            pnRunLengths[5] = 0;
        }else{
            CheckError2( D2DLineToRunLengths(pnRunLengths, pnOldRunLengths,
                    &pCompressedBuffer, &uCodeWord, &nCodeWordBits, nWidth, nFlags))
        }
        if (pnRunLengths[1]){
            CheckError2( RunLengthsToLine(pImageData + (nLine * nWidthBytes),
                    pnRunLengths, nWidth, nWidthBytes, nFlags))
        }
    }

    // Don't look for EOFB. Some images such as the Teranet images include
    // extra lines of image data.

Exit:
    return(nStatus);
}



/////////////////////////////////////////////////////////////////////////////
//
// LINETORL.CPP
//
// Kodak Confidental
// Copyright (c) Eastman Kodak Company 1989-2000
// All rights reserved
//
/////////////////////////////////////////////////////////////////////////////
/****************************************************************************
    LINETORL.C
****************************************************************************/

//#include "engdisp.h"

//#define debug


/****************************************************************************

    FUNCTION:   LineToRunLengths

    PURPOSE:    This routine calculates the run lengths for a line of image data.

****************************************************************************/

int WINAPI LineToRunLengths(PBYTE pImageData, PINT pnRunLengths, 
                        int nWidthPixels, int nWidthBytes, int nFlags){

int  nStatus = 0;

int  nRunLength;
int  nCount;
int  nCount1;
PINT pnRunLengths2;


#ifdef debug
int  nRunLengthTotal;
PINT pnRunLengthsTemp;
#endif



    nRunLength = 0;
    nCount = nWidthBytes;

#ifdef debug
    pnRunLengths2 = pnRunLengths;
    *(pnRunLengths2++) = 0;
    while (*pnRunLengths2){
        *(pnRunLengths2++) = 0;
    }
#endif

    pnRunLengths2 = pnRunLengths;

    if (!(nFlags & COMPRESS_EXPANDED_IS_LTR)){
        goto CalcRL1R;
    }

CalcRL1:
    if (nCount--){

#ifdef debug
        pnRunLengthsTemp = pnRunLengths;
        nRunLengthTotal = *(pnRunLengthsTemp++);
        while(*pnRunLengthsTemp){
            nRunLengthTotal = *(pnRunLengthsTemp++);
        }
        nRunLengthTotal += nRunLength;
        if (nRunLengthTotal & 7){
            Error(nStatus);
        }
#endif
        
        switch (*(pImageData++)){
            case 0x00: // 0000 0000
                *(pnRunLengths2++) = nRunLength;
                nRunLength = 8;
                goto CalcRL0;

            case 0x01:  // 0000 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 7;
                nRunLength = 1;
                goto CalcRL1;

            case 0x02:  // 0000 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 6;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x03:  // 0000 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 6;
                nRunLength = 2;
                goto CalcRL1;

            case 0x04:  // 0000 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 5;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0x05:  // 0000 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 5;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x06:  // 0000 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 5;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0x07:  // 0000 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 5;
                nRunLength = 3;
                goto CalcRL1;

            case 0x08:  // 0000 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0;

            case 0x09:  // 0000 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0x0a:  // 0000 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x0b:  // 0000 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0x0c:  // 0000 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0;

            case 0x0d: // 0000 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x0e:  // 0000 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0;

            case 0x0f:  // 0000 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                nRunLength = 4;
                goto CalcRL1;

            case 0x10: // 0001 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL0;

            case 0x11: // 0001 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1;

            case 0x12: // 0001 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x13: // 0001 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1;

            case 0x14: // 0001 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0x15: // 0001 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x16: // 0001 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0x17: // 0001 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1;

            case 0x18: // 0001 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL0;

            case 0x19: // 0001 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0x1a: // 0001 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x1b: // 0001 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0x1c: // 0001 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL0;

            case 0x1d: // 0001 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x1e: // 0001 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL0;

            case 0x1f: // 0001 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                nRunLength = 5;
                goto CalcRL1;

            case 0x20: // 0010 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 5;
                goto CalcRL0;

            case 0x21: // 0010 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL1;

            case 0x22: // 0010 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x23: // 0010 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL1;

            case 0x24: // 0010 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0x25: // 0010 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x26: // 0010 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0x27: // 0010 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL1;

            case 0x28: // 0010 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0;

            case 0x29: // 0010 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0x2a: // 0010 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x2b: // 0010 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0x2c: // 0010 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0;

            case 0x2d: // 0010 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x2e: // 0010 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0;

            case 0x2f: // 0010 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL1;

            case 0x30: // 0011 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 4;
                goto CalcRL0;

            case 0x31: // 0011 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1;

            case 0x32: // 0011 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x33: // 0011 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1;

            case 0x34: // 0011 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0x35: // 0011 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x36: // 0011 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0x37: // 0011 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1;

            case 0x38: // 0011 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 3;
                goto CalcRL0;

            case 0x39: // 0011 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0x3a: // 0011 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x3b: // 0011 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0x3c: // 0011 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 4;
                nRunLength = 2;
                goto CalcRL0;

            case 0x3d: // 0011 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x3e: // 0011 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 5;
                nRunLength = 1;
                goto CalcRL0;

            case 0x3f: // 0011 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                nRunLength = 6;
                goto CalcRL1;

            case 0x40: // 0100 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 6;
                goto CalcRL0;

            case 0x41: // 0100 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 5;
                nRunLength = 1;
                goto CalcRL1;

            case 0x42: // 0100 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x43: // 0100 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 2;
                goto CalcRL1;

            case 0x44: // 0100 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0x45: // 0100 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x46: // 0100 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0x47: // 0100 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 3;
                goto CalcRL1;

            case 0x48: // 0100 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0;

            case 0x49: // 0100 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0x4a: // 0100 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x4b: // 0100 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0x4c: // 0100 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0;

            case 0x4d: // 0100 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x4e: // 0100 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0;

            case 0x4f: // 0100 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 4;
                goto CalcRL1;

            case 0x50: // 0101 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL0;

            case 0x51: // 0101 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1;

            case 0x52: // 0101 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x53: // 0101 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1;

            case 0x54: // 0101 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0x55: // 0101 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x56: // 0101 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0x57: // 0101 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1;

            case 0x58: // 0101 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL0;

            case 0x59: // 0101 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0x5a: // 0101 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x5b: // 0101 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0x5c: // 0101 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL0;

            case 0x5d: // 0101 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x5e: // 0101 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL0;

            case 0x5f: // 0101 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 5;
                goto CalcRL1;

            case 0x60: // 0110 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 5;
                goto CalcRL0;

            case 0x61: // 0110 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL1;

            case 0x62: // 0110 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x63: // 0110 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL1;

            case 0x64: // 0110 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0x65: // 0110 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x66: // 0110 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0x67: // 0110 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL1;

            case 0x68: // 0110 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0;

            case 0x69: // 0110 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0x6a: // 0110 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x6b: // 0110 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0x6c: // 0110 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0;

            case 0x6d: // 0110 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x6e: // 0110 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0;

            case 0x6f: // 0110 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL1;

            case 0x70: // 0111 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 4;
                goto CalcRL0;

            case 0x71: // 0111 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1;

            case 0x72: // 0111 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x73: // 0111 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1;

            case 0x74: // 0111 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0x75: // 0111 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x76: // 0111 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0x77: // 0111 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1;

            case 0x78: // 0111 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 3;
                goto CalcRL0;

            case 0x79: // 0111 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0x7a: // 0111 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x7b: // 0111 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0x7c: // 0111 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 5;
                nRunLength = 2;
                goto CalcRL0;

            case 0x7d: // 0111 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 5;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x7e: // 0111 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 6;
                nRunLength = 1;
                goto CalcRL0;

            case 0x7f: // 0111 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                nRunLength = 7;
                goto CalcRL1;

            case 0x80: // 1000 0000
                *(pnRunLengths2++) = nRunLength + 1;
                nRunLength = 7;
                goto CalcRL0;

            case 0x81:  // 1000 0001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 6;
                nRunLength = 1;
                goto CalcRL1;

            case 0x82:  // 1000 0010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 5;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x83:  // 1000 0011
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 5;
                nRunLength = 2;
                goto CalcRL1;

            case 0x84:  // 1000 0100
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0x85:  // 1000 0101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x86:  // 1000 0110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0x87:  // 1000 0111
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 3;
                goto CalcRL1;

            case 0x88:  // 1000 1000
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0;

            case 0x89:  // 1000 1001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0x8a:  // 1000 1010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x8b:  // 1000 1011
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0x8c:  // 1000 1100
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0;

            case 0x8d: // 1000 1101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x8e:  // 1000 1110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0;

            case 0x8f:  // 1000 1111
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 4;
                goto CalcRL1;

            case 0x90: // 1001 0000
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL0;

            case 0x91: // 1001 0001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1;

            case 0x92: // 1001 0010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x93: // 1001 0011
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1;

            case 0x94: // 1001 0100
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0x95: // 1001 0101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x96: // 1001 0110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0x97: // 1001 0111
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1;

            case 0x98: // 1001 1000
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL0;

            case 0x99: // 1001 1001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0x9a: // 1001 1010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x9b: // 1001 1011
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0x9c: // 1001 1100
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL0;

            case 0x9d: // 1001 1101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x9e: // 1001 1110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL0;

            case 0x9f: // 1001 1111
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 5;
                goto CalcRL1;

            case 0xa0: // 1010 0000
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 5;
                goto CalcRL0;

            case 0xa1: // 1010 0001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL1;

            case 0xa2: // 1010 0010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0xa3: // 1010 0011
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL1;

            case 0xa4: // 1010 0100
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0xa5: // 1010 0101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0xa6: // 1010 0110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0xa7: // 1010 0111
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL1;

            case 0xa8: // 1010 1000
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0;

            case 0xa9: // 1010 1001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0xaa: // 1010 1010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0xab: // 1010 1011
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0xac: // 1010 1100
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0;

            case 0xad: // 1010 1101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0xae: // 1010 1110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0;

            case 0xaf: // 1010 1111
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL1;

            case 0xb0: // 1011 0000
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 4;
                goto CalcRL0;

            case 0xb1: // 1011 0001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1;

            case 0xb2: // 1011 0010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0xb3: // 1011 0011
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1;

            case 0xb4: // 1011 0100
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0xb5: // 1011 0101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0xb6: // 1011 0110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0xb7: // 1011 0111
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1;

            case 0xb8: // 1011 1000
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 3;
                goto CalcRL0;

            case 0xb9: // 1011 1001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0xba: // 1011 1010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0xbb: // 1011 1011
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0xbc: // 1011 1100
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 2;
                goto CalcRL0;

            case 0xbd: // 1011 1101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0xbe: // 1011 1110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 5;
                nRunLength = 1;
                goto CalcRL0;

            case 0xbf: // 1011 1111
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 6;
                goto CalcRL1;

            case 0xc0: // 1100 0000
                *(pnRunLengths2++) = nRunLength + 2;
                nRunLength = 6;
                goto CalcRL0;

            case 0xc1: // 1100 0001
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 5;
                nRunLength = 1;
                goto CalcRL1;

            case 0xc2: // 1100 0010
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0xc3: // 1100 0011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 4;
                nRunLength = 2;
                goto CalcRL1;

            case 0xc4: // 1100 0100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0xc5: // 1100 0101
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0xc6: // 1100 0110
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0xc7: // 1100 0111
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 3;
                goto CalcRL1;

            case 0xc8: // 1100 1000
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0;

            case 0xc9: // 1100 1001
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0xca: // 1100 1010
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0xcb: // 1100 1011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0xcc: // 1100 1100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0;

            case 0xcd: // 1100 1101
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0xce: // 1100 1110
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0;

            case 0xcf: // 1100 1111
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 4;
                goto CalcRL1;

            case 0xd0: // 1101 0000
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL0;

            case 0xd1: // 1101 0001
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1;

            case 0xd2: // 1101 0010
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0xd3: // 1101 0011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1;

            case 0xd4: // 1101 0100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0xd5: // 1101 0101
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0xd6: // 1101 0110
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0xd7: // 1101 0111
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1;

            case 0xd8: // 1101 1000
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL0;

            case 0xd9: // 1101 1001
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0xda: // 1101 1010
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0xdb: // 1101 1011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0xdc: // 1101 1100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL0;

            case 0xdd: // 1101 1101
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0xde: // 1101 1110
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL0;

            case 0xdf: // 1101 1111
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 5;
                goto CalcRL1;

            case 0xe0: // 1110 0000
                *(pnRunLengths2++) = nRunLength + 3;
                nRunLength = 5;
                goto CalcRL0;

            case 0xe1: // 1110 0001
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL1;

            case 0xe2: // 1110 0010
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0xe3: // 1110 0011
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL1;

            case 0xe4: // 1110 0100
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0xe5: // 1110 0101
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0xe6: // 1110 0110
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0xe7: // 1110 0111
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL1;

            case 0xe8: // 1110 1000
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0;

            case 0xe9: // 1110 1001
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0xea: // 1110 1010
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0xeb: // 1110 1011
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0xec: // 1110 1100
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0;

            case 0xed: // 1110 1101
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0xee: // 1110 1110
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0;

            case 0xef: // 1110 1111
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL1;

            case 0xf0: // 1111 0000
                *(pnRunLengths2++) = nRunLength + 4;
                nRunLength = 4;
                goto CalcRL0;

            case 0xf1: // 1111 0001
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1;

            case 0xf2: // 1111 0010
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0xf3: // 1111 0011
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1;

            case 0xf4: // 1111 0100
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0xf5: // 1111 0101
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0xf6: // 1111 0110
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0xf7: // 1111 0111
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1;

            case 0xf8: // 1111 1000
                *(pnRunLengths2++) = nRunLength + 5;
                nRunLength = 3;
                goto CalcRL0;

            case 0xf9: // 1111 1001
                *(pnRunLengths2++) = nRunLength + 5;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0xfa: // 1111 1010
                *(pnRunLengths2++) = nRunLength + 5;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0xfb: // 1111 1011
                *(pnRunLengths2++) = nRunLength + 5;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0xfc: // 1111 1100
                *(pnRunLengths2++) = nRunLength + 6;
                nRunLength = 2;
                goto CalcRL0;

            case 0xfd: // 1111 1101
                *(pnRunLengths2++) = nRunLength + 6;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0xfe: // 1111 1110
                *(pnRunLengths2++) = nRunLength + 7;
                nRunLength = 1;
                goto CalcRL0;

            case 0xff: // 1111 1111
                nRunLength += 8;
                nCount1 = nCount;
                while(((INT_PTR)pImageData & 3) && *pImageData == 0xff && nCount){
                    pImageData++;
                    nCount--;
                }
                if ( ! ( (INT_PTR) pImageData & 3) ) {
                    while((*((DWORD*)pImageData) == 0xffffffff) && (nCount >= 4))
					{
                        pImageData += 4;
                        nCount -= 4;
                    }
                    while(*pImageData == 0xff && nCount){
                        pImageData++;
                        nCount--;
                    }
                }
                nRunLength += (nCount1 - nCount) << 3;
                goto CalcRL1;
        }
    }else{
        // All done widthbytes.
        goto CalcRLDone;
    }
/*
CalcRL0(){
*/
CalcRL0:
    if (nCount--){

#ifdef debug
        pnRunLengthsTemp = pnRunLengths;
        nRunLengthTotal = *(pnRunLengthsTemp++);
        while(*pnRunLengthsTemp){
            nRunLengthTotal = *(pnRunLengthsTemp++);
        }
        nRunLengthTotal += nRunLength;
        if (nRunLengthTotal & 7){
            Error(nStatus);
        }
#endif
        
        switch (*(pImageData++)){
            case 0x00: // 0000 0000
                nRunLength += 8;
                goto CalcRL0;

            case 0x01:  // 0000 0001
                *(pnRunLengths2++) = nRunLength + 7;
                nRunLength = 1;
                goto CalcRL1;

            case 0x02:  // 0000 0010
                *(pnRunLengths2++) = nRunLength + 6;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x03:  // 0000 0011
                *(pnRunLengths2++) = nRunLength + 6;
                nRunLength = 2;
                goto CalcRL1;

            case 0x04:  // 0000 0100
                *(pnRunLengths2++) = nRunLength + 5;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0x05:  // 0000 0101
                *(pnRunLengths2++) = nRunLength + 5;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x06:  // 0000 0110
                *(pnRunLengths2++) = nRunLength + 5;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0x07:  // 0000 0111
                *(pnRunLengths2++) = nRunLength + 5;
                nRunLength = 3;
                goto CalcRL1;

            case 0x08:  // 0000 1000
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0;

            case 0x09:  // 0000 1001
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0x0a:  // 0000 1010
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x0b:  // 0000 1011
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0x0c:  // 0000 1100
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0;

            case 0x0d: // 0000 1101
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x0e:  // 0000 1110
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0;

            case 0x0f:  // 0000 1111
                *(pnRunLengths2++) = nRunLength + 4;
                nRunLength = 4;
                goto CalcRL1;

            case 0x10: // 0001 0000
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL0;

            case 0x11: // 0001 0001
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1;

            case 0x12: // 0001 0010
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x13: // 0001 0011
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1;

            case 0x14: // 0001 0100
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0x15: // 0001 0101
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x16: // 0001 0110
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0x17: // 0001 0111
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1;

            case 0x18: // 0001 1000
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL0;

            case 0x19: // 0001 1001
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0x1a: // 0001 1010
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x1b: // 0001 1011
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0x1c: // 0001 1100
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL0;

            case 0x1d: // 0001 1101
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x1e: // 0001 1110
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL0;

            case 0x1f: // 0001 1111
                *(pnRunLengths2++) = nRunLength + 3;
                nRunLength = 5;
                goto CalcRL1;

            case 0x20: // 0010 0000
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 5;
                goto CalcRL0;

            case 0x21: // 0010 0001
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL1;

            case 0x22: // 0010 0010
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x23: // 0010 0011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL1;

            case 0x24: // 0010 0100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0x25: // 0010 0101
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x26: // 0010 0110
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0x27: // 0010 0111
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL1;

            case 0x28: // 0010 1000
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0;

            case 0x29: // 0010 1001
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0x2a: // 0010 1010
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x2b: // 0010 1011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0x2c: // 0010 1100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0;

            case 0x2d: // 0010 1101
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x2e: // 0010 1110
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0;

            case 0x2f: // 0010 1111
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL1;

            case 0x30: // 0011 0000
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 4;
                goto CalcRL0;

            case 0x31: // 0011 0001
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1;

            case 0x32: // 0011 0010
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x33: // 0011 0011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1;

            case 0x34: // 0011 0100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0x35: // 0011 0101
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x36: // 0011 0110
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0x37: // 0011 0111
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1;

            case 0x38: // 0011 1000
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 3;
                goto CalcRL0;

            case 0x39: // 0011 1001
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0x3a: // 0011 1010
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x3b: // 0011 1011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0x3c: // 0011 1100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 4;
                nRunLength = 2;
                goto CalcRL0;

            case 0x3d: // 0011 1101
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x3e: // 0011 1110
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 5;
                nRunLength = 1;
                goto CalcRL0;

            case 0x3f: // 0011 1111
                *(pnRunLengths2++) = nRunLength + 2;
                nRunLength = 6;
                goto CalcRL1;

            case 0x40: // 0100 0000
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 6;
                goto CalcRL0;

            case 0x41: // 0100 0001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 5;
                nRunLength = 1;
                goto CalcRL1;

            case 0x42: // 0100 0010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x43: // 0100 0011
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 2;
                goto CalcRL1;

            case 0x44: // 0100 0100
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0x45: // 0100 0101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x46: // 0100 0110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0x47: // 0100 0111
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 3;
                goto CalcRL1;

            case 0x48: // 0100 1000
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0;

            case 0x49: // 0100 1001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0x4a: // 0100 1010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x4b: // 0100 1011
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0x4c: // 0100 1100
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0;

            case 0x4d: // 0100 1101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x4e: // 0100 1110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0;

            case 0x4f: // 0100 1111
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 4;
                goto CalcRL1;

            case 0x50: // 0101 0000
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL0;

            case 0x51: // 0101 0001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1;

            case 0x52: // 0101 0010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x53: // 0101 0011
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1;

            case 0x54: // 0101 0100
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0x55: // 0101 0101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x56: // 0101 0110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0x57: // 0101 0111
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1;

            case 0x58: // 0101 1000
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL0;

            case 0x59: // 0101 1001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0x5a: // 0101 1010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x5b: // 0101 1011
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0x5c: // 0101 1100
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL0;

            case 0x5d: // 0101 1101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x5e: // 0101 1110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL0;

            case 0x5f: // 0101 1111
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 5;
                goto CalcRL1;

            case 0x60: // 0110 0000
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 5;
                goto CalcRL0;

            case 0x61: // 0110 0001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL1;

            case 0x62: // 0110 0010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x63: // 0110 0011
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL1;

            case 0x64: // 0110 0100
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0x65: // 0110 0101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x66: // 0110 0110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0x67: // 0110 0111
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL1;

            case 0x68: // 0110 1000
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0;

            case 0x69: // 0110 1001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0x6a: // 0110 1010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x6b: // 0110 1011
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0x6c: // 0110 1100
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0;

            case 0x6d: // 0110 1101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x6e: // 0110 1110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0;

            case 0x6f: // 0110 1111
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL1;

            case 0x70: // 0111 0000
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 4;
                goto CalcRL0;

            case 0x71: // 0111 0001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1;

            case 0x72: // 0111 0010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x73: // 0111 0011
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1;

            case 0x74: // 0111 0100
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0x75: // 0111 0101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x76: // 0111 0110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0x77: // 0111 0111
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1;

            case 0x78: // 0111 1000
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 3;
                goto CalcRL0;

            case 0x79: // 0111 1001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0x7a: // 0111 1010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x7b: // 0111 1011
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0x7c: // 0111 1100
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 5;
                nRunLength = 2;
                goto CalcRL0;

            case 0x7d: // 0111 1101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 5;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x7e: // 0111 1110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 6;
                nRunLength = 1;
                goto CalcRL0;

            case 0x7f: // 0111 1111
                *(pnRunLengths2++) = nRunLength + 1;
                nRunLength = 7;
                goto CalcRL1;

            case 0x80: // 1000 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                nRunLength = 7;
                goto CalcRL0;

            case 0x81:  // 1000 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 6;
                nRunLength = 1;
                goto CalcRL1;

            case 0x82:  // 1000 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 5;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x83:  // 1000 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 5;
                nRunLength = 2;
                goto CalcRL1;

            case 0x84:  // 1000 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0x85:  // 1000 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x86:  // 1000 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0x87:  // 1000 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 3;
                goto CalcRL1;

            case 0x88:  // 1000 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0;

            case 0x89:  // 1000 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0x8a:  // 1000 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x8b:  // 1000 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0x8c:  // 1000 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0;

            case 0x8d: // 1000 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x8e:  // 1000 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0;

            case 0x8f:  // 1000 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 4;
                goto CalcRL1;

            case 0x90: // 1001 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL0;

            case 0x91: // 1001 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1;

            case 0x92: // 1001 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x93: // 1001 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1;

            case 0x94: // 1001 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0x95: // 1001 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x96: // 1001 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0x97: // 1001 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1;

            case 0x98: // 1001 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL0;

            case 0x99: // 1001 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0x9a: // 1001 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0x9b: // 1001 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0x9c: // 1001 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL0;

            case 0x9d: // 1001 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0x9e: // 1001 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL0;

            case 0x9f: // 1001 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 5;
                goto CalcRL1;

            case 0xa0: // 1010 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 5;
                goto CalcRL0;

            case 0xa1: // 1010 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL1;

            case 0xa2: // 1010 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0xa3: // 1010 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL1;

            case 0xa4: // 1010 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0xa5: // 1010 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0xa6: // 1010 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0xa7: // 1010 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL1;

            case 0xa8: // 1010 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0;

            case 0xa9: // 1010 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0xaa: // 1010 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0xab: // 1010 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0xac: // 1010 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0;

            case 0xad: // 1010 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0xae: // 1010 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0;

            case 0xaf: // 1010 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL1;

            case 0xb0: // 1011 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 4;
                goto CalcRL0;

            case 0xb1: // 1011 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1;

            case 0xb2: // 1011 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0xb3: // 1011 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1;

            case 0xb4: // 1011 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0xb5: // 1011 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0xb6: // 1011 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0xb7: // 1011 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1;

            case 0xb8: // 1011 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 3;
                goto CalcRL0;

            case 0xb9: // 1011 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0xba: // 1011 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0xbb: // 1011 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0xbc: // 1011 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 2;
                goto CalcRL0;

            case 0xbd: // 1011 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0xbe: // 1011 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 5;
                nRunLength = 1;
                goto CalcRL0;

            case 0xbf: // 1011 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 6;
                goto CalcRL1;

            case 0xc0: // 1100 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                nRunLength = 6;
                goto CalcRL0;

            case 0xc1: // 1100 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 5;
                nRunLength = 1;
                goto CalcRL1;

            case 0xc2: // 1100 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0xc3: // 1100 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 4;
                nRunLength = 2;
                goto CalcRL1;

            case 0xc4: // 1100 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0xc5: // 1100 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0xc6: // 1100 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0xc7: // 1100 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 3;
                goto CalcRL1;

            case 0xc8: // 1100 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0;

            case 0xc9: // 1100 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0xca: // 1100 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0xcb: // 1100 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0xcc: // 1100 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0;

            case 0xcd: // 1100 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0xce: // 1100 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0;

            case 0xcf: // 1100 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 4;
                goto CalcRL1;

            case 0xd0: // 1101 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL0;

            case 0xd1: // 1101 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1;

            case 0xd2: // 1101 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0xd3: // 1101 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1;

            case 0xd4: // 1101 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0xd5: // 1101 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0xd6: // 1101 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0xd7: // 1101 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1;

            case 0xd8: // 1101 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL0;

            case 0xd9: // 1101 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0xda: // 1101 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0xdb: // 1101 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0xdc: // 1101 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL0;

            case 0xdd: // 1101 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0xde: // 1101 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL0;

            case 0xdf: // 1101 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 5;
                goto CalcRL1;

            case 0xe0: // 1110 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                nRunLength = 5;
                goto CalcRL0;

            case 0xe1: // 1110 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL1;

            case 0xe2: // 1110 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0xe3: // 1110 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL1;

            case 0xe4: // 1110 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0xe5: // 1110 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0xe6: // 1110 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0xe7: // 1110 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL1;

            case 0xe8: // 1110 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0;

            case 0xe9: // 1110 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0xea: // 1110 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0xeb: // 1110 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0xec: // 1110 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0;

            case 0xed: // 1110 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0xee: // 1110 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0;

            case 0xef: // 1110 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL1;

            case 0xf0: // 1111 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                nRunLength = 4;
                goto CalcRL0;

            case 0xf1: // 1111 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1;

            case 0xf2: // 1111 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0xf3: // 1111 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1;

            case 0xf4: // 1111 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0;

            case 0xf5: // 1111 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0xf6: // 1111 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0;

            case 0xf7: // 1111 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1;

            case 0xf8: // 1111 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 5;
                nRunLength = 3;
                goto CalcRL0;

            case 0xf9: // 1111 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 5;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1;

            case 0xfa: // 1111 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 5;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0;

            case 0xfb: // 1111 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 5;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1;

            case 0xfc: // 1111 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 6;
                nRunLength = 2;
                goto CalcRL0;

            case 0xfd: // 1111 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 6;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1;

            case 0xfe: // 1111 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 7;
                nRunLength = 1;
                goto CalcRL0;

            case 0xff: // 1111 1111
                *(pnRunLengths2++) = nRunLength;
                nRunLength = 8;
                goto CalcRL1;
        }
    }else{
        // All done widthbytes.
        goto CalcRLDone;
    }



/*
CalcRL1R(){
*/
CalcRL1R:
    if (nCount--){

#ifdef debug
        pnRunLengthsTemp = pnRunLengths;
        nRunLengthTotal = *(pnRunLengthsTemp++);
        while(*pnRunLengthsTemp){
            nRunLengthTotal = *(pnRunLengthsTemp++);
        }
        nRunLengthTotal += nRunLength;
        if (nRunLengthTotal & 7){
            Error(nStatus);
        }
#endif
        
        switch (*(pImageData++)){
            case 0x00: // 0000 0000
                *(pnRunLengths2++) = nRunLength;
                nRunLength = 8;
                goto CalcRL0R;

            case 0x01:  // 0000 0001
                *(pnRunLengths2++) = nRunLength + 1;
                nRunLength = 7;
                goto CalcRL0R;

            case 0x02:  // 0000 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 6;
                goto CalcRL0R;

            case 0x03:  // 0000 0011
                *(pnRunLengths2++) = nRunLength + 2;
                nRunLength = 6;
                goto CalcRL0R;

            case 0x04:  // 0000 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 5;
                goto CalcRL0R;

            case 0x05:  // 0000 0101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 5;
                goto CalcRL0R;

            case 0x06:  // 0000 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 5;
                goto CalcRL0R;

            case 0x07:  // 0000 0111
                *(pnRunLengths2++) = nRunLength + 3;
                nRunLength = 5;
                goto CalcRL0R;

            case 0x08:  // 0000 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL0R;

            case 0x09:  // 0000 1001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL0R;

            case 0x0a:  // 0000 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL0R;

            case 0x0b:  // 0000 1011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL0R;

            case 0x0c:  // 0000 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 4;
                goto CalcRL0R;

            case 0x0d: // 0000 1101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 4;
                goto CalcRL0R;

            case 0x0e:  // 0000 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 4;
                goto CalcRL0R;

            case 0x0f:  // 0000 1111
                *(pnRunLengths2++) = nRunLength + 4;
                nRunLength = 4;
                goto CalcRL0R;

            case 0x10: // 0001 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x11: // 0001 0001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x12: // 0001 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x13: // 0001 0011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x14: // 0001 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x15: // 0001 0101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x16: // 0001 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x17: // 0001 0111
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x18: // 0001 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x19: // 0001 1001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x1a: // 0001 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x1b: // 0001 1011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x1c: // 0001 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x1d: // 0001 1101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x1e: // 0001 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x1f: // 0001 1111
                *(pnRunLengths2++) = nRunLength + 5;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x20: // 0010 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 5;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x21:  // 0010 0001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x22:  // 0010 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x23:  // 0010 0011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x24:  // 0010 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x25:  // 0010 0101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x26:  // 0010 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x27:  // 0010 0111
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x28:  // 0010 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x29:  // 0010 1001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x2a:  // 0010 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x2b:  // 0010 1011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x2c:  // 0010 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x2d: // 0010 1101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x2e:  // 0010 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x2f:  // 0010 1111
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x30: // 0011 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x31: // 0011 0001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x32: // 0011 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x33: // 0011 0011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x34: // 0011 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x35: // 0011 0101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x36: // 0011 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x37: // 0011 0111
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x38: // 0011 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x39: // 0011 1001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x3a: // 0011 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x3b: // 0011 1011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x3c: // 0011 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 4;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x3d: // 0011 1101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x3e: // 0011 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 5;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x3f: // 0011 1111
                *(pnRunLengths2++) = nRunLength + 6;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x40: // 0100 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 6;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x41:  // 0100 0001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 5;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x42:  // 0100 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x43:  // 0100 0011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x44:  // 0100 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x45:  // 0100 0101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x46:  // 0100 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x47:  // 0100 0111
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x48:  // 0100 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x49:  // 0100 1001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x4a:  // 0100 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x4b:  // 0100 1011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x4c:  // 0100 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x4d: // 0100 1101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x4e:  // 0100 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x4f:  // 0100 1111
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x50: // 0101 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x51: // 0101 0001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x52: // 0101 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x53: // 0101 0011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x54: // 0101 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x55: // 0101 0101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x56: // 0101 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x57: // 0101 0111
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x58: // 0101 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x59: // 0101 1001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x5a: // 0101 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x5b: // 0101 1011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x5c: // 0101 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x5d: // 0101 1101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x5e: // 0101 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x5f: // 0101 1111
                *(pnRunLengths2++) = nRunLength + 5;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x60: // 0110 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 5;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x61:  // 0110 0001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x62:  // 0110 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x63:  // 0110 0011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x64:  // 0110 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x65:  // 0110 0101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x66:  // 0110 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x67:  // 0110 0111
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x68:  // 0110 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x69:  // 0110 1001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x6a:  // 0110 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x6b:  // 0110 1011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x6c:  // 0110 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x6d: // 0110 1101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x6e:  // 0110 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x6f:  // 0110 1111
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x70: // 0111 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x71: // 0111 0001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x72: // 0111 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x73: // 0111 0011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x74: // 0111 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x75: // 0111 0101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x76: // 0111 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x77: // 0111 0111
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x78: // 0111 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x79: // 0111 1001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x7a: // 0111 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x7b: // 0111 1011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x7c: // 0111 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 5;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x7d: // 0111 1101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 5;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x7e: // 0111 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 6;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x7f: // 0111 1111
                *(pnRunLengths2++) = nRunLength + 7;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x80: // 1000 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 7;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x81:  // 1000 0001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 6;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x82:  // 1000 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 5;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x83:  // 1000 0011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 5;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x84:  // 1000 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x85:  // 1000 0101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x86:  // 1000 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x87:  // 1000 0111
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x88:  // 1000 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x89:  // 1000 1001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x8a:  // 1000 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x8b:  // 1000 1011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x8c:  // 1000 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x8d: // 1000 1101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x8e:  // 1000 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x8f:  // 1000 1111
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x90: // 1001 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x91: // 1001 0001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x92: // 1001 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x93: // 1001 0011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x94: // 1001 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x95: // 1001 0101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x96: // 1001 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x97: // 1001 0111
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x98: // 1001 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x99: // 1001 1001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x9a: // 1001 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x9b: // 1001 1011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x9c: // 1001 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x9d: // 1001 1101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x9e: // 1001 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x9f: // 1001 1111
                *(pnRunLengths2++) = nRunLength + 5;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xa0: // 1010 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 5;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xa1:  // 1010 0001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xa2:  // 1010 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xa3:  // 1010 0011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xa4:  // 1010 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xa5:  // 1010 0101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xa6:  // 1010 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xa7:  // 1010 0111
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xa8:  // 1010 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xa9:  // 1010 1001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xaa:  // 1010 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xab:  // 1010 1011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xac:  // 1010 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xad: // 1010 1101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xae:  // 1010 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xaf:  // 1010 1111
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xb0: // 1011 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xb1: // 1011 0001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xb2: // 1011 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xb3: // 1011 0011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xb4: // 1011 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xb5: // 1011 0101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xb6: // 1011 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xb7: // 1011 0111
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xb8: // 1011 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xb9: // 1011 1001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xba: // 1011 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xbb: // 1011 1011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xbc: // 1011 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xbd: // 1011 1101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xbe: // 1011 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 5;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xbf: // 1011 1111
                *(pnRunLengths2++) = nRunLength + 6;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xc0: // 1100 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 6;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xc1:  // 1100 0001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 5;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xc2:  // 1100 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xc3:  // 1100 0011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 4;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xc4:  // 1100 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xc5:  // 1100 0101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xc6:  // 1100 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xc7:  // 1100 0111
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xc8:  // 1100 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xc9:  // 1100 1001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xca:  // 1100 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xcb:  // 1100 1011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xcc:  // 1100 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xcd: // 1100 1101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xce:  // 1100 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xcf:  // 1100 1111
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xd0: // 1101 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xd1: // 1101 0001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xd2: // 1101 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xd3: // 1101 0011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xd4: // 1101 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xd5: // 1101 0101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xd6: // 1101 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xd7: // 1101 0111
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xd8: // 1101 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xd9: // 1101 1001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xda: // 1101 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xdb: // 1101 1011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xdc: // 1101 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xdd: // 1101 1101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xde: // 1101 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xdf: // 1101 1111
                *(pnRunLengths2++) = nRunLength + 5;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xe0: // 1110 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 5;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xe1:  // 1110 0001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xe2:  // 1110 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xe3:  // 1110 0011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xe4:  // 1110 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xe5:  // 1110 0101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xe6:  // 1110 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xe7:  // 1110 0111
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xe8:  // 1110 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xe9:  // 1110 1001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xea:  // 1110 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xeb:  // 1110 1011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xec:  // 1110 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xed: // 1110 1101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xee:  // 1110 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xef:  // 1110 1111
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xf0: // 1111 0000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                nRunLength = 4;
                goto CalcRL1R;

            case 0xf1: // 1111 0001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 4;
                goto CalcRL1R;

            case 0xf2: // 1111 0010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 4;
                goto CalcRL1R;

            case 0xf3: // 1111 0011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 4;
                goto CalcRL1R;

            case 0xf4: // 1111 0100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL1R;

            case 0xf5: // 1111 0101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL1R;

            case 0xf6: // 1111 0110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL1R;

            case 0xf7: // 1111 0111
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL1R;

            case 0xf8: // 1111 1000
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                nRunLength = 5;
                goto CalcRL1R;

            case 0xf9: // 1111 1001
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 5;
                goto CalcRL1R;

            case 0xfa: // 1111 1010
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 5;
                goto CalcRL1R;

            case 0xfb: // 1111 1011
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 5;
                goto CalcRL1R;

            case 0xfc: // 1111 1100
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                nRunLength = 6;
                goto CalcRL1R;

            case 0xfd: // 1111 1101
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 6;
                goto CalcRL1R;

            case 0xfe: // 1111 1110
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                nRunLength = 7;
                goto CalcRL1R;

            case 0xff: // 1111 1111
                nRunLength += 8;
                nCount1 = nCount;
                while(((INT_PTR)pImageData & 3) && *pImageData == 0xff && nCount){
                    pImageData++;
                    nCount--;
                }
                if ( ! ( (INT_PTR) pImageData & 3) ) {
                    while((*((DWORD*)pImageData) == 0xffffffff) && (nCount >= 4)){
                        pImageData += 4;
                        nCount -= 4;
                    }
                    while(*pImageData == 0xff && nCount){
                        pImageData++;
                        nCount--;
                    }
                }
                nRunLength += (nCount1 - nCount) << 3;
                goto CalcRL1R;
        }
    }else{
        // All done widthbytes.
        goto CalcRLDone;
    }
/*
CalcRL0R(){
*/
CalcRL0R:
    if (nCount--){

#ifdef debug
        pnRunLengthsTemp = pnRunLengths;
        nRunLengthTotal = *(pnRunLengthsTemp++);
        while(*pnRunLengthsTemp){
            nRunLengthTotal = *(pnRunLengthsTemp++);
        }
        nRunLengthTotal += nRunLength;
        if (nRunLengthTotal & 7){
            Error(nStatus);
        }
#endif
        
        switch (*(pImageData++)){
            case 0x00: // 0000 0000
                nRunLength += 8;
                while(*pImageData == 0x00 && nCount){
                    nRunLength += 8;
                    pImageData++;
                    nCount--;
                }
                goto CalcRL0R;

            case 0x01:  // 0000 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                nRunLength = 7;
                goto CalcRL0R;

            case 0x02:  // 0000 0010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 6;
                goto CalcRL0R;

            case 0x03:  // 0000 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                nRunLength = 6;
                goto CalcRL0R;

            case 0x04:  // 0000 0100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 5;
                goto CalcRL0R;

            case 0x05:  // 0000 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 5;
                goto CalcRL0R;

            case 0x06:  // 0000 0110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 5;
                goto CalcRL0R;

            case 0x07:  // 0000 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                nRunLength = 5;
                goto CalcRL0R;

            case 0x08:  // 0000 1000
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL0R;

            case 0x09:  // 0000 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL0R;

            case 0x0a:  // 0000 1010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL0R;

            case 0x0b:  // 0000 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL0R;

            case 0x0c:  // 0000 1100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 4;
                goto CalcRL0R;

            case 0x0d: // 0000 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 4;
                goto CalcRL0R;

            case 0x0e:  // 0000 1110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 4;
                goto CalcRL0R;

            case 0x0f:  // 0000 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                nRunLength = 4;
                goto CalcRL0R;

            case 0x10: // 0001 0000
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x11: // 0001 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x12: // 0001 0010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x13: // 0001 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x14: // 0001 0100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x15: // 0001 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x16: // 0001 0110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x17: // 0001 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x18: // 0001 1000
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x19: // 0001 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x1a: // 0001 1010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x1b: // 0001 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x1c: // 0001 1100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x1d: // 0001 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x1e: // 0001 1110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x1f: // 0001 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 5;
                nRunLength = 3;
                goto CalcRL0R;

            case 0x20: // 0010 0000
                *(pnRunLengths2++) = nRunLength + 5;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x21:  // 0010 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x22:  // 0010 0010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x23:  // 0010 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x24:  // 0010 0100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x25:  // 0010 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x26:  // 0010 0110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x27:  // 0010 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x28:  // 0010 1000
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x29:  // 0010 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x2a:  // 0010 1010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x2b:  // 0010 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x2c:  // 0010 1100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x2d: // 0010 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x2e:  // 0010 1110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x2f:  // 0010 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x30: // 0011 0000
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x31: // 0011 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x32: // 0011 0010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x33: // 0011 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x34: // 0011 0100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x35: // 0011 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x36: // 0011 0110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x37: // 0011 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x38: // 0011 1000
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x39: // 0011 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x3a: // 0011 1010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x3b: // 0011 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x3c: // 0011 1100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 4;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x3d: // 0011 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x3e: // 0011 1110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 5;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x3f: // 0011 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 6;
                nRunLength = 2;
                goto CalcRL0R;

            case 0x40: // 0100 0000
                *(pnRunLengths2++) = nRunLength + 6;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x41:  // 0100 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 5;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x42:  // 0100 0010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x43:  // 0100 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x44:  // 0100 0100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x45:  // 0100 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x46:  // 0100 0110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x47:  // 0100 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x48:  // 0100 1000
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x49:  // 0100 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x4a:  // 0100 1010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x4b:  // 0100 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x4c:  // 0100 1100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x4d: // 0100 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x4e:  // 0100 1110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x4f:  // 0100 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x50: // 0101 0000
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x51: // 0101 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x52: // 0101 0010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x53: // 0101 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x54: // 0101 0100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x55: // 0101 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x56: // 0101 0110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x57: // 0101 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x58: // 0101 1000
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x59: // 0101 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x5a: // 0101 1010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x5b: // 0101 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x5c: // 0101 1100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x5d: // 0101 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x5e: // 0101 1110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x5f: // 0101 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 5;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x60: // 0110 0000
                *(pnRunLengths2++) = nRunLength + 5;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x61:  // 0110 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x62:  // 0110 0010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x63:  // 0110 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x64:  // 0110 0100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x65:  // 0110 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x66:  // 0110 0110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x67:  // 0110 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x68:  // 0110 1000
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x69:  // 0110 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x6a:  // 0110 1010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x6b:  // 0110 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x6c:  // 0110 1100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x6d: // 0110 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x6e:  // 0110 1110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x6f:  // 0110 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x70: // 0111 0000
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x71: // 0111 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x72: // 0111 0010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x73: // 0111 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x74: // 0111 0100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x75: // 0111 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x76: // 0111 0110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x77: // 0111 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x78: // 0111 1000
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x79: // 0111 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x7a: // 0111 1010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x7b: // 0111 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x7c: // 0111 1100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 5;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x7d: // 0111 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 5;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x7e: // 0111 1110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 6;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x7f: // 0111 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 7;
                nRunLength = 1;
                goto CalcRL0R;

            case 0x80: // 1000 0000
                *(pnRunLengths2++) = nRunLength + 7;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x81:  // 1000 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 6;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x82:  // 1000 0010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 5;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x83:  // 1000 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 5;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x84:  // 1000 0100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x85:  // 1000 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x86:  // 1000 0110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x87:  // 1000 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 4;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x88:  // 1000 1000
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x89:  // 1000 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x8a:  // 1000 1010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x8b:  // 1000 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x8c:  // 1000 1100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x8d: // 1000 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x8e:  // 1000 1110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x8f:  // 1000 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 3;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x90: // 1001 0000
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x91: // 1001 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x92: // 1001 0010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x93: // 1001 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x94: // 1001 0100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x95: // 1001 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x96: // 1001 0110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x97: // 1001 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x98: // 1001 1000
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x99: // 1001 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x9a: // 1001 1010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x9b: // 1001 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x9c: // 1001 1100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x9d: // 1001 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x9e: // 1001 1110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0x9f: // 1001 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 5;
                *(pnRunLengths2++) = 2;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xa0: // 1010 0000
                *(pnRunLengths2++) = nRunLength + 5;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xa1:  // 1010 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xa2:  // 1010 0010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xa3:  // 1010 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xa4:  // 1010 0100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xa5:  // 1010 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xa6:  // 1010 0110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xa7:  // 1010 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xa8:  // 1010 1000
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xa9:  // 1010 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xaa:  // 1010 1010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xab:  // 1010 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xac:  // 1010 1100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xad: // 1010 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xae:  // 1010 1110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xaf:  // 1010 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xb0: // 1011 0000
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xb1: // 1011 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xb2: // 1011 0010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xb3: // 1011 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xb4: // 1011 0100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xb5: // 1011 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xb6: // 1011 0110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xb7: // 1011 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xb8: // 1011 1000
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xb9: // 1011 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xba: // 1011 1010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xbb: // 1011 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xbc: // 1011 1100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xbd: // 1011 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xbe: // 1011 1110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 5;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xbf: // 1011 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 6;
                *(pnRunLengths2++) = 1;
                nRunLength = 1;
                goto CalcRL1R;

            case 0xc0: // 1100 0000
                *(pnRunLengths2++) = nRunLength + 6;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xc1:  // 1100 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 5;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xc2:  // 1100 0010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xc3:  // 1100 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 4;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xc4:  // 1100 0100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xc5:  // 1100 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xc6:  // 1100 0110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xc7:  // 1100 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 3;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xc8:  // 1100 1000
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xc9:  // 1100 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xca:  // 1100 1010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xcb:  // 1100 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xcc:  // 1100 1100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xcd: // 1100 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xce:  // 1100 1110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xcf:  // 1100 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 2;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xd0: // 1101 0000
                *(pnRunLengths2++) = nRunLength + 4;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xd1: // 1101 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xd2: // 1101 0010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xd3: // 1101 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xd4: // 1101 0100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xd5: // 1101 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xd6: // 1101 0110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xd7: // 1101 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xd8: // 1101 1000
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xd9: // 1101 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xda: // 1101 1010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xdb: // 1101 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xdc: // 1101 1100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xdd: // 1101 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xde: // 1101 1110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xdf: // 1101 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 5;
                *(pnRunLengths2++) = 1;
                nRunLength = 2;
                goto CalcRL1R;

            case 0xe0: // 1110 0000
                *(pnRunLengths2++) = nRunLength + 5;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xe1:  // 1110 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 4;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xe2:  // 1110 0010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xe3:  // 1110 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 3;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xe4:  // 1110 0100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xe5:  // 1110 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xe6:  // 1110 0110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xe7:  // 1110 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 2;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xe8:  // 1110 1000
                *(pnRunLengths2++) = nRunLength + 3;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xe9:  // 1110 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xea:  // 1110 1010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xeb:  // 1110 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xec:  // 1110 1100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xed: // 1110 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xee:  // 1110 1110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xef:  // 1110 1111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 4;
                *(pnRunLengths2++) = 1;
                nRunLength = 3;
                goto CalcRL1R;

            case 0xf0: // 1111 0000
                *(pnRunLengths2++) = nRunLength + 4;
                nRunLength = 4;
                goto CalcRL1R;

            case 0xf1: // 1111 0001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 3;
                nRunLength = 4;
                goto CalcRL1R;

            case 0xf2: // 1111 0010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 4;
                goto CalcRL1R;

            case 0xf3: // 1111 0011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 2;
                nRunLength = 4;
                goto CalcRL1R;

            case 0xf4: // 1111 0100
                *(pnRunLengths2++) = nRunLength + 2;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL1R;

            case 0xf5: // 1111 0101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL1R;

            case 0xf6: // 1111 0110
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL1R;

            case 0xf7: // 1111 0111
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 3;
                *(pnRunLengths2++) = 1;
                nRunLength = 4;
                goto CalcRL1R;

            case 0xf8: // 1111 1000
                *(pnRunLengths2++) = nRunLength + 3;
                nRunLength = 5;
                goto CalcRL1R;

            case 0xf9: // 1111 1001
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 2;
                nRunLength = 5;
                goto CalcRL1R;

            case 0xfa: // 1111 1010
                *(pnRunLengths2++) = nRunLength + 1;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 5;
                goto CalcRL1R;

            case 0xfb: // 1111 1011
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 2;
                *(pnRunLengths2++) = 1;
                nRunLength = 5;
                goto CalcRL1R;

            case 0xfc: // 1111 1100
                *(pnRunLengths2++) = nRunLength + 2;
                nRunLength = 6;
                goto CalcRL1R;

            case 0xfd: // 1111 1101
                *(pnRunLengths2++) = nRunLength;
                *(pnRunLengths2++) = 1;
                *(pnRunLengths2++) = 1;
                nRunLength = 6;
                goto CalcRL1R;

            case 0xfe: // 1111 1110
                *(pnRunLengths2++) = nRunLength + 1;
                nRunLength = 7;
                goto CalcRL1R;

            case 0xff: // 1111 1111
                *(pnRunLengths2++) = nRunLength;
                nRunLength = 8;
                goto CalcRL1R;
        }
    }else{
        // All done widthbytes.
        goto CalcRLDone;
    }

CalcRLDone:
    *(pnRunLengths2++) = nRunLength;
    *(pnRunLengths2++) = 0;
    *(pnRunLengths2++) = 0;
    *(pnRunLengths2++) = 0;
    *(pnRunLengths2++) = 0;
    *pnRunLengths2 = 0;
    pnRunLengths2--;
    pnRunLengths2--;
    pnRunLengths2--;
    pnRunLengths2--;
    pnRunLengths2--;

    // Reduce the total runlengths to nWidthPixels.
    nCount = (nWidthBytes << 3) - nWidthPixels;
    while(nCount > 0){
        if (*pnRunLengths2 < nCount){
            nCount -= *pnRunLengths2;
            *(pnRunLengths2--) = 0;
        }else{
            *pnRunLengths2 -= nCount;
            break;
        }
    }

    return(nStatus);
}

