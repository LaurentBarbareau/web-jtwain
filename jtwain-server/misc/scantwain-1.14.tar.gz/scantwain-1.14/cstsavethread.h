////////////////////////////////////////////////////////////////////////////////
//	File:
//		$Archive: /main/deliverables/scantwain/cstsavethread.h $
//
//	Description:
/**
//		This file defines CSTSaveThread which inherits QThread. It is responsible
//		for saving images. It is necessary because libjpeg, libtiff and libpng
//		(especially libpng) can be very slow. Thefore images cannot be saved
//		in the main thread without limiting the responsivness of the UI. Images
//		cannot be saved in the scanning thread either, as that would slow
//		scanning and we want to scan as fast as possible. The only function
//		actually overloaded is the run() function, where all the work of
//		saving the images takes place.
//
 **/
//	History:
//		$Log: /main/deliverables/scantwain/cstsavethread.h $
//		
//		3     4/08/09 2:18p V737585
//		PR12757: Added a dialog to allow the user to let ScanTWAIN choose the
//		file type automatically or allow the user to select the file type based
//		on the pixel type. This allows dual-stream scanning, auto color detect
//		and toggle patch to be used while still making it easy for the user and
//		giving them the same flexibility as before if they want it.
//		
//		2     5/28/08 3:31p V737585
//		Added support for the TWAIN GUI. ScanTWAIN will now try to use the
//		driver's UI before using it's own. Additionally, support for
//		transferring Group IV and JPEG compressed images has been added.
//		Additionally, the ScanSettings dialog (aka the default driver UI) has
//		been updated to add support for setting the compression.
//		
//		1     3/26/08 1:04p V737585
//		PR 11740, 11749, 11750: THIS IS A MAJOR REVISION!! We now maintain an
//		image buffer of 10 images, we will not continue to transfer images from
//		the driver while that buffer is full. Additionally, a save thread has
//		been added to save the images in a separate thread. Several new custom
//		events have been added to assist in coordinating this. Finally, the
//		display resolution of the images has been reduced to between 75-150 dpi
//		to make the display faster. NOTE: ScanTWAIN now uses considerably more
//		memory and we may have to consider moving to memory mapped files if
//		this becomes a problem on low memory systems.
//
// Copyright (c) 2005-2008 Eastman Kodak Company
//
// This file is part of ScanTWAIN
//
// ScanTWAIN is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// ScanTWAIN is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY;  without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along
// with ScanTWAIN; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
//	$NoKeywords: $
////////////////////////////////////////////////////////////////////////////////

#ifndef CSTSAVETHREAD_H
#define CSTSAVETHREAD_H

////////////////////////////////////////////////////////////////////////////////
//									INCLUDE FILES
////////////////////////////////////////////////////////////////////////////////
#include <qthread.h>
#include <qptrqueue.h>
#include <tiffio.h>

#include "csttwain.h"
#include "sttypes.h"
#include "cstimgxferevent.h"

// Forward declaration
class CSTMainWindow;

class CSTSaveThread : public QThread
{
	
	public:
		
		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Constructor: Initializes the classes member variables
		//
		//	Parameters:
		//		stackSize	- The size of the stack for this thread
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		CSTSaveThread(uint stackSize = 0);
		
		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Destructor: Destroy's the thread
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		~CSTSaveThread();

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Sets the main window pointer member
		//
		//	Parameters:
		//		a_pWindow	- Pointer the the main window
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void SetMainWindow(CSTMainWindow* a_pWindow);

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Copies the image from the image transfer event and adds it to
		//		the queue to be saved.
		//
		//	Parameters:
		//		a_cstimgxferevent	- The image transfer event containing the image
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void QueueImage(CSTImgXferEvent *a_cstimgxferevent);

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Stops the thread once all images in the queue have been saved
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void StopThread(void);

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Stops the thread immediately
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void AbortThread(void);

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Sets the filename to save the images to.
		//
		//	Parameters:
		//		a_strFilename	- The filename to use
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void SetFilename(QString &a_strFilename);

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Sets the image file formats
		//
		//	Parameters:
		//		a_stfileformatsettings		- The image formats to save images in
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void SetFormats(const STFileFormatSettings& a_stfileformatsettings);


	protected:
		
		////////////////////////////////////////////////////////////////////////
		// Description:
		//		The function contains the code which actually runs
		//		inside the thread.
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		virtual void run(void);



	private:

		void SaveImage(unsigned char* a_pbImage,
					   TW_IMAGEINFO a_twimageinfo,
					   unsigned long a_ulImageSize);

		void SaveImageByFormat(unsigned char* a_pbImage,
							   TW_IMAGEINFO   a_twimageinfo,
							   unsigned long  a_ulImageSize,
							   int	  		  a_iFileFormat);

		void SaveTIFFImage(unsigned char*	a_pbImage,
						   TW_IMAGEINFO		a_twimageinfo,
						   QString 			a_strFileName,
						   unsigned long	a_ulImageSize);
		void SavePNGImage(unsigned char*	a_pbImage,
						  TW_IMAGEINFO		a_twimageinfo,
						  QString 			a_strFileName,
						  unsigned long	a_ulImageSize);
		void SaveJPEGImage(unsigned char*	a_pbImage,
						   TW_IMAGEINFO		a_twimageinfo,
						   QString 			a_strFileName,
						   unsigned long	a_ulImageSize);
		bool SetTIFFCompTags(TIFF* a_tiff, TW_IMAGEINFO a_twimageinfo);
		
		// For syncronization
		QMutex			m_mxMutex;			// Protects Member Variables
		QWaitCondition	m_qwaitcondition;	// A condition to wait on
		bool			m_bAbort;			// Flag to abort the thread
		bool			m_bStop;			// Flag to stop the thread
		CSTMainWindow	*m_pMainWindow;		// Pointer to our main window
		
		// Our Image Queue (stores pointers to images to be saved)
		QPtrQueue<CSTImgXferEvent>	m_qpqImgQueue;

		// Data for Saving Images
		QString					m_strFilename;			// Filename to save images to
		STFileFormatSettings	m_stfileformatsettings; // Image formats to save files to
		int						m_iCompressionQuality;	// JPEG,PNG Compression Quality

};

#endif
