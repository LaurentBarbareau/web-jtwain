////////////////////////////////////////////////////////////////////////////////
//	File:
//		$Archive: /main/deliverables/scantwain/cstfileformatdialog.cpp $
//
//	Description:
//		A class for allowing the user to select compression codecs for TIFF
//		image files.
//
//	History:
//		$Log: /main/deliverables/scantwain/cstfileformatdialog.cpp $
//		
//		2     4/16/09 9:58a V737585
//		Redesigned the file format dialog and some of the underlying structures
//		to work better with the new file format scheme. Also fixed a couple of
//		warnings compiling on Debian x64 systems.
//		
//		1     4/08/09 2:18p V737585
//		PR12757: Added a dialog to allow the user to let ScanTWAIN choose the
//		file type automatically or allow the user to select the file type based
//		on the pixel type. This allows dual-stream scanning, auto color detect
//		and toggle patch to be used while still making it easy for the user and
//		giving them the same flexibility as before if they want it.
//
// Copyright (c) 2009 Eastman Kodak Company
//
// This file is part of ScanTWAIN
//
// ScanTWAIN is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// ScanTWAIN is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY;  without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along
// with ScanTWAIN; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
//	$NoKeywords: $
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
//									INCLUDE FILES
////////////////////////////////////////////////////////////////////////////////
#include <qvariant.h>
#include <qlabel.h>
#include <qcombobox.h>
#include <qcheckbox.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qinputdialog.h>

#include "cstfileformatdialog.h"



////////////////////////////////////////////////////////////////////////
// Description:
//		Constructor: Initializes the classes member variables
//
//	Parameters:
//		parent	- This widget's parent widget
//		name	- The widget's name (for debugging)
//		modal	- Whether or not the dialog is shown modally
//		f1		- Widget style flags
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
CSTFileFormatDialog::CSTFileFormatDialog( QWidget* parent, const char* name, bool modal, WFlags fl)
    : QDialog( parent, name, modal, fl )
{
	if( !name )
	{
		setName("CSTFileFormatDialog");
	}
    setSizeGripEnabled(false);

    // Create the UI elements. Start with the group box for each format
    // adding the controls for the group box in order!
    
    // For bitonal images
    m_grpBitonal = new QHGroupBox(this, "m_grpBitonal");
	m_lblBitonal = new QLabel(m_grpBitonal, "m_lblBitonal");
	m_cbBitonal = new QComboBox(false, m_grpBitonal, "m_cbBitonal");
	m_cbBitonal->setSizePolicy(QSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed, m_cbBitonal->sizePolicy().hasHeightForWidth()));
	m_lblTIFFBitonal = new QLabel(m_grpBitonal, "m_lblTIFFBitonal");
	m_cbTIFFBitonal = new QComboBox(false, m_grpBitonal, "m_cbTIFFBitonal");
	m_cbTIFFBitonal->setSizePolicy(QSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed, m_cbTIFFBitonal->sizePolicy().hasHeightForWidth()));


    // For grayscale images
    m_grpGray = new QHGroupBox(this, "m_grpGray");
   	m_lblGray = new QLabel(m_grpGray, "m_lblGray");
	m_cbGray = new QComboBox(false, m_grpGray, "m_cbGray");
	m_cbGray->setSizePolicy(QSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed, m_cbGray->sizePolicy().hasHeightForWidth()));
	m_lblTIFFGray = new QLabel(m_grpGray, "m_lblTIFFGray");
	m_cbTIFFGray = new QComboBox(false, m_grpGray, "m_cbTIFFGray");
	m_cbTIFFGray->setSizePolicy(QSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed, m_cbTIFFGray->sizePolicy().hasHeightForWidth()));
	m_lblJPEGGray = new QLabel(m_grpGray, "m_lblJPEGGray");
    m_sbJPEGGray = new QSpinBox(25, 100, 1, m_grpGray, "m_sbJPEGGray");
    
    // For color images
    m_grpColor = new QHGroupBox(this, "m_grpColor");
	m_lblColor = new QLabel(m_grpColor, "m_lblColor");
	m_cbColor = new QComboBox(false, m_grpColor, "m_cbColor");
	m_cbColor->setSizePolicy(QSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed, m_cbColor->sizePolicy().hasHeightForWidth()));
	m_lblTIFFColor = new QLabel(m_grpColor, "m_lblTIFFColor");
	m_cbTIFFColor = new QComboBox(false, m_grpColor, "m_cbTIFFColor");
	m_cbTIFFColor->setSizePolicy(QSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed, m_cbTIFFColor->sizePolicy().hasHeightForWidth()));
	m_lblJPEGColor = new QLabel(m_grpColor, "m_lblJPEGColor");
    m_sbJPEGColor = new QSpinBox(25, 100, 1, m_grpColor, "m_sbJPEGColor");

	// Create the UI elements (Check Box)
	m_chkAutoFromDriver = new QCheckBox(this, "m_chkAutoFromDriver");

   	// Create the UI elements (Buttons)
	m_btnOK = new QPushButton(this, "m_btnOK");
	m_btnOK->setAutoDefault(true);
	m_btnOK->setDefault(true);
	m_btnOK->setSizePolicy(QSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed, m_btnOK->sizePolicy().hasHeightForWidth()));
	m_btnCancel = new QPushButton(this, "m_btnCancel");
	m_btnCancel->setSizePolicy(QSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed, m_btnCancel->sizePolicy().hasHeightForWidth()));

	// Now create the layout elements
	m_DialogLayout = new QHBoxLayout(this, 11, 6, "m_DialogLayout");
	m_DialogLayout->setResizeMode(QLayout::Fixed);
	m_ButtonLayout = new QVBoxLayout(0, 0, 6, "m_ButtonLayout");
	m_SubDialogLayout = new QVBoxLayout(0, 0, 6, "m_SubDialogLayout");
	m_Spacer1 = new QSpacerItem(20, 20, QSizePolicy::Expanding, QSizePolicy::Expanding);

	m_ButtonLayout->addWidget(m_btnOK);
	m_ButtonLayout->addWidget(m_btnCancel);
	m_ButtonLayout->addItem(m_Spacer1);

	m_SubDialogLayout->addWidget(m_chkAutoFromDriver);
	m_SubDialogLayout->addWidget(m_grpBitonal);
	m_SubDialogLayout->addWidget(m_grpGray);
	m_SubDialogLayout->addWidget(m_grpColor);

	m_DialogLayout->addLayout(m_SubDialogLayout);
	m_DialogLayout->addLayout(m_ButtonLayout);

	// Now we'll call the languageChange handler to set the text in the dialog
    languageChange();

	// Clear the Window State
    clearWState(WState_Polished);

    // signals and slots connections
	connect( m_btnOK, SIGNAL( clicked() ), this, SLOT( accept() ) );
	connect( m_btnCancel, SIGNAL( clicked() ), this, SLOT( reject() ) );
	connect( m_chkAutoFromDriver, SIGNAL(toggled(bool)), this, SLOT(AutoCheckedChange(bool)));
    connect( m_cbBitonal, SIGNAL(activated(int)), this, SLOT(BitonalFileFormatChanged(int)));
    connect( m_cbGray, SIGNAL(activated(int)), this, SLOT(GrayFileFormatChanged(int)));
    connect( m_cbColor, SIGNAL(activated(int)), this, SLOT(ColorFileFormatChanged(int))); 

	// Set the combo boxes to thier defaults
	m_chkAutoFromDriver->setChecked(m_stfileformatsettings.blAutoFromDriver);
	m_cbBitonal->setCurrentItem(m_stfileformatsettings.uiBitonalFileFormat);
	m_cbGray->setCurrentItem(m_stfileformatsettings.uiGrayFileFormat);
	m_cbColor->setCurrentItem(m_stfileformatsettings.uiColorFileFormat);
	m_cbTIFFBitonal->setCurrentItem(m_stfileformatsettings.uiBitonalTIFFCodec);
	m_cbTIFFGray->setCurrentItem(m_stfileformatsettings.uiGrayTIFFCodec);
	m_cbTIFFColor->setCurrentItem(m_stfileformatsettings.uiColorTIFFCodec);
	m_sbJPEGGray->setValue(m_stfileformatsettings.iGrayJPEGQuality);
	m_sbJPEGColor->setValue(m_stfileformatsettings.iColorJPEGQuality);
	
	// Use the changed slots to decided whether or not to show the TIFF codecs selector
	BitonalFileFormatChanged(m_cbBitonal->currentItem());
	GrayFileFormatChanged(m_cbGray->currentItem());
	ColorFileFormatChanged(m_cbColor->currentItem());
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Destructor: Destroy's the dialog
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
CSTFileFormatDialog::~CSTFileFormatDialog()
{
    // no need to delete child widgets, Qt does it all for us
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Sets the strings of the subwidgets using the current language
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTFileFormatDialog::languageChange()
{
    
	setCaption(tr("Choose File Format Settings"));
	m_grpBitonal->setTitle(tr("For Bitonal Images:"));
    m_lblBitonal->setText(tr("Format:"));
    m_lblTIFFBitonal->setText(tr("Compression:"));
    m_grpGray->setTitle(tr("For Grayscale Images:"));
    m_lblGray->setText(tr("Format:"));
    m_lblTIFFGray->setText(tr("Compression:"));
    m_lblJPEGGray->setText(tr("Quality:"));
    m_grpColor->setTitle(tr("For Color Images:"));
    m_lblColor->setText(tr("Format:"));
    m_lblTIFFColor->setText(tr("Compression:"));
    m_lblJPEGColor->setText(tr("Quality:"));
	m_chkAutoFromDriver->setText(tr("Automatic (Use Driver Settings)"));
    m_btnOK->setText(tr("&OK"));
	m_btnOK->setAccel(QKeySequence(tr("Alt+O")));
    m_btnCancel->setText(tr("&Cancel"));
	m_btnCancel->setAccel(QKeySequence(tr("Alt+C")));

	// Fill out the combo boxes
	m_cbBitonal->clear();
	m_cbBitonal->insertItem(tr("TIFF"), IDX_TIFFFILE);
	m_cbBitonal->insertItem(tr("PNG"), IDX_PNGFILE);

	m_cbTIFFBitonal->clear();
	m_cbTIFFBitonal->insertItem(tr("None"), IDX_NONE);
	m_cbTIFFBitonal->insertItem(tr("CCITT Group III"), IDX_CCITT3);
	m_cbTIFFBitonal->insertItem(tr("CCITT Group IV"), IDX_CCITT4);
    
	m_cbGray->clear();
	m_cbGray->insertItem(tr("TIFF"), IDX_TIFFFILE);
	m_cbGray->insertItem(tr("PNG"), IDX_PNGFILE);
	m_cbGray->insertItem(tr("JPEG"), IDX_JPEGFILE);

	m_cbTIFFGray->clear();
	m_cbTIFFGray->insertItem(tr("None"), IDX_NONE);
	m_cbTIFFGray->insertItem(tr("LZW"), IDX_LZW);
	m_cbTIFFGray->insertItem(tr("JPEG"), IDX_JPEG);

	m_cbColor->clear();
	m_cbColor->insertItem(tr("TIFF"), IDX_TIFFFILE);
	m_cbColor->insertItem(tr("PNG"), IDX_PNGFILE);
	m_cbColor->insertItem(tr("JPEG"), IDX_JPEGFILE);
	
	m_cbTIFFColor->clear();
	m_cbTIFFColor->insertItem(tr("None"), IDX_NONE);
	m_cbTIFFColor->insertItem(tr("LZW"), IDX_LZW);
	m_cbTIFFColor->insertItem(tr("JPEG"), IDX_JPEG);

}



////////////////////////////////////////////////////////////////////////
// Description:
//		Called when the Automatically Select From Driver check box changes
//
//	Parameters:
//		a_blChecked	- true if the check box is checked
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTFileFormatDialog::AutoCheckedChange(bool a_blChecked)
{
	// If automatic is selected (a_blChecked == true) then we'll disable
	// all the other settings because they will have no meaning
	m_cbBitonal->setEnabled(!a_blChecked);
    m_cbTIFFBitonal->setEnabled(!a_blChecked);
	m_cbGray->setEnabled(!a_blChecked);
	m_cbTIFFGray->setEnabled(!a_blChecked);
	m_sbJPEGGray->setEnabled(!a_blChecked);
	m_cbColor->setEnabled(!a_blChecked);
	m_cbTIFFColor->setEnabled(!a_blChecked);
	m_sbJPEGColor->setEnabled(!a_blChecked);
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Gets the currently selected file formats and TIFF codecs.
//
//	Parameters:
//		None
//
//	Returns:
//		STFileFormatSettings
////////////////////////////////////////////////////////////////////////
STFileFormatSettings CSTFileFormatDialog::GetFileFormatSettings( void )
{
	m_stfileformatsettings.blAutoFromDriver    = m_chkAutoFromDriver->isChecked();
	m_stfileformatsettings.uiColorFileFormat   = m_cbColor->currentItem();
	m_stfileformatsettings.uiGrayFileFormat    = m_cbGray->currentItem();
	m_stfileformatsettings.uiBitonalFileFormat = m_cbBitonal->currentItem();

	m_stfileformatsettings.uiBitonalTIFFCodec = m_cbTIFFBitonal->currentItem();
	m_stfileformatsettings.uiGrayTIFFCodec    = m_cbTIFFGray->currentItem();
	m_stfileformatsettings.uiColorTIFFCodec   = m_cbTIFFColor->currentItem(); 

    m_stfileformatsettings.iGrayJPEGQuality   = m_sbJPEGGray->value();
    m_stfileformatsettings.iColorJPEGQuality  = m_sbJPEGColor->value();

	return (m_stfileformatsettings);
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Sets the combo boxes to display the given formats and TIFF codecs
//
//	Parameters:
//		a_stfileformatsettings	- The selected file formats and TIFF codecs
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTFileFormatDialog::SetFileFormatSettings( const STFileFormatSettings& a_stfileformatsettings )
{
	m_stfileformatsettings = a_stfileformatsettings;

	m_cbColor->setCurrentItem(m_stfileformatsettings.uiColorFileFormat);
	m_cbGray->setCurrentItem(m_stfileformatsettings.uiGrayFileFormat);
	m_cbBitonal->setCurrentItem(m_stfileformatsettings.uiBitonalFileFormat);
	m_chkAutoFromDriver->setChecked(m_stfileformatsettings.blAutoFromDriver);

	m_cbTIFFColor->setCurrentItem(m_stfileformatsettings.uiColorTIFFCodec);
	m_cbTIFFGray->setCurrentItem(m_stfileformatsettings.uiGrayTIFFCodec);
	m_cbTIFFBitonal->setCurrentItem(m_stfileformatsettings.uiBitonalTIFFCodec);
	
	m_sbJPEGGray->setValue(m_stfileformatsettings.iGrayJPEGQuality);
	m_sbJPEGColor->setValue(m_stfileformatsettings.iColorJPEGQuality);
	
	// Use the changed slots to decided whether or not to show the TIFF codecs selector
	BitonalFileFormatChanged(m_cbBitonal->currentItem());
	GrayFileFormatChanged(m_cbGray->currentItem());
	ColorFileFormatChanged(m_cbColor->currentItem());
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Called when any of the file format settings are changed. It 
//      updates the UI showing the TIFF codec if TIFF was selected
//
//	Parameters:
//		none
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTFileFormatDialog::BitonalFileFormatChanged(int a_iIndex)
{
    if (a_iIndex == IDX_TIFFFILE)
    {
        m_cbTIFFBitonal->show();
        m_lblTIFFBitonal->show();
    }
    else
    {
        m_cbTIFFBitonal->hide();
        m_lblTIFFBitonal->hide();
    }
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Called when any of the file format settings are changed. It 
//      updates the UI showing the TIFF codec if TIFF was selected
//
//	Parameters:
//		none
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTFileFormatDialog::GrayFileFormatChanged(int a_iIndex)
{
    if (a_iIndex == IDX_TIFFFILE)
    {
        m_cbTIFFGray->show();
        m_lblTIFFGray->show();
    }
    else
    {
        m_cbTIFFGray->hide();
        m_lblTIFFGray->hide();
    }
    
    if (a_iIndex == IDX_JPEGFILE)
    {
        m_sbJPEGGray->show();
        m_lblJPEGGray->show();
    }
    else
    {
        m_sbJPEGGray->hide();
        m_lblJPEGGray->hide();
    }
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Called when any of the file format settings are changed. It 
//      updates the UI showing the TIFF codec if TIFF was selected
//
//	Parameters:
//		none
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTFileFormatDialog::ColorFileFormatChanged(int a_iIndex)
{
    if (a_iIndex == IDX_TIFFFILE)
    {
        m_cbTIFFColor->show();
        m_lblTIFFColor->show();
    }
    else
    {
        m_cbTIFFColor->hide();
        m_lblTIFFColor->hide();
    }
    
        if (a_iIndex == IDX_JPEGFILE)
    {
        m_sbJPEGColor->show();
        m_lblJPEGColor->show();
    }
    else
    {
        m_sbJPEGColor->hide();
        m_lblJPEGColor->hide();
    }
}

