// ScanTWAIN versions
#define VERSION_MAJOR			1
#define VERSION_MINOR			14
#define VERSION_PATCH			0
#define VERSION_BUILD			0
#define VERSION_YEAR			2011
#define VERSION_MONTH			02
#define	VERSION_DAY			    23

#define VERSION_TWAIN_MAJOR		2
#define VERSION_TWAIN_MINOR		0


// this put togeter the string to display to user's
#define szVERSION_INFO		szVERSION_DATE " " szVERSION_VERSION 		// YYYY/MM/DD M.m.b.p 


// this puts together the version string (M.m.b.p)
#if VERSION_BUILD
	#define szVERSION_VERSION	szVERSION_MAJOR "." szVERSION_MINOR "." szVERSION_PATCH "." szVERSION_BUILD
#elif VERSION_PATCH
	#define szVERSION_VERSION	szVERSION_MAJOR "." szVERSION_MINOR "." szVERSION_PATCH
#else
	#define szVERSION_VERSION	szVERSION_MAJOR "." szVERSION_MINOR
#endif

#define szVERSION_TWAIN			szVERSION_TWAIN_MAJOR "." szVERSION_TWAIN_MINOR


// this puts together the date (YYYY/MM/DD)
#define szVERSION_DATE		szVERSION_YEAR "/" szVERSION_MONTH "/" szVERSION_DAY


// versions for the resource
#define VERSION_PRODUCTVERSION		VERSION_MAJOR,VERSION_MINOR,VERSION_PATCH,VERSION_BUILD
#define szVERSION_PRODUCTVERSION	szVERSION_MAJOR ", " szVERSION_MINOR ", " szVERSION_PATCH ", " szVERSION_BUILD
#define szVERSION_PRODUCTNAME		"ScanTWAIN"
#define szVERSION_DESCRIPTION		"TWAIN ADF Scanning Application"
#define szVERSION_COMMENTS			""
#define szVERSION_COPYRIGHT			"Copyright � 2005-" szVERSION_YEAR
#define szVERSION_COMPANY			"Eastman Kodak Company"
//#define VERSION_FILETYPE			VFT_APP
//#define VERSION_OS				VOS__WINDOWS32


// magic macros to get numbers to strings
#define str(x)  #x
#define xstr(x) str(x)
#define szVERSION_MAJOR		xstr(VERSION_MAJOR)
#define szVERSION_MINOR		xstr(VERSION_MINOR)
#define szVERSION_PATCH		xstr(VERSION_PATCH)
#define szVERSION_BUILD		xstr(VERSION_BUILD)
#define szVERSION_YEAR		xstr(VERSION_YEAR)
#define szVERSION_MONTH		xstr(VERSION_MONTH)
#define szVERSION_DAY		xstr(VERSION_DAY)

