////////////////////////////////////////////////////////////////////////////////
//	File:
//		$Archive: /main/deliverables/scantwain/cstimgxferevent.cpp $
//
//	Description:
//		This file contains the implementation of CSTImgXferEvent, which inherits
//		QCustomEvent
//
//	History:
//		$Log: /main/deliverables/scantwain/cstimgxferevent.cpp $
//		
//		2     11/27/07 11:02a V737585
//		Added code to make ScanTWAIN, TWAIN 2.0 compliant
//		
//		1     1/23/06 5:24p V737585
//		Initial Revision
//
// Copyright (c) 2006 Eastman Kodak Company
//
// This file is part of ScanTWAIN
//
// ScanTWAIN is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// ScanTWAIN is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY;  without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along
// with ScanTWAIN; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
//	$NoKeywords: $
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//									INCLUDE FILES
////////////////////////////////////////////////////////////////////////////////
#include <cstdlib>
#include <qevent.h>
#include "cstimgxferevent.h"
#include "sttypes.h"

////////////////////////////////////////////////////////////////////////////////
//						DEFINES, TYPEDEFS, CONSTS & ENUMS
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////
// Description:
//		Constructor: Initializes the classes member variables
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
CSTImgXferEvent::CSTImgXferEvent() : QCustomEvent(STIMAGEXFER)
{
	m_pbImage = (unsigned char*)NULL;
	memset(&m_twimageinfo,0,sizeof(TW_IMAGEINFO));
}


////////////////////////////////////////////////////////////////////////
// Description:
//		Destructor: Destroy's the window (frees memory allocated in
//		the constructor.
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
CSTImgXferEvent::~CSTImgXferEvent()
{
	// delete the allocated memory
	if(m_pbImage != NULL)
	{
		FREE(m_pbImage);
	}
}


////////////////////////////////////////////////////////////////////////
// Description:
//		Copies the image data into the event.
//
//	Parameters:
//		a_pbImage		- Pointer to the image data (gets copied)
//		a_ulImageBytes	- The size of the image in bytes
//		a_twimageinfo	- The associated TWAIN image info
//
//	Returns:
//		bool			- True if successful
////////////////////////////////////////////////////////////////////////
bool CSTImgXferEvent::CopyData(unsigned char*	a_pbImage,
							   unsigned long	a_ulImageBytes,
							   TW_IMAGEINFO		a_twimageinfo)
{
	// "Copy" the TWAIN image info
	m_twimageinfo = a_twimageinfo;

	// Save the size in bytes
	m_ulImageBytes = a_ulImageBytes;
	
	// Allocate memory for the image and copy it, we use new so that
	// an exception will be thrown if need be
	m_pbImage = (unsigned char*)malloc(a_ulImageBytes*sizeof(unsigned char));
	if(m_pbImage == NULL)
	{
		m_ulImageBytes = 0;
		memset(&m_twimageinfo,0,sizeof(TW_IMAGEINFO));
		return false;
	}
	memcpy(m_pbImage, a_pbImage, m_ulImageBytes);

	return true;
}


////////////////////////////////////////////////////////////////////////
// Description:
//		Returns a pointer to the image data.
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
unsigned char* CSTImgXferEvent::Image(void)
{
	return m_pbImage;
}


////////////////////////////////////////////////////////////////////////
// Description:
//		Returns the image size in bytes.
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
unsigned long CSTImgXferEvent::ImageSizeInBytes(void)
{
	return m_ulImageBytes;
}


////////////////////////////////////////////////////////////////////////
// Description:
//		Returns the TWAIN image info structure associated with this
//		image.
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
TW_IMAGEINFO CSTImgXferEvent::ImageInfo(void)
{
	return m_twimageinfo;
}
