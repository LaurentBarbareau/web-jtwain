////////////////////////////////////////////////////////////////////////////////
//	File:
//		$Archive: /main/deliverables/scantwain/cstimagelabel.h $
//
//	Description:
/**
//		This file contains the definition of ScanTWAIN's image label. It
//		handles the display of images in ScanTWAIN (painting and resizing).
**/
//	History:
//		$Log: /main/deliverables/scantwain/cstimagelabel.h $
//		
//		1     11/02/05 3:41p V737585
//		Initial Revision
//
// Copyright (c) 2005 Eastman Kodak Company
//
// This file is part of ScanTWAIN
//
// ScanTWAIN is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// ScanTWAIN is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY;  without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along
// with ScanTWAIN; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
//	$NoKeywords: $
////////////////////////////////////////////////////////////////////////////////
#ifndef CSTIMAGELABEL_H
#define CSTIMAGELABEL_H

////////////////////////////////////////////////////////////////////////////////
//									INCLUDE FILES
////////////////////////////////////////////////////////////////////////////////
#include <qlabel.h>
#include <qimage.h>


class CSTImageLabel : public QLabel
{
	Q_OBJECT
	
	public:

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Constructor: Initializes the classes member variables
		//
		//	Parameters:
		//		parent	- This widget's parent widget
		//		name	- The widget's name (for debugging)
		//		f		- Widget Flags
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		CSTImageLabel(QWidget* parent, const char* name = 0, WFlags f = 0);


		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Destructor: Destroy's the label
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		~CSTImageLabel();
		
		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Sets the image that the label will display.
		//
		//	Parameters:
		//		a_imImage		- The image to display
		//		a_uiReduceResBy	- Factor to reduce the resolution by
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void setImage(const QImage& a_imImage, uint a_uiReduceResBy = 4);


	protected:
		
		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Responds to the label being resized
		//
		//	Parameters:
		//		a_evResize	- Passed in from QT containing old and new sizes
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void resizeEvent(QResizeEvent* a_evResize);
		
		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Paints the image on the label
		//
		//	Parameters:
		//		a_evPaint	- Passed in from QT, contains event related data
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void paintEvent(QPaintEvent* a_evPaint);

	private:

		QImage		m_imImage;		// This label's image
		QPixmap		m_pmBuffer;		// The pixmap actually painted to the label
		QSize		m_siOldSize;	// Stores original size when label is resized
		bool		m_bPainted;		// Whether or not the image has ever been painted

};		//End class CSTImageLabel


#endif
