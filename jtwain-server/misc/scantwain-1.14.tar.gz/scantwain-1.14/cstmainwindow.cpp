////////////////////////////////////////////////////////////////////////////////
//	File:
//		$Archive: /main/deliverables/scantwain/cstmainwindow.cpp $
//
//	Description:
//		ScanTWAIN's main window class. This class also provides the image
//		saving functionality.
//
//	History:
//		$Log: /main/deliverables/scantwain/cstmainwindow.cpp $
//		
//		32    7/24/09 2:55p V737585
//		Fixed a bug saving images in the home directory by default.
//		
//		31    7/24/09 2:42p V737585
//		Added support for Mac OS/X
//		
//		30    4/16/09 9:58a V737585
//		Redesigned the file format dialog and some of the underlying structures
//		to work better with the new file format scheme. Also fixed a couple of
//		warnings compiling on Debian x64 systems.
//		
//		29    4/08/09 2:18p V737585
//		PR12757: Added a dialog to allow the user to let ScanTWAIN choose the
//		file type automatically or allow the user to select the file type based
//		on the pixel type. This allows dual-stream scanning, auto color detect
//		and toggle patch to be used while still making it easy for the user and
//		giving them the same flexibility as before if they want it.
//		
//		28    2/23/09 4:13p V737585
//		Updated for version 1.11
//		
//		27    2/23/09 11:01a V737585
//		Make sure the TWAIN language get set to Brazilian Portuguese if the
//		country is Brazil.
//		
//		26    2/19/09 10:28a V737585
//		Added code to get the country and language from QT and convert it into
//		the appropriate TWAIN code to send to the driver.
//		
//		25    6/06/08 4:49p V737585
//		PR 12057: Updated error message string to include a space.
//		
//		24    5/29/08 10:39a V737585
//		Only verify the file format when starting a scan job and always allow
//		the user to select JPEG quality, even if it might get overriden by the
//		driver.
//		
//		23    5/28/08 3:31p V737585
//		Added support for the TWAIN GUI. ScanTWAIN will now try to use the
//		driver's UI before using it's own. Additionally, support for
//		transferring Group IV and JPEG compressed images has been added.
//		Additionally, the ScanSettings dialog (aka the default driver UI) has
//		been updated to add support for setting the compression.
//		
//		22    4/18/08 9:52a V737585
//		PR 11836: We were checking the stop flag where we shouldn't have been,
//		which could cause the save thread to exit before all the images are
//		saved. This would also leave them in the queue so they would come out
//		on the next scans and leave subsequent scans in the queue.
//		
//		21    4/09/08 3:44p V737585
//		Removed blFeederLoaded, it's no longer used.
//		
//		20    3/28/08 1:31p V737585
//		Don't check CAP_FEEDERLOADED when starting scanning, this will break
//		auto mode.
//		
//		19    3/27/08 11:48a V737585
//		We only need to stop the scan thread in StopScanning -- the save thread
//		will be stopped once scanning is stopped.
//		
//		18    3/27/08 11:45a V737585
//		PR 11753: The user was not seeing the "Out of Paper" message, as it was
//		going to the command line only. We now check for paper before beginning
//		a scan session and will report the error in a message box.
//		Additionally, scan thread and save thread errors will now all be
//		displayed in message boxes via events sent to the main ui thread. 
//		
//		17    3/26/08 2:44p V737585
//		Fixed a typo on uiYReduction in CSTMainWindow::ShowImage and added the
//		new save thread to the project file
//		
//		16    3/26/08 1:04p V737585
//		PR 11740, 11749, 11750: THIS IS A MAJOR REVISION!! We now maintain an
//		image buffer of 10 images, we will not continue to transfer images from
//		the driver while that buffer is full. Additionally, a save thread has
//		been added to save the images in a separate thread. Several new custom
//		events have been added to assist in coordinating this. Finally, the
//		display resolution of the images has been reduced to between 75-150 dpi
//		to make the display faster. NOTE: ScanTWAIN now uses considerably more
//		memory and we may have to consider moving to memory mapped files if
//		this becomes a problem on low memory systems.
//		
//		15    3/19/08 10:08a V737585
//		PR 11740: QT queues up the above events, essentially creating an buffer
//		full of images to be saved and/or displayed, the code below was added
//		to make sure this buffer is only allowed to grow to a certain size,
//		making ScanTWAIN a little nicer on the system if saving/displaying is
//		taking too long.
//		
//		14    1/25/08 8:39a V737585
//		Updated file copyright.
//		
//		13    1/24/08 4:45p V737585
//		PR 11601 "Select Scanner" should not have been reenabled after
//		scanning. ScanTWAIN will now close any open ds before trying to open
//		another.
//		
//		12    1/23/08 3:11p V737585
//		PR 11602: Don't store the original size unless the images are being
//		shown. This prevents the main windows from being restored to the wrong
//		size if "Hide Images" is clicked more than once.
//		
//		11    11/27/07 3:34p V737585
//		Minor fixes for TWAIN 2.0 Compliance
//		
//		10    11/27/07 11:02a V737585
//		Added code to make ScanTWAIN, TWAIN 2.0 compliant
//		
//		9     4/23/07 4:07p V737585
//		Image data is now copied into the QImage for display a single row at a
//		time. This avoids messing up the alignment. Also, make sure TIFF files
//		have the .tiff extension (rather than .tif).
//		
//		8     4/10/07 5:33p V737585
//		We now use the callback to determine if a image is ready to be
//		transferred, as opposed to the old icky way :)
//		
//		7     3/08/07 5:12p V737585
//		Changed ImageHeight to ImageLength to match twain.h and added
//		cstimgxferevent.* to the QT project file.
//		
//		6     8/15/06 12:31p V737585
//		Added code to convert 1bpp bitonal images to 8bpp bitonal images when
//		doing JPEG compression.
//		
//		5     1/24/06 10:35a V737585
//		Fixed memory leaks, added support for saving the image resolution in
//		the image file (using libjpeg, libtiff & libpng instead of QTs image
//		saving mechanism), fixed file format selection being saved after Cancel
//		is clicked. This work fixes PRs 7382, 7459, 7487 & 7486
//		
//		2     11/14/05 3:40p V737585
//		Updated to remove What's This? button from the title bar of ScanTWAIN's
//		dialogs.
//		
//		1     11/02/05 3:41p V737585
//		Initial Revision
//
// Copyright (c) 2005-2009 Eastman Kodak Company
//
// This file is part of ScanTWAIN
//
// ScanTWAIN is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// ScanTWAIN is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY;  without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along
// with ScanTWAIN; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
//	$NoKeywords: $
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
//									INCLUDE FILES
////////////////////////////////////////////////////////////////////////////////
#include <qapplication.h>
#include <qcolor.h>
#include <qimage.h>
#include <qbitmap.h>
#include <qmenubar.h>
#include <qpopupmenu.h>
#include <qstatusbar.h>
#include <qmessagebox.h>
#include <qlocale.h>

#include <stdlib.h>
#include <tiffio.h>
#include <png.h>

#include "cstmainwindow.h"
#include "cstscansettingsdialog.h"
#include "cstselectscannerdialog.h"
#include "cstfileformatdialog.h"
#include "cstimgxferevent.h"
#include "cstfiledialog.h"
#include "cstimageutils.h"
#include "sticons.h"



////////////////////////////////////////////////////////////////////////
// Description:
//		Constructor: Initializes the classes member variables
//
//	Parameters:
//		parent	- This widget's parent widget
//		name	- The widget's name (for debugging)
//		f1		- Widget style flags
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
CSTMainWindow::CSTMainWindow( QWidget* parent, const char* name, WFlags fl )
	: QMainWindow( parent, name, fl )
{

	TW_UINT16	sts;			// Holds the status of the TWAIN calls
	char		szMessage[256];	// Holds TWAIN errors
	char		*szFormat;		// Pointer to an image format string
	QStrList	strlistFormats;	// Holds the list of support image formats
	bool		bFoundJPEG;		// Is JPEG supported
	
	// If the dialog does not have a name give it a generic one
	if( !name )
	{
		setName("CSTMainWindow");
	}
	setMinimumSize(QSize(UIMINWIDTH,UIMINHEIGHT));

	// Create an empty status bar
	(void)statusBar();
	
    // actions
	m_actExit = new QAction( this, "m_actExit" );
	m_actExit->setIconSet(QIconSet(qembed_findImage("exit")));
	m_actChooseFilename = new QAction( this, "m_actChooseFilename" );
	m_actChooseFilename->setIconSet(QIconSet(qembed_findImage("filesaveas")));
	m_actFileFormat = new QAction(this, "m_actFileFormat");
	m_actSelectScanner = new QAction( this, "m_actSelectScanner" );
	m_actScanSetup = new QAction( this, "m_actScanSetup" );
	m_actScanSetup->setIconSet(QIconSet(qembed_findImage("scanner")));
	m_actScan = new QAction( this, "m_actScan" );
	m_actScan->setIconSet(QIconSet(qembed_findImage("start")));
	m_actScanStop = new QAction( this, "m_actScanStop" );
	m_actScanStop->setIconSet(QIconSet(qembed_findImage("stop")));
	m_actgViewImages = new QActionGroup( this, "m_actgViewImages" );
	m_actgViewImages->setUsesDropDown( FALSE );
	m_actViewNone = new QAction( m_actgViewImages, "m_actViewNone" );
	m_actViewNone->setToggleAction( TRUE );
	m_actViewNone->setIconSet(QIconSet(qembed_findImage("view_remove")));
	m_actView2Up = new QAction( m_actgViewImages, "m_actView2Up" );
	m_actView2Up->setToggleAction( TRUE );
	m_actView2Up->setOn( TRUE );
	m_actView2Up->setIconSet(QIconSet(qembed_findImage("view_left_right")));
	m_actViewToolbar = new QAction( this, "m_actViewToolbar" );
	m_actViewToolbar->setToggleAction( TRUE );
	m_actViewToolbar->setOn( TRUE );
	m_actViewStatusbar = new QAction( this, "m_actViewStatusbar" );
	m_actViewStatusbar->setToggleAction( TRUE );
	m_actViewStatusbar->setOn( TRUE );

    // toolbars
	m_toolBar = new QToolBar( QString(""), this, DockTop );

	m_actChooseFilename->addTo( m_toolBar );
	m_toolBar->addSeparator();
	m_actScanSetup->addTo( m_toolBar );
	m_toolBar->addSeparator();
	m_actScan->addTo( m_toolBar );
	m_actScanStop->addTo( m_toolBar );
	m_toolBar->addSeparator();

	// create the menu bar
	m_menuBar = new QMenuBar( this, "m_menuBar" );

	m_menuFile = new QPopupMenu( this );
	m_actChooseFilename->addTo( m_menuFile );
	m_menuFile->insertSeparator();
	m_actFileFormat->addTo( m_menuFile );	
	m_menuFile->insertSeparator();
	m_actExit->addTo( m_menuFile );
	m_menuBar->insertItem( QString(""), m_menuFile, 1 );

	m_menuScan = new QPopupMenu( this );
	m_actSelectScanner->addTo( m_menuScan );
	m_menuScan->insertSeparator();
	m_actScanSetup->addTo( m_menuScan );
	m_menuScan->insertSeparator();
	m_actScan->addTo( m_menuScan );
	m_actScanStop->addTo( m_menuScan );
	m_menuBar->insertItem( QString(""), m_menuScan, 2 );

	m_menuView = new QPopupMenu( this );
	m_actViewNone->addTo( m_menuView );
	m_actView2Up->addTo( m_menuView );
	m_menuView->insertSeparator();
	m_actViewStatusbar->addTo( m_menuView );
	m_actViewToolbar->addTo( m_menuView );
	m_menuBar->insertItem( QString(""), m_menuView, 3 );

	languageChange();
	resize( QSize(660, 550).expandedTo(minimumSizeHint()) );
	clearWState( WState_Polished );

	// Setup the Default Values
    m_strCurrentScanner	= tr("No Scanner Selected");	// Default is that no scanner is selected
	m_iCurrentImage = 1;
	m_iImageCount = 0;
	m_bFilenameChoosen = false;
	m_bShowImages = true;
	m_bDSOpened = false;

	// Setup the Image View
	setCentralWidget(new QWidget(this,"centralwidget"));

	// Create the layout
	m_qhblLayout = new QHBoxLayout(centralWidget(), 11, 6, "m_qhblLayout");

	// Create the labels and add them to the layout
	m_ilblImage1 = new CSTImageLabel(centralWidget(), "image1");
	m_qhblLayout->addWidget(m_ilblImage1);

	m_ilblImage2 = new CSTImageLabel(centralWidget(), "image2");
	m_qhblLayout->addWidget(m_ilblImage2);

	// the default filename is based on the current date and time
	QDateTime dt = QDateTime::currentDateTime();
	m_strCurrentFilename = QString(getenv("HOME")) + QString("/st") + dt.toString("ddMMyyhhmmss");

	// Create the labels for the statusbar
	m_lblFilename = new QLabel(statusBar());
	m_lblFilename->setText(m_strCurrentFilename);

	m_lblSelectedScanner = new QLabel(statusBar());
	m_lblSelectedScanner->setText(m_strCurrentScanner);

	m_lblBlank = new QLabel(statusBar());
	m_lblBlank->setText("");

	statusBar()->addWidget(m_lblBlank, 200, false);
	statusBar()->addWidget(m_lblSelectedScanner, 0, true);
	statusBar()->addWidget(m_lblFilename, 0, true);

	// We always save images by default
	m_bSaveImages = true;

	UpdateUI(UISTATE_STARTUP);	// Enable/Disable Appropriate Actions

	m_siOriginalSize = size();

	// signals and slots connections
	connect( m_actExit, SIGNAL( activated() ), this, SLOT( ExitApp() ) );
	connect( m_actViewStatusbar, SIGNAL( toggled(bool) ), this, SLOT( ToogleStatusbar(bool) ) );
	connect( m_actViewToolbar, SIGNAL( toggled(bool) ), this, SLOT( ToogleToolbar(bool) ) );
	connect( m_actFileFormat, SIGNAL( activated() ), this, SLOT( FileFormat() ) );
	connect( m_actScanSetup, SIGNAL( activated() ), this, SLOT( OpenScanSettingsDialog() ) );
	connect( m_actSelectScanner, SIGNAL( activated() ), this, SLOT( OpenSelectScannerDialog() ) );
	connect( m_actScan, SIGNAL( activated() ), this, SLOT( StartScanning() ) );
	connect( m_actScanStop, SIGNAL( activated() ), this, SLOT( StopScanning() ) );
	connect( m_actView2Up, SIGNAL( activated() ), this, SLOT( View2Up() ) );
	connect( m_actViewNone, SIGNAL( activated() ), this, SLOT( ViewNone() ) );
	connect( m_actChooseFilename, SIGNAL( activated() ), this, SLOT( ChooseFilename() ) );

	// Make sure QT has JPEG support compiled in
	bFoundJPEG = false;
	strlistFormats = QImageIO::inputFormats();
	for(szFormat = strlistFormats.first();
		szFormat != NULL;
		szFormat = strlistFormats.next())
	{
		if(strcasecmp(szFormat,"JPEG") == 0)
		{
			bFoundJPEG = true;
			break;
		}
	}

	// Throw up an error if we don't have JPEG support
	if (!bFoundJPEG)
	{
		QMessageBox::critical
		(
			this,
			tr("ScanTWAIN Error"),
			tr("QT does not have JPEG support compiled in"),
			QMessageBox::Ok,
			QMessageBox::NoButton
		);
		close();
	}

	TW_UINT16	twuint16Country;
	TW_UINT16	twuint16Language;
	GetTwainCountry(&twuint16Country, &twuint16Language);

	// Setup the TWAIN control class member
	sts = m_sttwainCtrl.SetIdentity(
									tr(szVERSION_COMPANY),
									tr("Document Imaging"),
									tr(szVERSION_PRODUCTNAME),
									tr(szVERSION_DATE " " szVERSION_PRODUCTVERSION),
									VERSION_TWAIN_MAJOR,
									VERSION_TWAIN_MINOR,
									DF_APP2 | DG_CONTROL | DG_IMAGE,
									twuint16Country,
									twuint16Language,
									1,
									0
								   );

	// Check the status of the call
	if( sts == TWRC_FAILURE )
	{
		m_sttwainCtrl.GetErrorString(szMessage,sizeof(szMessage));
		QMessageBox::critical
		(
		  this,
		  tr("ScanTWAIN Error"),
		  tr("TWAIN: SetIdentity Failed.\n The application will now exit: ") + szMessage,
		  QMessageBox::Ok,
		  QMessageBox::NoButton
		 );
		close();
	}

	sts = m_sttwainCtrl.OpenDSM();

	// check the status of the call
	if( sts == TWRC_FAILURE )
	{
		m_sttwainCtrl.GetErrorString(szMessage,sizeof(szMessage));
		QMessageBox::critical
		(
		  this,
		  tr("ScanTWAIN Error"),
		  tr("TWAIN: OpenDSM Failed: ") + szMessage + tr(". The application will now exit."),
		  QMessageBox::Ok,
		  QMessageBox::NoButton
		);
		close();
	}
	
	// On Mac OS/X we need to set the callback as soon as we open the
	// DSM. However, on Linux we want to do it after we open the DS.
	// So, only do this here if we're on OS/X.
	#ifdef __APPLE__
		// Set the callback
		sts = m_sttwainCtrl.SetCallback(TWAINCallback);
		if ( sts != TWRC_SUCCESS )
		{
			m_sttwainCtrl.GetErrorString(szMessage,sizeof(szMessage));
			QMessageBox::critical
			(
		 		this,
		 		tr("ScanTWAIN Error"),
		 		tr("TWAIN: Failed to set callback") + szMessage + tr(". The application will now exit."),
		 		QMessageBox::Ok,
		 		QMessageBox::NoButton
		 	);
			close();
		}
	#endif
}


////////////////////////////////////////////////////////////////////////
// Description:
//		Destructor: Destroy's the window
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
CSTMainWindow::~CSTMainWindow()
{
    // no need to delete child widgets, Qt does it all for us, just make
	// sure that our threads are stopped cleanly.
	m_scanthread.AbortThread();
	m_savethread.AbortThread();

	m_scanthread.wait();
	m_savethread.wait();
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Changes the text in the dialog in response to a change of
//		language event.
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTMainWindow::languageChange()
{
	setCaption( tr( "ScanTWAIN" ) );
	m_actExit->setText( tr( "Exit" ) );
	m_actExit->setMenuText( tr( "Exit" ) );
	m_actExit->setStatusTip( tr( "Exits the application" ) );
	m_actChooseFilename->setText( tr( "Choose Filename" ) );
	m_actChooseFilename->setMenuText( tr( "Choose Filename ..." ) );
	m_actChooseFilename->setStatusTip( tr( "Choose a Base Filename to Save Images To" ) );
	m_actSelectScanner->setText( tr( "Select Scanner" ) );
	m_actSelectScanner->setMenuText( tr( "Select Scanner" ) );
	m_actSelectScanner->setStatusTip( tr( "Select the Scanner to Acquire Images With" ) );
	m_actScanSetup->setText( tr( "Scanner Settings" ) );
	m_actScanSetup->setStatusTip( tr( "Change the Scanner Settings" ) );
	m_actScan->setText( tr( "Scan" ) );
	m_actScan->setMenuText( tr( "Scan" ) );
	m_actScan->setStatusTip( tr( "Start Scanning" ) );
	m_actScanStop->setText( tr( "Stop" ) );
	m_actScanStop->setMenuText( tr( "Stop" ) );
	m_actScanStop->setStatusTip( tr( "Stop Scanning" ) );
	m_actgViewImages->setText( tr( "View Images" ) );
	m_actgViewImages->setMenuText( tr( "View Images" ) );
	m_actViewNone->setText( tr( "Hide Images" ) );
	m_actViewNone->setMenuText( tr( "Hide Images" ) );
	m_actViewNone->setStatusTip( tr( "Do Not Display Scanned Images" ) );
	m_actView2Up->setText( tr( "2-Up" ) );
	m_actView2Up->setMenuText( tr( "2-Up" ) );
	m_actView2Up->setStatusTip( tr( "View 2 Images at a Time" ) );
	m_actViewToolbar->setText( tr( "View Toolbar" ) );
	m_actViewToolbar->setMenuText( tr( "View Toolbar" ) );
	m_actViewToolbar->setStatusTip( tr( "Show/Hide the Toolbar" ) );
	m_actViewStatusbar->setText( tr( "View Statusbar" ) );
	m_actViewStatusbar->setMenuText( tr( "View Statusbar" ) );
	m_actViewStatusbar->setStatusTip( tr( "Show/Hide the Statusbar" ) );
	m_actFileFormat->setText( tr( "File Format" ) );
	m_actFileFormat->setMenuText( tr( "File Format ..." ) );
	m_actFileFormat->setStatusTip( tr( "Select a File Format to Save Images As" ) );
	m_toolBar->setLabel( tr( "Main Toolbar" ) );
	m_menuFile->changeItem( m_menuFile->idAt( 2 ), tr( "File Format" ) );
	if (m_menuBar->findItem(1))
		m_menuBar->findItem(1)->setText( tr( "&File" ) );
	if (m_menuBar->findItem(2))
		m_menuBar->findItem(2)->setText( tr( "&Scan" ) );
	if (m_menuBar->findItem(3))
		m_menuBar->findItem(3)->setText( tr( "&View" ) );
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Sets the visibility of the tool bar
//
//	Parameters:
//		toggle	- T/F (Visible / Invisible)
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTMainWindow::ToogleToolbar( bool toggle )
{
    if( toggle )
	{
		m_toolBar->show();
	}
    else
	{
		m_toolBar->hide();
	}
    
    return;
}


////////////////////////////////////////////////////////////////////////
// Description:
//		Sets the visibility of the status bar
//
//	Parameters:
//		toogle	- T/F (Visible / Invisible)
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTMainWindow::ToogleStatusbar( bool toggle )
{
    if( toggle )
	{
		statusBar()->show();
	}
	else
	{
		statusBar()->hide();
	}
    
    return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Exits the application
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTMainWindow::ExitApp()
{
	close();
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Opens the Scan Settings Dialog
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTMainWindow::OpenScanSettingsDialog()
{
	// Open the UI to handle the settings.
	TW_UINT16			twrc;

	twrc = m_sttwainCtrl.Enable(TRUE, TRUE);
	if (twrc != TWRC_SUCCESS)
	{
		// The GUI failed to load for some reason, so we'll just use our built
		// in programatic GUI
		CSTScanSettingsDialog	*dlg;

		// First, we'll create (allocate memory for) the scan settings dialog
		try
		{
			dlg = new CSTScanSettingsDialog(this, 0, true, Qt::WStyle_Customize | Qt::WStyle_Dialog | Qt::WStyle_Title);
		}
		catch(...)
		{
			QMessageBox::critical(this,
								  tr("ScanTWAIN Error"),
								  tr("Out of Memory. Cannot Load Dialog."),
								  QMessageBox::Ok,
								  QMessageBox::NoButton
								 );
			return;
		}

		// Now we'll call the dialog functions that will negotiate the supported
		// capabilities with the driver. To do this these functions require a
		// pointer to our CSTTwain object.
		dlg->Negotiate(&m_sttwainCtrl);

		// now open the dialog and check the result
		if( dlg->exec() == QDialog::Accepted )
		{
			// the user clicked OK, so we should set all of the settings
			dlg->SendSettings(&m_sttwainCtrl);
		} // end if(dlg->exec() == QDialog::Accepted)
	
		// delete the dialog and return
		delete dlg;

		// return here so we don't update the UI
		return;
	}

	// Disable the window
	UpdateUI(UISTATE_DRIVERUIOPEN);
	
	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Opens the Select Scanner Dialog
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTMainWindow::OpenSelectScannerDialog()
{
    CSTSelectScannerDialog		*dlg;
    std::vector<TW_IDENTITY>	vecDsList;
	unsigned int				iter,
								index;
	TW_UINT16					sts;

	// Use the TWAIN control class to give a list of data sources
	vecDsList = m_sttwainCtrl.ListDS();

	// Check to make sure that some were found
	if( vecDsList.empty() )
	{
		// no data sources were found
		QMessageBox::information(
								 this,
								 tr("ScanTWAIN"),
								 tr("No Drivers Were Found."),
								 QMessageBox::Ok,
								 QMessageBox::NoButton
								);
		return;
	}

	// Since we found some data sources, we'll create a dialog
	// to choose which one we want.
	dlg = new CSTSelectScannerDialog(this, 0, true, Qt::WStyle_Customize | Qt::WStyle_Dialog | Qt::WStyle_Title);
	
	// and populate it's list box with our data sources
	dlg->ClearList();
	for(iter = 0; iter < vecDsList.size(); iter++)
	{
		dlg->AddToList(QString((char*)vecDsList[iter].ProductName));
	}

	// execute the dialog and check the response
	if ( dlg->exec() == QDialog::Accepted )
	{
		// This means that the user clicked OK. Error checking inside
		// the dialog class ensures that an item was selected, so we
		// won't check for that.

		// Because of the way we populated the list box in the
		// dialog we know that the list box's current item is the
		// same as the index into the vector, so let's copy
		// the identity into the main window class based on that fact.
		index = dlg->GetSelectedItem();
		m_twidentity = vecDsList[index];

		// If we already have a DS opened, close it first
		if (m_bDSOpened)
		{
			m_sttwainCtrl.CloseDS();
		}

		// Now we'll try and open the data source.
		sts = m_sttwainCtrl.OpenDS(m_twidentity);

		// Check the result
		if( sts == TWRC_FAILURE )
		{
			QMessageBox::critical(
								  this,
								  tr("Communications Error"),
								  tr("Please check to make sure the scanner has powered up successfully and that the cable is securely attached to both the PC and the scanner.\nIf you are still having a problem, then power down the scanner; then power up the scanner, wait for it to finish initializing and try again."),
								  QMessageBox::Ok,
							  	  QMessageBox::NoButton
								 );
			delete dlg;
			return;
		}

		// We now have a datasource opened
		m_bDSOpened = true;

		// If we're here then the DS was opened and we should be ready
		// to scan. First we'll update the appropriate UI elements
		m_lblSelectedScanner->setText(QString((char*)m_twidentity.ProductName));
		UpdateUI(UISTATE_SCANNERSELECTED);

		// Disable the action to allow selecting a scanner as this won't work
		// correctly after this point
		m_actSelectScanner->setEnabled(false);
	}

	// So at this point we're either done or the user cancelled.
	// In either case all we need to do is delete the dialog and return
	delete dlg;
	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Updates the UI State (Controls what actions are enabled)
//
//	Parameters:
//		a_iUIState	- The state to set the UI to
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTMainWindow::UpdateUI( int a_iUIState )
{

	// based on the UI State (m_iUIState) enable and disable the appropriate
	// actions. Two states are defined SCANNERSELECTED & SCANNING

	// The following actions are always enabled:
	//	actFileExit, actgViewImages, actViewStatusbar, actViewToolbar
	switch( a_iUIState )
	{
		default:
			QMessageBox::information(
									 this,
									 tr("ScanTWAIN Error"),
									 tr("Unhandled UI State Encountered."),
									 QMessageBox::Ok
									);
			break;
			
		case UISTATE_STARTUP:
			// Startup state (ie. no scanner selected and no scanning)
			// Therefore we disable the scan buttons (scan, stop, settings)
			m_actScan->setEnabled(false);
			m_actScanStop->setEnabled(false);
			m_actScanSetup->setEnabled(false);
			break;

		case UISTATE_SCANNERSELECTED:
			// Scanner Selected. We'll enable the scan buttons
			m_actScan->setEnabled(true);
			m_actScanSetup->setEnabled(true);
			m_actChooseFilename->setEnabled(true);
			m_actFileFormat->setEnabled(true);
			m_actScanStop->setEnabled(false);
			break;

		case UISTATE_SCANNING:
			// Scanning. Disable everything that's not always enabled
			// except stop.
			m_actScanStop->setEnabled(true);

			m_actScan->setEnabled(false);
			m_actScanSetup->setEnabled(false);
			m_actChooseFilename->setEnabled(false);
			m_actFileFormat->setEnabled(false);
			break;

		case UISTATE_DRIVERUIOPEN:
			// Disable the window
			setEnabled(false);
			break;

		case UISTATE_DRIVERUICLOSED:
			// Disable the window
			setEnabled(true);
			break;

	} // end switch(m_iUIState)

	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Starts Scanning
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTMainWindow::StartScanning( void )
{
	TW_UINT16		uiResult;
	TW_INT16		i16XferCount;
	char			szMessage[256];
	
	// By default we always save images
	m_bSaveImages = true;

	// Verify the file format
	if (!VerifyFileFormat()) 
	{
		// The file format is incompatible, we can't start
		return;
	}

	// ScanTWAIN only does memory transfers
	uiResult = m_sttwainCtrl.SetTransferMode(TWSX_MEMORY);
	if( uiResult != TWRC_SUCCESS )
	{
		m_sttwainCtrl.GetErrorString(szMessage,sizeof(szMessage));
		QMessageBox::critical
		(
		  this,
		  tr("ScanTWAIN Error"),
		  tr("Scan Canceled! (Unable to Set Image Transfer Mechanism): ") + szMessage,
		  QMessageBox::Ok,
		  QMessageBox::NoButton
		);
		return;
	} // end if(uiResult!=TWRC_SUCCESS)

	// We always want to scan a batch, so set CAP_XFERCOUNT to -1;
	i16XferCount = -1;
	uiResult = m_sttwainCtrl.SetOneValue(CAP_XFERCOUNT,TWTY_INT16,(TW_MEMREF)&i16XferCount);
	if( uiResult != TWRC_SUCCESS )
	{
		m_sttwainCtrl.GetErrorString(szMessage,sizeof(szMessage));
		QMessageBox::critical
		(
		  this,
		  tr("ScanTWAIN Error"),
		  tr("Scan Canceled (Failed to set CAP_XFERCOUNT)! ") + szMessage,
		  QMessageBox::Ok,
		  QMessageBox::NoButton
		);
		return;
	} // end if(uiResult!=TWRC_SUCCESS)

	// update the default filename if one wasn't selected
	if(!m_bFilenameChoosen)
	{
		// the default filename is based on the current date and time
		QDateTime dt = QDateTime::currentDateTime();
		m_strCurrentFilename = QString(getenv("HOME")) + QString("/st") + dt.toString("ddMMyyhhmmss");

		m_lblFilename->setText(m_strCurrentFilename);

		// reinitialize the counter
		m_iImageCount = 0;
	}

	// Set the current filename and file format settings needed by the save thread
	m_savethread.SetMainWindow(this);
	m_savethread.SetFilename(m_strCurrentFilename);
	m_savethread.SetFormats(m_stfileformatsettings);
	
	// Now we need to enable the driver
	uiResult = m_sttwainCtrl.Enable(FALSE);
	if( uiResult != TWRC_SUCCESS )
	{
		m_sttwainCtrl.GetErrorString(szMessage,sizeof(szMessage));
		QMessageBox::critical
		(
		  this,
		  tr("ScanTWAIN Error"),
		  tr("Scan Canceled (ENABLEDS Failed)! ") + szMessage,
		  QMessageBox::Ok,
		  QMessageBox::NoButton
		);
		return;
	} // end if(uiResult!=TWRC_SUCCESS)
	
	// setup the scan thread
	m_scanthread.SetTwainObject(&m_sttwainCtrl);
	m_scanthread.SetMainWindow(this);

	// At this point we're officially scanning so update the UI
	UpdateUI(UISTATE_SCANNING);
		
	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Stops scanning (stops the feeder)
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTMainWindow::StopScanning( void )
{
	
	// First stop the scan thread (this will signal the adf to stop)
	m_scanthread.StopThread();

	// We won't wait fot the thread to finish to allow any remaining images
	// to transfer and be displayed. The thread will disable the driver and
	// update the UI when all the remaining transfers are finished.
	
	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Hides the images
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTMainWindow::ViewNone( void )
{
	// get the current size of the window so that it can be restored later
	// PR 11602: Don't store the original size unless the images are
	// being shown. This prevents the main windows from being restored
	// to the wrong size if "Hide Images" is clicked more than once.
	if (m_bShowImages)
	{
		m_siOriginalSize = size();
	}

	// Indicate that we are not showing images
	m_bShowImages = false;

	// Hide the Image Labels
	m_ilblImage1->hide();
	m_ilblImage2->hide();

	// Resize to the minimum size
	resize(UIMINWIDTH, UIMINHEIGHT);

	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Shows Images in 2-Up Mode
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTMainWindow::View2Up( void )
{
	// if we're not currently showing images we'll need to resize first
	if(!m_bShowImages)
	{
		// resize the window to it's original size
		resize(m_siOriginalSize);
	}

	m_bShowImages = true;

	// Show the Image Labels
	m_ilblImage1->show();
	m_ilblImage2->show();

	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Opens the dialog to allow the user to select a base filename
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTMainWindow::ChooseFilename( void )
{
	CSTFileDialog*	cstfiledialog;

	cstfiledialog = new CSTFileDialog(this, "file dialog", true);

	// Setup the file fialog
	cstfiledialog->setMode(QFileDialog::AnyFile);
	//cstfiledialog->setFilter(tr("Images (*.jpg *.png *.tif)"));
	cstfiledialog->setViewMode(QFileDialog::List);
	cstfiledialog->setContentsPreviewEnabled(false);
	cstfiledialog->setDir("~/");
	cstfiledialog->SetCurrentExtension(tr(".tif"));

	// Now we'll show the dialog
	if(cstfiledialog->exec() == QDialog::Accepted)
	{
		QString strTemp;

		strTemp = cstfiledialog->selectedFile();
		if(!strTemp.isEmpty()) {
			// The user clicked ok, so we'll get the directory and filename
			m_strCurrentFilename = strTemp;
			m_bFilenameChoosen = true;
		}

		// update the status bar area
		m_lblFilename->setText(m_strCurrentFilename.section('/',-1));
	}

	// We're done delete the dialog
	delete cstfiledialog;

	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Create a QImage object from the image passed in and set the
//		image on the appropriate label (based on which label was last
//		used). Finally, send a paint event to allow QT to draw the image
//
//	Parameters:
//		a_pbImage		- The image
//		a_ulBytes		- The size of the image in bytes
//		a_twimageinfo	- The TWAIN information about the image
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTMainWindow::ShowImage
(
	unsigned char*	a_pbImage,
	unsigned long	a_ulBytes,
	TW_IMAGEINFO	a_twimageinfo
)
{
	QPaintEvent*	pevPaint;		// Used to tell the display to update the images
	QImage			imImage;		// The image which we will emit later
	uchar*			pbBits;			// A pointer to QImage's data
	uint*			pwBits;			// A pointer to QImage's data
	uint			uiXReduction;	// Factor to reduce the X resolution
	uint			uiYReduction;	// Factor to reduce the Y resolution
	uchar*			pucUncompressed;// The uncompressed G4 image (if needed)
	int 			iWidthBytes;	// Width of the image in bytes for bitonal data
	int				iG4sts;			// Status of G4 decompression
	uchar*			pucCompressed;	// The compressed G4 image (if neeed)
	
	// If we're not showing images so there's no work to be done
	if (!m_bShowImages)
	{
		return;
	}

	m_iImageCount++;
	
	// We can display three type of "compressed" images, JPEG, CCITT Group IV,
	// and uncompressed, but we do each a little differently...
	switch (a_twimageinfo.Compression)
	{
		default:
			QMessageBox::warning(this,
								 tr("ScanTWAIN Error"),
								 tr("Image data received with unrecognized compression. Image cannot be displayed."),
								 QMessageBox::Ok,
								 QMessageBox::NoButton
								);
			ViewNone();
			return;
	
		// JPEG...
		// We rely on QT to handle JPEG for us. We've checked at launch time
		// to see if it has, so hopefully we're ok with that
		case TWCP_JPEG:
			// Our image is compressed, display it by having QImage "load" it
			// from the data
			if (!imImage.loadFromData(a_pbImage,a_ulBytes,"JPEG"))
			{
				QMessageBox::warning(this,
									 tr("ScanTWAIN Error"),
									 tr("Failed to decompress image data. Image cannot be displayed"),
									 QMessageBox::Ok,
									 QMessageBox::NoButton
									);
				ViewNone();
				return;
			}
			break;

		case TWCP_GROUP4:
			// Calculate the width of our image in bytes
			if (a_twimageinfo.ImageWidth % 8)
			{
				iWidthBytes = a_twimageinfo.ImageWidth / 8 + 1;
			}
			else
			{
				iWidthBytes = a_twimageinfo.ImageWidth / 8;
			}

			// The Group IV decompression algorithm has a tendancy to overrun
			// it's buffers, both input and output. So not only do we have to
			// allocate an extra 1K (which is thankfully somewhat small) for the
			// uncompressed image, but we must also do that for the input and
			// copy the buffer we were give into it (NOTE: if you get memory
			// corruption problems when scanning with group IV compression, try
			// increase the 1K overrun before anything else)

			// Allocate memory for the compressed image (and copy it in)
			pucCompressed = (uchar*)malloc(a_ulBytes+1024);
			if (!pucCompressed)
			{
				QMessageBox::warning(this,
									 tr("ScanTWAIN Error"),
									 tr("Out of memory! Image cannot be displayed."),
									 QMessageBox::Ok,
									 QMessageBox::NoButton
									);
				ViewNone();
				return;
			}
			memset(pucCompressed,0,a_ulBytes+1024);
			memcpy(pucCompressed,a_pbImage,a_ulBytes);

			// Allocate memory for the uncompressed image
			pucUncompressed = (uchar*)malloc(a_twimageinfo.ImageLength*iWidthBytes + 1024);
			if (!pucUncompressed)
			{
				QMessageBox::warning(this,
									 tr("ScanTWAIN Error"),
									 tr("Out of memory! Image cannot be displayed."),
									 QMessageBox::Ok,
									 QMessageBox::NoButton
									);
				FREE(pucCompressed);
				ViewNone();
				return;
			}
			memset(pucUncompressed,0,a_twimageinfo.ImageLength*iWidthBytes + 1024);
			
			iG4sts = memg4_decompress
						(
							a_twimageinfo.ImageWidth,
							a_twimageinfo.ImageLength,
							iWidthBytes,
							pucUncompressed,
							pucCompressed,
							a_ulBytes,
							COMPRESS_G4_2D
						);
			if (iG4sts != 0)
			{
				QMessageBox::warning(this,
									 tr("ScanTWAIN Error"),
									 QString(tr("Failed to decompress image data. Image cannot be displayed: %1")).arg(iG4sts),
									 QMessageBox::Ok,
									 QMessageBox::NoButton
									);
				FREE(pucCompressed);
				FREE(pucUncompressed);
				ViewNone();
				return;
			}

			// Create the Image
			if(!imImage.create(a_twimageinfo.ImageWidth, a_twimageinfo.ImageLength, 1, 2, QImage::BigEndian))
			{
				QMessageBox::warning(this,
									 tr("ScanTWAIN Error"),
									 tr("Out of memory! Image cannot be displayed."),
									 QMessageBox::Ok,
									 QMessageBox::NoButton
									);

				FREE(pucCompressed);
				FREE(pucUncompressed);
				ViewNone();
				return;
			}

			// In order to save and display correctly the QImage needs a color
			// map. Here we map a 0 bit to black and a 1 bit to white.
			imImage.setColor(0, qRgb(0,0,0));
			imImage.setColor(1, qRgb(255,255,255));

			// Copy the data one row at a time to avoid possible alignment issues
			for(int ii = 0; ii < a_twimageinfo.ImageLength; ii++)
			{
				// Get the scanline and copy the data
				pbBits = imImage.scanLine(ii);
				memcpy(pbBits, pucUncompressed + (iWidthBytes * ii), iWidthBytes);
			}

			// free the uncompressed image
			FREE(pucCompressed);
			FREE(pucUncompressed);

			// DONE!
			break;

		case TWCP_NONE:

			// We have an uncompressed image...
			// To simplify display we want to create a QImage from the data and
			// the TW_IMAGEINFO structure.
			switch(a_twimageinfo.BitsPerPixel)
			{
				default:
					// An unrecognized bit depth was encountered, processing fails.
					QMessageBox::warning(this,
										 tr("ScanTWAIN Error"),
										 tr("Unrecognized bit depth. Image cannot be displayed."),
										 QMessageBox::Ok,
										 QMessageBox::NoButton
										);
					ViewNone();
					return;

				case 1:		// Bitonal Image
			
					// Create the Image
					if(!imImage.create(a_twimageinfo.ImageWidth, a_twimageinfo.ImageLength, 1, 2, QImage::BigEndian))
					{
						QMessageBox::warning(this,
											 tr("ScanTWAIN Error"),
											 tr("Out of memory! Image cannot be displayed."),
											 QMessageBox::Ok,
											 QMessageBox::NoButton
											);
						ViewNone();
						return;
					}

					// In order to save and display correctly the QImage needs a color
					// map. Here we map a 0 bit to black and a 1 bit to white.
					imImage.setColor(0, qRgb(0,0,0));
					imImage.setColor(1, qRgb(255,255,255));

					// Determine the width of a scanline in bytes
					if (a_twimageinfo.ImageWidth % 8)
					{
						iWidthBytes = a_twimageinfo.ImageWidth / 8 + 1;
					}
					else
					{
						iWidthBytes = a_twimageinfo.ImageWidth / 8;
					}

					// Copy the data one row at a time to avoid possible alignment issues
					for(int ii = 0; ii < a_twimageinfo.ImageLength; ii++)
					{
						// Get the scanline and copy the data
						pbBits = imImage.scanLine(ii);
						memcpy(pbBits, a_pbImage + (iWidthBytes * ii), iWidthBytes);
					}
					break;

				case 8:		// 8-bit Grayscale

					// Create the Image
					if(!imImage.create(a_twimageinfo.ImageWidth, a_twimageinfo.ImageLength,8,256))
					{
						QMessageBox::warning(this,
											 tr("ScanTWAIN Error"),
											 tr("Out of memory! Image cannot be displayed."),
											 QMessageBox::Ok,
											 QMessageBox::NoButton
											);
						ViewNone();
						return;
					}

					// In order to save and display correctly the QImage needs a color
					// map. We create a color map with 256 entries which are all grays.
					for(int ii = 0; ii < 256; ii++)
					{
						imImage.setColor(ii, qRgb(ii, ii, ii));
					}
			
					// Copy the data one row at a time to avoid possible alignment issues
					for(int ii = 0; ii < a_twimageinfo.ImageLength; ii++)
					{
						pbBits = imImage.scanLine(ii);
						memcpy
						(
							pbBits, 
							a_pbImage + (a_twimageinfo.ImageWidth * ii),
							a_twimageinfo.ImageWidth
						);
					}
					break;

				case 24: // 24-bit Color

					// Create the Image
					if(!imImage.create(a_twimageinfo.ImageWidth, a_twimageinfo.ImageLength,32))
					{
						QMessageBox::warning(this,
											 tr("ScanTWAIN Error"),
											 tr("Out of memory! Image cannot be saved or displayed."),
											 QMessageBox::Ok,
											 QMessageBox::NoButton
											);
						ViewNone();
						return;
					}

					// Get the pointer the QImage's pixels
					pwBits = reinterpret_cast<uint*>(imImage.bits());

					// QImage doesn't support 24-bit images so doing a memcpy to get
					// our image into it won't work. We have to loop over every pixel
					// in our image and place it into the QImage using qRgb to make
					// our data 32-bit aligned.
					for(uint ii=0; ii < a_ulBytes; ii+=3)
					{
						pwBits[ii/3] = qRgb(a_pbImage[ii],a_pbImage[ii+1],a_pbImage[ii+2]);
					} // end for(unsigned int ii=0 ...
				break;
			} // end switch(a_imageinfo.BitsPerPixel)

		break;
	} // end switch (a_twimageinfo.Compression)

	// We want to reduce the image resolution to around 100dpi, so calculate
	// the reduction factor by dividing the current resolution / 100
	if (Fix32ToFloat(a_twimageinfo.XResolution) > 100)
	{
		uiXReduction = (uint)(Fix32ToFloat(a_twimageinfo.XResolution)/100.0);
	}
	else
	{
		uiXReduction = 1;
	}
	if (Fix32ToFloat(a_twimageinfo.YResolution) > 100)
	{
		uiYReduction = (uint)(Fix32ToFloat(a_twimageinfo.YResolution)/100.0);
	}
	else
	{
		uiYReduction = 1;
	}

	// determine which image this one is and set the appropriate image label
	// then post a paint event to the appropriate label
	if( m_iCurrentImage == 1)
	{
		// we're on the first image so set the first image label
		m_ilblImage1->setImage(imImage,uiXReduction);

		pevPaint = new QPaintEvent(m_ilblImage1->rect());
		QApplication::postEvent(m_ilblImage1, pevPaint);

		// signal the next image to go to the second image label
		m_iCurrentImage = 2;
	}
	else
	{
		// we're on the second image so set the second image label
		m_ilblImage2->setImage(imImage,uiXReduction);

		pevPaint = new QPaintEvent(m_ilblImage2->rect());
		QApplication::postEvent(m_ilblImage2, pevPaint);

		// signal the next image to go to the first image label
		m_iCurrentImage = 1;
	}

	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Handles custom events posted to the main window. Specifically,
//		an image transfer event or a signal that the scan thread has
//		stopped.
//
//	Parameters:
//		a_evCustom	- The event to process
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTMainWindow::customEvent(QCustomEvent *a_evCustom)
{
	QString *strErr;

	
	// here is where we handle custom events that are posted to the main thread
	switch(a_evCustom->type())
	{
		default:
			QMessageBox::information(this,
									 tr("ScanTWAIN Error"),
									 tr("Unhandled Custom Event In Event Queue"),
									 QMessageBox::Ok
									);
			break;

		case STSCANISDONE:
			m_savethread.StopThread();
			break;

		case STSAVEISDONE:
			// This event can be set whenever the save thread is waiting
			// so we'll only update the UI if we're done scanning
			UpdateUI(UISTATE_SCANNERSELECTED);
			break;

		case STSTARTXFER:
			// This even is generated when TWAIN has an image ready for us so
			// this even is our cue to start the scan thread
			m_scanthread.start();

			// Start the save thread, too
			m_savethread.start();
			break;

		case STDISABLEDS:
			// This event is sent by the TWAINCallback to let us know to
			// send a disable ds
			m_sttwainCtrl.Disable();
			UpdateUI(UISTATE_DRIVERUICLOSED);
			break;

		case STIMAGEXFER:
		{
			CSTImgXferEvent	*stimgxfer =
					reinterpret_cast<CSTImgXferEvent*>(a_evCustom);

			// Display the image
			ShowImage(stimgxfer->Image(),
					  stimgxfer->ImageSizeInBytes(),
					  stimgxfer->ImageInfo());

			// PR 117??: We now need a separate thread to save the images, just
			// just to improve performance (although it may dramatically increase
			// memory comsumption.
			m_savethread.QueueImage(stimgxfer);

			break;
		}

		case STIMAGESAVED:

			// PR 11740: Let the scan thread know that we're done processing
			// an image so it can keep track of how many are in our buffer
			m_scanthread.NotifyImageProcessed();
			break;

		// The next 2 cases both have a QString pointer that contains the error
		// message. This QString was allocated by the class that sent the event
		// but MUST be freed here.
		case STIMAGEXFERFAIL:
		case STIMAGESAVEFAIL:
			
			// If this happens, we're done scanning/saving
			m_scanthread.AbortThread();
			m_savethread.AbortThread();
			
			// Fall through...
			strErr =
					reinterpret_cast<QString*>(a_evCustom->data());
			
			QMessageBox::critical(this,
								  tr("ScanTWAIN Error"),
								  *strErr,
								  QMessageBox::Ok,
								  QMessageBox::NoButton
								 );
			
			// THE STRING MUST BE FREED HERE
			delete strErr;

			// Update the UI on the failure (since scanning will have stopped)
			UpdateUI(UISTATE_SCANNERSELECTED);

			break;

	} // end switch(a_evCustom->type())
	
	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Determine the pixel type and the user selected format and make
//		sure it's compatible with the driver's current compression setting
//
//	Parameters:
//		none
//
//	Returns:
//		true if the file format is compatible with ICAP_COMPRESSION
////////////////////////////////////////////////////////////////////////
bool CSTMainWindow::VerifyFileFormat(void)
{
	// If we're in auto mode, then we're always ok
	if (m_stfileformatsettings.blAutoFromDriver) { return (true); }

	// If the DS is not open, we're always ok
	if (!m_bDSOpened) { return (true); }

	// Get the pixel type from the driver and validate it with the user
	// selected file type and compression
	switch (m_sttwainCtrl.GetPixelType())
	{
		default:
			QMessageBox::critical
			(
				this,
				tr("ScanTWAIN Error"),
				tr("Unrecognized pixel type"),
				QMessageBox::Ok,
				QMessageBox::NoButton
			);
			return (false);

		case TWPT_BW:
			
			return (VerifyFileFormatByCompression(m_stfileformatsettings.uiBitonalFileFormat,
			                                      m_stfileformatsettings.uiBitonalTIFFCodec));

		case TWPT_GRAY:
		
			return (VerifyFileFormatByCompression(m_stfileformatsettings.uiGrayFileFormat,
			                                      m_stfileformatsettings.uiGrayTIFFCodec));

		case TWPT_RGB:

			return (VerifyFileFormatByCompression(m_stfileformatsettings.uiColorFileFormat,
			                                      m_stfileformatsettings.uiColorTIFFCodec));

	} // end (m_sttwainCtrl.GetPixelType())

	return (true);
}



////////////////////////////////////////////////////////////////////////
// Description:
//		If a scanner is connected get the ICAP_COMPRESSION setting and
//		verify that the selected file format is compatible with it.
//
//		The rules are as follows:
//			1. PNG files only work with uncompressed data (TWCP_NONE)
//			2. JPEG files work with uncompressed and JPEG data (TWCP_JPEG)
//			3. TIFF files work with everything except JPEG data
//
//	Parameters:
//		a_iFileFormat	- The file format to check
//      a_iCompression  - The TIFF compression selected for this format
//
//	Returns:
//		true if the file format is compatible with ICAP_COMPRESSION
////////////////////////////////////////////////////////////////////////
bool CSTMainWindow::VerifyFileFormatByCompression(int a_iFileFormat, int a_iCompression)
{
	TW_UINT16	uiResult;
	TW_UINT16	uiValue;
	char		szMessage[256];

	// Get the driver's setting
	uiResult = m_sttwainCtrl.GetOneValue(ICAP_COMPRESSION,(TW_MEMREF)&uiValue);
	if ( uiResult != TWRC_SUCCESS )
	{
		m_sttwainCtrl.GetErrorString(szMessage,sizeof(szMessage));
		QMessageBox::critical
		(
			this,
			tr("ScanTWAIN Error"),
			tr("Failed to get ICAP_COMPRESSION: ") + szMessage,
			QMessageBox::Ok,
			QMessageBox::NoButton
		);
		return (false);
	}

	// Validate the file format...
	// If the user choose PNG, the image must be uncompressed
	// If we want to save a JPEG then the compression must be JPEG or NONE
	// If we want to save a TIFF then the compression cannot be JPEG and the
	// selcted TIFF compression must be the same as the drivers
	switch (a_iFileFormat)
	{
		default:
			QMessageBox::critical
			(
				this,
				tr("ScanTWAIN Error"),
				tr("Unrecognized file format"),
				QMessageBox::Ok,
				QMessageBox::NoButton
			);
			return (false);

		case IDX_PNGFILE:

			if (uiValue != TWCP_NONE)
			{
				QMessageBox::warning
				(
					parentWidget(true),
					tr("ScanTWAIN Error"),
					tr("ICAP_COMPRESSION setting is incompatible with a PNG file"),
					QMessageBox::Ok,
					QMessageBox::NoButton
				);
				return (false);
			}
			break;

		case IDX_JPEGFILE:

			if ((uiValue == TWCP_JPEG) || (uiValue == TWCP_NONE))
			{
				// we're ok
				return (true);
			}
			QMessageBox::warning
			(
				parentWidget(true),
				tr("ScanTWAIN Error"),
				tr("ICAP_COMPRESSION setting is incompatible with a JPEG file"),
				QMessageBox::Ok,
				QMessageBox::NoButton
			);
			return (false);

		case IDX_TIFFFILE:
            
			// Compression cannot be JPEG
			if (uiValue == TWCP_JPEG)
			{
				QMessageBox::warning
				(
					parentWidget(true),
					tr("ScanTWAIN Error"),
					tr("ICAP_COMPRESSION/TWCP_JPEG is not supported with TIFF files"),
					QMessageBox::Ok,
					QMessageBox::NoButton
				);
				return (false);
			}
			
			// User selected compression must be the same as the drivers
            bool blIsCompressionEqual = true;
			switch(uiValue)
			{
			    default:
			        // The driver's compression is something other than GROUP3,
			        // GROUP4 or NONE, so there's no way the settings the same
			        blIsCompressionEqual = false;
			        
			    case TWCP_GROUP31D:
                case TWCP_GROUP31DEOL:
                case TWCP_GROUP32D:
                    if (a_iCompression != IDX_CCITT3) { blIsCompressionEqual = false; }
                    break;
                    
                case TWCP_GROUP4:
                    if (a_iCompression != IDX_CCITT4) { blIsCompressionEqual = false; }
                    break;
                    
                case TWCP_NONE:
                    blIsCompressionEqual = true;
                    break;
            }
            
            if (!blIsCompressionEqual)
            {
				QMessageBox::warning
				(
					parentWidget(true),
					tr("ScanTWAIN Error"),
					tr("ICAP_COMPRESSION is not the same as the selected TIFF compression"),
					QMessageBox::Ok,
					QMessageBox::NoButton
				);
				return (false);
            }            
            
			break;
	} // end switch (a_iFileFormat)

	return (true);
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Opens the file format settings dialog so the user can select
//		the file format to save images in
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTMainWindow::FileFormat()
{
	CSTFileFormatDialog* dlg = new CSTFileFormatDialog(this, "fileformatdialog", true, Qt::WStyle_Customize | Qt::WStyle_Dialog | Qt::WStyle_Title);

	dlg->SetFileFormatSettings(m_stfileformatsettings);
	if (dlg->exec() == QDialog::Accepted)
	{
		m_stfileformatsettings = dlg->GetFileFormatSettings();
	}

	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Use QLocale to determine the system language and country and
//		set the twain language and twain country accordingly.
//
//	Parameters:
//		a_uiTwainCountry	- TWAIN country TWCY_*
//		a_uiTwainLanguage	- TWAIN language TWLG_*
//
//	Returns:
//		none
////////////////////////////////////////////////////////////////////////
void CSTMainWindow::GetTwainCountry(TW_UINT16 *a_uiTwainCountry, TW_UINT16 *a_uiTwainLanguage)
{
	QLocale qlocale = QLocale::system();

	// Get the twain country
	switch (qlocale.country())
	{
		default:
			*a_uiTwainCountry = TWCY_USA;	// Default to USA
			break;
		case QLocale::Afghanistan:
			*a_uiTwainCountry = TWCY_AFGHANISTAN;
			break;
		case QLocale::Algeria:
			*a_uiTwainCountry = TWCY_ALGERIA;
			break;
		case QLocale::AmericanSamoa:
			*a_uiTwainCountry = TWCY_AMERICANSAMOA;
			break;
		case QLocale::Andorra:
			*a_uiTwainCountry = TWCY_ANDORRA;
			break;
		case QLocale::Angola:
			*a_uiTwainCountry = TWCY_ANGOLA;
			break;
		case QLocale::Anguilla:
			*a_uiTwainCountry = TWCY_ANGUILLA;
			break;
		case QLocale::AntiguaAndBarbuda:
			*a_uiTwainCountry = TWCY_ANTIGUA;
			break;
		case QLocale::Argentina:
			*a_uiTwainCountry = TWCY_ARGENTINA;
			break;
		case QLocale::Aruba:
			*a_uiTwainCountry = TWCY_ARUBA;
			break;
		case QLocale::Australia:
			*a_uiTwainCountry = TWCY_AUSTRALIA;
			break;
		case QLocale::Austria:
			*a_uiTwainCountry = TWCY_AUSTRIA;
			break;
		case QLocale::Bahamas:
			*a_uiTwainCountry = TWCY_BAHAMAS;
			break;
		case QLocale::Bahrain:
			*a_uiTwainCountry = TWCY_BAHRAIN;
			break;
		case QLocale::Bangladesh:
			*a_uiTwainCountry = TWCY_BANGLADESH;
			break;
		case QLocale::Barbados:
			*a_uiTwainCountry = TWCY_BARBADOS;
			break;
		case QLocale::Belgium:
			*a_uiTwainCountry = TWCY_BELGIUM;
			break;
		case QLocale::Belize:
			*a_uiTwainCountry = TWCY_BELIZE;
			break;
		case QLocale::Benin:
			*a_uiTwainCountry = TWCY_BENIN;
			break;
		case QLocale::Bermuda:
			*a_uiTwainCountry = TWCY_BERMUDA;
			break;
		case QLocale::Bhutan:
			*a_uiTwainCountry = TWCY_BHUTAN;
			break;
		case QLocale::Bolivia:
			*a_uiTwainCountry = TWCY_BOLIVIA;
			break;
		case QLocale::Botswana:
			*a_uiTwainCountry = TWCY_BOTSWANA;
			break;
		case QLocale::UnitedKingdom:
			*a_uiTwainCountry = TWCY_BRITAIN;
			break;
		case QLocale::BritishVirginIslands:
			*a_uiTwainCountry = TWCY_BRITVIRGINIS;
			break;
		case QLocale::Brazil:
			*a_uiTwainCountry = TWCY_BRAZIL;
			break;
		case QLocale::BruneiDarussalam:
			*a_uiTwainCountry = TWCY_BRUNEI;
			break;
		case QLocale::Bulgaria:
			*a_uiTwainCountry = TWCY_BULGARIA;
			break;
		case QLocale::BurkinaFaso:
			*a_uiTwainCountry = TWCY_BURKINAFASO;
			break;
		case QLocale::Myanmar:
			*a_uiTwainCountry = TWCY_MYANMAR;
			break;
		case QLocale::Burundi:
			*a_uiTwainCountry = TWCY_BURUNDI;
			break;
		case QLocale::Cameroon:
			*a_uiTwainCountry = TWCY_CAMAROON;
			break;
		case QLocale::Canada:
			*a_uiTwainCountry = TWCY_CANADA;
			break;
		case QLocale::CapeVerde:
			*a_uiTwainCountry = TWCY_CAPEVERDEIS;
			break;
		case QLocale::CaymanIslands:
			*a_uiTwainCountry = TWCY_CAYMANIS;
			break;
		case QLocale::CentralAfricanRepublic:
			*a_uiTwainCountry = TWCY_CENTRALAFREP;
			break;
		case QLocale::Chad:
			*a_uiTwainCountry = TWCY_CHAD;
			break;
		case QLocale::Chile:
			*a_uiTwainCountry = TWCY_CHILE;
			break;
		case QLocale::China:
			*a_uiTwainCountry = TWCY_CHINA;
			break;
		case QLocale::ChristmasIsland:
			*a_uiTwainCountry = TWCY_CHRISTMASIS;
			break;
		case QLocale::CocosIslands:
			*a_uiTwainCountry = TWCY_COCOSIS;
			break;
		case QLocale::Colombia:
			*a_uiTwainCountry = TWCY_COLOMBIA;
			break;
		case QLocale::Comoros:
			*a_uiTwainCountry = TWCY_COMOROS;
			break;
		case QLocale::PeoplesRepublicOfCongo:
			*a_uiTwainCountry = TWCY_CONGO;
			break;
		case QLocale::CookIslands:
			*a_uiTwainCountry = TWCY_COOKIS;
			break;
		case QLocale::CostaRica:
			*a_uiTwainCountry = TWCY_COSTARICA;
			break;
		case QLocale::Cuba:
			*a_uiTwainCountry = TWCY_CUBA;
			break;
		case QLocale::Cyprus:
			*a_uiTwainCountry = TWCY_CYPRUS;
			break;
		case QLocale::CzechRepublic:
			*a_uiTwainCountry = TWCY_CZECHREPUBLIC;
			break;
		case QLocale::Denmark:
			*a_uiTwainCountry = TWCY_DENMARK;
			break;
		case QLocale::Djibouti:
			*a_uiTwainCountry = TWCY_DJIBOUTI;
			break;
		case QLocale::Dominica:
			*a_uiTwainCountry = TWCY_DOMINICA;
			break;
		case QLocale::DominicanRepublic:
			*a_uiTwainCountry = TWCY_DOMINCANREP;
			break;
		case QLocale::Ecuador:
			*a_uiTwainCountry = TWCY_ECUADOR;
			break;
		case QLocale::Egypt:
			*a_uiTwainCountry = TWCY_EGYPT;
			break;
		case QLocale::ElSalvador:
			*a_uiTwainCountry = TWCY_ELSALVADOR;
			break;
		case QLocale::EquatorialGuinea:
			*a_uiTwainCountry = TWCY_EQGUINEA;
			break;
		case QLocale::Ethiopia:
			*a_uiTwainCountry = TWCY_ETHIOPIA;
			break;
		case QLocale::FalklandIslands:
			*a_uiTwainCountry = TWCY_FALKLANDIS;
			break;
		case QLocale::FaroeIslands:
			*a_uiTwainCountry = TWCY_FAEROEIS;
			break;
		case QLocale::FijiCountry:
			*a_uiTwainCountry = TWCY_FIJIISLANDS;
			break;
		case QLocale::Finland:
			*a_uiTwainCountry = TWCY_FINLAND;
			break;
		case QLocale::France:
			*a_uiTwainCountry = TWCY_FRANCE;
			break;
		case QLocale::FrenchGuiana:
			*a_uiTwainCountry = TWCY_FRGUIANA;
			break;
		case QLocale::FrenchPolynesia:
			*a_uiTwainCountry = TWCY_FRPOLYNEISA;
			break;
		case QLocale::Gabon:
			*a_uiTwainCountry = TWCY_GABON;
			break;
		case QLocale::Gambia:
			*a_uiTwainCountry = TWCY_GAMBIA;
			break;
		case QLocale::Germany:
			*a_uiTwainCountry = TWCY_GERMANY;
			break;
		case QLocale::Ghana:
			*a_uiTwainCountry = TWCY_GHANA;
			break;
		case QLocale::Gibraltar:
			*a_uiTwainCountry = TWCY_GIBRALTER;
			break;
		case QLocale::Greece:
			*a_uiTwainCountry = TWCY_GREECE;
			break;
		case QLocale::Greenland:
			*a_uiTwainCountry = TWCY_GREENLAND;
			break;
		case QLocale::Grenada:
			*a_uiTwainCountry = TWCY_GRENADA;
			break;
		case QLocale::Guadeloupe:
			*a_uiTwainCountry = TWCY_GUADELOUPE;
			break;
		case QLocale::Guam:
			*a_uiTwainCountry = TWCY_GUAM;
			break;
		case QLocale::Guatemala:
			*a_uiTwainCountry = TWCY_GUATEMALA;
			break;
		case QLocale::Guinea:
			*a_uiTwainCountry = TWCY_GUINEA;
			break;
		case QLocale::GuineaBissau:
			*a_uiTwainCountry = TWCY_GUINEABISSAU;
			break;
		case QLocale::Guyana:
			*a_uiTwainCountry = TWCY_GUYANA;
			break;
		case QLocale::Haiti:
			*a_uiTwainCountry = TWCY_HAITI;
			break;
		case QLocale::Honduras:
			*a_uiTwainCountry = TWCY_HONDURAS;
			break;
		case QLocale::HongKong:
			*a_uiTwainCountry = TWCY_HONGKONG;
			break;
		case QLocale::Hungary:
			*a_uiTwainCountry = TWCY_HUNGARY;
			break;
		case QLocale::Iceland:
			*a_uiTwainCountry = TWCY_ICELAND;
			break;
		case QLocale::India:
			*a_uiTwainCountry = TWCY_INDIA;
			break;
		case QLocale::Indonesia:
			*a_uiTwainCountry = TWCY_INDONESIA;
			break;
		case QLocale::Iran:
			*a_uiTwainCountry = TWCY_IRAN;
			break;
		case QLocale::Iraq:
			*a_uiTwainCountry = TWCY_IRAQ;
			break;
		case QLocale::Ireland:
			*a_uiTwainCountry = TWCY_IRELAND;
			break;
		case QLocale::Israel:
			*a_uiTwainCountry = TWCY_ISRAEL;
			break;
		case QLocale::Italy:
			*a_uiTwainCountry = TWCY_ITALY;
			break;
		case QLocale::Jamaica:
			*a_uiTwainCountry = TWCY_JAMAICA;
			break;
		case QLocale::Japan:
			*a_uiTwainCountry = TWCY_JAPAN;
			break;
		case QLocale::Jordan:
			*a_uiTwainCountry = TWCY_JORDAN;
			break;
		case QLocale::Kenya:
			*a_uiTwainCountry = TWCY_KENYA;
			break;
		case QLocale::Kiribati:
			*a_uiTwainCountry = TWCY_KIRIBATI;
			break;
		case QLocale::Kuwait:
			*a_uiTwainCountry = TWCY_KUWAIT;
			break;
		case QLocale::Lao:
			*a_uiTwainCountry = TWCY_LAOS;
			break;
		case QLocale::Lebanon:
			*a_uiTwainCountry = TWCY_LEBANON;
			break;
		case QLocale::Liberia:
			*a_uiTwainCountry = TWCY_LIBERIA;
			break;
		case QLocale::LibyanArabJamahiriya:
			*a_uiTwainCountry = TWCY_LIBYA;
			break;
		case QLocale::Liechtenstein:
			*a_uiTwainCountry = TWCY_LIECHTENSTEIN;
			break;
		case QLocale::Luxembourg:
			*a_uiTwainCountry = TWCY_LUXENBOURG;
			break;
		case QLocale::Macau:
			*a_uiTwainCountry = TWCY_MACAO;
			break;
		case QLocale::Madagascar:
			*a_uiTwainCountry = TWCY_MADAGASCAR;
			break;
		case QLocale::Malawi:
			*a_uiTwainCountry = TWCY_MALAWI;
			break;
		case QLocale::Malaysia:
			*a_uiTwainCountry = TWCY_MALAYSIA;
			break;
		case QLocale::Maldives:
			*a_uiTwainCountry = TWCY_MALDIVES;
			break;
		case QLocale::Mali:
			*a_uiTwainCountry = TWCY_MALI;
			break;
		case QLocale::Malta:
			*a_uiTwainCountry = TWCY_MALTA;
			break;
		case QLocale::MarshallIslands:
			*a_uiTwainCountry = TWCY_MARSHALLIS;
			break;
		case QLocale::Mauritania:
			*a_uiTwainCountry = TWCY_MAURITANIA;
			break;
		case QLocale::Mauritius:
			*a_uiTwainCountry = TWCY_MAURITIUS;
			break;
		case QLocale::Mexico:
			*a_uiTwainCountry = TWCY_MEXICO;
			break;
		case QLocale::Micronesia:
			*a_uiTwainCountry = TWCY_MICRONESIA;
			break;
		case QLocale::Monaco:
			*a_uiTwainCountry = TWCY_MONACO;
			break;
		case QLocale::Mongolia:
			*a_uiTwainCountry = TWCY_MONGOLIA;
			break;
		case QLocale::Montserrat:
			*a_uiTwainCountry = TWCY_MONTSERRAT;
			break;
		case QLocale::Morocco:
			*a_uiTwainCountry = TWCY_MOROCCO;
			break;
		case QLocale::Mozambique:
			*a_uiTwainCountry = TWCY_MOZAMBIQUE;
			break;
		case QLocale::Namibia:
			*a_uiTwainCountry = TWCY_NAMIBIA;
			break;
		case QLocale::NauruCountry:
			*a_uiTwainCountry = TWCY_NAURU;
			break;
		case QLocale::Nepal:
			*a_uiTwainCountry = TWCY_NEPAL;
			break;
		case QLocale::Netherlands:
			*a_uiTwainCountry = TWCY_NETHERLANDS;
			break;
		case QLocale::NetherlandsAntilles:
			*a_uiTwainCountry = TWCY_NETHANTILLES;
			break;
		case QLocale::NewCaledonia:
			*a_uiTwainCountry = TWCY_NEWCALEDONIA;
			break;
		case QLocale::NewZealand:
			*a_uiTwainCountry = TWCY_NEWZEALAND;
			break;
		case QLocale::Nicaragua:
			*a_uiTwainCountry = TWCY_NICARAGUA;
			break;
		case QLocale::Niger:
			*a_uiTwainCountry = TWCY_NIGER;
			break;
		case QLocale::Nigeria:
			*a_uiTwainCountry = TWCY_NIGERIA;
			break;
		case QLocale::Niue:
			*a_uiTwainCountry = TWCY_NIUE;
			break;
		case QLocale::NorfolkIsland:
			*a_uiTwainCountry = TWCY_NORFOLKI;
			break;
		case QLocale::Norway:
			*a_uiTwainCountry = TWCY_NORWAY;
			break;
		case QLocale::Oman:
			*a_uiTwainCountry = TWCY_OMAN;
			break;
		case QLocale::Pakistan:
			*a_uiTwainCountry = TWCY_PAKISTAN;
			break;
		case QLocale::Palau:
			*a_uiTwainCountry = TWCY_PALAU;
			break;
		case QLocale::Panama:
			*a_uiTwainCountry = TWCY_PANAMA;
			break;
		case QLocale::Paraguay:
			*a_uiTwainCountry = TWCY_PARAGUAY;
			break;
		case QLocale::Peru:
			*a_uiTwainCountry = TWCY_PERU;
			break;
		case QLocale::Philippines:
			*a_uiTwainCountry = TWCY_PHILLIPPINES;
			break;
		case QLocale::Pitcairn:
			*a_uiTwainCountry = TWCY_PITCAIRNIS;
			break;
		case QLocale::PapuaNewGuinea:
			*a_uiTwainCountry = TWCY_PNEWGUINEA;
			break;
		case QLocale::Poland:
			*a_uiTwainCountry = TWCY_POLAND;
			break;
		case QLocale::Portugal:
			*a_uiTwainCountry = TWCY_PORTUGAL;
			break;
		case QLocale::Qatar:
			*a_uiTwainCountry = TWCY_QATAR;
			break;
		case QLocale::Reunion:
			*a_uiTwainCountry = TWCY_REUNIONI;
			break;
		case QLocale::Romania:
			*a_uiTwainCountry = TWCY_ROMANIA;
			break;
		case QLocale::RussianFederation:
			*a_uiTwainCountry = TWCY_RUSSIA;
			break;
		case QLocale::Rwanda:
			*a_uiTwainCountry = TWCY_RWANDA;
			break;
		case QLocale::SanMarino:
			*a_uiTwainCountry = TWCY_SANMARINO;
			break;
		case QLocale::SaoTomeAndPrincipe:
			*a_uiTwainCountry = TWCY_SAOTOME;
			break;
		case QLocale::SaudiArabia:
			*a_uiTwainCountry = TWCY_SAUDIARABIA;
			break;
		case QLocale::Senegal:
			*a_uiTwainCountry = TWCY_SENEGAL;
			break;
		case QLocale::Seychelles:
			*a_uiTwainCountry = TWCY_SEYCHELLESIS;
			break;
		case QLocale::SierraLeone:
			*a_uiTwainCountry = TWCY_SIERRALEONE;
			break;
		case QLocale::Singapore:
			*a_uiTwainCountry = TWCY_SINGAPORE;
			break;
		case QLocale::SolomonIslands:
			*a_uiTwainCountry = TWCY_SOLOMONIS;
			break;
		case QLocale::Somalia:
			*a_uiTwainCountry = TWCY_SOMALI;
			break;
		case QLocale::SouthAfrica:
			*a_uiTwainCountry = TWCY_SOUTHAFRICA;
			break;
		case QLocale::Spain:
			*a_uiTwainCountry = TWCY_SPAIN;
			break;
		case QLocale::SriLanka:
			*a_uiTwainCountry = TWCY_SRILANKA;
			break;
		case QLocale::StHelena:
			*a_uiTwainCountry = TWCY_STHELENA;
			break;
		case QLocale::StPierreAndMiquelon:
			*a_uiTwainCountry = TWCY_MIQUELON;
			break;
		case QLocale::SaintKittsAndNevis:
			*a_uiTwainCountry = TWCY_STKITTS;
			break;
		case QLocale::StLucia:
			*a_uiTwainCountry = TWCY_STLUCIA;
			break;
		case QLocale::StVincentAndTheGrenadines:
			*a_uiTwainCountry = TWCY_STVINCENT;
			break;
		case QLocale::Sudan:
			*a_uiTwainCountry = TWCY_SUDAN;
			break;
		case QLocale::Suriname:
			*a_uiTwainCountry = TWCY_SURINAME;
			break;
		case QLocale::Swaziland:
			*a_uiTwainCountry = TWCY_SWAZILAND;
			break;
		case QLocale::Sweden:
			*a_uiTwainCountry = TWCY_SWEDEN;
			break;
		case QLocale::Switzerland:
			*a_uiTwainCountry = TWCY_SWITZERLAND;
			break;
		case QLocale::SyrianArabRepublic:
			*a_uiTwainCountry = TWCY_SYRIA;
			break;
		case QLocale::Taiwan:
			*a_uiTwainCountry = TWCY_TAIWAN;
			break;
		case QLocale::Tanzania:
			*a_uiTwainCountry = TWCY_TANZANIA;
			break;
		case QLocale::Thailand:
			*a_uiTwainCountry = TWCY_THAILAND;
			break;
		case QLocale::TrinidadAndTobago:
			*a_uiTwainCountry = TWCY_TOBAGO;
			break;
		case QLocale::Togo:
			*a_uiTwainCountry = TWCY_TOGO;
			break;
		case QLocale::TongaCountry:
			*a_uiTwainCountry = TWCY_TONGAIS;
			break;
		case QLocale::Tunisia:
			*a_uiTwainCountry = TWCY_TUNISIA;
			break;
		case QLocale::Turkey:
			*a_uiTwainCountry = TWCY_TURKEY;
			break;
		case QLocale::TurksAndCaicosIslands:
			*a_uiTwainCountry = TWCY_TURKSCAICOS;
			break;
		case QLocale::Tuvalu:
			*a_uiTwainCountry = TWCY_TUVALU;
			break;
		case QLocale::Uganda:
			*a_uiTwainCountry = TWCY_UGANDA;
			break;
		case QLocale::UnitedArabEmirates:
			*a_uiTwainCountry = TWCY_UAEMIRATES;
			break;
		case QLocale::UnitedStates:
			*a_uiTwainCountry = TWCY_USA;
			break;
		case QLocale::Uruguay:
			*a_uiTwainCountry = TWCY_URUGUAY;
			break;
		case QLocale::Vanuatu:
			*a_uiTwainCountry = TWCY_VANUATU;
			break;
		case QLocale::VaticanCityState:
			*a_uiTwainCountry = TWCY_VATICANCITY;
			break;
		case QLocale::Venezuela:
			*a_uiTwainCountry = TWCY_VENEZUELA;
			break;
		case QLocale::WallisAndFutunaIslands:
			*a_uiTwainCountry = TWCY_WALLISIS;
			break;
		case QLocale::WesternSahara:
			*a_uiTwainCountry = TWCY_WESTERNSAHARA;
			break;
		case QLocale::Yemen:
			*a_uiTwainCountry = TWCY_YEMEN;
			break;
		case QLocale::Zambia:
			*a_uiTwainCountry = TWCY_ZAMBIA;
			break;
		case QLocale::Zimbabwe:
			*a_uiTwainCountry = TWCY_ZIMBABWE;
			break;
		case QLocale::Armenia:
			*a_uiTwainCountry = TWCY_ARMENIA;
			break;
		case QLocale::Azerbaijan:
			*a_uiTwainCountry = TWCY_AZERBAIJAN;
			break;
		case QLocale::Belarus:
			*a_uiTwainCountry = TWCY_BELARUS;
			break;
		case QLocale::BosniaAndHerzegowina:
			*a_uiTwainCountry = TWCY_BOSNIAHERZGO;
			break;
		case QLocale::Cambodia:
			*a_uiTwainCountry = TWCY_CAMBODIA;
			break;
		case QLocale::Croatia:
			*a_uiTwainCountry = TWCY_CROATIA;
			break;
		case QLocale::Estonia:
			*a_uiTwainCountry = TWCY_ESTONIA;
			break;
		case QLocale::Georgia:
			*a_uiTwainCountry = TWCY_GEORGIA;
			break;
		case QLocale::Latvia:
			*a_uiTwainCountry = TWCY_LATVIA;
			break;
		case QLocale::Lesotho:
			*a_uiTwainCountry = TWCY_LESOTHO;
			break;
		case QLocale::Lithuania:
			*a_uiTwainCountry = TWCY_LITHUANIA;
			break;
		case QLocale::Macedonia:
			*a_uiTwainCountry = TWCY_MACEDONIA;
			break;
		case QLocale::Mayotte:
			*a_uiTwainCountry = TWCY_MAYOTTEIS;
			break;
		case QLocale::Moldova:
			*a_uiTwainCountry = TWCY_MOLDOVA;
			break;
		case QLocale::DemocraticRepublicOfKorea:
			*a_uiTwainCountry = TWCY_NORTHKOREA;
			break;
		case QLocale::RepublicOfKorea:
			*a_uiTwainCountry = TWCY_SOUTHKOREA;
			break;
		case QLocale::PuertoRico:
			*a_uiTwainCountry = TWCY_PUERTORICO;
			break;
		case QLocale::Yugoslavia:
			*a_uiTwainCountry = TWCY_SERBIA;
			break;
		case QLocale::Slovakia:
			*a_uiTwainCountry = TWCY_SLOVAKIA;
			break;
		case QLocale::Slovenia:
			*a_uiTwainCountry = TWCY_SLOVENIA;
			break;
		case QLocale::Ukraine:
			*a_uiTwainCountry = TWCY_UKRAINE;
			break;
		case QLocale::USVirginIslands:
			*a_uiTwainCountry = TWCY_USVIRGINIS;
			break;
		case QLocale::VietNam:
			*a_uiTwainCountry = TWCY_VIETNAM;
			break;
	}

	switch (qlocale.language()) 
	{
		default:
			*a_uiTwainLanguage = TWLG_ENGLISH;
			break;
		case QLocale::Danish:
			*a_uiTwainLanguage = TWLG_DAN;
			break;
		case QLocale::Dutch:
			*a_uiTwainLanguage = TWLG_DUT;
			break;
		case QLocale::English:
			*a_uiTwainLanguage = TWLG_ENG;
			break;
		case QLocale::Finnish:
			*a_uiTwainLanguage = TWLG_FIN;
			break;
		case QLocale::French:
			*a_uiTwainLanguage = TWLG_FRN;
			break;
		case QLocale::German:
			*a_uiTwainLanguage = TWLG_GER;
			break;
		case QLocale::Icelandic:
			*a_uiTwainLanguage = TWLG_ICE;
			break;
		case QLocale::Italian:
			*a_uiTwainLanguage = TWLG_ITN;
			break;
		case QLocale::Norwegian:
			*a_uiTwainLanguage = TWLG_NOR;
			break;
		case QLocale::Portuguese:
            if (qlocale.country() == QLocale::Brazil) 
            {
                *a_uiTwainLanguage = TWLG_PORTUGUESE_BRAZIL;
            } 
            else 
            {
                *a_uiTwainLanguage = TWLG_POR;
            }
			break;
		case QLocale::Spanish:
			*a_uiTwainLanguage = TWLG_SPA;
			break;
		case QLocale::Swedish:
			*a_uiTwainLanguage = TWLG_SWE;
			break;
		case QLocale::C:
			*a_uiTwainLanguage = TWLG_USA;
			break;
		case QLocale::Afrikaans:
			*a_uiTwainLanguage = TWLG_AFRIKAANS;
			break;
		case QLocale::Albanian:
			*a_uiTwainLanguage = TWLG_ALBANIA;
			break;
		case QLocale::Arabic:
			*a_uiTwainLanguage = TWLG_ARABIC;
			break;
		case QLocale::Basque:
			*a_uiTwainLanguage = TWLG_BASQUE;
			break;
		case QLocale::Byelorussian:
			*a_uiTwainLanguage = TWLG_BYELORUSSIAN;
			break;
		case QLocale::Bulgarian:
			*a_uiTwainLanguage = TWLG_BULGARIAN;
			break;
		case QLocale::Catalan:
			*a_uiTwainLanguage = TWLG_CATALAN;
			break;
		case QLocale::Chinese:
			*a_uiTwainLanguage = TWLG_CHINESE;
			break;
		case QLocale::Croatian:
			*a_uiTwainLanguage = TWLG_CROATIA;
			break;
		case QLocale::Czech:
			*a_uiTwainLanguage = TWLG_CZECH;
			break;
		case QLocale::Estonian:
			*a_uiTwainLanguage = TWLG_ESTONIAN;
			break;
		case QLocale::Faroese:
			*a_uiTwainLanguage = TWLG_FAEROESE;
			break;
		case QLocale::Persian:
			*a_uiTwainLanguage = TWLG_FARSI;
			break;
		case QLocale::Greek:
			*a_uiTwainLanguage = TWLG_GREEK;
			break;
		case QLocale::Hebrew:
			*a_uiTwainLanguage = TWLG_HEBREW;
			break;
		case QLocale::Hungarian:
			*a_uiTwainLanguage = TWLG_HUNGARIAN;
			break;
		case QLocale::Indonesian:
			*a_uiTwainLanguage = TWLG_INDONESIAN;
			break;
		case QLocale::Japanese:
			*a_uiTwainLanguage = TWLG_JAPANESE;
			break;
		case QLocale::Korean:
			*a_uiTwainLanguage = TWLG_KOREAN;
			break;
		case QLocale::Latvian:
			*a_uiTwainLanguage = TWLG_LATVIAN;
			break;
		case QLocale::Lithuanian:
			*a_uiTwainLanguage = TWLG_LITHUANIAN;
			break;
		case QLocale::Polish:
			*a_uiTwainLanguage = TWLG_POLISH;
			break;
		case QLocale::Romanian:
			*a_uiTwainLanguage = TWLG_ROMANIAN;
			break;
		case QLocale::Russian:
			*a_uiTwainLanguage = TWLG_RUSSIAN;
			break;
		case QLocale::Serbian:
			*a_uiTwainLanguage = TWLG_SERBIAN_CYRILLIC;
			break;
		case QLocale::Slovak:
			*a_uiTwainLanguage = TWLG_SLOVAK;
			break;
		case QLocale::Slovenian:
			*a_uiTwainLanguage = TWLG_SLOVENIAN;
			break;
		case QLocale::Thai:
			*a_uiTwainLanguage = TWLG_THAI;
			break;
		case QLocale::Turkish:
			*a_uiTwainLanguage = TWLG_TURKISH;
			break;
		case QLocale::Ukrainian:
			*a_uiTwainLanguage = TWLG_UKRANIAN;
			break;
		case QLocale::Assamese:
			*a_uiTwainLanguage = TWLG_ASSAMESE;
			break;
		case QLocale::Bengali:
			*a_uiTwainLanguage = TWLG_BENGALI;
			break;
		case QLocale::Bihari:
			*a_uiTwainLanguage = TWLG_BIHARI;
			break;
		case QLocale::Gujarati:
			*a_uiTwainLanguage = TWLG_GUJARATI;
			break;
		case QLocale::Hindi:
			*a_uiTwainLanguage = TWLG_HINDI;
			break;
		case QLocale::Kannada:
			*a_uiTwainLanguage = TWLG_KANNADA;
			break;
		case QLocale::Kashmiri:
			*a_uiTwainLanguage = TWLG_KASHMIRI;
			break;
		case QLocale::Malayalam:
			*a_uiTwainLanguage = TWLG_MALAYALAM;
			break;
		case QLocale::Marathi:
			*a_uiTwainLanguage = TWLG_MARATHI;
			break;
		case QLocale::Oriya:
			*a_uiTwainLanguage = TWLG_ORISSI;
			break;
		case QLocale::Punjabi:
			*a_uiTwainLanguage = TWLG_PUNJABI;
			break;
		case QLocale::Pashto:
			*a_uiTwainLanguage = TWLG_PUSHTU;
			break;
		case QLocale::Tamil:
			*a_uiTwainLanguage = TWLG_TAMIL;
			break;
		case QLocale::Telugu:
			*a_uiTwainLanguage = TWLG_TELUGU;
			break;
		case QLocale::Urdu:
			*a_uiTwainLanguage = TWLG_URDU;
			break;
		case QLocale::Vietnamese:
			*a_uiTwainLanguage = TWLG_VIETNAMESE;
			break;
	}

	return;
}
