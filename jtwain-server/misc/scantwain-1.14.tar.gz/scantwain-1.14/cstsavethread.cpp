////////////////////////////////////////////////////////////////////////////////
//	File:
//		$Archive: /main/deliverables/scantwain/cstsavethread.cpp $
//
//	Description:
//		A derivation of QThread used to save images to a file
//
//	History:
//		$Log: /main/deliverables/scantwain/cstsavethread.cpp $
//		
//		9     4/16/09 9:58a V737585
//		Redesigned the file format dialog and some of the underlying structures
//		to work better with the new file format scheme. Also fixed a couple of
//		warnings compiling on Debian x64 systems.
//		
//		8     4/08/09 2:18p V737585
//		PR12757: Added a dialog to allow the user to let ScanTWAIN choose the
//		file type automatically or allow the user to select the file type based
//		on the pixel type. This allows dual-stream scanning, auto color detect
//		and toggle patch to be used while still making it easy for the user and
//		giving them the same flexibility as before if they want it.
//		
//		7     11/11/08 12:01p V737585
//		PR 12468: ScanTWAIN was not properly accounting for the padding in
//		uncompressed bitonal images.
//		
//		6     6/06/08 4:50p V737585
//		TIFFTAG_PLANARCONFIG was not being set for bitonal and grayscale scans.
//		This shouldn't be necessary, but apparently the older versions of
//		libtiff require it.
//		
//		5     5/28/08 3:31p V737585
//		Added support for the TWAIN GUI. ScanTWAIN will now try to use the
//		driver's UI before using it's own. Additionally, support for
//		transferring Group IV and JPEG compressed images has been added.
//		Additionally, the ScanSettings dialog (aka the default driver UI) has
//		been updated to add support for setting the compression.
//		
//		3     4/18/08 9:52a V737585
//		PR 11836: We were checking the stop flag where we shouldn't have been,
//		which could cause the save thread to exit before all the images are
//		saved. This would also leave them in the queue so they would come out
//		on the next scans and leave subsequent scans in the queue.
//		
//		2     3/27/08 11:45a V737585
//		PR 11753: The user was not seeing the "Out of Paper" message, as it was
//		going to the command line only. We now check for paper before beginning
//		a scan session and will report the error in a message box.
//		Additionally, scan thread and save thread errors will now all be
//		displayed in message boxes via events sent to the main ui thread. 
//		
//		1     3/26/08 1:04p V737585
//		PR 11740, 11749, 11750: THIS IS A MAJOR REVISION!! We now maintain an
//		image buffer of 10 images, we will not continue to transfer images from
//		the driver while that buffer is full. Additionally, a save thread has
//		been added to save the images in a separate thread. Several new custom
//		events have been added to assist in coordinating this. Finally, the
//		display resolution of the images has been reduced to between 75-150 dpi
//		to make the display faster. NOTE: ScanTWAIN now uses considerably more
//		memory and we may have to consider moving to memory mapped files if
//		this becomes a problem on low memory systems.
//
// Copyright (c) 2005-2008 Eastman Kodak Company
//
// This file is part of ScanTWAIN
//
// ScanTWAIN is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// ScanTWAIN is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY;  without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along
// with ScanTWAIN; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
//	$NoKeywords: $
////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////
//									INCLUDE FILES
////////////////////////////////////////////////////////////////////////////////
#include <stdlib.h>
#include <tiffio.h>
#include <png.h>

extern "C" {
	// Play tricks to avoid a conflict on the INT32 type definition
	// between libjpeg and Qt; Qt defines the type as an int whereas
	// libjpeg defines it as a long int.
	// This is safe to do because we don't use anything from the
	// libjpeg headers that relies on the INT32 definition.
	#ifndef XMD_H
	# define XMD_H
	# include <jpeglib.h>
	# undef XMD_H
	#else
	# include <jpeglib.h>
	#endif
}

#include <qapplication.h>
#include "cstsavethread.h"
#include "cstmainwindow.h"
#include "cstimgxferevent.h"
#include "csttwain.h"
#include "sttypes.h"



////////////////////////////////////////////////////////////////////////
// Description:
//		Constructor: Initializes the classes member variables
//
//	Parameters:
//		stackSize	- The size of the stack for this thread
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
CSTSaveThread::CSTSaveThread(uint stackSize) : QThread(stackSize)
{
	// Intialize some member variables
	m_bAbort = false;
	m_bStop = false;
	m_pMainWindow = NULL;
}


////////////////////////////////////////////////////////////////////////
// Description:
//		Destructor: Destroy's the thread
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
CSTSaveThread::~CSTSaveThread()
{
	m_mxMutex.lock();

	// set the abort flag
	m_bAbort = true;
	m_qwaitcondition.wakeAll();
	m_mxMutex.unlock();

	// wait for the thread to abort
	wait();
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Sets the main window pointer member
//
//	Parameters:
//		a_pWindow	- Pointer the the main window
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTSaveThread::SetMainWindow(CSTMainWindow* a_pWindow)
{
	m_mxMutex.lock();
	m_pMainWindow = a_pWindow;
	m_mxMutex.unlock();
	
	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Copies the image from the image transfer event and adds it to
//		the queue to be saved.
//
//	Parameters:
//		a_cstimgxferevent	- The image transfer event containing the image
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTSaveThread::QueueImage(CSTImgXferEvent *a_cstimgxferevent)
{
	CSTImgXferEvent	*stimgxferevent;
	QCustomEvent	*pevCustom;
	QString			*err;
	
	// Create a new image transfer event
	stimgxferevent = new CSTImgXferEvent();
	if (stimgxferevent == NULL)
	{
		// post the error event to the UI (Qt will delete the event and
		// the main window will delete the string)
		m_mxMutex.lock();
		err =  new QString("Out of Memory! Image cannot be saved.");
		pevCustom = new QCustomEvent(STIMAGESAVEFAIL);
		pevCustom->setData((void*)err);
		QApplication::postEvent(m_pMainWindow, pevCustom);
		m_mxMutex.unlock();
		
		AbortThread();
		return;
	}

	// Copy the data
	if (!stimgxferevent->CopyData(a_cstimgxferevent->Image(),
		 						  a_cstimgxferevent->ImageSizeInBytes(),
								  a_cstimgxferevent->ImageInfo()))
	{
		// post the error event to the UI (Qt will delete the event and
		// the main window will delete the string)
		m_mxMutex.lock();
		err =  new QString("Out of Memory (Copying Data)! Image cannot be saved.");
		pevCustom = new QCustomEvent(STIMAGESAVEFAIL);
		pevCustom->setData((void*)err);
		QApplication::postEvent(m_pMainWindow, pevCustom);
		m_mxMutex.unlock();

		delete stimgxferevent;
		return;
	}

	// Grab our mutex and add the image to the queue and wake up
	m_mxMutex.lock();
	m_qpqImgQueue.enqueue(stimgxferevent);
	m_qwaitcondition.wakeAll();
	m_mxMutex.unlock();

	// We don't want to delete the image xfer event we created until
	// it's saved, so we're done!
	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Stops the thread once all images in the queue have been saved
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTSaveThread::StopThread(void)
{
	// Setting this flag to true will tell the thread to stop after the currently
	// transferring image is transferred.
	m_mxMutex.lock();
	m_bStop = true;
	m_qwaitcondition.wakeAll();
	m_mxMutex.unlock();
	
	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Stops the thread immediately
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTSaveThread::AbortThread(void)
{
	// Set the abort flag to abort the thread
	m_mxMutex.lock();
	m_bAbort = true;
	
	// Wake up the thread so it will abort
	m_qwaitcondition.wakeAll();
	m_mxMutex.unlock();

	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Determine the filename to save the to and based on what image
//		format the user has choosen call the appropriate function to
//		actually save the image.
//
//	Parameters:
//		a_pbImage		- The image
//		a_twimageinfo	- The TWAIN information about the image
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTSaveThread::SaveImage(unsigned char*	a_pbImage,
							  TW_IMAGEINFO		a_twimageinfo,
							  unsigned long		a_ulImageSize
							 )
{
	QCustomEvent	*pevCustom;
	QString			*err;

	if (m_stfileformatsettings.blAutoFromDriver)
	{
		// If we're using the driver setting (aka Auto) then use the compression
		// setting from the driver to decide whether to save the image as a TIFF
		// or as a JPEG
		switch (a_twimageinfo.Compression)
		{
			default:
				m_mxMutex.lock();
				err = new QString("Unrecognized image compression");
				pevCustom = new QCustomEvent(STIMAGESAVEFAIL);
				pevCustom->setData((void*)err);
				QApplication::postEvent(m_pMainWindow, pevCustom);
				m_mxMutex.unlock();

				AbortThread();
				break;

			case TWCP_JPEG:

				SaveImageByFormat(a_pbImage, a_twimageinfo, a_ulImageSize, IDX_JPEGFILE);
				break;

			case TWCP_NONE:
			case TWCP_PACKBITS:
			case TWCP_GROUP31D:
			case TWCP_GROUP31DEOL:
			case TWCP_GROUP32D:
			case TWCP_GROUP4:
			case TWCP_LZW:

				SaveImageByFormat(a_pbImage, a_twimageinfo, a_ulImageSize, IDX_TIFFFILE);
				break;
		}

	}
	else
	{
		// The user can select different formats for different pixel types so
		// save the image to the appropriate format based on pixel type
		switch(a_twimageinfo.BitsPerPixel)
		{
			default:
				
				// post the error event to the UI (Qt will delete the event and
				// the main window will delete the string)
				m_mxMutex.lock();
				err =  new QString("Unrecognized number of bits per pixel");
				pevCustom = new QCustomEvent(STIMAGESAVEFAIL);
				pevCustom->setData((void*)err);
				QApplication::postEvent(m_pMainWindow, pevCustom);
				m_mxMutex.unlock();

				AbortThread();
				break;

			case 1:	// Bitonal
				
				SaveImageByFormat(a_pbImage, a_twimageinfo, a_ulImageSize, m_stfileformatsettings.uiBitonalFileFormat);
				break;

			case 8:
			
				SaveImageByFormat(a_pbImage, a_twimageinfo, a_ulImageSize, m_stfileformatsettings.uiGrayFileFormat);
				break;

			case 24:

				SaveImageByFormat(a_pbImage, a_twimageinfo, a_ulImageSize, m_stfileformatsettings.uiColorFileFormat);
				break;
		}
	}
}


////////////////////////////////////////////////////////////////////////
// Description:
//		Determine the filename to save the to and based on what image
//		format is specified call the appropriate function to actually save
//		the image.
//
//	Parameters:
//		a_pbImage			- The image
//		a_twimageinfo	- The TWAIN information about the image
//		a_ulImageSize	- Size of the image in bytes
//		a_efileformat	- The image format to save as
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTSaveThread::SaveImageByFormat(unsigned char* a_pbImage,
									  TW_IMAGEINFO   a_twimageinfo,
									  unsigned long  a_ulImageSize,
									  int	 		 a_iFileFormat)
{
	char			pcFileNumber[4];
	QString			qsFilename;
	static int		m_iImageCount = 0;
	QCustomEvent	*pevCustom;
	QString			*err;

	// Determine which file format to save in and then act on it
	m_iImageCount++;
	switch(a_iFileFormat)
	{
		default:
			// This should never happen, but just in case ...
			
			// post the error event to the UI (Qt will delete the event and
			// the main window will delete the string)
			m_mxMutex.lock();
			err = new QString("Unrecognized image format selected");
			pevCustom = new QCustomEvent(STIMAGESAVEFAIL);
			pevCustom->setData((void*)err);
			QApplication::postEvent(m_pMainWindow, pevCustom);
			m_mxMutex.unlock();

			AbortThread();
			break;

		case IDX_JPEGFILE:

			// Create the filename
			sprintf(pcFileNumber, "%03d", m_iImageCount);
			qsFilename = m_strFilename + "-" + pcFileNumber + ".jpg";
			
			// Save the JPEG Image
			SaveJPEGImage(a_pbImage, a_twimageinfo, qsFilename, a_ulImageSize);
			break;

		case IDX_PNGFILE:

			// Create the filename
			sprintf(pcFileNumber, "%03d", m_iImageCount);
			qsFilename = m_strFilename + "-" + pcFileNumber + ".png";
			
			SavePNGImage(a_pbImage, a_twimageinfo, qsFilename, a_ulImageSize);
			break;

		case IDX_TIFFFILE:

			// Create the filename
			sprintf(pcFileNumber, "%03d", m_iImageCount);
			qsFilename = m_strFilename + "-" + pcFileNumber + ".tiff";

			// Save the TIFF Image
			SaveTIFFImage(a_pbImage, a_twimageinfo, qsFilename, a_ulImageSize);
			break;
			
	} // end switch(m_eFileFormat)

	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Save the image with JPEG compression and a JFIF header
//
//	Parameters:
//		a_pbImage		- The image
//		a_twimageinfo	- The TWAIN information about the image
//		a_strFilename	- The name of the file to save the image too
//		a_ulImageSize	- Size of the image data in bytes
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTSaveThread::SaveJPEGImage(unsigned char*	a_pbImage,
								  TW_IMAGEINFO		a_twimageinfo,
								  QString 			a_strFilename,
								  unsigned long		a_ulImageSize
								 )
{
	jpeg_compress_struct	cinfo;			// Holds JPEG compression info
	jpeg_error_mgr 			jerr;			// Used to report compression errors
	FILE*					jpegFile;		// Pointer to the JPEG file to write
	unsigned char*			pbGrayImage;	// Grayscale image made from a bitonal one
	JSAMPROW				*row_pointers;	// Pointers to the image's scanlines
	int						i, j, ii;
	QString					*err;
	QCustomEvent			*pevCustom;
	size_t					sizetWritten;	// Number of bytes written to the file
	size_t					sizetLineWidth;	// Width of a scanline in bytes
	unsigned char			*pbRowStart;	// Pointer to the start of a scanline
	unsigned char			*pbGrayRowStart;// Pointer to the start of the grayscale scanline

	// Check the image's compression, if it's already JPEG compressed, all we
	// have to do is write the data to a file
	if (a_twimageinfo.Compression == TWCP_JPEG)
	{
		// open a file and write the data
		jpegFile = fopen(a_strFilename.utf8().data(), "wb");
		if (jpegFile)
		{
			sizetWritten = fwrite(a_pbImage,sizeof(unsigned char),a_ulImageSize, jpegFile);
			if (sizetWritten == a_ulImageSize)
			{
				// SUCCESS! Close the file and leave this function
				fclose(jpegFile);
				return;
			}
		}

		// If we didn't return above then there was an error, so report it
		// post the error event to the UI (Qt will delete the event and
		// the main window will delete the string)
		m_mxMutex.lock();
		err =  new QString("Error creating file. Image cannot be saved.");
		pevCustom = new QCustomEvent(STIMAGESAVEFAIL);
		pevCustom->setData((void*)err);
		QApplication::postEvent(m_pMainWindow, pevCustom);
		m_mxMutex.unlock();
		
		AbortThread();
	}

	// This function can only handle saving uncompressed data (we don't want
	// to get into decompresses, etc). This case should never happen (there's
	// protection in the StartScanning code), but just in case...
	if (a_twimageinfo.Compression != TWCP_NONE)
	{
		// Something bad happened, report it
		m_mxMutex.lock();
		err =  new QString("Cannot save JPEG (Incompatible Compression). Image cannot be saved.");
		pevCustom = new QCustomEvent(STIMAGESAVEFAIL);
		pevCustom->setData((void*)err);
		QApplication::postEvent(m_pMainWindow, pevCustom);
		m_mxMutex.unlock();
		
		AbortThread();
	}

	// Allocate memory for our scanline pointers
	row_pointers = (JSAMPROW*)malloc(sizeof(JSAMPROW)*a_twimageinfo.ImageLength);
	if (row_pointers == NULL)
	{
		// post the error event to the UI (Qt will delete the event and
		// the main window will delete the string)
		m_mxMutex.lock();
		err =  new QString("Out of Memory! Image cannot be saved.");
		pevCustom = new QCustomEvent(STIMAGESAVEFAIL);
		pevCustom->setData((void*)err);
		QApplication::postEvent(m_pMainWindow, pevCustom);
		m_mxMutex.unlock();

		AbortThread();
		return;
	}

	// Assign the error structure to the info structure
	cinfo.err = jpeg_std_error(&jerr);

	// Allocate memory for the compression info structure
	jpeg_create_compress(&cinfo);

	// Open the output file
	jpegFile = fopen(a_strFilename.utf8().data(), "wb");

	if(jpegFile)
	{
		// Set the output file pointer
		jpeg_stdio_dest(&cinfo, jpegFile);

		// Set up the basic image info
		cinfo.image_width = a_twimageinfo.ImageWidth;
		cinfo.image_height = a_twimageinfo.ImageLength;

		// Now all of the remaining flags and actually saving the image depends
		// on the bit depth of the image
		switch(a_twimageinfo.BitsPerPixel)
		{
			default:
				AbortThread();
				jpeg_destroy_compress(&cinfo);
				fclose(jpegFile);
				remove(a_strFilename.utf8().data());
				break;

			case 1:
				// JPEG compression does not allow bitonal images, so convert
				// it to an 8bpp bitonal (8bpp either 0 or 255).
				pbGrayImage = new unsigned char[a_twimageinfo.ImageWidth * a_twimageinfo.ImageLength];
				if (pbGrayImage == (unsigned char*)NULL)
				{
					//m_scanthread.AbortThread();
					//m_bSaveImages = false;
					jpeg_destroy_compress(&cinfo);
					fclose(jpegFile);
					remove(a_strFilename.utf8().data());
					break;
				}

				// Determine the width of a scanline in bytes
				if (a_twimageinfo.ImageWidth % 8)
				{
					sizetLineWidth = a_twimageinfo.ImageWidth / 8 + 1;
				}
				else
				{
					sizetLineWidth = a_twimageinfo.ImageWidth / 8;
				}

				// Now actually convert the image, line-by-line
				i = 0;
				while (i < a_twimageinfo.ImageLength)
				{
					pbRowStart = a_pbImage + (sizetLineWidth * i);
					pbGrayRowStart = pbGrayImage + (a_twimageinfo.ImageWidth *i);
		
					j = 0;
					while (j < a_twimageinfo.ImageWidth)
					{					
						pbGrayRowStart[j] = (pbRowStart[j/8] & (0x80>>(j%8))) ? 255 : 0;
						j++;
					}
					i++;					
				}
		
				// Setup the structure elements
				cinfo.input_components = 1;
				cinfo.in_color_space = JCS_GRAYSCALE;

				// Setup the compression defaults
				jpeg_set_defaults(&cinfo);
				jpeg_set_quality(&cinfo, m_stfileformatsettings.iGrayJPEGQuality, false);

				// Set the image resolution
				cinfo.density_unit = 1;	// dots/inch
				cinfo.X_density = (UINT16)Fix32ToFloat(a_twimageinfo.XResolution);
				cinfo.Y_density = (UINT16)Fix32ToFloat(a_twimageinfo.YResolution);
				
				// Get ready to start the compression
				jpeg_start_compress(&cinfo, true);

				// Setup the scanline pointers
				for (ii = 0; ii < a_twimageinfo.ImageLength; ii++)
				{
					row_pointers[ii] = (JSAMPLE*)&pbGrayImage[ii*a_twimageinfo.ImageWidth];
				}
				jpeg_write_scanlines(&cinfo, row_pointers, a_twimageinfo.ImageLength);

				// Finish up
				jpeg_finish_compress(&cinfo);
				jpeg_destroy_compress(&cinfo);
				fclose(jpegFile);
				delete pbGrayImage;
				
				break;
				
			case 8:
				
				// Setup the structure elements
				cinfo.input_components = 1;
				cinfo.in_color_space = JCS_GRAYSCALE;

				// Setup the compression defaults
				jpeg_set_defaults(&cinfo);
				jpeg_set_quality(&cinfo, m_stfileformatsettings.iGrayJPEGQuality, false);

				// Set the image resolution
				cinfo.density_unit = 1;	// dots/inch
				cinfo.X_density = (UINT16)Fix32ToFloat(a_twimageinfo.XResolution);
				cinfo.Y_density = (UINT16)Fix32ToFloat(a_twimageinfo.YResolution);
				
				// Get ready to start the compression
				jpeg_start_compress(&cinfo, true);

				for (ii = 0; ii < a_twimageinfo.ImageLength; ii++)
				{
					row_pointers[ii] = (JSAMPLE*)&a_pbImage[ii*cinfo.image_width];
				}
				jpeg_write_scanlines(&cinfo, row_pointers, a_twimageinfo.ImageLength);
				
				// Finish up
				jpeg_finish_compress(&cinfo);
				jpeg_destroy_compress(&cinfo);
				fclose(jpegFile);

				break;

			case 24:

				// Setup the structure elements
				cinfo.input_components = 3;
				cinfo.in_color_space = JCS_RGB;

				// Setup the compression defaults
				jpeg_set_defaults(&cinfo);
				jpeg_set_quality(&cinfo, m_stfileformatsettings.iColorJPEGQuality, false);

				// Set the image resolution
				cinfo.density_unit = 1;	// dots/inch
				cinfo.X_density = (UINT16)Fix32ToFloat(a_twimageinfo.XResolution);
				cinfo.Y_density = (UINT16)Fix32ToFloat(a_twimageinfo.YResolution);
				
				// Get ready to start the compression
				jpeg_start_compress(&cinfo, true);

				for (ii = 0; ii < a_twimageinfo.ImageLength; ii++)
				{
					row_pointers[ii] =
							(JSAMPLE*)&a_pbImage[ii*a_twimageinfo.ImageWidth*3];
				}
				jpeg_write_scanlines(&cinfo, row_pointers, a_twimageinfo.ImageLength);

				// Finish up
				jpeg_finish_compress(&cinfo);
				jpeg_destroy_compress(&cinfo);
				fclose(jpegFile);
				
				break;
		} // end switch(a_imImage.depth())

	} else {
	
		// post the error event to the UI (Qt will delete the event and
		// the main window will delete the string)
		m_mxMutex.lock();
		err =  new QString("Error creating file. Image cannot be saved.");
		pevCustom = new QCustomEvent(STIMAGESAVEFAIL);
		pevCustom->setData((void*)err);
		QApplication::postEvent(m_pMainWindow, pevCustom);
		m_mxMutex.unlock();

		AbortThread();
		jpeg_destroy_compress(&cinfo);
	
	} // end ifelse(jpegFile)

	// Free the scanline memory
	free(row_pointers);
	
	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Save the image in PNG format
//
//	Parameters:
//		a_pbImage		- The image
//		a_twimageinfo	- The TWAIN information about the image
//		a_strFilename	- The name of the file to save the image too
//		a_ulImageSize	- Size of the image data in bytes
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTSaveThread::SavePNGImage(unsigned char*	a_pbImage,
								 TW_IMAGEINFO	a_twimageinfo,
								 QString 		a_strFilename,
								 unsigned long	a_ulImageSize
								)
{
	FILE*			pngFile;		// Pointer to the PNG file to write
	png_structp		png_ptr;		// Pointer the PNG structure
	png_infop		info_ptr;		// Pointer the PNG information structure
	png_byte**		row_pointers;	// Pointer to a row of data
	QString			*err;
	QCustomEvent	*pevCustom;
	size_t			sizetLineWidth;	// Width of a scanline in bytes


	UNUSED_ARG(a_ulImageSize);
	
	// This function can only handle saving uncompressed data (we don't want
	// to get into decompresses, etc). This case should never happen (there's
	// protection in the StartScanning code), but just in case...
	if (a_twimageinfo.Compression != TWCP_NONE)
	{
		// Something bad happened, report it
		m_mxMutex.lock();
		err =  new QString("Cannot save JPEG (Incompatible Compression). Image cannot be saved.");
		pevCustom = new QCustomEvent(STIMAGESAVEFAIL);
		pevCustom->setData((void*)err);
		QApplication::postEvent(m_pMainWindow, pevCustom);
		m_mxMutex.unlock();
		
		AbortThread();
	}
	
	// Allocate memory for our scanline pointers
	row_pointers = (png_byte**)malloc(sizeof(png_byte*)*a_twimageinfo.ImageLength);
	if (row_pointers == NULL)
	{
		// post the error event to the UI (Qt will delete the event and
		// the main window will delete the string)
		m_mxMutex.lock();
		err =  new QString("Out of Memory! Image cannot be saved.");
		pevCustom = new QCustomEvent(STIMAGESAVEFAIL);
		pevCustom->setData((void*)err);
		QApplication::postEvent(m_pMainWindow, pevCustom);
		m_mxMutex.unlock();

		AbortThread();
		return;
	}
	
	// Open the output file
	pngFile = fopen(a_strFilename.utf8().data(), "wb");
	
	if(pngFile)
	{
		png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING,
										  (png_voidp) NULL,
										  NULL,
										  NULL);
		
		if(!png_ptr)
		{
			// post the error event to the UI (Qt will delete the event and
			// the main window will delete the string)
			m_mxMutex.lock();
			err =  new QString("Out of Memory (pngptr)! Image cannot be saved.");
			pevCustom = new QCustomEvent(STIMAGESAVEFAIL);
			pevCustom->setData((void*)err);
			QApplication::postEvent(m_pMainWindow, pevCustom);
			m_mxMutex.unlock();

			AbortThread();
			fclose(pngFile);
			remove(a_strFilename.utf8().data());
			free(row_pointers);
			return;
		}

		info_ptr = png_create_info_struct(png_ptr);
		if(!info_ptr)
		{
			// post the error event to the UI (Qt will delete the event and
			// the main window will delete the string)
			m_mxMutex.lock();
			err =  new QString("Out of Memory (pnginfo)! Image cannot be saved.");
			pevCustom = new QCustomEvent(STIMAGESAVEFAIL);
			pevCustom->setData((void*)err);
			QApplication::postEvent(m_pMainWindow, pevCustom);
			m_mxMutex.unlock();

			AbortThread();
			fclose(pngFile);
			remove(a_strFilename.utf8().data());
			free(row_pointers);
			return;
		}

		if(setjmp(png_jmpbuf(png_ptr)))
		{
			// post the error event to the UI (Qt will delete the event and
			// the main window will delete the string)
			m_mxMutex.lock();
			err =  new QString("Error setting png_jmpbuf! Image cannot be saved.");
			pevCustom = new QCustomEvent(STIMAGESAVEFAIL);
			pevCustom->setData((void*)err);
			QApplication::postEvent(m_pMainWindow, pevCustom);
			m_mxMutex.unlock();

			AbortThread();
			png_destroy_write_struct(&png_ptr, &info_ptr);
			fclose(pngFile);
			remove(a_strFilename.utf8().data());
			free(row_pointers);
			return;
		}

		// Finally initialize the io
		png_init_io(png_ptr, pngFile);
		
		// Now all of the remaining flags and actually saving the image depends
		// on the bit depth of the image
		switch(a_twimageinfo.BitsPerPixel)
		{
			default:

				// post the error event to the UI (Qt will delete the event and
				// the main window will delete the string)
				m_mxMutex.lock();
				err =  new QString("Unrecognized number of bits per pixel.");
				pevCustom = new QCustomEvent(STIMAGESAVEFAIL);
				pevCustom->setData((void*)err);
				QApplication::postEvent(m_pMainWindow, pevCustom);
				m_mxMutex.unlock();

				AbortThread();
				png_destroy_write_struct(&png_ptr, &info_ptr);
				fclose(pngFile);
				remove(a_strFilename.utf8().data());
				break;

			case 1:
				png_color	pngPalette[2];

				// Setup the necessary field in the png_into structure
				png_set_IHDR(png_ptr, info_ptr,
							 a_twimageinfo.ImageWidth, a_twimageinfo.ImageLength,
							 a_twimageinfo.BitsPerPixel, PNG_COLOR_TYPE_PALETTE,
							 PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_DEFAULT,
							 PNG_FILTER_TYPE_DEFAULT);
				// pixels/meter = pixels/inch * 39.37
				png_set_pHYs(png_ptr, info_ptr,
							 (uint)(Fix32ToFloat(a_twimageinfo.XResolution)*39.37),
							 (uint)(Fix32ToFloat(a_twimageinfo.YResolution)*39.37),
							 PNG_RESOLUTION_METER
							);

				pngPalette[0].red = 0;
				pngPalette[0].green = 0;
				pngPalette[0].blue = 0;
				pngPalette[1].red = 255;
				pngPalette[1].green = 255;
				pngPalette[1].blue = 255;
				png_set_PLTE(png_ptr, info_ptr, pngPalette, 2);

				// Determine the width of a scanline in bytes
				if (a_twimageinfo.ImageWidth % 8)
				{
					sizetLineWidth = a_twimageinfo.ImageWidth / 8 + 1;
				}
				else
				{
					sizetLineWidth = a_twimageinfo.ImageWidth / 8;
				}

				// Write the file header information.
				png_write_info(png_ptr, info_ptr);
				
				for(int ii = 0; ii < a_twimageinfo.ImageLength; ii++)
				{
					row_pointers[ii] = (png_byte*)&a_pbImage[ii*sizetLineWidth];
				}
				png_write_rows(png_ptr, row_pointers, a_twimageinfo.ImageLength);
				
				// Finish up
				png_write_end(png_ptr, info_ptr);
				png_destroy_write_struct(&png_ptr, &info_ptr);
				fclose(pngFile);

				break;
				
			case 8:

				// Setup the necessary field in the png_into structure
				png_set_IHDR(png_ptr, info_ptr,
							 a_twimageinfo.ImageWidth, a_twimageinfo.ImageLength,
							 a_twimageinfo.BitsPerPixel, PNG_COLOR_TYPE_GRAY,
							 PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_DEFAULT,
							 PNG_FILTER_TYPE_DEFAULT);
				// pixels/meter = pixels/inch * 39.37
				png_set_pHYs(png_ptr, info_ptr,
							 (uint)(Fix32ToFloat(a_twimageinfo.XResolution)*39.37),
							 (uint)(Fix32ToFloat(a_twimageinfo.YResolution)*39.37),
							 PNG_RESOLUTION_METER
							);
	
				// Write the file header information.
				png_write_info(png_ptr, info_ptr);
				
				for(int ii = 0; ii < a_twimageinfo.ImageLength; ii++)
				{
					row_pointers[ii] = (png_byte*)&a_pbImage[ii*a_twimageinfo.ImageWidth];
				}
				png_write_rows(png_ptr, row_pointers, a_twimageinfo.ImageLength);

				
				// Finish up
				png_write_end(png_ptr, info_ptr);
				png_destroy_write_struct(&png_ptr, &info_ptr);
				fclose(pngFile);

				break;

			case 24:

				// Setup the necessary field in the png_into structure
				png_set_IHDR(png_ptr, info_ptr,
							 a_twimageinfo.ImageWidth, a_twimageinfo.ImageLength,
							 8, PNG_COLOR_TYPE_RGB,
							 PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_DEFAULT,
							 PNG_FILTER_TYPE_DEFAULT);
				// pixels/meter = pixels/inch * 39.37
				png_set_pHYs(png_ptr, info_ptr,
							 (uint)(Fix32ToFloat(a_twimageinfo.XResolution)*39.37),
							 (uint)(Fix32ToFloat(a_twimageinfo.YResolution)*39.37),
							 PNG_RESOLUTION_METER
							);

				// Write the file header information.
				png_write_info(png_ptr, info_ptr);
				
				for(int ii = 0; ii < a_twimageinfo.ImageLength; ii++)
				{
					row_pointers[ii] = (png_byte*)&a_pbImage[ii*a_twimageinfo.ImageWidth*3];
				}
				png_write_rows(png_ptr, row_pointers, a_twimageinfo.ImageLength);
				
				// Finish up
				png_write_end(png_ptr, info_ptr);
				png_destroy_write_struct(&png_ptr, &info_ptr);
				fclose(pngFile);

				break;
				
		} // end switch(a_imImage.depth())

	} else {

		// post the error event to the UI (Qt will delete the event and
		// the main window will delete the string)
		m_mxMutex.lock();
		err =  new QString("Error creating file. Image cannot be saved.");
		pevCustom = new QCustomEvent(STIMAGESAVEFAIL);
		pevCustom->setData((void*)err);
		QApplication::postEvent(m_pMainWindow, pevCustom);
		m_mxMutex.unlock();
		
		AbortThread();
		
	} // end ifelse(jpegFile)

	// Free the scanline pointers
	free(row_pointers);

	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Save the image in TIFF format with the select compression
//
//	Parameters:
//		a_pbImage		- The image
//		a_twimageinfo	- The TWAIN information about the image
//		a_strFilename	- The name of the file to save the image too
//		a_ulImageSize	- Size of the image data in bytes
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTSaveThread::SaveTIFFImage
(
	unsigned char*	a_pbImage,
	TW_IMAGEINFO	a_twimageinfo,
	QString 		a_strFilename,
	unsigned long	a_ulImageSize
)
{
	TIFF*			tif;	// libtiff TIFF Image Structure
	QCustomEvent	*pevCustom;
	QString			*err;
	size_t			sizetLineWidth;	// Width of a scanline in bytes

	// Open the file for writing
	tif = TIFFOpen(a_strFilename.utf8().data(), "wb");
	
	if(tif) // only do this if the file handle is valid
	{
		// Set the fields that are not dependent on the bit depth
		TIFFSetField(tif, TIFFTAG_IMAGEWIDTH, a_twimageinfo.ImageWidth);
		TIFFSetField(tif, TIFFTAG_IMAGELENGTH, a_twimageinfo.ImageLength);
		TIFFSetField(tif, TIFFTAG_RESOLUTIONUNIT, RESUNIT_INCH);
		TIFFSetField(tif, TIFFTAG_XRESOLUTION, Fix32ToFloat(a_twimageinfo.XResolution));
		TIFFSetField(tif, TIFFTAG_YRESOLUTION, Fix32ToFloat(a_twimageinfo.YResolution));

		// Now all of the remaining flags and actually saving the image depends
		// on the bit depth of the image
		switch(a_twimageinfo.BitsPerPixel)
		{
			default:

				// post the error event to the UI (Qt will delete the event and
				// the main window will delete the string)
				m_mxMutex.lock();
				err =  new QString("Unrecognized number of bits per pixel");
				pevCustom = new QCustomEvent(STIMAGESAVEFAIL);
				pevCustom->setData((void*)err);
				QApplication::postEvent(m_pMainWindow, pevCustom);
				m_mxMutex.unlock();

				AbortThread();
				TIFFClose(tif);
				remove(a_strFilename.utf8().data());
				break;

			case 1:
				// Set the appropriate fields
				TIFFSetField(tif, TIFFTAG_BITSPERSAMPLE, a_twimageinfo.BitsPerSample[0]);
				TIFFSetField(tif, TIFFTAG_SAMPLESPERPIXEL, a_twimageinfo.SamplesPerPixel);
				TIFFSetField(tif, TIFFTAG_PHOTOMETRIC, PHOTOMETRIC_MINISBLACK);
				TIFFSetField(tif, TIFFTAG_FILLORDER, FILLORDER_LSB2MSB);
				TIFFSetField(tif, TIFFTAG_PLANARCONFIG, PLANARCONFIG_CONTIG);

				// Set the necessary fields for compressed data
				if (!SetTIFFCompTags(tif, a_twimageinfo))
				{
					// post the error event to the UI (Qt will delete the event and
					// the main window will delete the string)
					m_mxMutex.lock();
					err =  new QString("Unrecognized compression setting");
					pevCustom = new QCustomEvent(STIMAGESAVEFAIL);
					pevCustom->setData((void*)err);
					QApplication::postEvent(m_pMainWindow, pevCustom);
					m_mxMutex.unlock();

					AbortThread();
					TIFFClose(tif);
					remove(a_strFilename.utf8().data());
					return;
				}

				// Determine the width of a scanline in bytes
				if (a_twimageinfo.ImageWidth % 8)
				{
					sizetLineWidth = a_twimageinfo.ImageWidth / 8 + 1;
				}
				else
				{
					sizetLineWidth = a_twimageinfo.ImageWidth / 8;
				}

				// Now we're ready to actually write the image
				if (a_twimageinfo.Compression == TWCP_NONE)
				{
					// The image is not compressed, so write with TIFFWriteEncodedStrip
					TIFFWriteEncodedStrip(tif,
										  0,
										  a_pbImage,
										  sizetLineWidth * a_twimageinfo.ImageLength
										 );
				}
				else
				{
					// The image is compressed, use TIFFWriteRawStrip
					TIFFSetField(tif, TIFFTAG_ROWSPERSTRIP, a_twimageinfo.ImageLength);
					TIFFWriteRawStrip(tif, 0, a_pbImage, a_ulImageSize);
				}

				// Close the file
				TIFFClose(tif);
				break;
						
			case 8:
				TIFFSetField(tif, TIFFTAG_BITSPERSAMPLE, a_twimageinfo.BitsPerSample[0]);
				TIFFSetField(tif, TIFFTAG_SAMPLESPERPIXEL, a_twimageinfo.SamplesPerPixel);
				TIFFSetField(tif, TIFFTAG_PHOTOMETRIC, PHOTOMETRIC_MINISBLACK);
				TIFFSetField(tif, TIFFTAG_PLANARCONFIG, PLANARCONFIG_CONTIG);

				// Set the necessary fields for compressed data
				if (!SetTIFFCompTags(tif, a_twimageinfo))
				{
					// post the error event to the UI (Qt will delete the event and
					// the main window will delete the string)
					m_mxMutex.lock();
					err =  new QString("Unrecognized compression setting");
					pevCustom = new QCustomEvent(STIMAGESAVEFAIL);
					pevCustom->setData((void*)err);
					QApplication::postEvent(m_pMainWindow, pevCustom);
					m_mxMutex.unlock();

					AbortThread();
					TIFFClose(tif);
					remove(a_strFilename.utf8().data());
					return;
				}

				// Now we're ready to actually write the image
				if (a_twimageinfo.Compression == TWCP_NONE)
				{
					// The image is not compressed, so write with TIFFWriteEncodedStrip
					TIFFWriteEncodedStrip(tif,
										  0,
										  a_pbImage,
										  a_twimageinfo.ImageWidth * a_twimageinfo.ImageLength
						 				);
				}
				else
				{
					// The image is compressed, use TIFFWriteRawStrip
					TIFFSetField(tif, TIFFTAG_ROWSPERSTRIP, a_twimageinfo.ImageLength);
					TIFFWriteRawStrip(tif, 0, a_pbImage, a_ulImageSize);
				}

				// Close the file
				TIFFClose(tif);
				break;

			case 24:
				TIFFSetField(tif, TIFFTAG_BITSPERSAMPLE, a_twimageinfo.BitsPerSample[0]);
				TIFFSetField(tif, TIFFTAG_SAMPLESPERPIXEL, a_twimageinfo.SamplesPerPixel);
				TIFFSetField(tif, TIFFTAG_PHOTOMETRIC, PHOTOMETRIC_RGB);
				TIFFSetField(tif, TIFFTAG_PLANARCONFIG, PLANARCONFIG_CONTIG);

				// Set the necessary fields for compressed data
				if (!SetTIFFCompTags(tif, a_twimageinfo))
				{
					// post the error event to the UI (Qt will delete the event and
					// the main window will delete the string)
					m_mxMutex.lock();
					err =  new QString("Unrecognized compression setting");
					pevCustom = new QCustomEvent(STIMAGESAVEFAIL);
					pevCustom->setData((void*)err);
					QApplication::postEvent(m_pMainWindow, pevCustom);
					m_mxMutex.unlock();

					AbortThread();
					TIFFClose(tif);
					remove(a_strFilename.utf8().data());
					return;
				}

				// Now we're ready to actually write the image
				if (a_twimageinfo.Compression == TWCP_NONE)
				{
					// The image is not compressed, so write with TIFFWriteEncodedStrip
					TIFFWriteEncodedStrip(tif,
										  0,
										  a_pbImage,
										  a_twimageinfo.ImageWidth * a_twimageinfo.ImageLength * 3
										 );
				}
				else
				{
					// The image is compressed, use TIFFWriteRawStrip
					TIFFSetField(tif, TIFFTAG_ROWSPERSTRIP, a_twimageinfo.ImageLength);
					TIFFWriteRawStrip(tif, 0, a_pbImage, a_ulImageSize);
				}

				// Close the file
				TIFFClose(tif);
				break;
				
		} // end switch(a_qiImage.depth())
	}
	else
	{
		// post the error event to the UI (Qt will delete the event and
		// the main window will delete the string)
		m_mxMutex.lock();
		err =  new QString("Error creating file. Image cannot be saved!");
		pevCustom = new QCustomEvent(STIMAGESAVEFAIL);
		pevCustom->setData((void*)err);
		QApplication::postEvent(m_pMainWindow, pevCustom);
		m_mxMutex.unlock();

		AbortThread();
		
	} // end ifelse(tif)

	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Set the appropriate TIFF tags and other settings based on the
//		data's compression setting
//
//	Parameters:
//		a_tiff			- Pointer to the libTIFF file
//		a_twimageinfo	- The TWAIN image info describing the image
//
//	Returns:
//		true on success
////////////////////////////////////////////////////////////////////////
bool CSTSaveThread::SetTIFFCompTags(TIFF* a_tiff, TW_IMAGEINFO a_twimageinfo)
{
	// Validate...
	if (!a_tiff)
	{
		return (false);
	}

	// Determine the compression from the image info and set the
	// TIFF tag accordingly
	switch (a_twimageinfo.Compression)
	{
		default:
			return (false);
			
		case TWCP_NONE:
			// If the data is uncomopressed we will use the compression settings
			// specified by the user
			switch(a_twimageinfo.BitsPerPixel)
			{
				default:
					return (false);

				case 1:
					switch(m_stfileformatsettings.uiBitonalTIFFCodec)
					{
						default:
							// post the error event to the UI (Qt will delete the event and
							// the main window will delete the string)
							return (false);

						case IDX_NONE:
							TIFFSetField(a_tiff, TIFFTAG_COMPRESSION, COMPRESSION_NONE);
							break;
								
						case IDX_CCITT3:
							TIFFSetField(a_tiff, TIFFTAG_COMPRESSION, COMPRESSION_CCITTFAX3);
							break;

						case IDX_CCITT4:
							TIFFSetField(a_tiff, TIFFTAG_COMPRESSION, COMPRESSION_CCITTFAX4);
							break;
					} // end switch(m_stifcCodecs.uiBitonalCodec)
					break;

				case 8:
					switch(m_stfileformatsettings.uiGrayTIFFCodec)
					{
						default:
							return (false);
							
						case IDX_NONE:
							TIFFSetField(a_tiff, TIFFTAG_COMPRESSION, COMPRESSION_NONE);
							break;
								
						case IDX_LZW:
							TIFFSetField(a_tiff, TIFFTAG_COMPRESSION, COMPRESSION_LZW);
							break;

						case IDX_JPEG:
							TIFFSetField(a_tiff, TIFFTAG_COMPRESSION, COMPRESSION_JPEG);
							break;
						
					} // end switch(m_stifcCodecs.uiGrayCodec)

				case 24:
					switch(m_stfileformatsettings.uiColorTIFFCodec)
					{
						default:
							return (false);

						case IDX_NONE:
							TIFFSetField(a_tiff, TIFFTAG_COMPRESSION, COMPRESSION_NONE);
							break;
								
						case IDX_LZW:
							TIFFSetField(a_tiff, TIFFTAG_COMPRESSION, COMPRESSION_LZW);
							break;
					
						case IDX_JPEG:
							TIFFSetField(a_tiff, TIFFTAG_COMPRESSION, COMPRESSION_JPEG);
							break;
						
					} // end switch(m_stifcCodecs.uiColorCodec)
			} // end swtich(a_twimageinfo.BitsPerPixel)
			break;

		case TWCP_PACKBITS:
			TIFFSetField(a_tiff, TIFFTAG_COMPRESSION, COMPRESSION_PACKBITS);
			break;

		case TWCP_GROUP31D:
		case TWCP_GROUP31DEOL:
		case TWCP_GROUP32D:
			TIFFSetField(a_tiff, TIFFTAG_COMPRESSION, COMPRESSION_CCITTFAX3);
			TIFFSetField(a_tiff, TIFFTAG_FILLORDER, FILLORDER_MSB2LSB);
			break;

		case TWCP_GROUP4:
			TIFFSetField(a_tiff, TIFFTAG_COMPRESSION, COMPRESSION_CCITTFAX4);
			TIFFSetField(a_tiff, TIFFTAG_GROUP4OPTIONS, 0);
			TIFFSetField(a_tiff, TIFFTAG_FILLORDER, FILLORDER_MSB2LSB);
			TIFFSetField(a_tiff, TIFFTAG_PHOTOMETRIC, PHOTOMETRIC_MINISWHITE);
			break;

		case TWCP_JPEG:
			TIFFSetField(a_tiff, TIFFTAG_COMPRESSION, COMPRESSION_JPEG);
			break;

		case TWCP_LZW:
			TIFFSetField(a_tiff, TIFFTAG_COMPRESSION, COMPRESSION_LZW);
			break;

		case TWCP_JBIG:
			TIFFSetField(a_tiff, TIFFTAG_COMPRESSION, COMPRESSION_JBIG);
			break;
	} // end switch (a_twimageinfo.Compression)
	
	return (true);
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Sets the filename to save the images to.
//
//	Parameters:
//		a_strFilename	- The filename to use
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTSaveThread::SetFilename(QString &a_strFilename)
{
	m_mxMutex.lock();
	m_strFilename = a_strFilename;
	m_mxMutex.unlock();

	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Sets the image file format
//
//	Parameters:
//		a_efFormat		- The image format to save images in
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTSaveThread::SetFormats(const STFileFormatSettings& a_stfileformatsettings)
{
	m_mxMutex.lock();
	m_stfileformatsettings = a_stfileformatsettings;
	m_mxMutex.unlock();

	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		The function contains the code which actually runs
//		inside the thread.
//
//		This function will wait on an event and then begin saving
//		images from the queue. It will continue until the queue is
// 		empty and then wait on the event again until it is signalled.
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTSaveThread::run(void)
{
	CSTImgXferEvent *cstimgxferevent;
	QCustomEvent	*pevCustom;

	m_mxMutex.lock();
	m_bAbort = false;
	m_bStop = false;
	m_mxMutex.unlock();
	
	// Run forever unless we've been aborted
	while (!m_bAbort)
	{
		// First check to see if the queue is empty, if it wait on the event
		m_mxMutex.lock();
		if (m_qpqImgQueue.isEmpty() && (!m_bStop))
		{
			m_mxMutex.unlock();
			m_qwaitcondition.wait();
		}
		else
		{
			m_mxMutex.unlock();
		}

		// Check the queue again just in case we woke up on a delete or abort
		// PR 11836, don't check the stop flag here or we may exit the thread
		// without emptying the queue and therefore miss some images.
		m_mxMutex.lock();
		if (m_qpqImgQueue.isEmpty() || m_bAbort)
		{
			// Exit the thread
			m_mxMutex.unlock();
			break;
		}
		
		// Dequeue an image and save it
		cstimgxferevent = m_qpqImgQueue.dequeue();
		m_mxMutex.unlock();
		
		// Save the image
		SaveImage(cstimgxferevent->Image(),
				  cstimgxferevent->ImageInfo(),
				  cstimgxferevent->ImageSizeInBytes());

		// Let the main window know we've saved and image
		m_mxMutex.lock();
		pevCustom = new QCustomEvent(STIMAGESAVED);
		QApplication::sendEvent(m_pMainWindow, pevCustom);
		m_mxMutex.unlock();
		
		// Delete the image xfer event
		delete cstimgxferevent;
	}

	// If the queue is empty then we should be done with the scan job
	// should be done so signal the main UI
	m_mxMutex.lock();
	pevCustom = new QCustomEvent(STSAVEISDONE);
	QApplication::postEvent(m_pMainWindow, pevCustom);
	m_mxMutex.unlock();
	
	return;
}
