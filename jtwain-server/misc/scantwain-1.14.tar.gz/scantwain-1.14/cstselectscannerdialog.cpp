////////////////////////////////////////////////////////////////////////////////
//	File:
//		$Archive: /main/deliverables/scantwain/cstselectscannerdialog.cpp $
//
//	Description:
//		A class for allowing the user to select a twain data source.
//
//	History:
//		$Log: /main/deliverables/scantwain/cstselectscannerdialog.cpp $
//		
//		1     11/02/05 3:41p V737585
//		Initial Revision
//
// Copyright (c) 2005 Eastman Kodak Company
//
// This file is part of ScanTWAIN
//
// ScanTWAIN is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// ScanTWAIN is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY;  without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along
// with ScanTWAIN; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
//	$NoKeywords: $
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
//									INCLUDE FILES
////////////////////////////////////////////////////////////////////////////////
#include <qvariant.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qlistbox.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

#include "cstselectscannerdialog.h"

////////////////////////////////////////////////////////////////////////
// Description:
//		Constructor: Initializes the classes member variables
//
//	Parameters:
//		parent	- This widget's parent widget
//		name	- The widget's name (for debugging)
//		modal	- Whether or not the dialog is shown modally
//		f1		- Widget style flags
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
CSTSelectScannerDialog::CSTSelectScannerDialog( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
	// If the dialog does not have a name give it a generic one
	if( !name )
	{
		setName("CSTSelectScannerDialog");
	}

	// Create the UI Elements
	m_lblSelect = new QLabel(this, "m_lblSelect");
	m_lbScannerList = new QListBox(this, "m_lbScannerList");
	m_btnOK = new QPushButton(this, "m_btnOK");
	m_btnOK->setDefault(true);
	m_btnCancel = new QPushButton(this, "m_btnCancel");

	// Now create the layout elements
	m_DialogLayout = new QHBoxLayout(this, 11, 6, "m_DialogLayout");
	m_ControlLayout = new QVBoxLayout(0, 0, 6, "m_ControlLayout");
	m_ButtonLayout = new QVBoxLayout(0, 0, 6, "m_ButtonLayout");
	m_Spacer1 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Expanding);

	// Add the Controls and Buttons to their layouts
	m_ControlLayout->addWidget(m_lblSelect);
	m_ControlLayout->addWidget(m_lbScannerList);
	m_ButtonLayout->addWidget(m_btnOK);
	m_ButtonLayout->addWidget(m_btnCancel);
	m_ButtonLayout->addItem(m_Spacer1);

	// Add the control and button layouts to the dialog layout
	m_DialogLayout->addLayout(m_ControlLayout);
	m_DialogLayout->addLayout(m_ButtonLayout);
    
	// Call the languageChange slot to add the text to the UI elements
	languageChange();

	// Resize the dialog to the proper size
	resize(QSize(310, 240).expandedTo(minimumSizeHint()));

	// Clear the Window State
	clearWState(WState_Polished);

    // signals and slots connections
    connect( m_btnOK, SIGNAL( released() ), this, SLOT( accept() ) );
    connect( m_btnCancel, SIGNAL( released() ), this, SLOT( reject() ) );

}



////////////////////////////////////////////////////////////////////////
// Description:
//		Destructor: Destroy's the dialog
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
CSTSelectScannerDialog::~CSTSelectScannerDialog()
{
    // no need to delete child widgets, Qt does it all for us
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Changes the text in the dialog in response to a change of
//		language event.
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTSelectScannerDialog::languageChange(void)
{
	// The dialog's caption
	setCaption( tr( "Select a Scanner" ) );

	// Button Labels
	m_btnOK->setText(tr("&OK"));
	m_btnOK->setAccel(QKeySequence(tr("Alt+O")));
	m_btnCancel->setText(tr("&Cancel"));
	m_btnCancel->setAccel(QKeySequence(tr("Alt+C")));

	// Other UI Labels
	m_lblSelect->setText(tr("Select a Scanner:"));

	return;
}


////////////////////////////////////////////////////////////////////////
// Description:
//		Clears the list box
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTSelectScannerDialog::ClearList()
{
	m_lbScannerList->clear();
	
	return;
}


////////////////////////////////////////////////////////////////////////
// Description:
//		Returns the item selected in the list box
//
//	Parameters:
//		None
//
//	Returns:
//		uint	- The currently selected item
////////////////////////////////////////////////////////////////////////
uint CSTSelectScannerDialog::GetSelectedItem(void)
{
	return (m_lbScannerList->currentItem());
}


////////////////////////////////////////////////////////////////////////
// Description:
//		Adds a string to the list box
//
//	Parameters:
//		item	- The string to add
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTSelectScannerDialog::AddToList(QString item)
{
	m_lbScannerList->insertItem(item);
	
	return;
}

