////////////////////////////////////////////////////////////////////////////////
//	File:
//		$Archive: /main/deliverables/scantwain/cstscanthread.h $
//
//	Description:
/**
//		This file defines CSTScanThread which inherits QThread. It is responsible
//		for actually transferring images from the driver to the application. The
//		only function actually overloaded is the run() function, where all the
//		work of transferring the images actually takes place.
//
**/
//	History:
//		$Log: /main/deliverables/scantwain/cstscanthread.h $
//		
//		6     3/26/08 1:04p V737585
//		PR 11740, 11749, 11750: THIS IS A MAJOR REVISION!! We now maintain an
//		image buffer of 10 images, we will not continue to transfer images from
//		the driver while that buffer is full. Additionally, a save thread has
//		been added to save the images in a separate thread. Several new custom
//		events have been added to assist in coordinating this. Finally, the
//		display resolution of the images has been reduced to between 75-150 dpi
//		to make the display faster. NOTE: ScanTWAIN now uses considerably more
//		memory and we may have to consider moving to memory mapped files if
//		this becomes a problem on low memory systems.
//		
//		5     3/19/08 10:08a V737585
//		PR 11740: QT queues up the above events, essentially creating an buffer
//		full of images to be saved and/or displayed, the code below was added
//		to make sure this buffer is only allowed to grow to a certain size,
//		making ScanTWAIN a little nicer on the system if saving/displaying is
//		taking too long.
//		
//		4     1/24/06 10:33a V737585
//		Fixed memory leak and scanning only one page after a stop (PRs 7459 &
//		7487)
//		
//		1     11/02/05 3:41p V737585
//		Initial Revision
//
// Copyright (c) 2005-2006 Eastman Kodak Company
//
// This file is part of ScanTWAIN
//
// ScanTWAIN is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// ScanTWAIN is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY;  without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along
// with ScanTWAIN; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
//	$NoKeywords: $
////////////////////////////////////////////////////////////////////////////////

#ifndef CSTSCANTHREAD_H
#define CSTSCANTHREAD_H

////////////////////////////////////////////////////////////////////////////////
//									INCLUDE FILES
////////////////////////////////////////////////////////////////////////////////
#include <qthread.h>
#include "csttwain.h"
#include "sttypes.h"

class CSTMainWindow;

class CSTScanThread : public QThread
{
	
	public:
		
		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Constructor: Initializes the classes member variables
		//
		//	Parameters:
		//		stackSize	- The size of the stack for this thread
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		CSTScanThread(uint stackSize = 0);
		
		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Destructor: Destroy's the thread
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		~CSTScanThread();

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Sets the main window pointer member
		//
		//	Parameters:
		//		a_pWindow	- Pointer the the main window
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void SetMainWindow(CSTMainWindow* a_pWindow);

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Sets the TWAIN control class member
		//
		//	Parameters:
		//		a_psttwain	- Pointer to the TWAIN control class
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void SetTwainObject(CSTTwain* a_psttwain);

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Stops the thread once images have finished transferring
		//		Also stops the ADF
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void StopThread(void);

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Stops the thread immediately and does not wait for images to
		//		finish transferring.
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void AbortThread(void);

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Notifies the scan thread that we're done processing an image
		//		this will decrement the image count and signal the event if
		//		necessary.
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void NotifyImageProcessed(void);



	protected:
		
		////////////////////////////////////////////////////////////////////////
		// Description:
		//		The function contains the code which actually runs
		//		inside the thread.
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		virtual void run(void);


	private:

		QMutex			m_mxMutex;		// Protects Member Variables
		CSTMainWindow*	m_pMainWindow;	// A Pointer the Main Window
		CSTTwain*		m_psttwain;		// A Pointer to the TWAIN control class
		QWaitCondition	m_qwaitcondition; // A condition to wait on

		bool			m_bStop;		// Should the thread be stopped?
		bool			m_bAbort;		// Should the thread be aborted?
		int				m_iImgCount;	// How many images are in the queue to
		 								// be processed

}; // end class CSTScanThread

#endif
