////////////////////////////////////////////////////////////////////////////////
//	File:
//		$Archive: /main/deliverables/scantwain/cstscansettingsdialog.h $
//
//	Description:
/**
//		This file defines CSTScanSettingsDialog, a simple programmatic TWAIN
// 		UI class.
 **/
//	History:
//		$Log: /main/deliverables/scantwain/cstscansettingsdialog.h $
//		
//		4     5/28/08 3:31p V737585
//		Added support for the TWAIN GUI. ScanTWAIN will now try to use the
//		driver's UI before using it's own. Additionally, support for
//		transferring Group IV and JPEG compressed images has been added.
//		Additionally, the ScanSettings dialog (aka the default driver UI) has
//		been updated to add support for setting the compression.
//		
//		1     11/02/05 3:41p V737585
//		Initial Revision
//
// Copyright (c) 2005 Eastman Kodak Company
//
// This file is part of ScanTWAIN
//
// ScanTWAIN is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// ScanTWAIN is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY;  without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along
// with ScanTWAIN; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
//	$NoKeywords: $
////////////////////////////////////////////////////////////////////////////////
#ifndef SCANSETTINGSDIALOG_H
#define SCANSETTINGSDIALOG_H

////////////////////////////////////////////////////////////////////////////////
//									INCLUDE FILES
////////////////////////////////////////////////////////////////////////////////
#include <qvariant.h>
#include <qdialog.h>
#include <qlayout.h>
#include <qlabel.h>
#include <qcombobox.h>
#include <qpushbutton.h>
#include "csttwain.h"

////////////////////////////////////////////////////////////////////////////////
//						DEFINES, TYPEDEFS, CONSTS & ENUMS
////////////////////////////////////////////////////////////////////////////////
// For the Duplex Combo Box
#define IDX_SIMPLEX		0
#define IDX_DUPLEX		1

// For the Scan In Combo Box
#define	IDX_BITONAL		0
#define IDX_GRAY		1
#define IDX_RGB			2



class CSTScanSettingsDialog : public QDialog
{
    Q_OBJECT

	public:
		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Constructor: Initializes the classes member variables
		//
		//	Parameters:
		//		parent	- This widget's parent widget
		//		name	- The widget's name (for debugging)
		//		modal	- Whether or not the dialog is shown modally
		//		f1		- Widget style flags
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		CSTScanSettingsDialog( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Destructor: Destroy's the dialog
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		~CSTScanSettingsDialog();


		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Calls all the private helper functions to negotiate the
		//		supported capabilities with the TWAIN data source
		//
		//	Parameters:
		//		a_psttwain	- Pointer to the CSTTwain Object we're working with
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void Negotiate( CSTTwain * a_psttwain );
    	
		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Sends all of the settings selected in the dialog to the
		//		TWAIN data source.
		//
		//	Parameters:
		//		a_psttwain	- Pointer to the CSTTwain Object we're working with
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void SendSettings( CSTTwain * a_psttwain );

	protected slots:

		virtual void languageChange();
		void ModeChanged(int a_iIndex);

	private:
		void NegotiateResolution( CSTTwain * a_psttwain );
		void NegotiateDuplex( CSTTwain * a_psttwain );
		void NegotiatePixelType( CSTTwain * a_psttwain );
		void NegotiatePaperSize( CSTTwain * a_psttwain );
		void NegotiateCompression( CSTTwain * a_psttwain );

		QStringList		m_qstrlistPaperSizes;
		QStringList		m_qstrlistCompression;
		CSTTwain		*m_psttwain;
		
		// UI Elements
		QLabel*			m_lblPaperSize;
		QLabel*			m_lblScanIn;
		QLabel*			m_lblMode;
		QLabel*			m_lblResolution;
		QLabel*			m_lblCompression;

		QComboBox*		m_cbResolution;
		QComboBox*		m_cbScanIn;
		QComboBox*		m_cbPaperSize;
		QComboBox*		m_cbDuplex;
		QComboBox*		m_cbCompression;
		
		QPushButton*	m_btnOK;
		QPushButton*	m_btnCancel;
		
		// Layout Items
		QHBoxLayout*	m_DialogLayout;
		QGridLayout*	m_ControlLayout;
		QVBoxLayout*	m_ButtonLayout;
		QSpacerItem*	m_Spacer1;
		QSpacerItem*	m_Spacer3;

};

#endif // SCANSETTINGSDIALOG_H
