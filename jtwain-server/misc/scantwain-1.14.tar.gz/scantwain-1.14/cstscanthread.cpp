////////////////////////////////////////////////////////////////////////////////
//	File:
//		$Archive: /main/deliverables/scantwain/cstscanthread.cpp $
//
//	Description:
//		A derivation of QThread used to handle image transfers from the driver.
//
//	History:
//		$Log: /main/deliverables/scantwain/cstscanthread.cpp $
//		
//		14    8/15/08 10:49a V737585
//		Removed the extra "scanning" in the error dialog.
//		
//		13    5/28/08 3:31p V737585
//		Added support for the TWAIN GUI. ScanTWAIN will now try to use the
//		driver's UI before using it's own. Additionally, support for
//		transferring Group IV and JPEG compressed images has been added.
//		Additionally, the ScanSettings dialog (aka the default driver UI) has
//		been updated to add support for setting the compression.
//		
//		12    3/27/08 11:49a V737585
//		We weren't properly protecting our stop, abort and imgcount variables
//		when the thread is started up.
//		
//		11    3/27/08 11:45a V737585
//		PR 11753: The user was not seeing the "Out of Paper" message, as it was
//		going to the command line only. We now check for paper before beginning
//		a scan session and will report the error in a message box.
//		Additionally, scan thread and save thread errors will now all be
//		displayed in message boxes via events sent to the main ui thread. 
//		
//		10    3/26/08 1:04p V737585
//		PR 11740, 11749, 11750: THIS IS A MAJOR REVISION!! We now maintain an
//		image buffer of 10 images, we will not continue to transfer images from
//		the driver while that buffer is full. Additionally, a save thread has
//		been added to save the images in a separate thread. Several new custom
//		events have been added to assist in coordinating this. Finally, the
//		display resolution of the images has been reduced to between 75-150 dpi
//		to make the display faster. NOTE: ScanTWAIN now uses considerably more
//		memory and we may have to consider moving to memory mapped files if
//		this becomes a problem on low memory systems.
//		
//		9     3/19/08 10:08a V737585
//		PR 11740: QT queues up the above events, essentially creating an buffer
//		full of images to be saved and/or displayed, the code below was added
//		to make sure this buffer is only allowed to grow to a certain size,
//		making ScanTWAIN a little nicer on the system if saving/displaying is
//		taking too long.
//		
//		8     12/13/07 3:10p V737585
//		Always free the image buffer, even on a failure -- the underlying
//		memory corruption problem was resolved.
//		
//		7     12/11/07 3:14p V737585
//		
//		6     12/11/07 2:59p V737585
//		PR 11506: The error handling and coordination between
//		CSTTwain::XferMemory and ScanTWAIN's scan thread was overly
//		complicated, leading to errors/crashes if something went wrong while
//		scanning. This code was simplified to eliminate the problem.
//		
//		5     11/27/07 11:02a V737585
//		Added code to make ScanTWAIN, TWAIN 2.0 compliant
//		
//		4     1/24/06 10:33a V737585
//		Fixed memory leak and scanning only one page after a stop (PRs 7459 &
//		7487)
//		
//		1     11/02/05 3:41p V737585
//		Initial Revision
//
// Copyright (c) 2005-2008 Eastman Kodak Company
//
// This file is part of ScanTWAIN
//
// ScanTWAIN is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// ScanTWAIN is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY;  without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along
// with ScanTWAIN; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
//	$NoKeywords: $
////////////////////////////////////////////////////////////////////////////////
#include <qapplication.h>
#include "cstscanthread.h"
#include "cstmainwindow.h"
#include "cstimgxferevent.h"
#include "csttwain.h"
#include "sttypes.h"

// PR 11740: This number is how many images we'll accept before we force the
// scan thread to wait. It is basically choosen at random, but can have a
// big impact on performance, so be careful with it.
#define	IMAGEBUFFERSIZE	10




////////////////////////////////////////////////////////////////////////
// Description:
//		Constructor: Initializes the classes member variables
//
//	Parameters:
//		stackSize	- The size of the stack for this thread
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
CSTScanThread::CSTScanThread(uint stackSize) : QThread(stackSize)
{
	// Intialize some member variables
	m_bStop = false;
	m_bAbort = false;
	m_iImgCount = 0;
}


////////////////////////////////////////////////////////////////////////
// Description:
//		Destructor: Destroy's the thread
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
CSTScanThread::~CSTScanThread()
{
	m_mxMutex.lock();

	// set the abort flag
	m_bAbort = true;
	m_qwaitcondition.wakeAll();
	m_mxMutex.unlock();
	
	// wait for the thread to abort
	wait();
}


////////////////////////////////////////////////////////////////////////
// Description:
//		The function contains the code which actuallys runs
//		inside the thread.
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTScanThread::run(void)
{
	TW_UINT16			uiResult;
	TW_UINT32			dwImageBytes;
	TW_UINT32			dwActualBytes;
	TW_IMAGEINFO		twimageinfo;
	unsigned char*		pbImage;
	QCustomEvent*		evCustom;
	CSTImgXferEvent*	evImageXfer;
	char				szMessage[256];	
	QString				strError;
	
	// Reset the stop and abort flags
	m_mxMutex.lock();
	m_bStop = false;
	m_bAbort = false;

	// Reset the image count
	m_iImgCount = 0;
	m_mxMutex.unlock();

	// Oddly enough, transferring images, the most important part of the
	// application, also takes the least amount of code to implement. Primarily
	// because of the simplification provided by CSTTwain.
	// Here's how it works:
	//  1) Wait for the Transfer to be Ready
	//  2) Check the TWAIN state, as long as we're still in state 6
	//     there are images to be transfered. Quit if we're not in state 6.
	//	3) Actually transfer the image from the driver. Memory for the image
	//     is allocated by the TWAIN control class CSTTwain.
	//  4) Send the image info and the image itself off to the Main Window
	//     for saving and viewing.
	//  5) Goto Step 2
	
	// Now we must wait for a transfer to be ready (Step 1)
	uiResult = m_psttwain->WaitForXferReady(60);
	if( uiResult != TWRC_SUCCESS)
	{
		m_psttwain->SetState(CSTTwain::TWN_STATE_4);

		// post the error event to the UI (Qt will delete the event and
		// the main window will delete the string)
		QString *err = new QString("Timeout Waiting for Transfer Ready");
		evCustom = new QCustomEvent(STIMAGEXFERFAIL);
		evCustom->setData((void*)err);
		QApplication::postEvent(m_pMainWindow, evCustom);

		// post an event to update the UI (Qt will delete the event)
		evCustom = new QCustomEvent(STSCANISDONE);
		QApplication::postEvent(m_pMainWindow, evCustom);
		return;	
	}

	// Initialize the variables for the first time.
	pbImage = (unsigned char*)NULL;
	memset(&twimageinfo,0,sizeof(TW_IMAGEINFO));
	dwImageBytes = 0;
	dwActualBytes = 0;
	
	while( m_psttwain->GetState() == CSTTwain::TWN_STATE_6)		// Step 2
	{

		// If the abort flag has been set, stop immediately
		if(m_bAbort) break;

		// If the stop flag has been set, we stop the adf and continue
		// to transfer images until all the pending transfers have completed
		if(m_bStop)
		{
			uiResult = m_psttwain->StopFeeder();
			if( uiResult != TWRC_SUCCESS )
			{
				// post the error event to the UI (Qt will delete the event and
				// the main window will delete the string)
				QString *err = new QString("MSG_STOPFEEDER Failed");
				evCustom = new QCustomEvent(STIMAGEXFERFAIL);
				evCustom->setData((void*)err);
				QApplication::postEvent(m_pMainWindow, evCustom);

				break;
			}
		}

		// Step 3
		//   Initialize dwActualBytes and twimageinfo. DO NOT initialize
		//   pbImage or dwImageBytes since we may be reusing them
		dwActualBytes = 0;
		memset(&twimageinfo,0,sizeof(TW_IMAGEINFO));

		// Now actually transfer the image
		uiResult = m_psttwain->XferMemory(
										  &pbImage,
										  &dwImageBytes,
										  &dwActualBytes,
										  &twimageinfo
										 );
		// Check the Result
		if( uiResult != TWRC_SUCCESS )
		{
			// If we failed because the scan was cancelled, don't report the error
			if( uiResult != TWRC_CANCEL )
			{
				// Get additional error information based on the TWAIN
				// condition code
				m_psttwain->GetErrorString(szMessage, sizeof(szMessage));

				// post the error event to the UI (Qt will delete the event and
				// the main window will delete the string)
				strError =  QString("Memory Transfer Failed. Scanning Canceled: ")
						  + QString(szMessage);
				QString *err = new QString(strError);
				evCustom = new QCustomEvent(STIMAGEXFERFAIL);
				evCustom->setData((void*)err);
				QApplication::postEvent(m_pMainWindow, evCustom);
				break;
			}
			else
			{
				// post the error event to the UI (Qt will delete the event and
				// the main window will delete the string)
				QString *err = new QString("Out of Paper");
				evCustom = new QCustomEvent(STIMAGEXFERFAIL);
				evCustom->setData((void*)err);
				QApplication::postEvent(m_pMainWindow, evCustom);
			} // end if(uiResult!=TWRC_CANCEL)
			
			break;
		} // end if(uiResult!=TWRC_SUCCESS)

		// The image has been transferred. Now we'll use CSTImgXferEvent to copy
		// the image data and send it to the main thread to be processed. QT
		// will automatically delete the event when it's done with it.
		evImageXfer = new CSTImgXferEvent();
		if(!evImageXfer->CopyData(pbImage, dwActualBytes, twimageinfo))
		{
			// Out of Memory
			// post the error event to the UI (Qt will delete the event and
			// the main window will delete the string)
			QString *err = new QString("Out of Memory. Scanning Cancelled");
			evCustom = new QCustomEvent(STIMAGEXFERFAIL);
			evCustom->setData((void*)err);
			QApplication::postEvent(m_pMainWindow, evCustom);
			break;
		}

		// Send the Event to the GUI
		m_mxMutex.lock();
		QApplication::postEvent(m_pMainWindow, evImageXfer);
		m_mxMutex.unlock();

		// PR 11740: QT queues up the above events, essentially creating an
		// buffer full of images to be saved and/or displayed, the code below
		// was added to make sure this buffer is only allowed to grow to a
		// certain size, making ScanTWAIN a little nicer on the system if
		// saving/displaying is taking too long.
		
		// See if we need to wait before transferring more data
		m_mxMutex.lock();

		// Increment the count of images received and see if it's over the limit
		if (++m_iImgCount >= IMAGEBUFFERSIZE)
		{
			m_mxMutex.unlock();
			if (!m_qwaitcondition.wait())
			{
				// post the error event to the UI (Qt will delete the event and
				// the main window will delete the string)
				QString *err = new QString("Scan Thread Wait Timed Out. Scanning Cancelled!");
				evCustom = new QCustomEvent(STIMAGEXFERFAIL);
				evCustom->setData((void*)err);
				QApplication::postEvent(m_pMainWindow, evCustom);
			}
		}
		m_mxMutex.unlock();

	} // end while(m_psttwain-GetState()==TWN_STATE_6)

	// free the image buffer we were using
	FREE(pbImage);

	// Transfers finished. Make sure we're in the correct TWAIN state
	m_psttwain->SetState(CSTTwain::TWN_STATE_4);
	
	// Signal the UI that scanner is done
	evCustom = new QCustomEvent(STSCANISDONE);
	QApplication::postEvent(m_pMainWindow, evCustom);

	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Sets the main window pointer member
//
//	Parameters:
//		a_pWindow	- Pointer the the main window
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTScanThread::SetMainWindow(CSTMainWindow* a_pWindow)
{
	m_mxMutex.lock();
	m_pMainWindow = a_pWindow;
	m_mxMutex.unlock();
	
	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Sets the TWAIN control class member
//
//	Parameters:
//		a_psttwain	- Pointer to the TWAIN control class
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTScanThread::SetTwainObject(CSTTwain* a_psttwain)
{
	m_mxMutex.lock();
	m_psttwain = a_psttwain;
	m_mxMutex.unlock();
	
	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Stops the thread once images have finished transferring
//		Also stops the ADF
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTScanThread::StopThread(void)
{
	// Setting this flag to true will tell the thread to stop after the currently
	// transferring image is transferred.
	m_mxMutex.lock();
	m_bStop = true;
	m_qwaitcondition.wakeAll();
	m_mxMutex.unlock();
	
	return;
}




////////////////////////////////////////////////////////////////////////
// Description:
//		Stops the thread immediately and does not wait for images to
//		finish transferring.
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTScanThread::AbortThread(void)
{
	// Set the abort flag to abort the thread
	m_mxMutex.lock();
	m_bAbort = true;
	m_qwaitcondition.wakeAll();
	m_mxMutex.unlock();

	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Notifies the scan thread that we're done processing an image
//		this will decrement the image count and signal the event if
//		necessary.
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTScanThread::NotifyImageProcessed(void)
{
	// lock the mutex
	m_mxMutex.lock();

	// decrement the image count
	// find out if we need to signal the event
	if (--m_iImgCount < IMAGEBUFFERSIZE)
	{
		m_qwaitcondition.wakeAll();
	}

	// unlock the mutex
	m_mxMutex.unlock();
}
