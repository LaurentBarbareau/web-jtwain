////////////////////////////////////////////////////////////////////////////////
//	File:
//		$Archive: /main/deliverables/scantwain/cstscansettingsdialog.cpp $
//
//	Description:
//		A class for allowing the user to select a twain data source.
//
//	History:
//		$Log: /main/deliverables/scantwain/cstscansettingsdialog.cpp $
//		
//		8     5/28/08 3:31p V737585
//		Added support for the TWAIN GUI. ScanTWAIN will now try to use the
//		driver's UI before using it's own. Additionally, support for
//		transferring Group IV and JPEG compressed images has been added.
//		Additionally, the ScanSettings dialog (aka the default driver UI) has
//		been updated to add support for setting the compression.
//		
//		7     1/25/08 8:39a V737585
//		Updated file copyright.
//		
//		6     1/23/08 2:53p V737585
//		Added colon after "Mode" in the dialog strings.
//		
//		5     11/27/07 3:34p V737585
//		Minor fixes for TWAIN 2.0 Compliance
//		
//		4     11/27/07 11:02a V737585
//		Added code to make ScanTWAIN, TWAIN 2.0 compliant
//		
//		1     11/02/05 3:41p V737585
//		Initial Revision
//
// Copyright (c) 2005-2008 Eastman Kodak Company
//
// This file is part of ScanTWAIN
//
// ScanTWAIN is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// ScanTWAIN is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY;  without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along
// with ScanTWAIN; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
//	$NoKeywords: $
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
//									INCLUDE FILES
////////////////////////////////////////////////////////////////////////////////
#include <qvariant.h>
#include <qlayout.h>
#include <qlabel.h>
#include <qcombobox.h>
#include <qpushbutton.h>
#include <qmessagebox.h>

#include "cstscansettingsdialog.h"


////////////////////////////////////////////////////////////////////////
// Description:
//		Constructor: Initializes the classes member variables
//
//	Parameters:
//		parent	- This widget's parent widget
//		name	- The widget's name (for debugging)
//		modal	- Whether or not the dialog is shown modally
//		f1		- Widget style flags
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
CSTScanSettingsDialog::CSTScanSettingsDialog( QWidget* parent, const char* name, bool modal, WFlags fl )
	: QDialog( parent, name, modal, fl )
{
	// If the dialog does not have a name give it a generic one
	if( !name )
	{
		setName( "ScanSettingsDialog" );
	}
	setSizeGripEnabled( false );

	// Create the UI Elements
	m_lblPaperSize = new QLabel(this, "m_lblPaperSize");
	m_lblPaperSize->setAlignment(QLabel::AlignVCenter | QLabel::AlignRight);
	m_lblScanIn = new QLabel(this, "m_lblScanIn");
	m_lblScanIn->setAlignment(QLabel::AlignVCenter | QLabel::AlignRight);
	m_lblMode = new QLabel(this, "m_lblMode");
	m_lblMode->setAlignment(QLabel::AlignVCenter | QLabel::AlignRight);
	m_lblResolution = new QLabel(this, "m_lblResolution");
	m_lblResolution->setAlignment(QLabel::AlignVCenter | QLabel::AlignRight);
	m_lblCompression = new QLabel(this, "m_lblCompression");
	m_lblCompression->setAlignment(QLabel::AlignVCenter | QLabel::AlignRight);
	
	m_cbResolution = new QComboBox(false, this, "m_cbResolution" );
	m_cbResolution->setSizePolicy(QSizePolicy((QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, m_cbResolution->sizePolicy().hasHeightForWidth()));
	m_cbScanIn = new QComboBox(false, this, "m_cbScanIn" );
	m_cbScanIn->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, m_cbScanIn->sizePolicy().hasHeightForWidth() ) );
	m_cbPaperSize = new QComboBox(false, this, "m_cbPaperSize" );
	m_cbPaperSize->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, m_cbPaperSize->sizePolicy().hasHeightForWidth() ) );
	m_cbDuplex = new QComboBox(false, this, "m_cbDuplex" );
	m_cbDuplex->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, m_cbDuplex->sizePolicy().hasHeightForWidth() ) );
	m_cbCompression = new QComboBox(false, this, "m_cbCompression" );
	m_cbCompression->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, m_cbDuplex->sizePolicy().hasHeightForWidth() ) );

	m_btnOK = new QPushButton(this, "m_btnOK");
	m_btnOK->setDefault(true);
	m_btnCancel = new QPushButton(this, "m_btnCancel");

	// Create the Layouts
	m_DialogLayout = new QHBoxLayout(this, 11, 6, "m_DialogLayout");
	m_ControlLayout = new QGridLayout(0, 1, 1, 0, 8, "m_ControlLayout");
	m_ButtonLayout = new QVBoxLayout(0, 0, 6, "m_ButtonLayout");
	m_Spacer1 = new QSpacerItem( 20, 20, QSizePolicy::Minimum, QSizePolicy::Expanding );
	m_Spacer3 = new QSpacerItem( 16, 20, QSizePolicy::Minimum, QSizePolicy::Minimum );

	// Now we'll layout the dialog
	m_ControlLayout->addWidget(m_lblScanIn, 0, 0);
	m_ControlLayout->addWidget(m_lblMode, 1, 0);
	m_ControlLayout->addWidget(m_lblResolution, 2, 0);
	m_ControlLayout->addWidget(m_lblPaperSize, 3, 0);
	m_ControlLayout->addWidget(m_lblCompression, 4, 0);
	m_ControlLayout->addWidget(m_cbScanIn, 0, 1);
	m_ControlLayout->addWidget(m_cbDuplex, 1, 1);
	m_ControlLayout->addWidget(m_cbResolution, 2, 1);
	m_ControlLayout->addWidget(m_cbPaperSize, 3, 1);
	m_ControlLayout->addWidget(m_cbCompression, 4, 1);
	
	m_ButtonLayout->addWidget(m_btnOK);
	m_ButtonLayout->addWidget(m_btnCancel);
	m_ButtonLayout->addItem(m_Spacer1);

	m_DialogLayout->addLayout(m_ControlLayout);
	m_DialogLayout->addLayout(m_ButtonLayout);
	m_DialogLayout->addItem(m_Spacer3);

	// Call the languageChange slot to add the text to the UI elements
	languageChange();

	// Resize the dialog to the proper size
	resize( QSize(356, 144).expandedTo(minimumSizeHint()) );

	// Clear the Window State
	clearWState( WState_Polished );

    // signals and slots connections
	connect( m_btnOK, SIGNAL( clicked() ), this, SLOT( accept() ) );
	connect( m_btnCancel, SIGNAL( clicked() ), this, SLOT( reject() ) );
	connect( m_cbScanIn, SIGNAL( activated(int) ), this, SLOT( ModeChanged(int) ) );

    // set the tab order
	setTabOrder( m_btnOK, m_btnCancel );
	setTabOrder( m_btnCancel, m_cbScanIn );
	setTabOrder( m_cbScanIn, m_cbDuplex );
	setTabOrder( m_cbDuplex, m_cbResolution );
	setTabOrder( m_cbResolution, m_cbPaperSize );

	// Initialize the string list of paper sizes
	m_qstrlistPaperSizes.append(tr("Auto"));
	m_qstrlistPaperSizes.append(tr("A4"));
	m_qstrlistPaperSizes.append(tr("JIS B5"));
	m_qstrlistPaperSizes.append(tr("US Letter"));
	m_qstrlistPaperSizes.append(tr("US Legal"));
	m_qstrlistPaperSizes.append(tr("A5"));
	m_qstrlistPaperSizes.append(tr("ISO B4"));
	m_qstrlistPaperSizes.append(tr("ISO B6"));
	m_qstrlistPaperSizes.append(tr("SPACEFILL"));
	m_qstrlistPaperSizes.append(tr("US Ledger"));
	m_qstrlistPaperSizes.append(tr("US Executive"));
	m_qstrlistPaperSizes.append(tr("A3"));
	m_qstrlistPaperSizes.append(tr("ISO B3"));
	m_qstrlistPaperSizes.append(tr("A6"));
	m_qstrlistPaperSizes.append(tr("C4"));
	m_qstrlistPaperSizes.append(tr("C5"));
	m_qstrlistPaperSizes.append(tr("C6"));
	m_qstrlistPaperSizes.append(tr("4A0"));
	m_qstrlistPaperSizes.append(tr("2A0"));
	m_qstrlistPaperSizes.append(tr("A0"));
	m_qstrlistPaperSizes.append(tr("A1"));
	m_qstrlistPaperSizes.append(tr("A2"));
	m_qstrlistPaperSizes.append(tr("A7"));
	m_qstrlistPaperSizes.append(tr("A8"));
	m_qstrlistPaperSizes.append(tr("A9"));
	m_qstrlistPaperSizes.append(tr("A10"));
	m_qstrlistPaperSizes.append(tr("ISO B0"));
	m_qstrlistPaperSizes.append(tr("ISO B1"));
	m_qstrlistPaperSizes.append(tr("ISO B2"));
	m_qstrlistPaperSizes.append(tr("ISO B5"));
	m_qstrlistPaperSizes.append(tr("ISO B7"));
	m_qstrlistPaperSizes.append(tr("ISO B8"));
	m_qstrlistPaperSizes.append(tr("ISO B9"));
	m_qstrlistPaperSizes.append(tr("ISO B10"));
	m_qstrlistPaperSizes.append(tr("JIS B0"));
	m_qstrlistPaperSizes.append(tr("JIS B1"));
	m_qstrlistPaperSizes.append(tr("JIS B2"));
	m_qstrlistPaperSizes.append(tr("JIS B3"));
	m_qstrlistPaperSizes.append(tr("JIS B4"));
	m_qstrlistPaperSizes.append(tr("JIS B6"));
	m_qstrlistPaperSizes.append(tr("JIS B7"));
	m_qstrlistPaperSizes.append(tr("JIS B8"));
	m_qstrlistPaperSizes.append(tr("JIS B9"));
	m_qstrlistPaperSizes.append(tr("JIS B10"));
	m_qstrlistPaperSizes.append(tr("C0"));
	m_qstrlistPaperSizes.append(tr("C1"));
	m_qstrlistPaperSizes.append(tr("C2"));
	m_qstrlistPaperSizes.append(tr("C3"));
	m_qstrlistPaperSizes.append(tr("C7"));
	m_qstrlistPaperSizes.append(tr("C8"));
	m_qstrlistPaperSizes.append(tr("C9"));
	m_qstrlistPaperSizes.append(tr("C10"));
	m_qstrlistPaperSizes.append(tr("US Statement"));
	m_qstrlistPaperSizes.append(tr("Business Card"));

	// Initialize the string list of compressions
	m_qstrlistCompression.append(tr("None"));
	m_qstrlistCompression.append(tr("Packbits"));
	m_qstrlistCompression.append(tr("CCITT Group III (1D)"));
	m_qstrlistCompression.append(tr("CCITT Group III (1D-EOL)"));
	m_qstrlistCompression.append(tr("CCITT Group III (2D)"));
	m_qstrlistCompression.append(tr("CCITT Group IV"));
	m_qstrlistCompression.append(tr("JPEG"));
	m_qstrlistCompression.append(tr("LZW"));
	m_qstrlistCompression.append(tr("JBIG"));
	m_qstrlistCompression.append(tr("PNG"));
	m_qstrlistCompression.append(tr("RLE4"));
	m_qstrlistCompression.append(tr("RLE8"));
	m_qstrlistCompression.append(tr("Bitfields"));

	m_psttwain = (CSTTwain*)NULL;
}

////////////////////////////////////////////////////////////////////////
// Description:
//		Destructor: Destroy's the dialog
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
CSTScanSettingsDialog::~CSTScanSettingsDialog()
{
    // no need to delete child widgets, Qt does it all for us
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Changes the text in the dialog in response to a change of
//		language event.
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTScanSettingsDialog::languageChange()
{
	// Dialog Caption
	setCaption( tr( "Scanner Settings" ) );

	// Text Labels
	m_lblPaperSize->setText(tr("Paper Size:"));
	m_lblScanIn->setText(tr("Scan In:"));
	m_lblMode->setText(tr("Mode:"));
	m_lblResolution->setText(tr("Resolution:"));
	m_lblCompression->setText(tr("Compression:"));
	
	// Button Labels
	m_btnOK->setText(tr("&OK"));
	m_btnOK->setAccel(QKeySequence(tr("Alt+O")));
	m_btnCancel->setText(tr("&Cancel"));
	m_btnCancel->setAccel(QKeySequence(tr("Alt+C")));

	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Calls all the private helper functions to negotiate the
//		supported capabilities with the TWAIN data source
//
//	Parameters:
//		a_psttwain	- Pointer to the CSTTwain Object we're working with
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTScanSettingsDialog::Negotiate( CSTTwain *a_psttwain )
{
	// This should be called before anything else, so save our pointer
	m_psttwain = a_psttwain;
	
	NegotiatePixelType(a_psttwain);
	NegotiateResolution(a_psttwain);
	NegotiatePaperSize(a_psttwain);
	NegotiateDuplex(a_psttwain);
	NegotiateCompression(a_psttwain);

	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Sends all of the settings selected in the dialog to the
//		TWAIN data source.
//
//	Parameters:
//		a_psttwain	- Pointer to the CSTTwain Object we're working with
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTScanSettingsDialog::SendSettings( CSTTwain *a_psttwain )
{
	TW_UINT16	uiResult;
	QString		qstrText;
	TW_UINT16	uiValue;

	// now we'll go through and for each combo box that's enabled we'll get the
	// selected value in the combo box and send that value to the driver. While
	// this function is the important part of the TWAIN interface this dialog has
	// it is actually the simplest.

	//PixelType
	if( m_cbScanIn->isEnabled() )
	{
		// we'll switch on the currently selected value and use CSTTwain's
		// SetOneValue function to simplfy setting the value
		switch( m_cbScanIn->currentItem() )
		{
			default:
				// This should never happen, but just in case
				QMessageBox::warning(
									 parentWidget(true),
									 tr("ScanTWAIN Error"),
									 tr("Unrecognized Item in Scan In Combo Box"),
									 QMessageBox::Ok,
									 QMessageBox::NoButton
									);
				break;

			case IDX_BITONAL:
				uiValue = TWPT_BW;
				uiResult = a_psttwain->SetOneValue(ICAP_PIXELTYPE,TWTY_UINT16,(TW_MEMREF)&uiValue);
				// Check the Result
				if( uiResult != TWRC_SUCCESS )
				{
					QMessageBox::warning(
										 parentWidget(true),
										 tr("ScanTWAIN Error"),
										 tr("Unable to Set Pixel Type BW"),
										 QMessageBox::Ok,
										 QMessageBox::NoButton
										);
				}
				break;
				
			case IDX_GRAY:
				uiValue = TWPT_GRAY;
				uiResult = a_psttwain->SetOneValue(ICAP_PIXELTYPE,TWTY_UINT16,(TW_MEMREF)&uiValue);
				// Check the Result
				if( uiResult != TWRC_SUCCESS )
				{
					QMessageBox::warning(
										 parentWidget(true),
										 tr("ScanTWAIN Error"),
										 tr("Unable to Set Pixel Type BW"),
										 QMessageBox::Ok,
										 QMessageBox::NoButton
										);
				}
				break;

			case IDX_RGB:
				uiValue = TWPT_RGB;
				uiResult = a_psttwain->SetOneValue(ICAP_PIXELTYPE,TWTY_UINT16,(TW_MEMREF)&uiValue);
				// Check the Result
				if( uiResult != TWRC_SUCCESS )
				{
					QMessageBox::warning(
										 parentWidget(true),
										 tr("ScanTWAIN Error"),
										 tr("Unable to Set Pixel Type BW"),
										 QMessageBox::Ok,
										 QMessageBox::NoButton
										);
				}
				break;

		} // end switch(m_cbScanIn->getCurrent())

	} // end if(m_cbScanIn->isEnabled())
	

	//Duplex
	if( m_cbDuplex->isEnabled() )
	{
		switch(m_cbDuplex->currentItem())
		{
			default:
				// This should never happen, but just in case
				QMessageBox::warning(
									 parentWidget(true),
									 tr("ScanTWAIN Error"),
									 tr("Unrecognized Item in Duplex Combo Box"),
									 QMessageBox::Ok,
									 QMessageBox::NoButton
									);
				break;

			case IDX_SIMPLEX:
				// Use CSTTwain's SetDuplexEnabled Function to make this easy
				uiResult = a_psttwain->SetDuplexEnabled(false);
				// Check the result
				if( uiResult != TWRC_SUCCESS )
				{
					QMessageBox::warning(
										 parentWidget(true),
										 tr("ScanTWAIN ERROR"),
										 tr("Unable to Set Simplex Mode."),
										 QMessageBox::Ok,
										 QMessageBox::NoButton
										);
				}
				break;

			case IDX_DUPLEX:
				// Use CSTTwain's SetDuplexEnabled Function to make this easy
				uiResult = a_psttwain->SetDuplexEnabled(true);
				// Check the result
				if( uiResult != TWRC_SUCCESS )
				{
					QMessageBox::warning(
										 parentWidget(true),
										 tr("ScanTWAIN ERROR"),
										 tr("Unable to Set Duplex Mode."),
										 QMessageBox::Ok,
										 QMessageBox::NoButton
										);
				}
				break;
		} // end switch(m_cbDuplex->getCurrent())
	} // end if(m_cbDuplex->getCurrent())


	//Resolution
	// Get the current text for the resultion and then we'll convert that
	QString qstrResText;
	float	fRes;
	
	if( m_cbResolution->isEnabled() )
	{
		qstrResText = m_cbResolution->currentText();
		fRes = qstrResText.toFloat();
		if( fRes == 0.0 )
		{
			// the value couldn't be converted
			QMessageBox::warning(
								 parentWidget(true),
								 tr("ScanTWAIN Error"),
								 tr("Error Converting Resolution String.\nValue Not Set."),
								 QMessageBox::Ok,
								 QMessageBox::NoButton
								);
		}
		else
		{
			// use CSTTwain's SetResolution function to make this job simple
			uiResult = a_psttwain->SetResolution(fRes);
			// Check the result
			if( uiResult != TWRC_SUCCESS )
			{
				QMessageBox::warning(
									 parentWidget(true),
									 tr("ScanTWAIN Error"),
									 tr("Could not set resolution."),
									 QMessageBox::Ok,
									 QMessageBox::NoButton
									);
			} // end if(uiResult!=TWRC_SUCCESS)
		} // end elseif(fRes == 0.0)
	} // end if(m_cbResolution->isEnabled())
	
	
	//Paper Size
	if( m_cbPaperSize->isEnabled() )
	{
		int			iPaperSize;
		TW_UINT16	uiPaperSize;
		
		// Get the currently selected text from the Combo Box
		qstrText = m_cbPaperSize->currentText();
		// now we need to find the index of the selected item in m_qstrlistPaperSizes
		iPaperSize = m_qstrlistPaperSizes.findIndex(qstrText);
		if( iPaperSize == -1 )
		{
			QMessageBox::warning(
								 parentWidget(true),
								 tr("ScanTWAIN Error"),
								 tr("Unable to determine paper size value."),
								 QMessageBox::Ok,
								 QMessageBox::NoButton
								);
		}
		else
		{
			// we were able to find the value, which is equal to the appropriate
			// TWSS_* constant. That means we'll just take the value and use it
			// to send to the driver.
			uiPaperSize = iPaperSize;
			uiResult = a_psttwain->SetOneValue(ICAP_SUPPORTEDSIZES,TWTY_UINT16,(TW_MEMREF)&uiPaperSize);
			// Check the result
			if( uiResult != TWRC_SUCCESS )
			{
				QMessageBox::warning(
									 parentWidget(true),
									 tr("ScanTWAIN Error"),
									 tr("Unable to set paper size."),
									 QMessageBox::Ok,
									 QMessageBox::NoButton
									);
			} // end if(uiResult != TWRC_SUCCESS)
			
		} // end elseif(iPaperSize == -1)
		
	} // end if(m_cbPaperSize->isEnabled())
	
	
	//Compression
	if( m_cbCompression->isEnabled() )
	{
		int			iCompression;
		TW_UINT16	uiCompression;
		
		// Get the currently selected text from the Combo Box
		qstrText = m_cbCompression->currentText();
		// now we need to find the index of the selected item in m_qstrlistPaperSizes
		iCompression = m_qstrlistCompression.findIndex(qstrText);
		if( iCompression == -1 )
		{
			QMessageBox::warning(
								 parentWidget(true),
								 tr("ScanTWAIN Error"),
								 tr("Unable to determine compression value."),
								 QMessageBox::Ok,
								 QMessageBox::NoButton
								);
		}
		else
		{
			// we were able to find the value, which is equal to the appropriate
			// TWCP_* constant. That means we'll just take the value and use it
			// to send to the driver.
			uiCompression = iCompression;
			uiResult = a_psttwain->SetOneValue(ICAP_COMPRESSION,TWTY_UINT16,(TW_MEMREF)&uiCompression);
			// Check the result
			if( uiResult != TWRC_SUCCESS )
			{
				QMessageBox::warning(
									 parentWidget(true),
									 tr("ScanTWAIN Error"),
									 tr("Unable to set compression."),
									 QMessageBox::Ok,
									 QMessageBox::NoButton
									);
			} // end if(uiResult != TWRC_SUCCESS)
			
		} // end elseif(iCompression == -1)
		
	} // end if(m_cbCompression->isEnabled())

	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Determines the data source's available resolutions and adds
//		them into the resolution combo box.
//
//	Parameters:
//		a_psttwain	- Pointer to the CSTTwain Object we're working with
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTScanSettingsDialog::NegotiateResolution( CSTTwain *a_psttwain )
{
	TW_CAPABILITY		twcapability;
	pTW_ENUMERATION		ptwenumeration;
	pTW_RANGE			ptwrange;
	pTW_ONEVALUE		ptwonevalue;
	TW_UINT16			twuint16Result,
						twuint16CurIndex,
						twuint16DefIndex,
						twuint16Index;
	pTW_FIX32			ptwfix32Value;
	float				fValue,
						fMin,
						fMax,
						fStep;
	
	// First we'll make sure the resolution combo box is cleared
	m_cbResolution->clear();
	
	// Now we'll determine was scanning resolutions the driver supports.
	// This is done by getting ICAP_XRESOLUTION (which will be identitcal
	// to ICAP_YRESOLUTION). Since we don't know what type of value we'll get
	// back from the driver we will have to parse out the result. The only
	// thing we know for certain is that whatever values are returned they will
	// be of the type TW_FIX32.

	// We'll use CSTTwain's GetCapability function to getting the data easy
	twuint16Result = a_psttwain->GetCapability(ICAP_XRESOLUTION, &twcapability);

	// Check the result of the call
	if( twuint16Result != TWRC_SUCCESS )
	{
		QMessageBox::warning(
							 this,
							 tr("ScanTWAIN: Error"),
							 tr("Unable to negotiate resolution capability"),
							 QMessageBox::Ok,
							 QMessageBox::NoButton
							);
		return;
	}
	else
	{
		// First, determine the type of container the data is in
		switch(twcapability.ConType)
		{
			default:
				// We should never be here, but just in case
				QMessageBox::warning(
									 parentWidget(true),
									 tr("ScanTWAIN Error"),
									 tr("Unexpected Container Type (MSG_GET/ICAP_XRESOLUTION."),
									 QMessageBox::Ok,
									 QMessageBox::NoButton
									);
				
				// Disable the combobox
				m_cbResolution->setEnabled(false);
				break;
			
			case TWON_ENUMERATION:		// This data is in an enumeration

				// Now we'll parse the data, by getting a pointer of the right
				// type to it and accessing it that way
				ptwenumeration = (pTW_ENUMERATION)a_psttwain->MemLock(twcapability.hContainer);
				if (ptwenumeration == NULL)
				{
					QMessageBox::warning(
										 parentWidget(true),
										 tr("ScanTWAIN Error"),
										 tr("Memory Lock Failed!"),
										 QMessageBox::Ok,
										 QMessageBox::NoButton
										 );
					
					// Even if the lock failed we still may have to free the memory
					a_psttwain->MemFree(twcapability.hContainer);
					twcapability.hContainer = NULL;

					m_cbResolution->setEnabled(false);
					return;
				}
				twuint16CurIndex = ptwenumeration->CurrentIndex;
				twuint16DefIndex = ptwenumeration->DefaultIndex;

				// Now we'll loop through all the values in the enumeration and
				// add them to the resolution combo box.
				for(
					twuint16Index = 0;
					twuint16Index < ptwenumeration->NumItems;
					twuint16Index++
				   )
				{
					ptwfix32Value = (pTW_FIX32)&(ptwenumeration->ItemList[twuint16Index*sizeof(TW_FIX32)]);
					fValue = Fix32ToFloat(*ptwfix32Value);
					m_cbResolution->insertItem(QString("%1").arg(fValue,0,'f',0), twuint16Index);
				}

				// Now we'll set the current item in the combo box to the
				// current value reported by the driver (since the combo
				// box indices are the same as the enumeration's we'll use
				// the current index we got from the driver to do this).
				m_cbResolution->setCurrentItem(twuint16CurIndex);

				break;

			case TWON_ONEVALUE:

				// The resolution is a single value so we'll get that
				ptwonevalue = (pTW_ONEVALUE)a_psttwain->MemLock(twcapability.hContainer);
				if (ptwonevalue == NULL)
				{
					QMessageBox::warning(
										 parentWidget(true),
										 tr("ScanTWAIN Error"),
										 tr("Memory Lock Failed"),
										 QMessageBox::Ok,
										 QMessageBox::NoButton
										 );
					
					// Even if the lock failed we still may have to free the memory
					a_psttwain->MemFree(twcapability.hContainer);
					twcapability.hContainer = NULL;

					m_cbResolution->setEnabled(false);
					return;
				}
				ptwfix32Value = (pTW_FIX32)ptwonevalue->Item;
				fValue = Fix32ToFloat(*ptwfix32Value);
				m_cbResolution->insertItem(QString("%1").arg(fValue,0,'f',0),0);

				break;

			case TWON_RANGE:
				
				// The resolution value is a range, so let's grab the data and
				// then loop to fill in the combo box
				ptwrange = (pTW_RANGE)a_psttwain->MemLock(twcapability.hContainer);
				if (ptwrange == NULL)
				{
					QMessageBox::warning(
										 parentWidget(true),
										 tr("ScanTWAIN Error"),
										 tr("Memory Lock Failed"),
										 QMessageBox::Ok,
										 QMessageBox::NoButton
										 );
					
					// Even if the lock failed we still may have to free the memory
					a_psttwain->MemFree(twcapability.hContainer);
					twcapability.hContainer = NULL;

					m_cbResolution->setEnabled(false);
					return;
				}
				ptwfix32Value = (pTW_FIX32)&(ptwrange->MinValue);
				fMin  = Fix32ToFloat(*ptwfix32Value);
				ptwfix32Value = (pTW_FIX32)&(ptwrange->MaxValue);
				fMax  = Fix32ToFloat(*ptwfix32Value);
				ptwfix32Value = (pTW_FIX32)&(ptwrange->StepSize);
				fStep = Fix32ToFloat(*ptwfix32Value);

				// Construct the string list
				for(
					fValue = fMin, twuint16Index=0;
					fValue < fMax;
					fValue += fStep, twuint16Index++
				   )
				{
					m_cbResolution->insertItem(QString("%1").arg(fValue,0,'f',0),twuint16Index);
				}

				break;
		} // switch(twcapability.ConType)

		// Unlock the memory
		a_psttwain->MemUnlock(twcapability.hContainer);
		
	} // elseif (twuint16 == TWRC_FAILURE)

	// free the container
	a_psttwain->MemFree(twcapability.hContainer);
	twcapability.hContainer = NULL;

	return;
}


////////////////////////////////////////////////////////////////////////
// Description:
//		Determines if duplex scanning is supported and whether or not
//		it is enabled and adjust the combo box accordingly.
//
//	Parameters:
//		a_psttwain	- Pointer to the CSTTwain Object we're working with
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTScanSettingsDialog::NegotiateDuplex( CSTTwain *a_psttwain )
{
	TW_UINT16	twuint16Result,			// The result of the call to the driver
				twuint16Duplex;			// The value returned by the driver
	TW_BOOL		twboolDuplexEnabled;	// Is Duplex currently enabled


	// First, we'll setup the combo box, Simplex will be index 0, Duplex 1
	m_cbDuplex->clear();
	m_cbDuplex->insertItem(tr("Simplex"),IDX_SIMPLEX);
	m_cbDuplex->insertItem(tr("Duplex"),IDX_DUPLEX);
	
	// This function will determine whether or not the driver supports duplex
	// mode and if it does it will determine what the current setting is.
	// Based on that information it will setup the Duplex Mode combo box,
	// m_cbDuplex, accordingly.

	// To determine if Duplex mode is supported we'll check the CAP_DUPLEX
	// capability. CAP_DUPLEX is a TWON_ONEVALUE of type TW_UINT16

	// Since this capability is TWON_ONEVALUE, we'll use CSTTwain's
	// GetOneValue function to make this job simpler
	twuint16Result = a_psttwain->GetOneValue(
											 CAP_DUPLEX,
											 (TW_MEMREF)&twuint16Duplex
											);

	//.Now we'll check the result of this call
	if( twuint16Result != TWRC_SUCCESS )
	{
		QMessageBox::warning(
							 this,
							 tr("ScanTWAIN: Error"),
							 tr("Unable to negotiate Duplex capability"),
							 QMessageBox::Ok,
							 QMessageBox::NoButton
							);

		// disable the combo box
		m_cbDuplex->setEnabled(false);
	}
	else
	{
		// The call succeeded so let's check the value we got back
		switch(twuint16Duplex)
		{
			default:
				
				// We should never be here, but just in case...
				QMessageBox::warning(
									 this,
									 tr("ScanTWAIN: Error"),
									 tr("Unhandled Option: MSG_GET/CAP_DUPLEX"),
									 QMessageBox::Ok,
									 QMessageBox::NoButton
									);
				break;

			case TWDX_NONE:

				// Duplex is not supported so we'll make sure that simplex is
				// selected and disable the combo box
				m_cbDuplex->setCurrentItem(IDX_SIMPLEX);
				m_cbDuplex->setEnabled(false);;
				
				break;

			case TWDX_1PASSDUPLEX:
			case TWDX_2PASSDUPLEX:
				
				// Duplex Mode is supported, now let's check if duplex is on
				twboolDuplexEnabled = a_psttwain->GetDuplexEnabled();

				if( twboolDuplexEnabled )
				{
					// Duplex Enabled. Set the combo box accordingly
					m_cbDuplex->setCurrentItem(IDX_DUPLEX);
				}
				else
				{
					// Duplex Disabled. Set the combo box accordingly
					m_cbDuplex->setCurrentItem(IDX_SIMPLEX);
				}
				
				break;
				
		} // end switch(twuint16Duplex)
		
	} // end elseif(twuint16Result == TWRC_FAILURE)

	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Sets the combo box choices and gets the currently selected
//		pixel type from the data source.
//
//	Parameters:
//		a_psttwain	- Pointer to the CSTTwain Object we're working with
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTScanSettingsDialog::NegotiatePixelType( CSTTwain *a_psttwain )
{

	TW_UINT16	twuint16PixelType,
				twuint16Result;
		

	// First let's clear the combo box and set it up the way we want
	m_cbScanIn->clear();
	m_cbScanIn->insertItem(tr("Bitonal"),IDX_BITONAL);
	m_cbScanIn->insertItem(tr("Gray"),IDX_GRAY);
	m_cbScanIn->insertItem(tr("Color"),IDX_RGB);


	// NOTE: I had wanted to show using a MSG_SET to restrict the driver to
	// use only B&W, Gray and RGB, however I was not successful in getting that
	// to work. So instead, we'll just get the current value for the pixel type
	// and reflect that in the combo box. We'll always set the pixel type when
	// we close the combo box so we're sure to use either B&W, Gray or RGB

	// The capability we're working with here is ICAP_PIXELTYPE of type
	// TW_UINT16. We'll use the GetOneValue function to make this easy.
	twuint16Result = a_psttwain->GetOneValue(
											 ICAP_PIXELTYPE,
											 (TW_MEMREF)&twuint16PixelType
											);
	// Check the result
	if( twuint16Result != TWRC_SUCCESS )
	{
		QMessageBox::warning(
							 parentWidget(true),
							 tr("ScanTWAIN Error"),
							 tr("Unable to Get Pixel Type."),
							 QMessageBox::Ok,
							 QMessageBox::NoButton
							);

		// disable the control
		m_cbScanIn->setEnabled(false);
	}
	else
	{
		// Now we'll set the current value of the combo box accordingly
		switch(twuint16PixelType)
		{
			default:
				QMessageBox::warning(
									 parentWidget(true),
									 tr("ScanTWAIN Error"),
									 tr("Current Pixel Format is Not Supported."),
									 QMessageBox::Ok,
									 QMessageBox::NoButton
									);

				// Our default is color(RGB) so set the combo box accordingly
				m_cbScanIn->setCurrentItem(IDX_RGB);
				break;

			case TWPT_BW:
				m_cbScanIn->setCurrentItem(IDX_BITONAL);
				break;

			case TWPT_GRAY:
				m_cbScanIn->setCurrentItem(IDX_GRAY);
				break;

			case TWPT_RGB:
				m_cbScanIn->setCurrentItem(IDX_RGB);
				break;

		} // end switch(twuint16PixelType)

	} // end elseif(twuint16Result == TWRC_FAILURE)
		
	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Determines which of the available paper sizes (from TWAIN 1.9)
//		are supported and adds them into the combo box. It also sets
//		the currently selected paper size.
//
//	Parameters:
//		a_psttwain	- Pointer to the CSTTwain Object we're working with
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTScanSettingsDialog::NegotiatePaperSize( CSTTwain *a_psttwain )
{
	TW_CAPABILITY		twcapability;
	pTW_ENUMERATION		ptwenumeration;
	TW_UINT16			twuint16Result,
						twuint16CurIndex,
						twuint16DefIndex,
						twuint16Index,
						twuint16Value;
	TW_UINT32			twuint32NumItems;

	QMap<QString,TW_UINT16>::iterator	itor;

	// First let's clear the combo box
	m_cbPaperSize->clear();

	// Now we're going to get the supported paper sizes from the driver. We'll
	// use CSTTwain's GetCapability to do this, using ICAP_SUPPORTEDSIZES.
	twuint16Result = a_psttwain->GetCapability(ICAP_SUPPORTEDSIZES, &twcapability);

	// Check the result of the call
	if( twuint16Result != TWRC_SUCCESS )
	{
		QMessageBox::warning(
							 this,
							 tr("ScanTWAIN Error"),
							 tr("Unable to negotiate paper size capability"),
							 QMessageBox::Ok,
							 QMessageBox::NoButton
							);

		// disable the combo box
		m_cbPaperSize->setEnabled(false);
	}
	else
	{
		// This capability is always an enumeration so now we parse it accordingly
		ptwenumeration = (pTW_ENUMERATION)a_psttwain->MemLock(twcapability.hContainer);
		if (ptwenumeration == NULL)
		{
			QMessageBox::warning(
								 parentWidget(true),
								 tr("ScanTWAIN Error"),
								 tr("Memory Lock Failed!"),
								 QMessageBox::Ok,
								 QMessageBox::NoButton
								 );
			
			// Even if the lock failed we still might have to free the memory
			a_psttwain->MemFree(twcapability.hContainer);
			twcapability.hContainer = NULL;

			// Disable this combobox
			m_cbPaperSize->setEnabled(false);
			return;
		}
		twuint32NumItems = ptwenumeration->NumItems;
		twuint16CurIndex = ptwenumeration->CurrentIndex;
		twuint16DefIndex = ptwenumeration->DefaultIndex;

		// Now we loop through all the items in our result and add them to
		// the combo box, using their value too lookup the string
		for( twuint16Index=0; twuint16Index < twuint32NumItems; twuint16Index++)
		{
			twuint16Value = ((TW_UINT16)(ptwenumeration->ItemList[twuint16Index*sizeof(TW_UINT16)]));

			// now we have a value which also serves as the index into our string
			// list, so we can just go ahead and add that element from the list
			// into the combo box.
			m_cbPaperSize->insertItem(m_qstrlistPaperSizes[twuint16Value], twuint16Index);
		} // end for(twuint16Index...)

		// now we'll set the current value
		m_cbPaperSize->setCurrentItem(twuint16CurIndex);

		// Unlock the memory from GetCapability
		a_psttwain->MemUnlock(twcapability.hContainer);
		
	} // end elseif(twuint16Result == TWRC_FAILURE)

	// free the container
	a_psttwain->MemFree(twcapability.hContainer);
	twcapability.hContainer = NULL;

	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Determines the data source's available compressions and adds
//		them into the compression combo box.
//
//	Parameters:
//		a_psttwain	- Pointer to the CSTTwain Object we're working with
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTScanSettingsDialog::NegotiateCompression( CSTTwain *a_psttwain )
{
	TW_CAPABILITY		twcapability;
	pTW_ENUMERATION		ptwenumeration;
	pTW_ONEVALUE		ptwonevalue;
	TW_UINT16			twuint16Result,
						twuint16CurIndex,
						twuint16DefIndex,
						twuint16Index,
						twuint16Value;
	TW_UINT32			twuint32NumItems;

	QMap<QString,TW_UINT16>::iterator	itor;

	// First let's clear the combo box
	m_cbCompression->clear();

	// Now we're going to get the supported paper sizes from the driver. We'll
	// use CSTTwain's GetCapability to do this, using ICAP_COMPRESSION.
	twuint16Result = a_psttwain->GetCapability(ICAP_COMPRESSION, &twcapability);

	// Check the result of the call
	if( twuint16Result != TWRC_SUCCESS )
	{
		QMessageBox::warning(
							 this,
							 tr("ScanTWAIN Error"),
							 tr("Unable to negotiate compression capability"),
							 QMessageBox::Ok,
							 QMessageBox::NoButton
							);

		// disable the combo box
		m_cbCompression->setEnabled(false);
		return;
	}
		
	// First, determine the type of container the data is in
	switch(twcapability.ConType)
	{
		default:
			// We should never be here, but just in case
			QMessageBox::warning(
								 parentWidget(true),
								 tr("ScanTWAIN Error"),
								 tr("Unexpected Container Type (MSG_GET/ICAP_COMPESSION."),
								 QMessageBox::Ok,
								 QMessageBox::NoButton
								);
				
			// Disable the combobox
			m_cbCompression->setEnabled(false);
			break;
			
		case TWON_ENUMERATION:		// This data is in an enumeration

			// This capability is always an enumeration so now we parse it accordingly
			ptwenumeration = (pTW_ENUMERATION)a_psttwain->MemLock(twcapability.hContainer);
			if (ptwenumeration == NULL)
			{
				QMessageBox::warning(
									 parentWidget(true),
									 tr("ScanTWAIN Error"),
									 tr("Memory Lock Failed!"),
									 QMessageBox::Ok,
									 QMessageBox::NoButton
									);
			
				// Even if the lock failed we still might have to free the memory
				a_psttwain->MemFree(twcapability.hContainer);
				twcapability.hContainer = NULL;

				// Disable this combobox
				m_cbCompression->setEnabled(false);
				return;
			}
			twuint32NumItems = ptwenumeration->NumItems;
			twuint16CurIndex = ptwenumeration->CurrentIndex;
			twuint16DefIndex = ptwenumeration->DefaultIndex;

			// Now we loop through all the items in our result and add them to
			// the combo box, using their value too lookup the string
			for( twuint16Index=0; twuint16Index < twuint32NumItems; twuint16Index++)
			{
				twuint16Value = ((TW_UINT16)(ptwenumeration->ItemList[twuint16Index*sizeof(TW_UINT16)]));

				// now we have a value which also serves as the index into our string
				// list, so we can just go ahead and add that element from the list
				// into the combo box.
				m_cbCompression->insertItem(m_qstrlistCompression[twuint16Value], twuint16Index);
			} // end for(twuint16Index...)

			// now we'll set the current value
			m_cbCompression->setCurrentItem(twuint16CurIndex);

			// Unlock the memory from GetCapability
			a_psttwain->MemUnlock(twcapability.hContainer);
			break;

		case TWON_ONEVALUE:

			// The resolution is a single value so we'll get that
			ptwonevalue = (pTW_ONEVALUE)a_psttwain->MemLock(twcapability.hContainer);
			if (ptwonevalue == NULL)
			{
				QMessageBox::warning(
									 parentWidget(true),
									 tr("ScanTWAIN Error"),
									 tr("Memory Lock Failed"),
									 QMessageBox::Ok,
									 QMessageBox::NoButton
									);
					
				// Even if the lock failed we still may have to free the memory
				a_psttwain->MemFree(twcapability.hContainer);
				twcapability.hContainer = NULL;

				m_cbCompression->setEnabled(false);
				return;
			}
			twuint16Value = *(pTW_UINT16)ptwonevalue->Item;

			// Set the one compression type in the dialog
			m_cbCompression->insertItem(m_qstrlistCompression[twuint16Value], 0);

			a_psttwain->MemUnlock(twcapability.hContainer);
			break;
	} // switch(twcapability.ConType)

	// free the container
	a_psttwain->MemFree(twcapability.hContainer);
	twcapability.hContainer = NULL;

	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		This function is called whenever the scan mode (pixel type) is
//		changed.
//
//	Parameters:
//		a_iIndex	- The index of the value the mode was changed to
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTScanSettingsDialog::ModeChanged(int a_iIndex)
{
	TW_UINT16	uiValue,
				uiResult;

	// If the mode has change we need to set it and then negotiate the
	// other values all over again.
	switch(a_iIndex)
	{
		default:
			// This should never happen, but just in case
			QMessageBox::warning(
								 parentWidget(true),
								 tr("ScanTWAIN Error"),
								 tr("Unrecognized Item in Scan In Combo Box"),
								 QMessageBox::Ok,
								 QMessageBox::NoButton
								);
			break;

		case IDX_BITONAL:
			uiValue = TWPT_BW;
			uiResult = m_psttwain->SetOneValue(ICAP_PIXELTYPE,TWTY_UINT16,(TW_MEMREF)&uiValue);
			// Check the Result
			if( uiResult != TWRC_SUCCESS )
			{
				QMessageBox::warning(
									 parentWidget(true),
									 tr("ScanTWAIN Error"),
									 tr("Unable to Set Pixel Type BW"),
									 QMessageBox::Ok,
									 QMessageBox::NoButton
									);
			}
			break;
				
		case IDX_GRAY:
			uiValue = TWPT_GRAY;
			uiResult = m_psttwain->SetOneValue(ICAP_PIXELTYPE,TWTY_UINT16,(TW_MEMREF)&uiValue);
			// Check the Result
			if( uiResult != TWRC_SUCCESS )
			{
				QMessageBox::warning(
									 parentWidget(true),
									 tr("ScanTWAIN Error"),
									 tr("Unable to Set Pixel Type BW"),
									 QMessageBox::Ok,
									 QMessageBox::NoButton
									);
			}
			break;

		case IDX_RGB:
			uiValue = TWPT_RGB;
			uiResult = m_psttwain->SetOneValue(ICAP_PIXELTYPE,TWTY_UINT16,(TW_MEMREF)&uiValue);
			// Check the Result
			if( uiResult != TWRC_SUCCESS )
			{
				QMessageBox::warning(
									 parentWidget(true),
									 tr("ScanTWAIN Error"),
									 tr("Unable to Set Pixel Type BW"),
									 QMessageBox::Ok,
									 QMessageBox::NoButton
									);
			}
			break;

	} // end switch(a_iIndex)

	// Negotiate all the values (including the pixel type)
	if (m_psttwain) { Negotiate(m_psttwain); }

	return;
}
