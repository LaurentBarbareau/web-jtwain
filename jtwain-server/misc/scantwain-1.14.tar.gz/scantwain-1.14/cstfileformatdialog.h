////////////////////////////////////////////////////////////////////////////////
//	File:
//		$Archive: /main/deliverables/scantwain/cstfileformatdialog.h $
//
//	Description:
/**
//		This file defines CSTTiffDialog, a dialog box allowing the user to
//		select the compression codecs to use when saving TIFF image files.
**/
//	History:
//		$Log: /main/deliverables/scantwain/cstfileformatdialog.h $
//		
//		2     4/16/09 9:58a V737585
//		Redesigned the file format dialog and some of the underlying structures
//		to work better with the new file format scheme. Also fixed a couple of
//		warnings compiling on Debian x64 systems.
//		
//		1     4/08/09 2:18p V737585
//		PR12757: Added a dialog to allow the user to let ScanTWAIN choose the
//		file type automatically or allow the user to select the file type based
//		on the pixel type. This allows dual-stream scanning, auto color detect
//		and toggle patch to be used while still making it easy for the user and
//		giving them the same flexibility as before if they want it.
//
// Copyright (c) 2009 Eastman Kodak Company
//
// This file is part of ScanTWAIN
//
// ScanTWAIN is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// ScanTWAIN is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY;  without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along
// with ScanTWAIN; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
//	$NoKeywords: $
////////////////////////////////////////////////////////////////////////////////
#ifndef CSTFILEFORMATDIALOG_H
#define CSTFILEFORMATDIALOG_H

////////////////////////////////////////////////////////////////////////////////
//									INCLUDE FILES
////////////////////////////////////////////////////////////////////////////////
#include <qvariant.h>
#include <qdialog.h>
#include <qlayout.h>
#include <qlabel.h>
#include <qcombobox.h>
#include <qpushbutton.h>
#include <qcheckbox.h>
#include <qspinbox.h>
#include <qhgroupbox.h>
#include "sttypes.h"

////////////////////////////////////////////////////////////////////////////////
//						DEFINES, TYPEDEFS, CONSTS & ENUMS
////////////////////////////////////////////////////////////////////////////////

class CSTFileFormatDialog : public QDialog
{
	Q_OBJECT

	public:
		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Constructor: Initializes the classes member variables
		//
		//	Parameters:
		//		parent	- This widget's parent widget
		//		name	- The widget's name (for debugging)
		//		modal	- Whether or not the dialog is shown modally
		//		f1		- Widget style flags
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		CSTFileFormatDialog( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Destructor: Destroy's the dialog
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		~CSTFileFormatDialog();

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Gets the currently selected file formats and TIFF codecs.
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		STFileFormatSettings
		////////////////////////////////////////////////////////////////////////
		STFileFormatSettings GetFileFormatSettings( void );

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Sets the combo boxes to display the given formats and TIFF codecs
		//
		//	Parameters:
		//		a_stfileformatsettings	- The selected file formats and TIFF codecs
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void SetFileFormatSettings(const STFileFormatSettings& a_stfileformatsettings );

	public slots:

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Called when the Automatically Select From Driver check box changes
		//
		//	Parameters:
		//		a_blChecked	- true if the check box is checked
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		virtual void AutoCheckedChange(bool a_blChecked);

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Called when any of the file format settings are changed. It 
        //      updates the UI showing the TIFF codec if TIFF was selected
		//
		//	Parameters:
		//		none
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		virtual void BitonalFileFormatChanged(int a_iIndex);

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Called when any of the file format settings are changed. It 
        //      updates the UI showing the TIFF codec if TIFF was selected
		//
		//	Parameters:
		//		none
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		virtual void GrayFileFormatChanged(int a_iIndex);

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Called when any of the file format settings are changed. It 
        //      updates the UI showing the TIFF codec if TIFF was selected
		//
		//	Parameters:
		//		none
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		virtual void ColorFileFormatChanged(int a_iIndex);

	protected slots:

		virtual void languageChange();

	private:

		STFileFormatSettings	m_stfileformatsettings;

		// UI Elements
		QLabel*			m_lblBitonal;
		QLabel*			m_lblGray;
		QLabel*			m_lblColor;
		QLabel*         m_lblTIFFBitonal;
		QLabel*         m_lblTIFFGray;
		QLabel*         m_lblTIFFColor;
		QLabel*         m_lblJPEGGray;
		QLabel*         m_lblJPEGColor;
		QCheckBox*		m_chkAutoFromDriver;
		QComboBox*		m_cbBitonal;
		QComboBox*		m_cbColor;
		QComboBox*		m_cbGray;
		QComboBox*      m_cbTIFFBitonal;
		QComboBox*      m_cbTIFFColor;
		QComboBox*      m_cbTIFFGray;
		QSpinBox*       m_sbJPEGGray;
		QSpinBox*       m_sbJPEGColor;
		QPushButton*	m_btnOK;
		QPushButton*	m_btnCancel;
		
		// Layout Elements
		QHBoxLayout*	m_DialogLayout;
		QVBoxLayout*	m_ButtonLayout;
		QVBoxLayout*	m_SubDialogLayout;
		QSpacerItem*	m_Spacer1;

        // Group Boxes for each pixel type
        QHGroupBox*     m_grpBitonal;
        QHGroupBox*     m_grpGray;
        QHGroupBox*     m_grpColor;

        // Grids to hold controls inside the group boxes
		QGridLayout*	m_BitonalLayout;
		QGridLayout*    m_GrayLayout;
		QGridLayout*    m_ColorLayout;

};

#endif // CSTFILEFORMATDIALOG_H
