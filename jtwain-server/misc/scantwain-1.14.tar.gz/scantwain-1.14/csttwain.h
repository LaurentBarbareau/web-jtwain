////////////////////////////////////////////////////////////////////////////////
//	File:
//		$Archive: /main/deliverables/scantwain/csttwain.h $
//
//	Description:
/**
//		This file defines CSTTwain, a simple class for controlling a TWAIN
//		driver. It aims to make controlling the driver and setting/negotiating
//		a drivers capabilities as simple as possible.
//
//		It contains serveral routines for setting and negotiating capabilities
//		but also provides a generic interface for doing so allowing for
//		simple service routines to be added to the class in the furture and
//		provide support for custom capabilities.
**/
//	History:
//		$Log: /main/deliverables/scantwain/csttwain.h $
//		
//		10    7/24/09 2:42p V737585
//		Added support for Mac OS/X
//		
//		9     5/28/08 3:31p V737585
//		Added support for the TWAIN GUI. ScanTWAIN will now try to use the
//		driver's UI before using it's own. Additionally, support for
//		transferring Group IV and JPEG compressed images has been added.
//		Additionally, the ScanSettings dialog (aka the default driver UI) has
//		been updated to add support for setting the compression.
//		
//		8     11/27/07 3:34p V737585
//		Minor fixes for TWAIN 2.0 Compliance
//		
//		7     11/27/07 11:02a V737585
//		Added code to make ScanTWAIN, TWAIN 2.0 compliant
//		
//		6     4/10/07 4:23p V737585
//		Updated to use twain2.h instead of the older twain.h
//		
//		5     3/21/07 4:28p V737585
//		Removed extra qualifiers to make gcc4 happy.
//		
//		4     1/24/06 10:29a V737585
//		Fixed comments in the XferMemory description.
//		
//		1     11/02/05 3:41p V737585
//		Initial Revision
//
// Copyright (c) 2005 Eastman Kodak Company
//
// This file is part of ScanTWAIN
//
// ScanTWAIN is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// ScanTWAIN is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY;  without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along
// with ScanTWAIN; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
//	$NoKeywords: $
////////////////////////////////////////////////////////////////////////////////

#ifndef CSTTWAIN_H
#define CSTTWAIN_H



////////////////////////////////////////////////////////////////////////////////
//									INCLUDE FILES
////////////////////////////////////////////////////////////////////////////////
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <dlfcn.h>
#include <vector>
#include "twain.h"

////////////////////////////////////////////////////////////////////////////////
//						DEFINES, TYPEDEFS, CONSTS & ENUMS
////////////////////////////////////////////////////////////////////////////////
#define	IMAGEWAITTIMEOUT	1	// Time in secs between polling for an image

float    Fix32ToFloat(TW_FIX32	a_twfix32Val);
TW_FIX32 FloatToFix32(float     a_fVal);


class CSTTwain
{
 	public:

		////////////////////////////////////////////////////////////////////////
		//															STRUCTURES//
		////////////////////////////////////////////////////////////////////////
		// These structures copies of MS Windows structures that we need to
		// do a native transfer.
		struct BITMAPFILEHEADER
		{
			unsigned short	bfType;
			unsigned long	bfSize;
			unsigned short	bfReserved1;
			unsigned short	bfReserved2;
			unsigned long	bfOffBits;
		};

		struct BITMAPINFOHEADER
		{
			unsigned long	biSize;
			long			biWidth;
			long			biHeight;
			unsigned short	biPlanes;
			unsigned short	biBitCount;
			unsigned long	biCompression;
			unsigned long	biSizeImage;
			long			biXPelsPerMeter;
			long			biYPelsPerMeter;
			unsigned long	biClrUsed;
			unsigned long	biClrImportant;
		};

		struct RGBQUAD
		{
			unsigned char	rgbBlue;
			unsigned char	rgbGreen;
			unsigned char	rgbRed;
			unsigned char	rgbReserved;
		};


		////////////////////////////////////////////////////////////////////////
		//														ENUMERATIONS  //
		////////////////////////////////////////////////////////////////////////
		enum ETWNSTATE
		{
			TWN_STATE_UNDEFINED		= 0,
			TWN_STATE_1				= 1,
			TWN_STATE_2				= 2,
			TWN_STATE_3				= 3,
			TWN_STATE_4				= 4,
			TWN_STATE_5				= 5,
			TWN_STATE_6				= 6,
			TWN_STATE_7				= 7,
		};

		
		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Constructor: Initializes the classes member variables
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		CSTTwain
		(
			void
		);


		
		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Destructor: Destorys the class, closes the TWAIN DSM
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		~CSTTwain
		(
			void
		);

		

		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		This function opens the shared library and tells the data
		//		source manager to open.
		//
		//	Parameters:
		//		(none)
		//
		//	Returns:
		//		TWRC_SUCCESS
		//		TWRC_FAILURE
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 OpenDSM
		(
			void
		);



		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Closes the TWAIN data source manager
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void CloseDSM
		(
			void
		);


		
		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		Query the DSM for a list of available data sources (drivers)
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		vector<string> - List of all data sources found. If no data
		//						 sources are found then the vector will be
		//						 empty.
		///////////////////////////////////////////////////////////////////////
		std::vector<TW_IDENTITY> ListDS
		(
			void
		);


		
		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		This function is used to open the driver.
		//
		//	Parameters:
		//		a_twidentityDs	- identity of the driver we're opening
		//
		//	Returns:
		//		TWRC_SUCCESS
		//		TWRC_FAILURE
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 OpenDS
		(
			TW_IDENTITY a_twidentityDs
		);


		
		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		Closes the data source (driver).
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		///////////////////////////////////////////////////////////////////////
		void CloseDS
		(
			void
		);


		
		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		Setup the application identity.  The TWAIN DSM uses this to
		//		uniquely identify the application, assigning it an ID when
		//		the DSM is first opened. This must be called before the DSM
		//		can be opened.
		//
		//	Parameters:
		//		a_szManufacturer			- company name
		//		a_szProductFamily			- product name
		//		a_szProductName				- model name
		//		a_szVersionInfo				- generic version info
		//		a_twuint16ProtocolMajor		- TWAIN.H major
		//		a_twuint16ProtocolMinor		- TWAIN.H minor
		//		a_twuint32SupportedGroups	- DF_APP2 | DG_CONTROL | DG_IMAGE
		//		a_twuint16VersionCountry	- TWCY_*
		//		a_twuint16VersionLanguage	- TWLG_*
		//		a_twuint16VersionMajorNum	- driver major
		//		a_twuint16VersionMinorNum	- driver minor
		//
		//	Returns:
		//		TWRC_SUCCESS
		//		TWRC_FAILURE
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 SetIdentity
		(
			const char*	a_szManufacturer,
			const char*	a_szProductFamily,
			const char*	a_szProductName,
			const char*	a_szVersionInfo,
			TW_UINT16	a_twuint16ProtocolMajor,
			TW_UINT16	a_twuint16ProtocolMinor,
			TW_UINT32	a_twuint32SupportedGroups,
			TW_UINT16	a_twuint16VersionCountry,
			TW_UINT16	a_twuint16VersionLanguage,
			TW_UINT16	a_twuint16VersionMajorNum,
			TW_UINT16	a_twuint16VersionMinorNum
		);


		
		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		The entry prodedure to the DSM. This uses the application
		//		identity member variable and the data source identity member
		//		variable to simplify the standard DSM_Entry call.
		//
		//	Parameters:
		//		a_twuint16DG	- Data Group
		//		a_twuint16DAT	- Data Access Type
		//		a_twuint16MSG	- Message
		//		a_twmemref		- Pointer to data
		//
		//	Returns:
		//		TWRC_SUCCESS
		//		TWRC_FAILURE
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 Entry
		(
			TW_UINT16	a_twuint16DG,
			TW_UINT16	a_twuint16DAT,
			TW_UINT16	a_twuint16MSG,
			TW_MEMREF	a_twmemref
		);


		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		GetCapability is used to simply reading a capability from the
		//		data source. It acts on the currently open data sources and
		//		will fail if no data source is currently open.
		//
		//	Parameters:
		//		a_twuint16Cap	- The TWAIN capability to get
		//		a_twcapability	- The TWAIN capability structure to fill in
		//						- This structure must be freed by the caller.
		//
		//	Returns:
		//		TWRC_SUCCESS
		//		TWRC_FAILURE
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 GetCapability
		(
			TW_UINT16		a_twuint16Cap,
			pTW_CAPABILITY	a_ptwcapability
		);


		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		Set Capability is used to simply setting the value of a
		//		capability for the current data source. If no data source
		//		is open the call will fail.
		//
		//	Parameters:
		//		a_twuint16Cap		- The TWAIN Tag for the value
		//		a_twuint16ConType	- The TWAIN Container Type
		//		a_twmemrefValue		- The TWAIN Container Iteself
		//
		//	Returns:
		//		TWRC_SUCCESS
		//		TWRC_FAILURE
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 SetCapability
		(
				pTW_CAPABILITY	a_ptwcapability
		);


		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		This function sets a single value according to the TWAIN
		//		specification.
		//
		//	Parameters:
		//		a_twuint16Tag	- The TWAIN Tag for the value
		//		a_twuint16Type	- The TWAIN Type for the value
		//		a_twmemrefValue	- The TWAIN value itself
		//
		//	Returns:
		//		TWRC_SUCCESS
		//		TWRC_FAILURE
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 SetOneValue
		(
			TW_UINT16	a_twuint16Tag,
			TW_UINT16	a_twuint16Type,
			TW_MEMREF	a_twmemrefValue
		);


		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		This function sets a single value according to the
		//		TWAIN specification.
		//
		//	Parameters:
		//		a_twuint16Tag	- The TWAIN Tag for the value
		//		a_twmemrefValue	- The TWAIN value itself
		//
		//	Returns:
		//		TWRC_SUCCESS
		//		TWRC_FAILURE
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 GetOneValue
		(
			TW_UINT16	a_twuint16Tag,
			TW_MEMREF	a_twmemrefValue
		);


		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		This function enables the driver. It also determines if the
		//		driver's user interface should be shown.
		//
		//	Parameters:
		//		a_boolShowUI	- whether or not to show the driver's UI
		//		a_boolShowUIOnly- only show the UI, don't start scanning
		//
		//	Returns:
		//		TWRC_SUCCESS
		//		TWRC_FAILURE
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 Enable
		(
			TW_BOOL		a_boolShowUi,
			TW_BOOL		a_boolShowUiOnly = 0
		);



		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		Disable the driver
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		TWRC_SUCCESS
		//		TWRC_FAILURE
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 Disable
		(
			void
		);


		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		Get the current TWAIN state.
		//
		//	Parameters:
		//		(none)
		//
		//	Returns:
		//		ETWNSTATE
		///////////////////////////////////////////////////////////////////////
		ETWNSTATE GetState
		(
			void
		);


		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		Managing the TWAIN states can be a little weird if you're still
		//		new to them.  This method takes us from our current state down
		//		to some desired state (given in the argument)...
		//
		//	Parameters:
		//		a_etwnstate		- state we want to get to
		//
		//	Returns:
		//		TWRC_SUCCESS
		//		TWRC_FAILURE
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 SetState
		(
			ETWNSTATE	a_etwnstate
		);


		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		GetPixelType returns a TW_UINT16 indicating the pixel type
		//		the driver is currently set to use.
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		TWPT_BW 
		//		TWPT_GRAY
		//		TWPT_RGB
		//		TWPT_PALETTE
		//		TWPT_CMY
		//		TWPT_CMYK
		//		TWPT_YUV
		//		TWPT_YUVK
		//		TWPT_CIEXYZ
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 GetPixelType
		(
			void
		);
		

		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		SetPixelType tell the driver what pixel type to use.
		//
		//	Parameters:
		//		a_twuint16PixelType	- Indicates the type of pixel to use
		//
		//	Returns:
		//		TWRC_SUCCESS
		//		TWRC_FAILURE
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 SetPixelType
		(
			TW_UINT16 a_twuint16PixelType
		);

		
		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		GetResolution returns the resolution the driver is currently
		// 		set to scan at. It assumes that X and Y resolutions are equal.
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		TW_FIX32	resolution
		///////////////////////////////////////////////////////////////////////
		float GetResolution
		(
			void
		);

		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		SetResolution sets the resolution the driver should scan at.
		//		It sets both the X and Y resolutions, making them equal.
		//
		//	Parameters:
		//		a_twfix32Resolution	- The requested resolution
		//
		//	Returns:
		//		TWRC_SUCCESS
		//		TWRC_FAILURE
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 SetResolution
		(
			float a_fResolution
		);

		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		SetDuplex sets the driver to scan in duplex mode.
		//
		//	Parameters:
		//		a_twboolEnabled	- Enable/Disable Duplex Mode
		//
		//	Returns:
		//		TWRC_SUCCESS
		//		TWRC_FAILURE
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 SetDuplexEnabled
		(
			TW_BOOL	a_twboolEnabled
		);

		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		GetDuplex returns whether or not the driver is set to scan in
		//		duplex mode.
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		TW_BOOL	- TRUE if duplex is enabled.
		///////////////////////////////////////////////////////////////////////
		TW_BOOL GetDuplexEnabled
		(
			void
		);


		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		SetTransferMode tell the driver what transfer mode to use.
		//
		//	Parameters:
		//		a_twuint16XferMode	- Indicates the transfer mode to use
		//
		//	Returns:
		//		TWRC_SUCCESS
		//		TWRC_FAILURE
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 SetTransferMode
		(
			TW_UINT16 a_twuint16XferMode
		);

		
		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		GetTransferMode returns the transfer mode the driver will use.
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		TWSX_NATIVE
		//		TWSX_FILE
		//		TWSX_MEMORY
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 GetTransferMode
		(
			void
		);

		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		This function retrieves the image information
		//
		//	Parameters:
		//		a_ptwimageinfo	- pointer to an image info structure
		//
		//	Returns:
		//		TWRC_SUCCESS
		//		TWRC_FAILURE
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 ImageInfo
		(
			TW_IMAGEINFO	*a_ptwimageinfo
		);

				
		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		This function waits for some indication that an image is ready
		//		to be transfered.
		//
		//	Parameters:
		//		a_twint32Timeout	- How long to wait (in seconds)
		//
		//	Returns:
		//		TWRC_SUCCESS
		//		TWRC_FAILURE
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 WaitForXferReady
		(
			TW_INT32	a_twint32Timeout
		);


		///////////////////////////////////////////////////////////////////////
		//	Description:
		//	 Do a memory transfer...the application should start by sending in
		//	 a pointer to a NULL address, and it should send a size of 0.  The
		//	 method will allocate the needed memory and report the size of that
		//	 memory.  The application needs to hold on to this information for
		//	 the next call...
		//
		//	Parameters:
		//		a_pbImage				- pointer to the image memory pointer
		//		a_twuint32ImageBytes	- size of allocated memory
		//		a_dwActualBytes			- actual size of the image in bytes
		//		a_twimageinfo			- information about the image
		//
		//	Returns:
		//		TWRC_SUCCESS
		//		TWRC_FAILURE
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 XferMemory
		(
			unsigned char	**a_ppbImage,
			TW_UINT32		*a_twuint32ImageBytes,
			TW_UINT32		*a_dwActualBytes,
			TW_IMAGEINFO	*a_ptwimageinfo
		);


		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		Do a file transfer.
		//
		//	Parameters:
		//		a_szFilename		- string indicating the filename
		//		a_ptwpendingxfers	- pointer to a pending transfer structure
		//
		//	Returns:
		//		TWRC_SUCCESS
		//		TWRC_FAILURE
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 XferFile
		(
			char*		a_szFilename,
			TW_UINT16	a_twuint16FileFormat
		);


		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		Do a native transfer.
		//
		//	Parameters:
		//		a_pbitmapinfoheader		- pointer to a DIB handle
		//
		//	Returns:
		//		TWRC_SUCCESS
		//		TWRC_FAILURE
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 XferNative
		(
			BITMAPINFOHEADER	**a_ppbitmapinfoheader
		);


		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		This function ends any pending transfers
		//
		//	Parameters:
		//		a_twuint16MSG	- 
		//
		//	Returns:
		//		TWRC_SUCCESS
		//		TWRC_FAILURE
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 PendingXfers
		(
			TW_UINT16		a_twuint16MSG
		);


		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		This function send the command to stop the ADF
		//
		//	Parameters:
		//		a_twuint16MSG	- 
		//
		//	Returns:
		//		TWRC_SUCCESS
		//		TWRC_FAILURE
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 StopFeeder
		(
			void
		);


		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		This function register the specified callback function with
		//		the data source manager.
		//
		//	Parameters:
		//		a_pfCallback	- Pointer to the Callback Function
		//
		//	Returns:
		//		TWRC_SUCCESS
		//		TWRC_FAILURE
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 SetCallback(
				TW_UINT16 (*a_pfCallback)(
										  pTW_IDENTITY	a_pOrigin,
										  pTW_IDENTITY 	a_pDest,
										  TW_UINT32		a_DG,
										  TW_UINT16		a_DAT,
										  TW_UINT16		a_MSG,
										  TW_MEMREF		a_pData
										 )
							 );


		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		This function makes the call to the DSM for
		//		DG_CONTROL / DAT_ENTRYPOINT / MSG_GET to get the memory
		//		allocation function pointers.
		//
		//	Parameters:
		//		(none)
		//
		//	Returns:
		//		TWRC_SUCCESS
		//		TWRC_FAILURE
		///////////////////////////////////////////////////////////////////////
		TW_UINT16 GetEntrypoint(void);


		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		This function gets the size of a given TWAIN data type
		//
		//  Parameters:
		//		TW_UINT16	a_twuint16ItemType
		//
		//	Returns:
		//		The size of the specified item in bytes
		///////////////////////////////////////////////////////////////////////
		size_t GetDatatypeSize(TW_UINT16 a_twuint16ItemType);


		///////////////////////////////////////////////////////////////////////
		//	Description:
		//		This function is used to log a message
		//
		//  Parameters:
		//		a_cszFormat - The format string (printf style)
		//		Variable Arguments
		//
		//	Returns:
		//		(none)
		///////////////////////////////////////////////////////////////////////
		void Log(const char *a_cszFormat, ... );



		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Get the current condition code and fills in a string with error
		//		information.
		//
		//	Parameters:
		//		a_szMessage		- Pointer to a string to fill in
		//		a_sizetLen		- Length of the string, a_szMessage in bytes
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void GetErrorString(char *a_szMessage, size_t a_sizetLen);



		// Memory Allocation Routines (for Managing TW_HANDLE's)
		TW_HANDLE	MemAlloc(TW_UINT32 a_twuint32Size);
		void		MemFree(TW_HANDLE a_twhandle);
		TW_MEMREF	MemLock(TW_HANDLE a_twhandle);
		void		MemUnlock(TW_HANDLE a_twhandle);

		
	private:

		// Decide whether or not to abort when memory corrupt is detected
		void		AbortOnCorruptMem(void);

		// Converts the string in the TW_IDENTITY structure from PASCAL
		// format if we're running on Mac OS/X
		void		ConvertTwIdentity(TW_IDENTITY &a_rtwidentity, bool a_blToPascal);
		void 		PascalStringToCString(char* a_szString);
		void		CStringToPascalString(char* a_szString);

		// The pointer to the only function call exported by the TWAIN
		// Source Manager.  We do all our calls through this...
		DSMENTRYPROC		m_pfnDsmEntryProc;

		// A handle to the DSM module...
		void				*m_pvDSM;

		// Memory allocation function pointers (from DAT_ENTRYPOINT)
		DSM_MEMALLOCATE		m_pfnDsmMemAlloc;
		DSM_MEMFREE			m_pfnDsmMemFree;
		DSM_MEMLOCK			m_pfnDsmMemLock;
		DSM_MEMUNLOCK		m_pfnDsmMemUnlock;

		// The identities...
		TW_IDENTITY			m_twidentityApp;
		TW_IDENTITY			m_twidentityDs;
		TW_IDENTITY			*m_ptwidentityDs;

		// The user interface...
		TW_USERINTERFACE	m_twuserinterface;

		// The xfer structures...
		TW_SETUPFILEXFER	m_twsetupfilexfer;

		// The current pending transfer...
		TW_PENDINGXFERS		m_twpendingxfers;

		// Our Current State
		ETWNSTATE			m_etwnstate;

		// Are we talking to a TWAIN 2.0 Compliant DSM
		bool				m_blTWAIN2;
		
};

#endif	// CTEMPLATE_H
