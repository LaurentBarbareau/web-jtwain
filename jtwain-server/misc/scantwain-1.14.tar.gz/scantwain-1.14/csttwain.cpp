////////////////////////////////////////////////////////////////////////////////
//	File:
//		$Archive: /main/deliverables/scantwain/csttwain.cpp $
//
//	Description:
//		A simple class for controlling a TWAIN driver
//
//	History:
//		$Log: /main/deliverables/scantwain/csttwain.cpp $
//		
//		14    7/24/09 2:42p V737585
//		Added support for Mac OS/X
//		
//		13    4/16/09 9:58a V737585
//		Redesigned the file format dialog and some of the underlying structures
//		to work better with the new file format scheme. Also fixed a couple of
//		warnings compiling on Debian x64 systems.
//		
//		12    5/28/08 3:31p V737585
//		Added support for the TWAIN GUI. ScanTWAIN will now try to use the
//		driver's UI before using it's own. Additionally, support for
//		transferring Group IV and JPEG compressed images has been added.
//		Additionally, the ScanSettings dialog (aka the default driver UI) has
//		been updated to add support for setting the compression.
//		
//		11    1/25/08 8:39a V737585
//		Updated file copyright.
//		
//		10    1/24/08 4:43p V737585
//		The CloseDS function was actually calling CloseDSM. Also, we won't
//		switch states if either CloseDS or CloseDSM fails.
//		
//		9     12/11/07 3:14p V737585
//		
//		8     12/11/07 2:59p V737585
//		PR 11506: The error handling and coordination between
//		CSTTwain::XferMemory and ScanTWAIN's scan thread was overly
//		complicated, leading to errors/crashes if something went wrong while
//		scanning. This code was simplified to eliminate the problem.
//		
//		7     11/27/07 3:34p V737585
//		Minor fixes for TWAIN 2.0 Compliance
//		
//		6     11/27/07 11:02a V737585
//		Added code to make ScanTWAIN, TWAIN 2.0 compliant
//		
//		5     4/10/07 5:33p V737585
//		We now use the callback to determine if a image is ready to be
//		transferred, as opposed to the old icky way :)
//		
//		4     1/24/06 10:30a V737585
//		Fixed a memory leak in the XferMemory function.
//		
//		1     11/02/05 3:41p V737585
//		Initial Revision
//
//	Copyright (c) 2005-2008 Eastman Kodak Company
//
// This file is part of ScanTWAIN
//
// ScanTWAIN is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// ScanTWAIN is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY;  without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along
// with ScanTWAIN; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
//	$NoKeywords: $
////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////
//									INCLUDE FILES
////////////////////////////////////////////////////////////////////////////////
#ifdef __APPLE__
	#include <CoreServices/CoreServices.h>
	#define	 TWAIN_DSM "/System/Library/Frameworks/TWAIN.framework/TWAIN"
#else
	#define	 TWAIN_DSM "libtwaindsm.so"
#endif

#include <stdlib.h>
#include <vector>
#include "csttwain.h"
#include "sttypes.h"

extern TW_UINT16 TWAINCallback(
								pTW_IDENTITY a_pOrigin,
								pTW_IDENTITY a_pDest,
								TW_UINT32	a_DG,
								TW_UINT16	a_DAT,
								TW_UINT16	a_MSG,
								TW_MEMREF	a_pData
							  );


// Helper Functions
float Fix32ToFloat
(
	TW_FIX32	a_twfix32Val
)
{
	float fValue;

	fValue = (float)a_twfix32Val.Whole + (float)a_twfix32Val.Frac / 65536.0;

	return fValue;
}


TW_FIX32 FloatToFix32
(
	float     a_fVal
)
{
	TW_FIX32	twfix32Val;
	TW_INT32	twint32Val;

	twint32Val = (TW_INT32)(a_fVal * 65536.0 + 0.5);
	twfix32Val.Whole = twint32Val >> 16;
	twfix32Val.Frac  = twint32Val & 0x0000ffffL;

	return twfix32Val;
}


/////////////////////////////////////////////////////////////////////////////
//	Description:
//		Constructor...
//
//	Parameters:
//		(none)
//
//	Returns:
//		(none)
//////////////////////////////////////////////////////////////////////////////
CSTTwain::CSTTwain
(
	void
)
{
	// Initialize the memeber variables, in particular zero all the pointers
	// and set the current TWAIN state to 1.
	m_pfnDsmEntryProc	= 0;
	m_pvDSM				= 0;
	m_ptwidentityDs		= 0;
	m_etwnstate			= TWN_STATE_1;
	m_blTWAIN2			= false;

	// Initialize the memory allocation function pointers
	m_pfnDsmMemAlloc	= (DSM_MEMALLOCATE)NULL;
	m_pfnDsmMemFree		= (DSM_MEMFREE)NULL;
	m_pfnDsmMemLock		= (DSM_MEMLOCK)NULL;
	m_pfnDsmMemUnlock	= (DSM_MEMUNLOCK)NULL;

	// Zero the memory for the Application and Data Soruce identity
	memset(&m_twidentityApp,0,sizeof(m_twidentityApp));
	memset(&m_twidentityDs,0,sizeof(m_twidentityDs));

	return;
}

/////////////////////////////////////////////////////////////////////////////
//	Description:
//		Destructor...
//
//	Parameters:
//		(none)
//
//	Returns:
//		(none)
//////////////////////////////////////////////////////////////////////////////
CSTTwain::~CSTTwain
(
	void
)
{
	// move down to state 1 so that the DSM is closed
	SetState(CSTTwain::TWN_STATE_1);
	
	// Uninitialize the memory allocation function pointers
	m_pfnDsmMemAlloc	= (DSM_MEMALLOCATE)NULL;
	m_pfnDsmMemFree		= (DSM_MEMFREE)NULL;
	m_pfnDsmMemLock		= (DSM_MEMLOCK)NULL;
	m_pfnDsmMemUnlock	= (DSM_MEMUNLOCK)NULL;

	return;
}


//////////////////////////////////////////////////////////////////////////////
//	Description:
//		This function opens the shared library and tells the data source
//		manager to open.
//
//	Parameters:
//		(none)
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
//////////////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::OpenDSM
(
	void
)
{
	int sts;	// tracks the status each step along the way

	// This section does some error checking.
	//
	// Make sure that the application has not already been assigned an ID
	// if it has then fail.
	if (m_twidentityApp.Id != 0)
	{
		Log("The DSM seems to have assigned an ID already!\n");
		return (TWRC_FAILURE);
	}

	// We should be in TWAIN state 1, make sure that this is true, if not fail
	if (m_etwnstate != TWN_STATE_1)
	{
		Log("OpenDSM executed in the wrong state: %d\n",m_etwnstate);
		return (TWRC_FAILURE);
	}
	
	// Now we're ready to try and load the DSM...
	m_pvDSM = dlopen(TWAIN_DSM, RTLD_LAZY | RTLD_GLOBAL);
	if (!m_pvDSM)
	{
		Log("Error Loading Shared Library: %s\n",dlerror());
		return (TWRC_FAILURE);
	}

	// If we've gotten this far then the DSM is loaded and we just need to get
	// a pointer to the entry function, DSM_Entry.
	m_pfnDsmEntryProc = (DSMENTRYPROC)dlsym(m_pvDSM,"DSM_Entry");
	if (!m_pfnDsmEntryProc)
	{
		Log("Error Loading Shared Procedure: %s\n",dlerror());
		return (TWRC_FAILURE);
	}

	// The last step of this process is to call the Entry function to open
	// the DSM and give us a way to talk to the driver

	// To do this the DS identity has to be NULL
	memset(&m_twidentityDs,0,sizeof(m_twidentityDs));
	m_ptwidentityDs = 0;

	// Now call the entry function. We'll do this using this classes Entry
	// member to make things easier.
	sts = Entry
		  (
			DG_CONTROL,
			DAT_PARENT,
			MSG_OPENDSM,
			(TW_MEMREF)NULL
		  );
	// Check for errors
	if (sts != TWRC_SUCCESS)
	{
		Log("Entry(DAT_PARENT/MSG_OPENDSM) failed.\n");
		return (TWRC_FAILURE);
	}

	// Determine if we're talking to a TWAIN 2.0 compliant DSM
	if (m_twidentityApp.SupportedGroups & DF_DSM2)
	{
		m_blTWAIN2 = true;
		sts = GetEntrypoint();
		if (sts != TWRC_SUCCESS)
		{
			Log("Entry(DAT_ENTRYPOINT/MSG_GET) failed.\n");
			return (TWRC_FAILURE);
		}
	}

	// If we're here then everything worked, so we officially move to
	// TWAIN state 3 and we're done.
	m_etwnstate = TWN_STATE_3;
	
	return (TWRC_SUCCESS);
}


//////////////////////////////////////////////////////////////////////////////
//	Description:
//		This function tells the DSM to close and frees the handle to the
//		data source manager shared library.
//
//	Parameters:
//		None
//
//	Returns:
//		None
//////////////////////////////////////////////////////////////////////////////
void CSTTwain::CloseDSM
(
	void
)
{
	int 		sts;		// stores the status returned by the TWAIN call
		
	// We need to make sure that we're in TWAIN state 3 (or lower) before we
	// can close.
	if (m_etwnstate > TWN_STATE_3)
	{
		Log("CloseDSM executed in wrong state: %d\n",m_etwnstate);
		return;
	}

	// The driver identiry must be NULL for this call
	m_ptwidentityDs = 0;

	// Call DSM_Entry (using the Entry member) to close the DSM
	if (m_pvDSM)	// make sure the DSM is open first
	{
		sts = Entry(
					DG_CONTROL,
					DAT_PARENT,
					MSG_CLOSEDSM,
					(TW_MEMREF)NULL
				   );

		if (sts == TWRC_SUCCESS)
		{
			// We assume everything went to plan and now we'll close
			// the shared library.
			dlclose(m_pvDSM);
			
			// Now we reset some member variables to indicated that the DSM
			// is now closed.
			m_pvDSM				= 0;
			m_twidentityApp.Id	= 0;

			// Fall into TWAIN state 1
			m_etwnstate			= TWN_STATE_1;
		}
	}

	return;
}


//////////////////////////////////////////////////////////////////////////////
//	Description:
//		Query the DSM for a list of available data sources (aka drivers)
//
//	Parameters:
//		None
//
//	Returns:
//		vector<TW_IDENTITY>	- List of all data sources found. If no data
//							  sources are found then the vector will be empty.
//////////////////////////////////////////////////////////////////////////////
std::vector<TW_IDENTITY> CSTTwain::ListDS
(
	void
)
{
	TW_INT16					retValue;
	TW_IDENTITY					srcId;
	std::vector<TW_IDENTITY>	dsList;

	// To get the list we will call the DSM Entry to get the first data source
	// and we'll loop until we can no longer get another data source
	retValue = Entry(DG_CONTROL,DAT_IDENTITY,MSG_GETFIRST,(TW_MEMREF)&srcId);
	if (retValue == TWRC_FAILURE)
	{
		// If the call failed then no data sources could be found, so
		// make sure that the list is clear and then return it.
		dsList.clear();
	}
	else
	{
		// If the call did not fail we'll enter the loop to add the driver to
		// the list and look for more
		while ( retValue == TWRC_SUCCESS )
		{
			ConvertTwIdentity(srcId,false);
			dsList.push_back(srcId);

			// Attempt to get the next data source
			retValue = Entry(
							 DG_CONTROL,
							 DAT_IDENTITY,
							 MSG_GETNEXT,
							 (TW_MEMREF)&srcId
							);
		}
	}

	// Now that we've found all the data sources, we're done
	return dsList;
}



//////////////////////////////////////////////////////////////////////////////
//	Description:
//		This function is used to open the driver.
//
//	Parameters:
//		a_twidentityDs		- identity of the driver we're opening
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
//////////////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::OpenDS
(
	TW_IDENTITY a_twidentityDs
)
{
	int 		sts;		// stores the status returned by the TWAIN call

	// Verify that we are in TWAIN state 3 (i.e. the DSM is open)
	if (m_etwnstate != TWN_STATE_3)
	{
		Log("OpenDS executed in wrong state: %d\n",m_etwnstate);
		return (TWRC_FAILURE);
	}

	// Zero the DS identity variable and then copy (numberics first) the
	// function parameter into the member variable so we'll have a copy
	// of it for later.
	m_twidentityDs.Id 				= a_twidentityDs.Id;
	m_twidentityDs.Version 			= a_twidentityDs.Version;
	m_twidentityDs.ProtocolMajor	= a_twidentityDs.ProtocolMajor;
	m_twidentityDs.ProtocolMinor	= a_twidentityDs.ProtocolMinor;
	m_twidentityDs.SupportedGroups	= a_twidentityDs.SupportedGroups;

	// The reinterpret_casts are essential since on Mac OS X the TWAIN strings
	// are in Pascal format and are defined as unsigned chars.
	strncpy(
			reinterpret_cast<char*>(m_twidentityDs.Manufacturer),
			reinterpret_cast<const char*>(a_twidentityDs.Manufacturer),
			sizeof(m_twidentityDs.Manufacturer)
		   );
	strncpy(
			reinterpret_cast<char*>(m_twidentityDs.ProductFamily),
			reinterpret_cast<const char*>(a_twidentityDs.ProductFamily),
			sizeof(m_twidentityDs.ProductFamily)
		   );
	strncpy(
			reinterpret_cast<char*>(m_twidentityDs.ProductName),
			reinterpret_cast<const char*>(a_twidentityDs.ProductName),
			sizeof(m_twidentityDs.ProductName)
		   );
	ConvertTwIdentity(m_twidentityDs, true);

	// No DS is open yet, so we need to make sure that the pointer to the
	// identity that we store is NULL.
	m_ptwidentityDs = 0;

	// Now that we're setup let's actually try and open the DS.
	sts = Entry(
				DG_CONTROL,
				DAT_IDENTITY,
				MSG_OPENDS,
				(TW_MEMREF)&m_twidentityDs
			   );
	if (sts != TWRC_SUCCESS)
	{
		Log("Entry(DAT_IDENTITY/MSG_OPENDS) failed.\n");
		return (TWRC_FAILURE);
	}

	// The open DS call was successful, let's assign the pointer member
	// variable that we'll need for later.
	m_ptwidentityDs = &m_twidentityDs;

	// With all that finished we're now is TWAIN state 4
	m_etwnstate = TWN_STATE_4;
	
	// On Linux TWAIN wants the callback to be associated with the DS, but
	// on Mac OS/X the callback should not be. So if we're not on OS/X do
	// this here.
	#ifndef __APPLE__
		TW_CALLBACK	twcallback;	// Our xfer ready callback
		memset(&twcallback,0,sizeof(twcallback));
		twcallback.CallBackProc = (TW_MEMREF)TWAINCallback;
		sts = Entry(
					DG_CONTROL,
					DAT_CALLBACK,
					MSG_REGISTER_CALLBACK,
					(TW_MEMREF)&twcallback
			   	   );
		if (sts != TWRC_SUCCESS)
		{
			Log( "Entry(DAT_CALLBACK/MSG_REGISTER_CALLBACK) failed.\n");
			return (TWRC_FAILURE);
		}
	#endif
	
	return (TWRC_SUCCESS);
}



//////////////////////////////////////////////////////////////////////////////
//	Description:
//		Closes the data source (driver).
//
//	Parameters:
//		(none)
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
//////////////////////////////////////////////////////////////////////////////
void CSTTwain::CloseDS
(
	void
)
{
	int 		sts;		// stores the status returned by the TWAIN call

	// Make sure the we are in TWAIN state 4 (the data source is open)
	if (m_etwnstate != TWN_STATE_4)
	{
		Log("CloseDS executed in wrong state: %d\n",m_etwnstate);
		return;
	}

	// In Order to close the data source the pointer used in the
	// DSM_Entry function must be NULL
	m_ptwidentityDs = 0;

	// Call the DSM_Entry function to close the driver. It is assumed that
	// the driver closes.
	sts = Entry(
				DG_CONTROL,
				DAT_IDENTITY,
				MSG_CLOSEDS,
				(TW_MEMREF)&m_twidentityDs
			   );

	// Now that the data source is closed we're in TWAIN state 3
	if (sts == TWRC_SUCCESS)
	{
		m_etwnstate = TWN_STATE_3;
		memset(&m_twidentityDs,0,sizeof(m_twidentityDs));
	}
	
	return;
}



//////////////////////////////////////////////////////////////////////////////
//	Description:
//		Setup the application identity.  The TWAIN DSM uses this to
//		uniquely identify the application, assigning it an ID when
//		the DSM is first opened. This must be called before the DSM
//		can be opened.
//
//	Parameters:
//		a_szManufacturer				- company name
//		a_szProductFamily				- product name
//		a_szProductName				- model name
//		a_szVersionInfo				- generic version info
//		a_twuint16ProtocolMajor		- TWAIN.H major
//		a_twuint16ProtocolMinor		- TWAIN.H minor
//		a_twuint32SupportedGroups	- DF_APP2 | DG_CONTROL | DG_IMAGE
//		a_twuint16VersionCountry		- TWCY_*
//		a_twuint16VersionLanguage	- TWLG_*
//		a_twuint16VersionMajorNum	- driver major
//		a_twuint16VersionMinorNum	- driver minor
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
//////////////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::SetIdentity
(
	const char*		a_szManufacturer,
	const char*		a_szProductFamily,
	const char*		a_szProductName,
	const char*		a_szVersionInfo,
	TW_UINT16		a_twuint16ProtocolMajor,
	TW_UINT16		a_twuint16ProtocolMinor,
	TW_UINT32		a_twuint32SupportedGroups,
	TW_UINT16		a_twuint16VersionCountry,
	TW_UINT16		a_twuint16VersionLanguage,
	TW_UINT16		a_twuint16VersionMajorNum,
	TW_UINT16		a_twuint16VersionMinorNum
)
{
	// Verify that we are in TWAIN state 1
	if (m_etwnstate != TWN_STATE_1)
	{
		Log("SetIdentity executed in wrong state: %d\n",m_etwnstate);
		return (TWRC_FAILURE);
	}

	// Make sure the ID is clear...
	m_twidentityApp.Id = 0;


	// Now we will copy the strings into the application identity member
	// variable. Linux uses the UTF8 encoding standard so we can use the
	// standard strncpy function to do this.
	// Copy the Manufacturer string
	strncpy(
			(char*)m_twidentityApp.Manufacturer,
			a_szManufacturer,
			sizeof(m_twidentityApp.Manufacturer)
		   );
	
	// Copy the Product Family string
	strncpy(
			(char*)m_twidentityApp.ProductFamily,
			a_szProductFamily,
			sizeof(m_twidentityApp.ProductFamily)
	       );

	// Copy the Product Name string
	strncpy(
			(char*)m_twidentityApp.ProductName,
			a_szProductName,
			sizeof(m_twidentityApp.ProductName)
		   );

	// Copy the Version Info string
	strncpy(
			(char*)m_twidentityApp.Version.Info,
			a_szVersionInfo,
			sizeof(m_twidentityApp.Version.Info)
		   );

	// This is the application identity that will be sent to the DSM
	// if we're on Mac OS/X then the strings need to be PASCAL format
	ConvertTwIdentity(m_twidentityApp, true);

	// Now we will copy the numeric values into the application identity
	// member variable.
	m_twidentityApp.ProtocolMajor		= a_twuint16ProtocolMajor;
	m_twidentityApp.ProtocolMinor		= a_twuint16ProtocolMinor;
	m_twidentityApp.SupportedGroups		= a_twuint32SupportedGroups;
	m_twidentityApp.Version.Country		= a_twuint16VersionCountry;
	m_twidentityApp.Version.Language	= a_twuint16VersionLanguage;
	m_twidentityApp.Version.MajorNum	= a_twuint16VersionMajorNum;
	m_twidentityApp.Version.MinorNum	= a_twuint16VersionMinorNum;

	return (TWRC_SUCCESS);
}

//////////////////////////////////////////////////////////////////////////////
//	Description:
//		The entry prodedure to the DSM. This uses the application identity
//		member variable and the data source identity memeber variable
//		to simple the standard DSM_Entry call.
//
//	Parameters:
//		a_twuint16DG	- Data Group
//		a_twuint16DAT	- Data Access Type
//		a_twuint16MSG	- Message
//		a_twmemref		- Pointer to data
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
//////////////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::Entry
(
	TW_UINT16		a_twuint16DG,
	TW_UINT16		a_twuint16DAT,
	TW_UINT16		a_twuint16MSG,
	TW_MEMREF		a_twmemref
)
{
	TW_UINT16 sts;

	// Error Checking: Make sure the the DSM is open
	if (!m_pfnDsmEntryProc)
	{
		Log("The Driver Must be Opened Before Entry.\n");
		return (TWRC_FAILURE);
	}

	// Now we'll call the DSM_Entry function. We will trap any errors so
	// that the application won't crash, even if the driver does.
	try
	{
		sts = (*m_pfnDsmEntryProc)
				(
				 &m_twidentityApp,
				 m_ptwidentityDs,
				 a_twuint16DG,
				 a_twuint16DAT,
				 a_twuint16MSG,
				 a_twmemref
				);
	}
	catch(...)
	{
		Log("m_pfnDsmEntryProc crashed.\n");
		sts = TWRC_FAILURE;
	}

	// Now return the status of the DSM_Entry call
	return (sts);
}



//////////////////////////////////////////////////////////////////////////////
//	Description:
//		This function sets a single value according to the TWAIN specification
//
//	Parameters:
//		a_twuint16Tag	- The TWAIN Tag for the value
//		a_twuint16Type	- The TWAIN Type for the value
//		a_twmemrefValue	- The TWAIN value itself
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
//////////////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::SetOneValue
(
	TW_UINT16	a_twuint16Tag,
	TW_UINT16	a_twuint16Type,
	TW_MEMREF	a_twmemrefValue
)
{
	TW_UINT16		sts;			// The status of the Entry call
	TW_CAPABILITY	twcapability;	// TWAIN capability data
	TW_ONEVALUE		*ptwonevalue;	// Pointer to the TWAIN one value data

	// Make sure we are in the correct state to set the value (state 4)
	if (m_etwnstate != TWN_STATE_4)
	{
		Log("SetOneValue executed in wrong state: %d\n",m_etwnstate);
		return (TWRC_FAILURE);
	}
 
	// Setup the TWAIN capability structure according to the specification

	twcapability.Cap		= a_twuint16Tag;
	twcapability.ConType	= TWON_ONEVALUE;

	// Allocate memory for the container and verify it was allocated
	twcapability.hContainer = MemAlloc(sizeof(*ptwonevalue)+8192);
	if (!twcapability.hContainer)
	{
		Log("Failed to allocate memory for %d.\n",a_twuint16Tag);
		return (TWRC_FAILURE);
	}
	
	// Now setup the container
	ptwonevalue = (TW_ONEVALUE*)MemLock(twcapability.hContainer);
	if (ptwonevalue == NULL)
	{
		// Log the error
		Log("SetOneValue: Failed to Lock Memory!\n");

		// Even if the lock failed we still might have to free the memory
		if(twcapability.hContainer)
		{
			MemFree(twcapability.hContainer);
			twcapability.hContainer = 0;
		}

		return (TWRC_FAILURE);
	}
	
	// Copy the value
	ptwonevalue->ItemType = a_twuint16Type;
	memcpy(&ptwonevalue->Item, a_twmemrefValue, GetDatatypeSize(a_twuint16Type));
	
	// Unlock the memory
	MemUnlock(twcapability.hContainer);

	// Send the Command to the Driver
	sts = Entry(
				DG_CONTROL,
				DAT_CAPABILITY,
				MSG_SET,
				(TW_MEMREF)&twcapability
			   );

	// Free the container
	if(twcapability.hContainer)
	{
		MemFree(twcapability.hContainer);
		twcapability.hContainer = 0;
	}
	
	// Check to make sure that the entry call succeeded
	if (sts != TWRC_SUCCESS)
	{
		Log("Entry(DAT_CAPABILITY/MSG_SET %d) failed.\n",a_twuint16Tag);
	}

	return (sts);
}



//////////////////////////////////////////////////////////////////////////////
//	Description:
//		This function sets a single value according to the TWAIN specification
//
//	Parameters:
//		a_twuint16Tag	- The TWAIN Tag for the value
//		a_twmemrefValue	- The TWAIN value itself
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
//////////////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::GetOneValue
(
	TW_UINT16	a_twuint16Tag,
	TW_MEMREF	a_twmemrefValue
)
{
	TW_UINT16		sts;			// The status of the Entry call
	TW_CAPABILITY	twcapability;	// TWAIN capability data
	TW_ONEVALUE		*ptwonevalue;	// Pointer to the TWAIN one value data

	// Make sure we are in the correct state to get the value (state 4)
	if (m_etwnstate != TWN_STATE_4)
	{
		Log("GetOneValue executed in wrong state: %d\n",m_etwnstate);
		return (TWRC_FAILURE);
	}
 
	// Setup the TWAIN capability structure according to the specification
	twcapability.Cap		= a_twuint16Tag;
	twcapability.ConType	= TWON_ONEVALUE;
	twcapability.hContainer	= NULL;

	// Send the Command to get the value to the driver
	sts = Entry(
				DG_CONTROL,
				DAT_CAPABILITY,
				MSG_GETCURRENT,
				(TW_MEMREF)&twcapability
			   );

	// Make sure that the command succeeded
	if (sts != TWRC_SUCCESS)
	{
		Log("Entry(DAT_CAPABILITY/MSG_GETCURRENT %d) failed.\n",a_twuint16Tag);
		return (sts);
	}

	// Now we'll look at the type of value returned and copy it into the function
	// parameter so that it can be returned to the caller.
	ptwonevalue = (TW_ONEVALUE*)MemLock(twcapability.hContainer);
	if (ptwonevalue == NULL)
	{
		// Log the error
		Log("GetOneValue: Failed to Lock Memory!\n");
		
		// Even, if we couldn't lock the memory we may still have to free it
		if (twcapability.hContainer)
		{
			MemFree(twcapability.hContainer);
			twcapability.hContainer = 0;
		}

		return (TWRC_FAILURE);
	}
	
	// Copy the value
	memcpy(a_twmemrefValue, &ptwonevalue->Item, GetDatatypeSize(ptwonevalue->ItemType));

	// Unlock the memory
	MemUnlock(twcapability.hContainer);

	// Now, as per the TWAIN spec, we need to free the container
	if(twcapability.hContainer)
	{
		MemFree(twcapability.hContainer);
		twcapability.hContainer = 0;
	}
	
	// Check to make sure that the entry call succeeded
	if (sts != TWRC_SUCCESS)
	{
		Log("Entry(DAT_CAPABILITY/MSG_GET %d) failed.\n",a_twuint16Tag);
	}

	// Return the status of the Entry call
	return (sts);
}



///////////////////////////////////////////////////////////////////////
//	Description:
//		GetCapability is used to simply reading a capability from the
//		data source. It acts on the currently open data sources and
//		will fail if no data source is currently open.
//
//	Parameters:
//		a_twuint16Cap	- The TWAIN capability to get
//		a_twcapability	- The TWAIN capability structure to fill in
//						- This structure must be freed by the caller.
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
///////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::GetCapability
(
	TW_UINT16		a_twuint16Cap,
	pTW_CAPABILITY	a_ptwcapability
)
{
	TW_UINT16		sts;			// The status of the Entry call
	
	// Make sure we are in the correct state to set the value (state 4)
	if (m_etwnstate != TWN_STATE_4)
	{
		Log("GetCapability executed in wrong state: %d\n",m_etwnstate);
		return (TWRC_FAILURE);
	}

	// Now we setup the TW_CAPABILITY to query the source as described
	// in the TWAIN 1.9 spec, page 4-69
	a_ptwcapability->Cap		= a_twuint16Cap;
	a_ptwcapability->ConType	= TWON_DONTCARE16;
	a_ptwcapability->hContainer	= NULL;

	// Now send the command to the data source using the Entry function
	sts = Entry(
		  		DG_CONTROL,
		  		DAT_CAPABILITY,
		  		MSG_GET,
		  		(TW_MEMREF)a_ptwcapability
			   );

	// Check to make sure that the entry call succeeded
	if (sts != TWRC_SUCCESS)
	{
		Log("Entry(DAT_CAPABILITY/MSG_GET %d) failed.\n", a_twuint16Cap);
	}

	// Return the status of the Entry call
	return (sts);
}



///////////////////////////////////////////////////////////////////////
//	Description:
//		Set Capability is used to simply setting the value of a
//		capability for the current data source. If no data source
//		is open the call will fail. In addition, the caller must
//		have allocated a_twmemrefValue and is reponsible for
//		freeing it.
//
//	Parameters:
//		a_twuint16Cap		- The TWAIN Tag for the value
//		a_twuint16ConType	- The TWAIN Container Type
//		a_twmemrefValue		- The TWAIN Container Iteself
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
///////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::SetCapability
(
	pTW_CAPABILITY	a_ptwcapability
)
{

	TW_UINT16		sts;			// The status of the funcion call
	
	// Make sure we are in the correct state to set the value (state 4)
	if (m_etwnstate != TWN_STATE_4)
	{
		Log("SetCapability executed in wrong state: %d\n",m_etwnstate);
		return (TWRC_FAILURE);
	}
	
	// The capability structure should already be setup so we'll
	// just go ahead and send down the command
	
	// Now send the command to the driver
	sts = Entry(
				DG_CONTROL,
				DAT_CAPABILITY,
				MSG_SET,
				(TW_MEMREF)&a_ptwcapability
			   );

	// Check to make sure that the entry call succeeded
	if (sts != TWRC_SUCCESS)
	{
		Log("Entry(DAT_CAPABILITY/MSG_SET %d failed.\n",a_ptwcapability->Cap);
	}

	// Return the status of the Entry call
	return (sts);
	
}


///////////////////////////////////////////////////////////////////////////////
//	Description:
//		GetPixelType returns a TW_UINT16 indicating the pixel type
//		the driver is currently set to use.
//
//	Parameters:
//		None
//
//	Returns:
//		TWPT_BW
//		TWPT_GRAY
//		TWPT_RGB
//		TWPT_PALETTE
//		TWPT_CMY
//		TWPT_CMYK
//		TWPT_YUV
//		TWPT_YUVK
//		TWPT_CIEXYZ
///////////////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::GetPixelType
(
	void
)
{
	TW_UINT16	sts;					// Holds the status
	TW_UINT16 	twuint16PixelType;		// Holds the pixel type

	// Use the GetOneValue function to get the value for ICAP_PIXELTYPE
	sts = GetOneValue(ICAP_PIXELTYPE, (TW_MEMREF)&twuint16PixelType);

	// Check the status of the call
	if ( sts == TWRC_FAILURE )
	{
		Log( "Unable to get pixel type.\n");
		return (sts);
	}

	return (twuint16PixelType);
}



///////////////////////////////////////////////////////////////////////////////
//	Description:
//		SetPixelType tell the driver what pixel type to use.
//
//	Parameters:
//		a_twuint16PixelType	- Indicates the type of pixel to use
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
///////////////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::SetPixelType
(
	TW_UINT16 a_twuint16PixelType
)
{
	TW_UINT16	sts;				// Holds the status

	// Use the SetOneValue function to set the value for ICAP_PIXELTYPE
	sts = SetOneValue(ICAP_PIXELTYPE, TWTY_UINT16, (TW_MEMREF)&a_twuint16PixelType);

	// Check the status of the call
	if ( sts == TWRC_FAILURE )
	{
		Log( "Unable to set pixel type.\n");
	}

	return(sts);
}

///////////////////////////////////////////////////////////////////////////////
//	Description:
//		GetResolution returns the resolution the driver is currently
// 		set to scan at. It assumes that X and Y resolutions are equal.
//
//	Parameters:
//		None
//
//	Returns:
//		float	resolution
///////////////////////////////////////////////////////////////////////////////
float CSTTwain::GetResolution
(
	void
)
{
	TW_UINT16	sts;				// Holds the status
	TW_FIX32 	twfix32XRes;		// Holds the x resolution
	TW_FIX32	twfix32YRes;		// Holds the y resolution
	float		fXResolution,		// Holds the converted X Resolution
				fYResolution;		// Holds the converted Y Resolution
	
	// Use the GetOneValue function to get the value for ICAP_XRESOLUTION
	sts = GetOneValue(ICAP_XRESOLUTION, (TW_MEMREF)&twfix32XRes);

	// Check the status of the call
	if ( sts == TWRC_FAILURE )
	{
		Log( "Unable to get X resolution.\n");
		return (-1.0);
	}

	// Convert the value
	fXResolution = Fix32ToFloat(twfix32XRes);

	// Use the GetOneValue function to get the value for ICAP_XRESOLUTION
	sts = GetOneValue(ICAP_YRESOLUTION, (TW_MEMREF)&twfix32YRes);

	// Check the status of the call
	if ( sts == TWRC_FAILURE )
	{
		Log( "Unable to get Y resolution.\n");
		return (-1.0);
	}

	// Convert the Value
	fYResolution = Fix32ToFloat(twfix32YRes);

	// Compare the two resolutions
	if ( fXResolution != fYResolution )
	{
		Log(
			"X and Y Resolutions Are NOT Equal. X: %f Y: %f\n",
			fXResolution,
			fYResolution
			);
		return (-1.0);
	}

	return (fXResolution);
}

///////////////////////////////////////////////////////////////////////////////
//	Description:
//		SetResolution sets the resolution the driver should scan at.
//		It sets both the X and Y resolutions, making them equal.
//
//	Parameters:
//		a_twfix32Resolution	- The requested resolution
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
///////////////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::SetResolution
(
	float a_fResolution
)
{
	TW_FIX32	twfix32Resolution;		// Holds the converted resolution
	TW_UINT16	sts;					// Holds the status


	// Convert the Value
	twfix32Resolution = FloatToFix32(a_fResolution);
	
	// Use the SetOneValue function to set the value for ICAP_XRESOLUTION
	sts = SetOneValue(ICAP_XRESOLUTION, TWTY_FIX32, (TW_MEMREF)&twfix32Resolution);

	// Check the status of the call
	if ( sts == TWRC_FAILURE )
	{
		Log("Unable to set X resolution: %f.\n", a_fResolution);
		return (sts);
	}

	// Use the SetOneValue function to set the value for ICAP_YRESOLUTION
	sts = SetOneValue(ICAP_YRESOLUTION, TWTY_FIX32, (TW_MEMREF)&twfix32Resolution);

	// Check the status of the call
	if ( sts == TWRC_FAILURE )
	{
		Log("Unable to set Y resolution: %f.\n", a_fResolution);
		return (sts);
	}

	return(sts);
}


///////////////////////////////////////////////////////////////////////////////
//	Description:
//		SetDuplex sets the driver to scan in duplex mode.
//
//	Parameters:
//		a_twboolEnabled	- Enable/Disable Duplex Mode
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
///////////////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::SetDuplexEnabled
(
	TW_BOOL	a_twboolEnabled
)
{
	TW_UINT16	sts;				// Holds the status

	// Use the SetOneValue function to set the value for ICAP_DUPLEX
	sts = SetOneValue(CAP_DUPLEXENABLED, TWTY_BOOL, (TW_MEMREF)&a_twboolEnabled);

	// Check the status of the call
	if ( sts == TWRC_FAILURE )
	{
		Log( "Unable to set duplex mode: %d.\n",a_twboolEnabled);
	}

	return(sts);
}

///////////////////////////////////////////////////////////////////////////////
//	Description:
//		GetDuplex returns whether or not the driver is set to scan in
//		duplex mode.
//
//	Parameters:
//		None
//
//	Returns:
//		TW_BOOL	- TRUE if duplex is enabled.
///////////////////////////////////////////////////////////////////////////////
TW_BOOL CSTTwain::GetDuplexEnabled
(
	void
)
{
	TW_UINT16	sts;					// Holds the status
	TW_BOOL 	twboolEnabled;			// Holds the pixel type

	// Use the GetOneValue function to get the value for ICAP_DUPLEX
	sts = GetOneValue(CAP_DUPLEXENABLED, (TW_MEMREF)&twboolEnabled);

	// Check the status of the call
	if ( sts == TWRC_FAILURE )
	{
		Log( "Unable to get duplex mode.\n");
		return (sts);
	}

	return (twboolEnabled);
}



///////////////////////////////////////////////////////////////////////////////
//	Description:
//		SetTransferMode tell the driver what transfer mode to use.
//
//	Parameters:
//		a_twuint16XferMode	- Indicates the transfer mode to use
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
///////////////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::SetTransferMode
(
	TW_UINT16 a_twuint16XferMode
)
{
	TW_UINT16	sts;				// Holds the status

	// Use the SetOneValue function to set the value for ICAP_XFERMECH
	sts = SetOneValue(ICAP_XFERMECH, TWTY_UINT16, (TW_MEMREF)&a_twuint16XferMode);

	// Check the status of the call
	if ( sts == TWRC_FAILURE )
	{
		Log( "Unable to set transfer mode.\n");
	}

	return(sts);
}



///////////////////////////////////////////////////////////////////////////////
//	Description:
//		GetTransferMode returns the transfer mode the driver will use.
//
//	Parameters:
//		None
//
//	Returns:
//		TWSX_NATIVE
//		TWSX_FILE
//		TWSX_MEMORY
///////////////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::GetTransferMode
(
	void
)
{
	TW_UINT16	sts;					// Holds the status
	TW_UINT16 	twuint16XferMode;		// Holds the transfer mode

	// Use the GetOneValue function to get the value for ICAP_XFERMECH
	sts = GetOneValue(ICAP_XFERMECH, (TW_MEMREF)&twuint16XferMode);

	// Check the status of the call
	if ( sts == TWRC_FAILURE )
	{
		Log( "Unable to get transfer mode.\n");
		return (sts);
	}

	return (twuint16XferMode);
}

//////////////////////////////////////////////////////////////////////////////
//	Description:
//		This function retrieves the image information
//
//	Parameters:
//		a_ptwimageinfo	- pointer to an image info structure
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
//////////////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::ImageInfo
(
	TW_IMAGEINFO	*a_ptwimageinfo
)
{
	TW_UINT16 sts;

	// Make sure we're in the correct TWAIN state (6)
	if (m_etwnstate < TWN_STATE_6)
	{
		Log("ImageInfo executed in wrong state: %d\n",m_etwnstate);
		return (TWRC_FAILURE);
	}

	// Zero the image info sturcture so that we know it's clean
	memset(a_ptwimageinfo,0,sizeof(*a_ptwimageinfo));

	// Send the command to get the image info from the driver
	sts = Entry(
				DG_IMAGE,
				DAT_IMAGEINFO,
				MSG_GET,
				(TW_MEMREF)a_ptwimageinfo
			   );

	// Check to make sure the operation succeeded
	if (sts != TWRC_SUCCESS)
	{
		Log("Entry(DAT_IMAGEINFO/MSG_GET) failed.\n");
	}

	return (sts);
}


//////////////////////////////////////////////////////////////////////////////
//	Description:
//		This function enables the driver. It also determines if the driver's
//		user interface should be shown
//
//	Parameters:
//		a_boolShowUI	- whether or not to show the driver's UI
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
//////////////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::Enable
(
	TW_BOOL	 a_boolShowUi,
	TW_BOOL	 a_boolShowUiOnly
)
{
	TW_UINT16 sts;
	TW_UINT16 twuint16MSG;
	
	// Make certain we are in the correct TWAIN state (4)
	if (m_etwnstate != TWN_STATE_4)
	{
		Log("Enable executed in wrong state: %d\n",m_etwnstate);
		return (TWRC_FAILURE);
	}

	// Setup the structure based on whether we're scanning or showing the UI only
	if (!a_boolShowUiOnly)
	{
		// Copy the show UI flag into user interface structure
		m_twuserinterface.ShowUI = a_boolShowUi;

		// Modal support is nasty, so we're not going to support it...
		m_twuserinterface.ModalUI = 0;

		// Set the message
		twuint16MSG = MSG_ENABLEDS;
	}
	else
	{
		// Set up the structure to show the UI
		m_twuserinterface.ShowUI = 1;
		m_twuserinterface.ModalUI = 0;

		// Set the message
		twuint16MSG = MSG_ENABLEDSUIONLY;
	}
		
		
	// We're not working under WINDOWS so we don't need the parent handle
	m_twuserinterface.hParent = 0;

	// There is a possible race condition where the driver might report
	// XferReady before we return from this call. To avoid this we'll
	// fake being in state 5.
	m_etwnstate = TWN_STATE_5;

	// Send the Enable command to the driver
	sts = Entry(
				DG_CONTROL,
				DAT_USERINTERFACE,
				twuint16MSG,
				(TW_MEMREF)&m_twuserinterface
			   );
	
	// Check the result
	if (sts != TWRC_SUCCESS)
	{
		// Switch back into our actual state, if the call failed
		m_etwnstate = TWN_STATE_4;
		Log("Entry(DAT_USERINTERFACE/MSG_ENABLEDS) failed.\n");
	}

	return (sts);
}



//////////////////////////////////////////////////////////////////////////////
//	Description:
//		Disables the driver
//
//	Parameters:
//		(none)
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
//////////////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::Disable
(
	void
)
{
	TW_UINT16 sts;

	// Validate...
	if (m_etwnstate < TWN_STATE_5)
	{
		Log("Disable executed in wrong state: %d.\n",m_etwnstate);
		return (TWRC_FAILURE);
	}

	m_twuserinterface.ShowUI = 0;
	m_twuserinterface.ModalUI = 0;
	m_twuserinterface.hParent = 0;

	// Send the Disable command to the driver
	sts = Entry(
				DG_CONTROL,
				DAT_USERINTERFACE,
				MSG_DISABLEDS,
				(TW_MEMREF)&m_twuserinterface
			   );

	// Check the status of the command
	if (sts != TWRC_SUCCESS)
	{
		Log("Entry(DAT_USERINTERFACE/MSG_DISABLEDS) failed.\n");
		return (TWRC_FAILURE);
	}

	// Now we're back in state 4
	m_etwnstate = TWN_STATE_4;
	
	return (sts);
}



//////////////////////////////////////////////////////////////////////////////
//	Description:
//		Get the current TWAIN state.
//
//	Parameters:
//		(none)
//
//	Returns:
//		ETWNSTATE
//////////////////////////////////////////////////////////////////////////////
CSTTwain::ETWNSTATE CSTTwain::GetState
(
	void
)
{
	return (m_etwnstate);
}



//////////////////////////////////////////////////////////////////////////////
//	Description:
//		Managing the TWAIN states can be a little weird if you're still
//		new to them.  This method takes us from our current state down
//		to some desired state (given in the argument)...
//
//	Parameters:
//		a_etwnstate		- state we want to get to
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
//////////////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::SetState
(
	ETWNSTATE	a_etwnstate
)
{
	TW_UINT16	sts;

	//	TWAIN STATE: 7 -> 6
	//	End the transfer...we only care about the status return for this one
	//	call.  If the status fails for the other then we still want to try to
	//	get to our desired state (we may be out of sync with the driver), but
	//	we can have real errors with this call, such as if the pod is opened
	//	on the device during scanning...
	if ( (a_etwnstate <  m_etwnstate) && (m_etwnstate == TWN_STATE_7) )
	{
		sts = PendingXfers(MSG_ENDXFER);
		if (sts != TWRC_SUCCESS)
		{
			return (sts);
		}
	}

	//	TWAIN STATE: 6 -> 5
	//	This will end image capture.
	if ( (a_etwnstate <  m_etwnstate) && (m_etwnstate == TWN_STATE_6) )
	{
		PendingXfers(MSG_RESET);
	}

	//	TWAIN STATE: 5 -> 4
	//	This will diable the driver.
	if ( (a_etwnstate <  m_etwnstate) && (m_etwnstate == TWN_STATE_5))
	{
		Disable();
	}

	//	TWAIN STATE: 4 -> 3
	//	This will close the driver.
	if ( (a_etwnstate <  m_etwnstate) && (m_etwnstate == TWN_STATE_4) )
	{
		CloseDS();
	}

	//	TWAIN STATE: 3 -> 1
	//	This closes the data source manager
	if ( (a_etwnstate <  m_etwnstate) && (m_etwnstate == TWN_STATE_3) )
	{
		CloseDSM();
	}

	return (TWRC_SUCCESS);
}



//////////////////////////////////////////////////////////////////////////////
//	Description:
//		This function waits for some indication that an image is ready
//		to be transfered. This function is a hack, it is a robust way around
//		the proper mechanism of setting a callback function that responds
//		to when an image is ready for transfer. Refer to the SetCallback
//		member for the proper way to do this.
//
//	Parameters:
//		a_twint32Timeout	- How long to wait (in seconds)
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
//////////////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::WaitForXferReady
(
	TW_INT32	a_twint32Timeout
)
{
	int 			sts;			// Status indicator
	long			ii;				// Iterator
	TW_IMAGEINFO	twimageinfo;	// Holds the image information

		
	// Make sure that we're in the correct TWAIN state (5)
	if (m_etwnstate != TWN_STATE_5)
	{
		Log("WaitForXferReady executed in wrong state: %d\n",m_etwnstate);
		return (TWRC_FAILURE);
	}

	//	Wait for (loop until) we have some indication that the image is ready
	for (ii = 0; ii < a_twint32Timeout; ii++)
	{
		// Try to get the image information
		memset(&twimageinfo,0,sizeof(twimageinfo));
		sts = Entry(
					DG_IMAGE,
					DAT_IMAGEINFO,
					MSG_GET,
					(TW_MEMREF)&twimageinfo
				   );

		// Check the result
		if (sts == TWRC_SUCCESS)
		{
			// Success, we have an image and are done waiting
			m_etwnstate = TWN_STATE_6;
			break;
		}
		
		// If we didn't break, we're still waiting for an image
		sleep(IMAGEWAITTIMEOUT);
	}

	return (TWRC_SUCCESS);
}



//////////////////////////////////////////////////////////////////////////////
//	Description:
//		Do a memory transfer...the application should start by sending in
//		a pointer to a NULL address, and it should send a size of 0.  The
//		method will allocate the needed memory and report the size of that
//		memory.  The application needs to hold on to this information for
//		the next call...
//
//	Parameters:
//		a_pbImage				- pointer to the image memory pointer
//		a_twuint32ImageBytes	- size of allocated memory
//		a_twimageinfo			- information about the image
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
//////////////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::XferMemory
(
	unsigned char	**a_ppbImage,
	TW_UINT32		*a_twuint32ImageBytes,
	TW_UINT32		*a_dwActualBytes,
	TW_IMAGEINFO	*a_ptwimageinfo
)
{
	TW_UINT16		sts;
	TW_UINT32		twuint32BytesCaptured;
	TW_IMAGEMEMXFER	twimagememxfer;
	TW_SETUPMEMXFER	twsetupmemxfer;
	unsigned char*	pbXferBuffer;
		
	// Make sure we're in the correct TWAIN state (6)
	if (m_etwnstate != TWN_STATE_6)
	{
		Log("XferMemory executed in wrong state: %d\n",m_etwnstate);
		return (TWRC_FAILURE);
	}

	// Now we need to find out how the driver prefers to transfer the image
	memset(&twsetupmemxfer,0,sizeof(twsetupmemxfer));
	sts = Entry(
				DG_CONTROL,
				DAT_SETUPMEMXFER,
				MSG_GET,
				(TW_MEMREF)&twsetupmemxfer
			   );
	
	// Check the status
	if (sts != TWRC_SUCCESS)
	{
		Log("Entry(DAT_SETUPMEMXFER/MSG_GET) failed.\n");
		return (TWRC_FAILURE);
	}

	// Let's check to see if memory has been allocated for the image. If it
	// hasn't been, then we'll allocate enough memory to hold a 8.5"x11"
	// 8-bit grayscale image @ 300 dpi.
	if ( (*a_ppbImage == (unsigned char*)NULL) || (*a_twuint32ImageBytes == 0) )
	{
		*a_twuint32ImageBytes = 0x400000;
		*a_ppbImage = (unsigned char*)calloc(*a_twuint32ImageBytes,sizeof(unsigned char));

		// Make sure the memory was allocated
		if (*a_ppbImage == (unsigned char*)NULL)
		{
			Log("calloc (Image) failed.\n");
			return (TWRC_FAILURE);
		}
	}

	// Now we'll allocate a buffer to hold the data we've transferred from the
	// source. It will be of the source's preferred size.
	pbXferBuffer = (unsigned char*)calloc(twsetupmemxfer.Preferred,sizeof(unsigned char));
	if(pbXferBuffer == (unsigned char*)NULL)
	{
		Log("calloc (Transfer Buffer) failed.\n");
		return (TWRC_FAILURE);
	}
	
	// Now that we have memory allocated let's setup the image transfer
	// structure accordingly.
	memset(&twimagememxfer,0,sizeof(twimagememxfer));
	twimagememxfer.Memory.Flags	 = 0;
	twimagememxfer.Memory.Length = twsetupmemxfer.Preferred;
	twimagememxfer.Memory.TheMem = (TW_MEMREF)pbXferBuffer;
	twuint32BytesCaptured		 = 0;

	// intialize the actual bytes transferred
	*a_dwActualBytes = 0;

	// Now we'll actually do the transfer. As long as the memory transfer is
	// successful then we'll continue to transfer data. We won't stop unless we
	// finish or some error occurrs (i.e. we'll transfer the entire image).
	do
	{
		// Everything is setup for the first transfer, so let's do it.
		sts = Entry(DG_IMAGE,
					DAT_IMAGEMEMXFER,
					MSG_GET,
					(TW_MEMREF)&twimagememxfer
				   );

		// PR 11506: Don't try to copy or realloc data if we didn't read any
		if (twimagememxfer.BytesWritten > 0)
		{
			// Next, we'll make sure that we've allocated enough memory for our
			// image and if we haven't we'll allocate more.
			if( (twuint32BytesCaptured + twimagememxfer.BytesWritten) >=
					   *a_twuint32ImageBytes )
			{
				// Allocate an additional 4MB
				*a_twuint32ImageBytes += 0x400000;
				*a_ppbImage = (unsigned char*)realloc(*a_ppbImage,*a_twuint32ImageBytes);

				if(*a_ppbImage == (unsigned char*)NULL)
				{
					Log("realloc (image) failed.\n");
					FREE(pbXferBuffer);
					return (TWRC_FAILURE);
				}
			} //end if((twuint32BytesCaptured ...

			// If we made it here then the transfer was successful. So we now need
			// to copy the data that was transferred into the image buffer.
			memcpy(&(*a_ppbImage)[twuint32BytesCaptured],
					pbXferBuffer,
					twimagememxfer.BytesWritten);
				
			// Record how much data we've transferred so far
			twuint32BytesCaptured += twimagememxfer.BytesWritten;
		}

	} while (sts == TWRC_SUCCESS); // continue while the call is successful

	// Check to make sure that we got our image
	if (sts == TWRC_XFERDONE)
	{
		m_etwnstate = TWN_STATE_7;

		// Now we're in state 7
		// Get the image info and store it
		sts = ImageInfo(a_ptwimageinfo);
		if (sts != TWRC_SUCCESS)
		{
			Log("ImageInfo() failed.\n");
		}

		//	TWAIN STATE: 7 -> 6
		//	Now we'll end the transfer
		sts = SetState(TWN_STATE_6);
		if (sts != TWRC_SUCCESS)
		{
			Log("Ending the transfer failed.");
		}
	}

	// return the actual bytes captured
	*a_dwActualBytes = twuint32BytesCaptured;

	// free the transfer buffer
	FREE(pbXferBuffer);

	return (sts);
}



//////////////////////////////////////////////////////////////////////////////
//	Description:
//		Do a file transfer.
//
//	Parameters:
//		a_szFilename		- string indicating the filename
//		a_ptwpendingxfers	- pointer to a pending transfer structure
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
//////////////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::XferFile
(
	char*		a_szFilename,
	TW_UINT16	a_twuint16FileFormat
)
{
	TW_UINT16	sts;

	// Make sure we're in the correct TWAIN state (6)
	if (m_etwnstate != TWN_STATE_6)
	{
		Log("XferFile executed in wrong state: %d\n",m_etwnstate);
		return (TWRC_FAILURE);
	}

	// Initialize the file transfer structure
	memset(&m_twsetupfilexfer,0,sizeof(m_twsetupfilexfer));

	// Setup the file transfer.
	strncpy(
			(char*)m_twsetupfilexfer.FileName,
			a_szFilename,
			sizeof(m_twsetupfilexfer.FileName)
		   );
	CStringToPascalString((char*)m_twsetupfilexfer.FileName);
	m_twsetupfilexfer.Format = a_twuint16FileFormat;

	// Send the setup file transfer command to the driver
	sts = Entry(
				DG_CONTROL,
				DAT_SETUPFILEXFER,
				MSG_SET,
				(TW_MEMREF)&m_twsetupfilexfer
			   );

	// Check the status
	if (sts != TWRC_SUCCESS)
	{
		Log("Entry(DAT_SETUPFILEXFER/MSG_SET) failed.\n");

		// Unknown error, transfer failed. We'll goto state 5
		SetState(TWN_STATE_5);
		return (TWRC_FAILURE);
	}

	// If the setup succeeded, go ahead and transfer the file
	sts = Entry(
				DG_IMAGE,
				DAT_IMAGEFILEXFER,
				MSG_GET,
				(TW_MEMREF)NULL
			   );
	
	// Check the status 
	if (sts == TWRC_XFERDONE)
	{
		// Transfer is complete, we're now in state 7
		m_etwnstate = TWN_STATE_7;
	}
	else if (sts == TWRC_CANCEL)
	{
		// Transfer was cancelled, signalling we're out of paper
		printf("Out Of Paper.\n");
	}
	else if (sts != TWRC_XFERDONE)
	{
		// An unknown error occurred, the transfer failed
		Log("Entry(DAT_IMAGEFILEXFER/MSG_GET) failed: %d\n",sts);
		
		// Goto TWAIN state 5
		SetState(TWN_STATE_5);
	}

	// Now check to make sure that we've actually got our image
	// and act accordingly.
	if (sts == TWRC_XFERDONE)
	{
		//	TWAIN STATE: 7 -> 6 or 5
		//	End the transfer...
		sts = SetState(TWN_STATE_6);
		if (sts != TWRC_SUCCESS)
		{
			Log("Ending the transfer failed.\n");
		}
	}

	return (sts);
}



//////////////////////////////////////////////////////////////////////////////
//	Description:
//		Do a native transfer.
//
//	Parameters:
//		a_pbitmapinfoheader		- pointer to a DIB handle
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
//////////////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::XferNative
(
	BITMAPINFOHEADER	**a_ppbitmapinfoheader
)
{
	TW_UINT16	sts;

	// Make sure we're in the correct TWAIN state (6)
	if (m_etwnstate != TWN_STATE_6)
	{
		Log("XferNative executed in wrong state: %d\n",m_etwnstate);
		return (TWRC_FAILURE);
	}

	// Send the command to transfer the image to the driver
	sts = Entry(
				DG_IMAGE,
				DAT_IMAGENATIVEXFER,
				MSG_GET,
				(TW_MEMREF)a_ppbitmapinfoheader
			   );

	// Check the result of the command
	if (sts == TWRC_XFERDONE)
	{
		// The transfer is done we're in state 7
		m_etwnstate = TWN_STATE_7;
	}
	else if (sts == TWRC_CANCEL)
	{
		// The transfer was cancelled, meaning we're out of paper
		printf("Out Of Paper.\n");
	}
	else if (sts != TWRC_XFERDONE)
	{
		// Unknown error, transfer failed. We'll goto state 5
		Log("Entry(DAT_IMAGENATIVEXFER/MSG_GET) failed: %d",sts);
		SetState(TWN_STATE_5);
	}

	// Now check to make sure we have our image
	if (sts == TWRC_XFERDONE)
	{
		//	TWAIN STATE: 7 -> 6 or 5
		//	End the transfer.
		sts = SetState(TWN_STATE_6);
		if (sts != TWRC_SUCCESS)
		{
			// Unable to end the transfer
			Log("Ending the transfer failed.\n");
		}
	}

	return (sts);
}



//////////////////////////////////////////////////////////////////////////////
//	Description:
//		This function ends any pending transfers
//
//	Parameters:
//		a_twuint16MSG	- 
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
//////////////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::PendingXfers
(
	TW_UINT16		a_twuint16MSG
)
{
	TW_UINT16 sts;

	// Make sure we're in the correct TWAIN state (6)
	if (m_etwnstate < TWN_STATE_6)
	{
		Log("PendingXfers executed in wrong state: %d\n",m_etwnstate);
		return (TWRC_FAILURE);
	}

	// Clear out the pending transfers structure
	memset(&m_twpendingxfers,0,sizeof(m_twpendingxfers));

	// Send the command to the driver
	sts = Entry(
				DG_CONTROL,
				DAT_PENDINGXFERS,
				a_twuint16MSG,
				(TW_MEMREF)&m_twpendingxfers
			   );

	// Check the status of the command
	if (sts != TWRC_SUCCESS)
	{
		Log("Entry(DAT_PENDINGXFERS/%d) failed.\n",a_twuint16MSG);
	}

	// If there was no error, we'll set the state based on the result
	if (sts == TWRC_SUCCESS)
	{
		if (a_twuint16MSG == MSG_RESET)
		{
			// We should reset, sending us to state 5.
			m_etwnstate = TWN_STATE_5;
		}
		else if (a_twuint16MSG == MSG_ENDXFER)
		{
			if (m_twpendingxfers.Count == 0)
			{
				// if all of the transfers are finished goto state 5
				m_etwnstate = TWN_STATE_5;
			}
			else
			{
				// otherwise goto state 6 for more transfers
				m_etwnstate = TWN_STATE_6;
			}
		}
		else
		{
			// This message doesn't change state...
		}
	}

	return (sts);
}



///////////////////////////////////////////////////////////////////////
//	Description:
//		This function send the command to stop the ADF
//
//	Parameters:
//		a_twuint16MSG	-
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
///////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::StopFeeder
(
	void
)
{
	TW_UINT16	sts;

	sts = Entry(
				DG_CONTROL,
				DAT_PENDINGXFERS,
				MSG_STOPFEEDER,
				(TW_MEMREF)&m_twpendingxfers
			   );

	return (sts);
}



///////////////////////////////////////////////////////////////////////
//	Description:
//		This function registers the specified callback function with
//		the data source manager.
//
//	Parameters:
//		a_pfCallback	- Pointer to the Callback Function
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
///////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::SetCallback(
				TW_UINT16 (*a_pfCallback)(
										  pTW_IDENTITY	a_pOrigin,
										  pTW_IDENTITY 	a_pDest,
										  TW_UINT32		a_DG,
										  TW_UINT16		a_DAT,
										  TW_UINT16		a_MSG,
										  TW_MEMREF		a_pData
										 )
							   )
{
	TW_UINT16	sts;
	TW_CALLBACK	twcallback;

	// zero the callback structure
	memset(&twcallback, 0, sizeof(TW_CALLBACK));

	// set up the TW_CALLBACK structure
	twcallback.CallBackProc = (TW_MEMREF)a_pfCallback;

	// Now call the entry function to send the callback to the DSM
	sts = Entry(
				DG_CONTROL,
				DAT_CALLBACK,
				MSG_REGISTER_CALLBACK,
				(TW_MEMREF)&twcallback
			   );

	return (sts);
}



///////////////////////////////////////////////////////////////////////
//	Description:
//		This function makes the call to the DSM for
//		DG_CONTROL / DAT_ENTRYPOINT / MSG_GET to get the memory
//		allocation function pointers.
//
//	Parameters:
//		(none)
//
//	Returns:
//		TWRC_SUCCESS
//		TWRC_FAILURE
///////////////////////////////////////////////////////////////////////
TW_UINT16 CSTTwain::GetEntrypoint(void)
{
	TW_UINT16		sts;
	TW_ENTRYPOINT	twentrypoint;

	// zero the entry point structure
	memset(&twentrypoint, 0, sizeof(TW_ENTRYPOINT));
	twentrypoint.Size = sizeof(TW_ENTRYPOINT);

	// Now call the entry function
	sts = Entry(
				DG_CONTROL,
				DAT_ENTRYPOINT,
				MSG_GET,
				(TW_MEMREF)&twentrypoint
				);
	if (sts != TWRC_SUCCESS)
	{
		Log("DG_CONTROL/DAT_ENTRYPOINT/MSG_GET Failed: %d\n",sts);
		return (sts);
	}

	// Assign our member variables to the values we got from the DSM
	m_pfnDsmMemAlloc	= twentrypoint.DSM_MemAllocate;
	m_pfnDsmMemFree		= twentrypoint.DSM_MemFree;
	m_pfnDsmMemLock		= twentrypoint.DSM_MemLock;
	m_pfnDsmMemUnlock	= twentrypoint.DSM_MemUnlock;

	return (TWRC_SUCCESS);
}



///////////////////////////////////////////////////////////////////////
//	Description:
//		This function allocates the specified number of bytes and
//		returns a TW_HANDLE to that memory. This is used when
//		allocating memory for use by the TWAIN DSM. This routine makes
//		memory allocation easier as it will use the appropriate routine
//		for TWAIN 1.x and TWAIN 2.x data source managers.
//
//		NOTE: MEMORY ALLOCATION WITH THIS FUNCTION MUST BE FREEDED USING
//		CSTTWAIN::MEMFREE!
//
//	Parameters:
//		a_twuint32Size	- Number of bytes to allocate
//
//	Returns:
//		TW_HANDLE		- The allocated memory
///////////////////////////////////////////////////////////////////////
TW_HANDLE CSTTwain::MemAlloc(TW_UINT32 a_twuint32Size)
{
	if (m_blTWAIN2)
	{
		if (!m_pfnDsmMemAlloc)
		{
			Log("CSTTwain::MemAlloc - TWAIN 2.x DsmMemAlloc is NULL!\n");
			AbortOnCorruptMem();
			return ((TW_HANDLE)NULL);
		}
		return ((*m_pfnDsmMemAlloc)(a_twuint32Size));
	}
	else
	{
		#ifdef __APPLE__
			return ((TW_HANDLE)NewHandleClear(a_twuint32Size));
		#else
			void *pvMem = malloc(a_twuint32Size);
			if (pvMem)	{ memset(pvMem, 0, a_twuint32Size); }
			return ((TW_HANDLE)pvMem);
		#endif
	}
}



///////////////////////////////////////////////////////////////////////
//	Description:
//		This function frees a TW_HANDLE allocated with CSTTwain::MemAlloc
//
//	Parameters:
//		a_twhandle		- The handle to free
//
//	Returns:
//		(none)
///////////////////////////////////////////////////////////////////////
void CSTTwain::MemFree(TW_HANDLE a_twhandle)
{
	if (m_blTWAIN2)
	{
		if (!m_pfnDsmMemFree)
		{
			Log("CSTTwain::MemFree - TWAIN 2.x DsmMemFree is NULL!\n");
			AbortOnCorruptMem();
			return;
		}
		(*m_pfnDsmMemFree)(a_twhandle);
	}
	else
	{
		#ifdef __APPLE__
			DisposeHandle(a_twhandle);
		#else
			FREE(a_twhandle);
		#endif
	}
}



///////////////////////////////////////////////////////////////////////
//	Description:
//		This function locks a TW_HANDLE that was allocated with
//		CSTTwain::MemAlloc
//
//	Parameters:
//		a_twhandle		- The handle to lock
//
//	Returns:
//		TW_MEMREF
///////////////////////////////////////////////////////////////////////
TW_MEMREF CSTTwain::MemLock(TW_HANDLE a_twhandle)
{
	if (m_blTWAIN2)
	{
		if (!m_pfnDsmMemLock)
		{
			Log("CSTTwain::MemLock - TWAIN 2.x DsmMemLock is NULL!\n");
			AbortOnCorruptMem();
			return ((TW_MEMREF)NULL);
		}
		return ((*m_pfnDsmMemLock)(a_twhandle));
	}

	// This is a no-op for TWAIN 1.x DSMs (although it does dereference
	// on Mac OS/X
	#ifdef __APPLE__
		return ((TW_MEMREF)(*a_twhandle));
	#else
		return ((TW_MEMREF)a_twhandle);
	#endif
}



///////////////////////////////////////////////////////////////////////
//	Description:
//		This function unlocks TW_HANDLE that was locked with 
//		CSTTwain::MemLock
//
//	Parameters:
//		a_twhandle		- The handle to unlock
//
//	Returns:
//		(none)
///////////////////////////////////////////////////////////////////////
void CSTTwain::MemUnlock(TW_HANDLE a_twhandle)
{
	if (m_blTWAIN2)
	{
		if (!m_pfnDsmMemUnlock)
		{
			Log("CSTTwain::MemUnlock - TWAIN 2.x DsmMemUnlock is NULL\n");
			AbortOnCorruptMem();
			return;
		}
		(*m_pfnDsmMemUnlock)(a_twhandle);
	}

	// This is a no-op for TWAIN 1.x DSMs
	return;
}



///////////////////////////////////////////////////////////////////////
//	Description:
//		This function gets the size of a given TWAIN data type
//
//  Parameters:
//		TW_UINT16	a_twuint16ItemType
//
//	Returns:
//		The size of the specified item in bytes
///////////////////////////////////////////////////////////////////////
size_t CSTTwain::GetDatatypeSize(TW_UINT16 a_twuint16ItemType)
{
	size_t	sizet;

    switch (a_twuint16ItemType) 
	{
		default:
			Log("Unrecognized a_twuint16Type: %d\n",a_twuint16ItemType);
			sizet = sizeof(TW_INT16);
			break;    
		case TWTY_BOOL:		sizet = sizeof(TW_BOOL);	break;
        case TWTY_INT8:		sizet = sizeof(TW_INT8);	break;
        case TWTY_UINT8:	sizet = sizeof(TW_UINT8);	break;
        case TWTY_INT16:	sizet = sizeof(TW_INT16);	break;
		case TWTY_UINT16:	sizet = sizeof(TW_UINT16);	break;
        case TWTY_INT32:	sizet = sizeof(TW_INT32);	break;
        case TWTY_UINT32:	sizet = sizeof(TW_UINT32);	break;
        case TWTY_FIX32:	sizet = sizeof(TW_FIX32);	break;
        case TWTY_FRAME:	sizet = sizeof(TW_FRAME);	break;
        case TWTY_STR32:	sizet = sizeof(TW_STR32);	break;
		case TWTY_STR64:	sizet = sizeof(TW_STR64);	break;
		case TWTY_STR128:	sizet = sizeof(TW_STR128);	break;
		case TWTY_STR255:	sizet = sizeof(TW_STR255);	break;
		case TWTY_STR1024:	sizet = sizeof(TW_STR1024);	break;
		case TWTY_UNI512:	sizet = sizeof(TW_UNI512);	break;
    }

    return (sizet);
}



///////////////////////////////////////////////////////////////////////
//	Description:
//		This function is used to log a message
//
//  Parameters:
//		a_cszFormat - The format string (printf style)
//		Variable Arguments
//
//	Returns:
//		(none)
///////////////////////////////////////////////////////////////////////
void CSTTwain::Log(const char *a_cszFormat, ... )
{
	va_list	valistParams;

	// We just use vfprintf to log the message for now
	va_start(valistParams, a_cszFormat);
	vfprintf(stderr, a_cszFormat, valistParams);
	va_end(valistParams);

	return;
}



///////////////////////////////////////////////////////////////////////
//	Description:
//		This function provides one place for the user to change the
//		behavior of CSTTWain when memory corruption is detected. This
//		is specific to when the DsmMemAlloc/Lock/Unlock/Free pointers
//		get set to NULL when talking to a TWAIN 2.x DSM
//
//  Parameters:
//		a_cszFormat - The format string (printf style)
//		Variable Arguments
//
//	Returns:
//		(none)
///////////////////////////////////////////////////////////////////////
void CSTTwain::AbortOnCorruptMem(void)
{
	Log("Memory Corruption Detected!!\n\n");
	Log("  A VERY serious error has occurred. The application has detected\n");
	Log("  that some of its memory has become corrupted. The application has\n");
	Log("  been closed to prevent further problems and unexpected behavior.\n");

	// NOTE: If you do not wish to abort on this error, comment out the 
	// following line. However, you should be aware that if this error does
	// occurr that something very serious is wrong and your application
	// should be throughly checked for programming errors!
	abort();

	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Get the current condition code and fills in a string with error
//		information.
//
//	Parameters:
//		a_szMessage		- Pointer to a string to fill in
//		a_sizetLen		- Length of the string, a_szMessage in bytes
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTTwain::GetErrorString(char *a_szMessage, size_t a_sizetLen)
{
	TW_STATUS	twstatus;
	TW_UINT16	twuint16Sts;

	// zero out the string (this will make sure it's null terminated)
	memset(a_szMessage,0,a_sizetLen);

	// Get the condition code
	twuint16Sts = Entry(DG_CONTROL, DAT_STATUS, MSG_GET, (TW_MEMREF)&twstatus);
	if (twuint16Sts != TWRC_SUCCESS)
	{
		strncpy(a_szMessage,"Unknown (No Condition Code)", a_sizetLen -1);
		return;
	}

	// Set the message based on the condition code
	switch (twstatus.ConditionCode)
	{
		default:
		case TWCC_BUMMER:
			strncpy(a_szMessage,"Undefined Error", a_sizetLen -1);
			break;

		case TWCC_SUCCESS:
			// Don't return a message on success, it results in weird error
			// messages when a function fails for a reason not related to the
			// the driver (e.g. wrong state)
			break;

		case TWCC_LOWMEMORY:
			strncpy(a_szMessage,"Not enough memory to perform operation", a_sizetLen -1);
			break;

		case TWCC_NODS:
			strncpy(a_szMessage,"No Datasource", a_sizetLen -1);
			break;

		case TWCC_MAXCONNECTIONS:
			strncpy(a_szMessage,"DS is connected to max possible applications", a_sizetLen -1);
			break;

		case TWCC_OPERATIONERROR:
			strncpy(a_szMessage,"Operation Error", a_sizetLen -1);
			break;

		case TWCC_BADCAP:
			strncpy(a_szMessage,"Unknown Capability", a_sizetLen -1);
			break;

		case TWCC_BADPROTOCOL:
			strncpy(a_szMessage,"Unrecognized MSG DG DAT combination", a_sizetLen -1);
			break;

		case TWCC_BADVALUE:
			strncpy(a_szMessage,"Data parameter out of range", a_sizetLen -1);
			break;

		case TWCC_SEQERROR:
			strncpy(a_szMessage,"DG DAT MSG out of expected sequence", a_sizetLen -1);
			break;

		case TWCC_BADDEST:
			strncpy(a_szMessage,"Unknown destination application/source in DSM_Entry", a_sizetLen -1);
			break;

		case TWCC_CAPUNSUPPORTED:
			strncpy(a_szMessage,"Capability not supported by source", a_sizetLen -1);
			break;

		case TWCC_CAPBADOPERATION:
			strncpy(a_szMessage,"Operation not supported by capability", a_sizetLen -1);
			break;

		case TWCC_CAPSEQERROR:
			strncpy(a_szMessage,"Capability has dependance on another capability", a_sizetLen -1);
			break;

		case TWCC_DENIED:
			strncpy(a_szMessage,"File system operation is denied (file is protected)", a_sizetLen -1);
			break;

		case TWCC_FILEEXISTS:
			strncpy(a_szMessage,"Operation failed because the file already exists", a_sizetLen -1);
			break;

		case TWCC_FILENOTFOUND:
			strncpy(a_szMessage,"File not found", a_sizetLen -1);
			break;

		case TWCC_NOTEMPTY:
			strncpy(a_szMessage,"Operation failed because the directory is not empty", a_sizetLen -1);
			break;

		case TWCC_PAPERJAM:
			strncpy(a_szMessage,"The feeder is jammed", a_sizetLen -1);
			break;

		case TWCC_PAPERDOUBLEFEED:
			strncpy(a_szMessage,"The feeder detected multiple pages", a_sizetLen -1);
			break;

		case TWCC_FILEWRITEERROR:
			strncpy(a_szMessage,"Error writing the file (disk full)", a_sizetLen -1);
			break;

		case TWCC_CHECKDEVICEONLINE:
			strncpy(a_szMessage,"Device is offline", a_sizetLen -1);
			break;

		case TWCC_INTERLOCK:
			strncpy(a_szMessage,"Interlock failedure", a_sizetLen -1);
			break;

		case TWCC_DAMAGEDCORNER:
			strncpy(a_szMessage,"The paper has a damaged corner", a_sizetLen -1);
			break;

		case TWCC_FOCUSERROR:
			strncpy(a_szMessage,"Focus error", a_sizetLen -1);
			break;

		case TWCC_DOCTOOLIGHT:
			strncpy(a_szMessage,"Document is too light", a_sizetLen -1);
			break;

		case TWCC_DOCTOODARK:
			strncpy(a_szMessage,"Document is too dark", a_sizetLen -1);
			break;

	} // end switch (st.ConditionCode)

	return;
}



////////////////////////////////////////////////////////////////////////
// Description:
//		If we're running on Mac OS/X this will convert the strings in a
//		TW_IDENITY structure from PASCAL to C format or vice-versa.
//
//	Parameters:
//		a_rtwidentity	- The TW_IDENTITY structure to convert
//		a_blToPascal	- True to convert strings to PASCAL format
//						  False to convert string to C format
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTTwain::ConvertTwIdentity(TW_IDENTITY &a_rtwidentity, bool a_blToPascal)
{

	if (a_blToPascal)
	{
		CStringToPascalString((char*)a_rtwidentity.Manufacturer);
		CStringToPascalString((char*)a_rtwidentity.ProductFamily);
		CStringToPascalString((char*)a_rtwidentity.ProductName);
		CStringToPascalString((char*)a_rtwidentity.Version.Info);
	}
	else
	{
		PascalStringToCString((char*)a_rtwidentity.Manufacturer);
		PascalStringToCString((char*)a_rtwidentity.ProductFamily);
		PascalStringToCString((char*)a_rtwidentity.ProductName);
		PascalStringToCString((char*)a_rtwidentity.Version.Info);
	}
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Converts a PASCAL string (with a prefix representing the size) to
//		a C-Style NULL terminated string.
//
//	Parameters:
//		a_szString	- The PASCAL string to convert
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTTwain::PascalStringToCString(char* a_szString)
{
	#ifdef __APPLE__

		unsigned char ucSize = (0xff & a_szString[0]);
		memmove(a_szString, &a_szString[1], ucSize);
		a_szString[ucSize] = '\0';

	#else

		a_szString = a_szString;

	#endif
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Converts a C-Style string (NULL terminated) to a PASCAL string
//		(with a prefix representing the size).
//
//	Parameters:
//		a_szString	- The PASCAL string to convert
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTTwain::CStringToPascalString(char* a_szString)
{
	#ifdef __APPLE__

		size_t sizet = strlen(a_szString);
		memmove(&a_szString[1], a_szString, sizet);
		a_szString[0] = sizet;

	#else

		a_szString = a_szString;

	#endif
}
