////////////////////////////////////////////////////////////////////////////////
//	File:
//		$Archive: /main/deliverables/scantwain/cstselectscannerdialog.h $
//
//	Description:
/**
//		This file defines CSTSelectScannerDialog, a dialog for displaying
//		available TWAIN datasources and allowing the user to select one.
**/
//	History:
//		$Log: /main/deliverables/scantwain/cstselectscannerdialog.h $
//		
//		1     11/02/05 3:41p V737585
//		Initial Revision
//
// Copyright (c) 2005 Eastman Kodak Company
//
// This file is part of ScanTWAIN
//
// ScanTWAIN is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// ScanTWAIN is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY;  without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along
// with ScanTWAIN; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
//	$NoKeywords: $
////////////////////////////////////////////////////////////////////////////////
#ifndef SELECTSCANNERDIALOG_H
#define SELECTSCANNERDIALOG_H

////////////////////////////////////////////////////////////////////////////////
//									INCLUDE FILES
////////////////////////////////////////////////////////////////////////////////
#include <qvariant.h>
#include <qdialog.h>
#include <qlayout.h>
#include <qlabel.h>
#include <qlistbox.h>
#include <qpushbutton.h>

////////////////////////////////////////////////////////////////////////////////
//						DEFINES, TYPEDEFS, CONSTS & ENUMS
////////////////////////////////////////////////////////////////////////////////



class CSTSelectScannerDialog : public QDialog
{
    Q_OBJECT

	public:
	
		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Constructor: Initializes the classes member variables
		//
		//	Parameters:
		//		parent	- This widget's parent widget
		//		name	- The widget's name (for debugging)
		//		modal	- Whether or not the dialog is shown modally
		//		f1		- Widget style flags
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		CSTSelectScannerDialog( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Destructor: Destroy's the dialog
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		~CSTSelectScannerDialog();
		
		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Clears the list box
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void	ClearList();

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Returns the item selected in the list box
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		uint	- The currently selected item
		////////////////////////////////////////////////////////////////////////
		uint	GetSelectedItem();
		
		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Adds a string to the list box
		//
		//	Parameters:
		//		item	- The string to add
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void 	AddToList( QString item );

	
	protected slots:
		
		virtual void languageChange(void);


	private:
		
		QLabel*			m_lblSelect;
		QListBox*		m_lbScannerList;
		QPushButton*	m_btnOK;
		QPushButton* 	m_btnCancel;

		QHBoxLayout* 	m_DialogLayout;
		QVBoxLayout* 	m_ControlLayout;
		QVBoxLayout* 	m_ButtonLayout;
		QSpacerItem* 	m_Spacer1;

};

#endif // SELECTSCANNERDIALOG_H
