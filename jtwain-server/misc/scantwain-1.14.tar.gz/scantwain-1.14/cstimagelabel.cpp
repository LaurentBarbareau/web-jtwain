////////////////////////////////////////////////////////////////////////////////
//	File:
//		$Archive: /main/deliverables/scantwain/cstimagelabel.cpp $
//
//	Description:
//		This file contains the implementation of ScanTWAIN's image label. It
//		handles the display of images in ScanTWAIN (painting and resizing).
//
//	History:
//		$Log: /main/deliverables/scantwain/cstimagelabel.cpp $
//		
//		6     4/16/09 9:48a V737585
//		PR 12746: ScanTWAIN was attempting to rescale the image everytime it
//		repainted, when it didn't have to. This could leave to a crash when
//		closing the GUI after having scanned. Now, ScanTWAIN won't rescale when
//		repainting unless absolutely necessary.
//		
//		5     11/27/07 3:34p V737585
//		Minor fixes for TWAIN 2.0 Compliance
//		
//		4     1/23/06 5:25p V737585
//		Optimized to reduce memory usage.
//		
//		1     11/02/05 3:41p V737585
//		Initial Revision
//
// Copyright (c) 2005-2006 Eastman Kodak Company
//
// This file is part of ScanTWAIN
//
// ScanTWAIN is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// ScanTWAIN is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY;  without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along
// with ScanTWAIN; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
//	$NoKeywords: $
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
//									INCLUDE FILES
////////////////////////////////////////////////////////////////////////////////
//#include "sttypes.h"
#include "cstimagelabel.h"



////////////////////////////////////////////////////////////////////////
// Description:
//		Constructor: Initializes the classes member variables
//
//	Parameters:
//		parent	- This widget's parent widget
//		name	- The widget's name (for debugging)
//		f		- Widget Flags
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
CSTImageLabel::CSTImageLabel(QWidget* parent, const char* name, WFlags f) :
		QLabel(parent, name, f)
{
	setAlignment(Qt::AlignCenter);
	setPaletteBackgroundColor(Qt::white);
	m_bPainted = false;

}



////////////////////////////////////////////////////////////////////////
// Description:
//		Destructor: Destroy's the dialog
//
//	Parameters:
//		None
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
CSTImageLabel::~CSTImageLabel()
{
	// There's nothing to destroy that won't be done automatically
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Sets the image that the label will display.
//
//	Parameters:
//		a_imImage		- The image to display
//		a_uiReduceResBy	- Factor to reduce the resolution by
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTImageLabel::setImage(const QImage& a_imImage, uint a_uiReduceResBy)
{
	// QImage's scale function will return a copy of the QImage by using this
	// function we'll effective reduce the resolution and copy the image at the
	// same time.
	m_imImage = a_imImage.scale(
								 a_imImage.width() / a_uiReduceResBy,
								 a_imImage.height() / a_uiReduceResBy,
								 QImage::ScaleMin
							   );

	// this image has not yet been painted, our painted member must show this
	m_bPainted = false;
}


////////////////////////////////////////////////////////////////////////
// Description:
//		Responds to the label being resized
//
//	Parameters:
//		a_evResize	- Passed in from QT containing old and new sizes
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTImageLabel::resizeEvent(QResizeEvent* a_evResize)
{
	// This handler is called after the object has been resized, for
	// optimization of the paint event we want to record the old size of the
	// label, we do that here.
	m_siOldSize = a_evResize->oldSize();
}



////////////////////////////////////////////////////////////////////////
// Description:
//		Paints the image on the label
//
//	Parameters:
//		a_evPaint	- Passed in from QT, contains event related data
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
void CSTImageLabel::paintEvent(QPaintEvent*	a_evPaint)
{
	QImage		imTemp;

	//UNUSED_ARG(a_evPaint); // No sttypes.h because of twain.h, so no UNUSED_ARG
	a_evPaint = a_evPaint;
	
	// This paint event will get called whenever the label needs to be updated.
	// Since update() calls are optimized by QT it is most efficient to manage
	// the resizing of the image in the paint event.

	// Since this label is just an image it is simple to repaint it, all we
	// need to do is create the pixmap from the image we already have and
	// bitBlt it onto the label.

	// Of course we'll only do this is we have a valid image to display
	if(!m_imImage.isNull())
	{
		// There are several reason this paint event might be called. However,
		// unless the label has been resized we don't want to rescale the image
		// Also, if this image has never been painted then we need to scale it
		if( (m_siOldSize != size()) || !m_bPainted)
		{
			// The size has changed, so we need to rescale the image.
			m_pmBuffer = m_imImage.scale(width(),height(),QImage::ScaleMin);

            // Set the old size to the one we have now and record that this
            // image has been painted, so we don't scale more than necessary
			m_siOldSize = size();
			m_bPainted = true;
		} // end if(m_siOldSize != size())

		// Based on the size of the image (and the pixmap, we'll center the
		// image on the label.
		int iXCentered = (width() - m_pmBuffer.width()) / 2;
		int iYCentered = (height() - m_pmBuffer.height()) / 2;

		// now bitBlt the pixmap onto the label
		bitBlt(this, iXCentered, iYCentered, &m_pmBuffer, 0, 0, m_pmBuffer.width(), m_pmBuffer.height());

	} // end if(!m_imImage.isNull())
}
