////////////////////////////////////////////////////////////////////////////////
//	File:
//		$Archive: /main/deliverables/scantwain/cstimgxferevent.h $
//
//	Description:
/**
//		This file contains the definition of CSTImgXferEvent, which inherits
//		QCustomEvent
 **/
//	History:
//		$Log: /main/deliverables/scantwain/cstimgxferevent.h $
//		
//		3     11/27/07 11:02a V737585
//		Added code to make ScanTWAIN, TWAIN 2.0 compliant
//		
//		2     4/10/07 4:23p V737585
//		Updated to use twain2.h instead of the older twain.h
//		
//		1     1/23/06 5:24p V737585
//		Initial Revision
//		
//
// Copyright (c) 2006 Eastman Kodak Company
//
// This file is part of ScanTWAIN
//
// ScanTWAIN is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// ScanTWAIN is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY;  without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along
// with ScanTWAIN; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
//	$NoKeywords: $
////////////////////////////////////////////////////////////////////////////////
#ifndef CSTIMGXFEREVENT_H
#define CSTIMGXFEREVENT_H

////////////////////////////////////////////////////////////////////////////////
//									INCLUDE FILES
////////////////////////////////////////////////////////////////////////////////
#include <qevent.h>
#include "twain.h"

////////////////////////////////////////////////////////////////////////////////
//						DEFINES, TYPEDEFS, CONSTS & ENUMS
////////////////////////////////////////////////////////////////////////////////


class CSTImgXferEvent : public QCustomEvent
{

	public:

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Constructor: Initializes the classes member variables
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		CSTImgXferEvent();

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Destructor: Destroy's the window (frees memory allocated in
		//		the constructor.
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		~CSTImgXferEvent();

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Copies the image data into the event.
		//
		//	Parameters:
		//		a_pbImage		- Pointer to the image data (gets copied)
		//		a_ulImageBytes	- The size of the image in bytes
		//		a_twimageinfo	- The associated TWAIN image info
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		bool	CopyData(unsigned char* a_pbImage,
						 unsigned long	a_ulImageBytes,
						 TW_IMAGEINFO	a_twimageinfo);

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Returns a pointer to the image data.
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		unsigned char*	Image(void);

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Returns the image size in bytes.
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		unsigned long	ImageSizeInBytes(void);

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Returns the TWAIN image info structure associated with this
		//		image.
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		TW_IMAGEINFO	ImageInfo(void);

	private:
		TW_IMAGEINFO	m_twimageinfo;		// The TWAIN Image Info
		unsigned char*	m_pbImage;			// Image data (allocated in ctor)
		unsigned long	m_ulImageBytes;		// Size of Image in bytes
};

#endif // end #ifndef CSTIMGXFEREVENT_H
