////////////////////////////////////////////////////////////////////////////////
//	File:
//		$Archive: /main/deliverables/scantwain/cstmainwindow.h $
//
//	Description:
/**
//		This file contains the definition of CSTMainWindow. This class provides
//		ScanTWAIN's main interface as well as it's image processing and saving
//		functionality.
**/
//	History:
//		$Log: /main/deliverables/scantwain/cstmainwindow.h $
//		
//		11    4/16/09 9:58a V737585
//		Redesigned the file format dialog and some of the underlying structures
//		to work better with the new file format scheme. Also fixed a couple of
//		warnings compiling on Debian x64 systems.
//		
//		10    4/08/09 2:18p V737585
//		PR12757: Added a dialog to allow the user to let ScanTWAIN choose the
//		file type automatically or allow the user to select the file type based
//		on the pixel type. This allows dual-stream scanning, auto color detect
//		and toggle patch to be used while still making it easy for the user and
//		giving them the same flexibility as before if they want it.
//		
//		9     2/19/09 10:28a V737585
//		Added code to get the country and language from QT and convert it into
//		the appropriate TWAIN code to send to the driver.
//		
//		8     5/29/08 10:39a V737585
//		Only verify the file format when starting a scan job and always allow
//		the user to select JPEG quality, even if it might get overriden by the
//		driver.
//		
//		7     5/28/08 3:31p V737585
//		Added support for the TWAIN GUI. ScanTWAIN will now try to use the
//		driver's UI before using it's own. Additionally, support for
//		transferring Group IV and JPEG compressed images has been added.
//		Additionally, the ScanSettings dialog (aka the default driver UI) has
//		been updated to add support for setting the compression.
//		
//		6     3/26/08 1:04p V737585
//		PR 11740, 11749, 11750: THIS IS A MAJOR REVISION!! We now maintain an
//		image buffer of 10 images, we will not continue to transfer images from
//		the driver while that buffer is full. Additionally, a save thread has
//		been added to save the images in a separate thread. Several new custom
//		events have been added to assist in coordinating this. Finally, the
//		display resolution of the images has been reduced to between 75-150 dpi
//		to make the display faster. NOTE: ScanTWAIN now uses considerably more
//		memory and we may have to consider moving to memory mapped files if
//		this becomes a problem on low memory systems.
//		
//		5     1/24/08 4:45p V737585
//		PR 11601 "Select Scanner" should not have been reenabled after
//		scanning. ScanTWAIN will now close any open ds before trying to open
//		another.
//		
//		4     1/24/06 10:35a V737585
//		Fixed memory leaks, added support for saving the image resolution in
//		the image file (using libjpeg, libtiff & libpng instead of QTs image
//		saving mechanism), fixed file format selection being saved after Cancel
//		is clicked. This work fixes PRs 7382, 7459, 7487 & 7486
//		
//		1     11/02/05 3:41p V737585
//		Initial Revision
//
// Copyright (c) 2005-2006 Eastman Kodak Company
//
// This file is part of ScanTWAIN
//
// ScanTWAIN is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// ScanTWAIN is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY;  without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along
// with ScanTWAIN; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
//	$NoKeywords: $
////////////////////////////////////////////////////////////////////////////////
#ifndef MAINWINDOW_H
#define MAINWINDOW_H


////////////////////////////////////////////////////////////////////////////////
//									INCLUDE FILES
////////////////////////////////////////////////////////////////////////////////
#include <qvariant.h>
#include <qmainwindow.h>
#include <qlayout.h>
#include <qaction.h>
#include <qtoolbar.h>
#include <qpopupmenu.h>
#include <qstring.h>
#include <qlabel.h>
#include "csttwain.h"
#include "sttypes.h"
#include "cstscanthread.h"
#include "cstsavethread.h"
#include "cstimagelabel.h"

////////////////////////////////////////////////////////////////////////////////
//						DEFINES, TYPEDEFS, CONSTS & ENUMS
////////////////////////////////////////////////////////////////////////////////
#define UIMINWIDTH 550
#define UIMINHEIGHT 110


class CSTMainWindow : public QMainWindow
{
    Q_OBJECT

	public:
		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Constructor: Initializes the classes member variables
		//
		//	Parameters:
		//		parent	- This widget's parent widget
		//		name	- The widget's name (for debugging)
		//		f1		- Widget style flags
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		CSTMainWindow(
					   QWidget* parent = 0,
					   const char* name = 0,
					   WFlags fl = WType_TopLevel
					 );

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Destructor: Destroy's the window
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		~CSTMainWindow();

	public slots:
		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Sets the visibility of the tool bar
		//
		//	Parameters:
		//		toggle	- T/F (Visible / Invisible)
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void ToogleToolbar( bool toggle );
		
		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Sets the visibility of the status bar
		//
		//	Parameters:
		//		toogle	- T/F (Visible / Invisible)
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void ToogleStatusbar( bool toggle );

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Opens the file format settings dialog so the user can select
		//		the file format to save images in
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void FileFormat();

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Exits the application
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void ExitApp();

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Opens the Scan Settings Dialog
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void OpenScanSettingsDialog();

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Opens the Select Scanner Dialog
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void OpenSelectScannerDialog();

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Updates the UI State (Controls what actions are enabled)
		//
		//	Parameters:
		//		a_iUIState	- The state to set the UI to
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void UpdateUI( int a_iUIState );

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Starts Scanning
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void StartScanning( void );

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Stops scanning (stops the feeder)
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void StopScanning( void );

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Hides the images
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void ViewNone( void );

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Shows Images in 2-Up Mode
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void View2Up( void );

		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Opens the dialog to allow the user to select a base filename
		//
		//	Parameters:
		//		None
		//
		//	Returns:
		//		None
		////////////////////////////////////////////////////////////////////////
		void ChooseFilename( void );


		////////////////////////////////////////////////////////////////////////
		// Description:
		//		Use QLocale to determine the system language and country and
		//		set the twain language and twain country accordingly.
		//
		//	Parameters:
		//		a_uiTwainCountry	- TWAIN country TWCY_*
		//		a_uiTwainLanguage	- TWAIN language TWLG_*
		//
		//	Returns:
		//		none
		////////////////////////////////////////////////////////////////////////
		void GetTwainCountry(TW_UINT16 *a_uiTwainCountry, TW_UINT16 *a_uiTwainLanguage);

		
	protected slots:
		void languageChange();

	private:
		
		void ShowImage(unsigned char*	a_pbImage,
					   unsigned long	a_ulBytes,
					   TW_IMAGEINFO		a_twimageinfo);
		void customEvent( QCustomEvent * a_evCustom );
		bool VerifyFileFormat(void);
		bool VerifyFileFormatByCompression(int a_iFileFormat, int a_iCompression);
		
		// Variables to Help Control UI Behavior
		bool				 m_bFileFormatCancel;	// Was the format change cancelled
		bool				 m_bShowImages;			// Are images being displayed
		bool				 m_bSaveImages;			// Are images being saved
		bool				 m_bFilenameChoosen;	// Was a filename choosen
		int					 m_iImageCount;			// Number of images scanned
		int					 m_iCurrentImage;		// The image pane to display in
		int					 m_iCompressionQuality;	// JPEG,PNG Compression Quality
		QString				 m_strCurrentScanner;	// ProductName of selected scanner
		QString				 m_strCurrentFilename;	// Base filename for images
		QSize				 m_siOriginalSize;		// Window size before hiding images
		bool				 m_bDSOpened;			// Do we have a DS Open?
		STFileFormatSettings m_stfileformatsettings;// File format settings


		// Variables for managing & controlling the scanner
		TW_IDENTITY		m_twidentity;			// TWAIN scanner identity
		CSTTwain		m_sttwainCtrl;			// TWAIN control class
		CSTScanThread	m_scanthread;			// Thread to scan images
		CSTSaveThread	m_savethread;			// Thread to save images
		

		// UI Elements
		QMenuBar*		m_menuBar;				// Menu Bar
		QPopupMenu*		m_menuFile;				// File Menu
		QPopupMenu*		m_menuScan;				// Scan Menu
		QPopupMenu*		m_menuView;				// View Menu
		QToolBar*		m_toolBar;				// Tool Bar
		QLabel*			m_lblFilename;			// Filename Status Bar Label
		QLabel*			m_lblSelectedScanner;	// Scanner Status Bar Label
		QLabel*			m_lblBlank;				// Blank Label to hold hints (cosmetic)
		QHBoxLayout*	m_qhblLayout;			// Image View Layout
		CSTImageLabel*	m_ilblImage1;			// Displays the 1st image
		CSTImageLabel*	m_ilblImage2;			// Displays the 2nd image
		
		// ACTIONS - UI Control (Menu Items & Tool Bar Buttons)
		QAction*		m_actExit;				// Exits Application
		QAction*		m_actChooseFilename;	// Chooses a base filename
		QAction*		m_actSelectScanner;		// Select a scanner
		QAction*		m_actScanSetup;			// Adjust scanner settings
		QAction*		m_actScan;				// Start Scanning
		QAction*		m_actScanStop;			// Stops Scanning
		QActionGroup*	m_actgViewImages;		// Related ViewNone & View2Up
		QAction*		m_actViewNone;			// Do not display images
		QAction*		m_actView2Up;			// Display images in 2up mode
		QAction*		m_actViewToolbar;		// Toggles tool bar visibility
		QAction*		m_actViewStatusbar;		// Toggles status bar visibility
		QAction*		m_actFileFormat;

};

#endif // MAINWINDOW_H
