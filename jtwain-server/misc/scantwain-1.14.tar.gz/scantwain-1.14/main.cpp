////////////////////////////////////////////////////////////////////////////////
//	File:
//		$Archive: /main/deliverables/scantwain/main.cpp $
//
//	Description:
//		This file contains the main function of ScanTWAIN.
//
//	History:
//		$Log: /main/deliverables/scantwain/main.cpp $
//		
//		4     5/28/08 3:31p V737585
//		Added support for the TWAIN GUI. ScanTWAIN will now try to use the
//		driver's UI before using it's own. Additionally, support for
//		transferring Group IV and JPEG compressed images has been added.
//		Additionally, the ScanSettings dialog (aka the default driver UI) has
//		been updated to add support for setting the compression.
//		
//		1     11/02/05 3:54p V737585
//		Initial Revision
//
// Copyright (c) 2005 Eastman Kodak Company
//
// This file is part of ScanTWAIN
//
// ScanTWAIN is free software; you can redistribute it and/or modify it under
// the terms of the GNU General Public License as published by the Free Software
// Foundation; either version 2 of the License, or (at your option) any later
// version.
//
// ScanTWAIN is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY;  without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
// more details.
//
// You should have received a copy of the GNU General Public License along
// with ScanTWAIN; if not, write to the Free Software Foundation, Inc.,
// 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
//	$NoKeywords: $
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
//									INCLUDE FILES
////////////////////////////////////////////////////////////////////////////////
#include <qapplication.h>
#include "sttypes.h"
#include "cstmainwindow.h"

////////////////////////////////////////////////////////////////////////////////
//															GLOBAL VARIABLES  //
////////////////////////////////////////////////////////////////////////////////
static CSTMainWindow*	g_pMainWindow;



////////////////////////////////////////////////////////////////////////
// Description:
//		This if the main function, the entry point for the application
//
//	Parameters:
//		argc	- Number of Arguments
//		argv	- Arguments
//
//	Returns:
//		Exit status
////////////////////////////////////////////////////////////////////////
int main( int argc, char ** argv )
{
	QApplication	a( argc, argv );
    CSTMainWindow	w;

	// Once the Main Window is created we'll need to assign it to the global
	// variable so that our callback can use it when it needs to
	g_pMainWindow = &w;

	// Show the window
    w.show();

	// Connect the lastWindowClosed signal to the quit slot to terminate
    a.connect( &a, SIGNAL( lastWindowClosed() ), &a, SLOT( quit() ) );

	// run the application
	return a.exec();
}

////////////////////////////////////////////////////////////////////////
// Description:
//		This function is passed to the TWAIN DSM to handle callbacks. It
//		responds to the TWAIN MSG by sending events to ScanTWAIN's main
//		window, via postEvent. This function is defined in main.cpp.
//
//	Parameters:
//		a_pOrigin	- The origin of the callback (data source)
//		a_pDest		- The destination of the callback (application)
//		a_DG		- The TWAIN data group
//		a_DAT		- The TWAIN capability
//		a_MSG		- The TWAIN message
//		a_pData		- The
//
//	Returns:
//		None
////////////////////////////////////////////////////////////////////////
TW_UINT16 TWAINCallback(
						pTW_IDENTITY a_pOrigin,
						pTW_IDENTITY a_pDest,
						TW_UINT32	a_DG,
						TW_UINT16	a_DAT,
						TW_UINT16	a_MSG,
						TW_MEMREF	a_pData
					   )
{
	QCustomEvent*	pevCustom;
	
	UNUSED_ARG(a_pOrigin);
	UNUSED_ARG(a_pDest);
	UNUSED_ARG(a_DG);
	UNUSED_ARG(a_DAT);
	UNUSED_ARG(a_pData);

	// This is a simple call back all we're going to do is check the
	// MSG parameter to find out why we got called and send out the
	// appropriate event
	switch(a_MSG)
	{
		default:
			// unhandled, do nothing
			qDebug("Unhandled TWAIN Callback Message.");
			break;

		case MSG_XFERREADY:
			// Image(s) is/are ready to be transferred, signal the
			// application to start transferring
			pevCustom = new QCustomEvent(STSTARTXFER);
			QApplication::sendEvent(g_pMainWindow, pevCustom);

			break;

		case MSG_CLOSEDSOK:
		case MSG_CLOSEDSREQ:
			// We're being told to close down the UI, send an event to the main
			// window to send a DISABLEDS
			pevCustom = new QCustomEvent(STDISABLEDS);
			QApplication::sendEvent(g_pMainWindow, pevCustom);

			break;

		// TODO: Add Device Event (MSG_DEVICEEVENT) Here
	}

	return TWRC_SUCCESS;
}
