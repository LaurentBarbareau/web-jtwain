
#include <jni.h>                      

jboolean checkStatus(
  JNIEnv* env,
  jboolean* hasException,
  jint status
);

