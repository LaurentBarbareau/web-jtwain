package uk.co.mmscomputing.device.capi.man;

public interface ManufacturerConstants{

  static public final int CAPI_MANUID_AVM      = 0x214D5641;  // "AVM!"
  static public final int CAPI_MANUID_EICON    = 0x44444944;  // "DIDD"

}

