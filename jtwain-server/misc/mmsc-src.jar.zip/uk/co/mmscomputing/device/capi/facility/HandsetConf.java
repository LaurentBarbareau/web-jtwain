package uk.co.mmscomputing.device.capi.facility;

import uk.co.mmscomputing.device.capi.*;

public class HandsetConf extends FacilityConf{
  public HandsetConf(Rider r){
    super(r);
  }
}

