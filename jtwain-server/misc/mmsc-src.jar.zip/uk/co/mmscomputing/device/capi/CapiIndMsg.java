package uk.co.mmscomputing.device.capi;

public class CapiIndMsg extends MsgIn{
  public CapiIndMsg(Rider r){super(r);}
}

