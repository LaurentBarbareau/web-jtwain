package uk.co.mmscomputing.device.capi.facility;

import uk.co.mmscomputing.device.capi.*;

public class PwrMgmtInd extends FacilityInd{
  public PwrMgmtInd(Rider r){
    super(r);
  }
}

