package uk.co.mmscomputing.device.twain;

public class TwainException extends TwainIOException{
  public TwainException(String msg){
    super(msg);
  }
}