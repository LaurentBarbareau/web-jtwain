package uk.co.mmscomputing.device.phone;

public interface PhoneBook{
  public String getName(String remote);
  public String getNumber(String name);
}